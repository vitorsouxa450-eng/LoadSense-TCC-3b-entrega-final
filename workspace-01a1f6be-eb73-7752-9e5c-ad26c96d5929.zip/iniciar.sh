#!/usr/bin/env bash
# LoadSense — sobe API, app e site de uma vez (modo com login).
#
#   ./iniciar.sh
#
# Pré-requisito: MySQL 8.0 com o banco "loadsense" carregado (veja COMO_ABRIR_O_PROJETO.md)
# e dependências instaladas (npm install em api/, app/ e site/).
set -e
RAIZ="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$RAIZ/logs"

echo "▸ API        http://localhost:5174"
(cd "$RAIZ/api" && LS_EXIBIR_CODIGO=1 nohup node server/index.js > "$RAIZ/logs/api.log" 2>&1 &)
sleep 2
echo "▸ App        http://localhost:5173"
(cd "$RAIZ/app" && nohup npx vite --host 0.0.0.0 --port 5173 --strictPort > "$RAIZ/logs/app.log" 2>&1 &)
echo "▸ Site       http://localhost:5175"
(cd "$RAIZ/site" && nohup npx vite --host 0.0.0.0 --port 5175 --strictPort > "$RAIZ/logs/site.log" 2>&1 &)
sleep 3
echo ""
echo "Logs em $RAIZ/logs/ · para parar: feche o terminal ou finalize os processos node."
echo "Login de demonstração: admin@loadsense.local / LoadSense@2026"
