export type Funcao = {
  id: string;
  nome: string;
  paraQueServe: string;
  comoUsar: string[];
  onde: string;
};

export type PassoGuia = { titulo: string; texto: string };

export const PLATAFORMAS_AJUDA = ["app", "site"] as const;
export type PlataformaAjuda = (typeof PLATAFORMAS_AJUDA)[number];

export function chaveGuia(plataforma: PlataformaAjuda): string {
  return `loadsense.guia.v1.${plataforma}`;
}

export const PASSOS_GUIA_APP: PassoGuia[] = [
  {
    titulo: "Bem-vindo ao LoadSense",
    texto:
      "O LoadSense registra as pesagens dos caminhões, acompanha as viagens e avisa quando algo sai do esperado. Este guia mostra em poucos passos por onde começar. Você pode rever tudo depois em Configurações > Ajuda.",
  },
  {
    titulo: "Dashboard",
    texto: "É a tela inicial. Mostra o resumo do dia: operações em andamento, pesagens recentes e alertas em aberto.",
  },
  {
    titulo: "Operações",
    texto:
      "Cada pesagem de um caminhão é uma operação. Toque em Nova para registrar uma pesagem, ou em uma operação da lista para ver as leituras, o peso e o histórico.",
  },
  {
    titulo: "Monitoramento",
    texto:
      "Mostra no mapa as viagens em andamento: onde estão, para onde vão e o estado de cada uma (em trânsito, parado, sem sinal ou chegou).",
  },
  {
    titulo: "Alertas",
    texto:
      "Avisos automáticos, como excesso de peso, atraso ou perda de sinal. Ao resolver um alerta, informe o motivo e o que foi feito. Use os filtros para ver os em aberto, os resolvidos ou todos.",
  },
  {
    titulo: "Relatórios e Histórico",
    texto:
      "Histórico lista as operações concluídas. Relatórios reúne os resumos do período. A exportação em planilha está disponível nos planos Profissional, Avançado e Enterprise.",
  },
  {
    titulo: "Primeiros passos",
    texto:
      "Antes de começar, troque a senha inicial em Perfil > Alterar senha. Depois, confira em Configurações > Ajuda a explicação de cada função.",
  },
];

export const PASSOS_GUIA_SITE: PassoGuia[] = [
  {
    titulo: "Bem-vindo ao LoadSense",
    texto:
      "O site é a central de gestão: aqui você acompanha as operações, configura a empresa e administra a equipe. Este guia mostra por onde começar. Você pode rever tudo depois em Configurações > Ajuda.",
  },
  {
    titulo: "Painel",
    texto: "Tela inicial com os indicadores do período: pesagens, alertas e viagens em andamento.",
  },
  {
    titulo: "Planilha Operacional",
    texto:
      "Lista as operações em forma de planilha, com filtros e exportação para Excel ou CSV (planos Profissional, Avançado e Enterprise).",
  },
  {
    titulo: "Nova operação",
    texto:
      "Registra uma nova pesagem: escolha o caminhão, o motorista e a rota. A balança preenche o peso automaticamente quando estiver conectada.",
  },
  {
    titulo: "Monitoramento e Alertas",
    texto:
      "Monitoramento mostra as viagens no mapa com a rota. Alertas traz os avisos automáticos, que podem ser resolvidos com motivo e ação registrados.",
  },
  {
    titulo: "Cadastros e configurações",
    texto:
      "Em Configurações você cadastra caminhões, motoristas e rotas, define os parâmetros de pesagem, gerencia a equipe e as permissões. Comece pelos cadastros: sem caminhão e motorista não é possível registrar uma operação.",
  },
];

export const FUNCOES_APP: Funcao[] = [
  {
    id: "dashboard",
    nome: "Dashboard",
    paraQueServe: "Resumo do dia em uma tela só.",
    comoUsar: [
      "Veja quantas operações estão em andamento e quantos alertas estão em aberto.",
      "Toque em um alerta ou em uma operação para abrir os detalhes.",
    ],
    onde: "Barra inferior, primeiro ícone.",
  },
  {
    id: "operacoes",
    nome: "Operações",
    paraQueServe: "Lista todas as pesagens e permite registrar novas.",
    comoUsar: [
      "Use Nova para registrar uma pesagem: escolha caminhão, motorista e rota.",
      "Toque em uma operação para ver o peso bruto, a tara, o peso líquido e as leituras da balança.",
      "Use a busca por placa, código, motorista ou produto para encontrar uma operação.",
    ],
    onde: "Barra inferior, ícone de caminhão.",
  },
  {
    id: "monitoramento",
    nome: "Monitoramento",
    paraQueServe: "Acompanha no mapa as viagens em andamento.",
    comoUsar: [
      "Cada viagem aparece com a rota e a posição atual do caminhão.",
      "O estado indica se a viagem está em trânsito, parada, sem sinal ou se já chegou.",
      "Viagens que ainda não têm rastreio ativo aparecem como aguardando ativação, com o código RFID da empresa.",
    ],
    onde: "Barra inferior, ícone de mapa.",
  },
  {
    id: "alertas",
    nome: "Alertas",
    paraQueServe: "Avisa quando algo sai do esperado.",
    comoUsar: [
      "Tipos comuns: excesso de peso, atraso na entrega, divergência de tara, leitura manual, possível carga extra e perda de sinal do rastreio.",
      "Para resolver, escreva o motivo e como foi resolvido. Fica registrado quem resolveu e quando.",
      "Use os filtros Em aberto, Resolvidos e Todos para organizar a lista.",
    ],
    onde: "Ícone de sino no cabeçalho, ou pelo Dashboard.",
  },
  {
    id: "relatorios",
    nome: "Relatórios",
    paraQueServe: "Resumos das operações de um período.",
    comoUsar: [
      "Escolha o período e abra o relatório para ver os totais.",
      "A exportação em planilha depende do plano da empresa.",
    ],
    onde: "Barra inferior, ícone de gráfico.",
  },
  {
    id: "historico",
    nome: "Histórico",
    paraQueServe: "Operações já concluídas, para consulta.",
    comoUsar: ["Use os filtros para achar uma operação antiga pela data, pelo caminhão ou pelo motorista."],
    onde: "Barra inferior, Relatórios, opção Histórico.",
  },
  {
    id: "configuracoes",
    nome: "Configurações",
    paraQueServe: "Conta, plano, preferências, segurança e esta ajuda.",
    comoUsar: [
      "Perfil e Alterar senha: dados pessoais e senha.",
      "Segurança: ative a verificação em duas etapas.",
      "Equipe e permissões (administrador): cria contas e define o que cada cargo pode fazer.",
      "Meus dados (LGPD): veja, corrija ou exclua seus dados pessoais.",
    ],
    onde: "Barra inferior, último ícone.",
  },
  {
    id: "status",
    nome: "Status do sistema",
    paraQueServe: "Mostra se o servidor, o banco e os equipamentos estão funcionando.",
    comoUsar: ["Se a balança ou o leitor RFID aparecer como sem sinal, confira o cabo e a energia do equipamento."],
    onde: "Configurações > Sistema.",
  },
];

export const FUNCOES_SITE: Funcao[] = [
  {
    id: "painel",
    nome: "Painel",
    paraQueServe: "Indicadores do período em uma tela.",
    comoUsar: ["Confira pesagens, alertas e viagens em andamento.", "Clique em um item para abrir os detalhes."],
    onde: "Menu lateral, Dashboard.",
  },
  {
    id: "planilha",
    nome: "Planilha Operacional",
    paraQueServe: "Todas as operações em forma de planilha.",
    comoUsar: [
      "Filtre por período, caminhão, motorista ou situação.",
      "Exporte para Excel ou CSV. Disponível nos planos Profissional, Avançado e Enterprise.",
    ],
    onde: "Menu lateral, Operação.",
  },
  {
    id: "nova-operacao",
    nome: "Nova operação",
    paraQueServe: "Registra uma nova pesagem.",
    comoUsar: [
      "Escolha o caminhão, o motorista e a rota.",
      "Confirme a tara e o peso. Com a balança conectada, o peso é preenchido sozinho.",
      "Depois de concluir, a operação aparece na planilha e no histórico.",
    ],
    onde: "Menu lateral, Operação.",
  },
  {
    id: "monitoramento",
    nome: "Monitoramento",
    paraQueServe: "Viagens no mapa, com a rota e o estado de cada caminhão.",
    comoUsar: [
      "Estados: aguardando ativação, em trânsito, parado, sem sinal ou chegou.",
      "Para o rastreio começar, informe o código RFID fornecido pela empresa parceira.",
    ],
    onde: "Menu lateral, Operação.",
  },
  {
    id: "alertas",
    nome: "Alertas",
    paraQueServe: "Avisos automáticos que precisam de atenção.",
    comoUsar: [
      "Filtre por Em aberto, Resolvidos ou Todos.",
      "Ao resolver, informe quem resolveu, o motivo e a ação tomada.",
    ],
    onde: "Menu lateral, Operação.",
  },
  {
    id: "historico",
    nome: "Histórico",
    paraQueServe: "Operações concluídas e seus eventos.",
    comoUsar: ["Abra uma operação para ver as leituras e o histórico de eventos (início, parada, chegada, alertas)."],
    onde: "Menu lateral, Dados.",
  },
  {
    id: "relatorios",
    nome: "Relatórios",
    paraQueServe: "Resumos e exportações do período.",
    comoUsar: ["Escolha o período e gere o relatório.", "A exportação depende do plano da empresa."],
    onde: "Menu lateral, Dados.",
  },
  {
    id: "cadastros",
    nome: "Cadastros e planos",
    paraQueServe: "Caminhões, motoristas, rotas, unidades e balanças da empresa.",
    comoUsar: [
      "Cadastre primeiro os caminhões, os motoristas e as rotas. Sem eles não há operação.",
      "Veja o plano atual da empresa e o que ele libera.",
    ],
    onde: "Configurações > Planos e cadastros.",
  },
  {
    id: "parametros",
    nome: "Parâmetros e hardware",
    paraQueServe: "Tolerâncias de peso e situação dos equipamentos.",
    comoUsar: [
      "Tolerância: quanto o peso pode variar antes de gerar aviso.",
      "Limite crítico: acima dele o alerta sai como crítico.",
      "Dispositivos mostram se a balança e o leitor RFID estão enviando dados.",
    ],
    onde: "Configurações > Parâmetros e hardware.",
  },
  {
    id: "equipe",
    nome: "Equipe e segurança",
    paraQueServe: "Contas, cargos e verificação em duas etapas.",
    comoUsar: [
      "Administradores criam contas e exigem a troca de senha quando necessário.",
      "Permissões por cargo definem o que supervisores e operadores podem fazer.",
    ],
    onde: "Configurações > Equipe e segurança.",
  },
  {
    id: "lgpd",
    nome: "Meus dados (LGPD)",
    paraQueServe: "Direitos sobre os seus dados pessoais.",
    comoUsar: ["Veja os dados guardados sobre você, corrija ou exclua sua conta."],
    onde: "Configurações > Meus dados (LGPD).",
  },
];
