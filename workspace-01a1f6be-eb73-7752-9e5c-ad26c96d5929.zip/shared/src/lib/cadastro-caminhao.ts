export const PLACA_RE = /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$|^[A-Z]{3}[0-9]{4}$/;
export const RFID_RE = /^[A-Za-z0-9._:-]{1,100}$/;

export const TIPOS_VEICULO = [
  { valor: "TRUCK", rotulo: "Caminhão" },
  { valor: "TRACTOR", rotulo: "Cavalo mecânico" },
  { valor: "SEMI_TRAILER", rotulo: "Semirreboque" },
  { valor: "TRAILER", rotulo: "Reboque" },
  { valor: "OTHER", rotulo: "Outro" },
] as const;

export interface FormCaminhao {
  placa: string;
  tipo: string;
  rfid: string;
  frota: string;
  fabricante: string;
  modelo: string;
  ano: string;
  eixos: string;
  tara: string;
  pbt: string;
  carga: string;
}

export const FORM_CAMINHAO_VAZIO: FormCaminhao = {
  placa: "",
  tipo: "TRUCK",
  rfid: "",
  frota: "",
  fabricante: "",
  modelo: "",
  ano: "",
  eixos: "",
  tara: "",
  pbt: "",
  carga: "",
};

export type ErrosCaminhao = Partial<Record<keyof FormCaminhao, string>>;

function numeroOpcional(texto: string): number | null | "invalido" {
  const t = texto.trim();
  if (t === "") return null;
  const n = Number(t.replace(",", "."));
  return Number.isFinite(n) && n >= 0 ? n : "invalido";
}

export function validarCaminhao(form: FormCaminhao): { erros: ErrosCaminhao; corpo: Record<string, unknown> | null } {
  const erros: ErrosCaminhao = {};
  const placa = form.placa.toUpperCase().replace(/[\s-]/g, "");
  if (!PLACA_RE.test(placa)) erros.placa = "Use o formato ABC1D23 ou ABC1234.";

  const rfid = form.rfid.trim();
  if (rfid && !RFID_RE.test(rfid))
    erros.rfid = "Use letras, números, ponto, hífen, dois-pontos ou sublinhado (até 100).";

  if (form.frota.trim().length > 40) erros.frota = "Máximo de 40 caracteres.";
  if (form.fabricante.trim().length > 80) erros.fabricante = "Máximo de 80 caracteres.";
  if (form.modelo.trim().length > 100) erros.modelo = "Máximo de 100 caracteres.";

  const anoTexto = form.ano.trim();
  const ano = anoTexto === "" ? null : Number(anoTexto);
  if (ano !== null && (!Number.isInteger(ano) || ano < 1950 || ano > new Date().getFullYear() + 1)) {
    erros.ano = `Ano entre 1950 e ${new Date().getFullYear() + 1}.`;
  }

  const eixosTexto = form.eixos.trim();
  const eixos = eixosTexto === "" ? null : Number(eixosTexto);
  if (eixos !== null && (!Number.isInteger(eixos) || eixos < 2 || eixos > 20)) erros.eixos = "Entre 2 e 20 eixos.";

  const tara = numeroOpcional(form.tara);
  if (tara === "invalido") erros.tara = "Informe um número maior ou igual a zero.";
  const pbt = numeroOpcional(form.pbt);
  if (pbt === "invalido") erros.pbt = "Informe um número maior ou igual a zero.";
  const carga = numeroOpcional(form.carga);
  if (carga === "invalido") erros.carga = "Informe um número maior ou igual a zero.";
  if (typeof tara === "number" && typeof pbt === "number" && pbt < tara) {
    erros.pbt = "O limite de peso bruto deve ser maior ou igual à tara.";
  }

  if (Object.keys(erros).length) return { erros, corpo: null };
  const texto = (v: string) => (v.trim() === "" ? null : v.trim());
  return {
    erros,
    corpo: {
      placa,
      tipo: form.tipo,
      rfid: texto(rfid),
      frota: texto(form.frota),
      fabricante: texto(form.fabricante),
      modelo: texto(form.modelo),
      anoFabricacao: ano,
      eixos,
      taraKg: typeof tara === "number" ? tara : null,
      limitePbtKg: typeof pbt === "number" ? pbt : null,
      limiteCargaKg: typeof carga === "number" ? carga : null,
    },
  };
}

export function erroCorpoCaminhao(corpo: Record<string, unknown>): string | null {
  const placa = String(corpo.placa ?? "");
  if (!PLACA_RE.test(placa)) return "Placa inválida. Use o formato ABC1D23 ou ABC1234.";
  const tara = typeof corpo.taraKg === "number" ? corpo.taraKg : null;
  const pbt = typeof corpo.limitePbtKg === "number" ? corpo.limitePbtKg : null;
  if (tara !== null && pbt !== null && pbt < tara) return "O limite de peso bruto deve ser maior ou igual à tara.";
  return null;
}
