import { useEffect, useRef } from "react";
import { api } from "./api";

export function useSincronia(aoMudar: () => void, ativo = true, intervaloMs = 4000) {
  const versaoRef = useRef<string | null>(null);
  const aoMudarRef = useRef(aoMudar);
  aoMudarRef.current = aoMudar;

  useEffect(() => {
    if (!ativo) return;
    let vivo = true;
    let temporizador: ReturnType<typeof setTimeout> | undefined;
    versaoRef.current = null;
    const verificar = async () => {
      try {
        const { versao } = await api.sincronia();
        if (!vivo) return;
        if (versaoRef.current !== null && versao !== versaoRef.current) aoMudarRef.current();
        versaoRef.current = versao;
      } catch {}
      if (vivo) temporizador = setTimeout(verificar, intervaloMs);
    };
    verificar();
    return () => {
      vivo = false;
      if (temporizador) clearTimeout(temporizador);
    };
  }, [ativo, intervaloMs]);
}
