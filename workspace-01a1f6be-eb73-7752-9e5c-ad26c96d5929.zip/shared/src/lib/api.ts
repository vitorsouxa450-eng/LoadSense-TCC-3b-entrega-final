const CHAVE_SERVIDOR = "loadsense-servidor-v1";

export function enderecoServidor(): string {
  const salvo = typeof localStorage !== "undefined" ? localStorage.getItem(CHAVE_SERVIDOR) : null;
  return (salvo ?? (import.meta.env.VITE_API_URL as string | undefined) ?? "").replace(/\/$/, "");
}

export function definirEnderecoServidor(endereco: string): void {
  localStorage.setItem(CHAVE_SERVIDOR, endereco.trim().replace(/\/$/, ""));
}

const base = () => `${enderecoServidor()}/api`;
const CHAVE_SESSAO = "loadsense-sessao-v1";

export interface DesafioDoisFatores {
  doisFatores: true;
  desafio: string;
  emailMascarado?: string;
  codigoDemo?: string;
}
export function ehDesafioDoisFatores(valor: unknown): valor is DesafioDoisFatores {
  return typeof valor === "object" && valor !== null && (valor as { doisFatores?: unknown }).doisFatores === true;
}

export interface SessaoApi {
  accessToken: string;
  refreshToken: string;
  expiraEm?: string;
  usuario: {
    id: number;
    nome: string;
    email: string;
    telefone?: string | null;
    papel: string;
    papelDescricao?: string;
    trocarSenha?: boolean;
  };
  empresa: {
    id: number;
    nome: string;
    razaoSocial?: string;
    slug?: string;
    cnpj?: string | null;
    fusoHorario?: string;
  };
  permissoes: string[];
  preferencias?: Record<string, unknown> | null;
  dispositivoId?: number;
}

export class ErroApi extends Error {
  status: number;
  detalhe?: string;
  constructor(status: number, mensagem: string, detalhe?: string) {
    super(mensagem);
    this.status = status;
    this.detalhe = detalhe;
  }
}

export function sessaoSalva(): SessaoApi | null {
  try {
    const bruto = localStorage.getItem(CHAVE_SESSAO);
    return bruto ? (JSON.parse(bruto) as SessaoApi) : null;
  } catch {
    return null;
  }
}

export function guardarSessao(sessao: SessaoApi | null) {
  try {
    if (sessao) localStorage.setItem(CHAVE_SESSAO, JSON.stringify(sessao));
    else localStorage.removeItem(CHAVE_SESSAO);
  } catch {}
}

let sessao = sessaoSalva();
export const sessaoAtual = () => sessao;

export function idDispositivo(): string {
  const chave = "loadsense-dispositivo";
  let valor = localStorage.getItem(chave);
  if (!valor) {
    valor = `web-${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    localStorage.setItem(chave, valor);
  }
  return valor;
}

async function requisitar<T>(
  metodo: string,
  caminho: string,
  corpo?: unknown,
  { auth = true, tentarRenovar = true, sinal }: { auth?: boolean; tentarRenovar?: boolean; sinal?: AbortSignal } = {},
): Promise<T> {
  const tokenEnviado = auth ? sessao?.accessToken : undefined;
  const resposta = await fetch(`${base()}${caminho}`, {
    method: metodo,
    headers: {
      ...(corpo ? { "content-type": "application/json" } : {}),
      ...(auth && sessao?.accessToken ? { authorization: `Bearer ${sessao.accessToken}` } : {}),
    },
    body: corpo ? JSON.stringify(corpo) : undefined,
    signal: sinal,
  });

  if (resposta.status === 401 && auth && tentarRenovar && sessao?.refreshToken) {
    const renovada = await renovarSeNecessario(tokenEnviado);
    if (renovada) return requisitar<T>(metodo, caminho, corpo, { auth, tentarRenovar: false, sinal });
  }

  const texto = await resposta.text();
  let dados: unknown = null;
  try {
    dados = texto ? JSON.parse(texto) : null;
  } catch {
    dados = texto;
  }

  if (!resposta.ok) {
    const erro = dados as { erro?: string; detalhe?: string } | null;
    throw new ErroApi(resposta.status, erro?.erro ?? `Falha na requisição (${resposta.status}).`, erro?.detalhe);
  }
  return dados as T;
}

let renovacaoEmCurso: Promise<boolean> | null = null;

function renovarSessao(): Promise<boolean> {
  if (!sessao?.refreshToken) return Promise.resolve(false);
  if (!renovacaoEmCurso) {
    renovacaoEmCurso = (async () => {
      try {
        const dados = await requisitar<{ accessToken: string }>(
          "POST",
          "/auth/refresh",
          { refreshToken: sessao?.refreshToken },
          { auth: false, tentarRenovar: false },
        );
        sessao = { ...(sessao as SessaoApi), accessToken: dados.accessToken };
        guardarSessao(sessao);
        return true;
      } catch {
        guardarSessao(null);
        sessao = null;
        return false;
      } finally {
        renovacaoEmCurso = null;
      }
    })();
  }
  return renovacaoEmCurso;
}

function renovarSeNecessario(tokenEnviado: string | undefined): Promise<boolean> {
  if (sessao?.accessToken && tokenEnviado && sessao.accessToken !== tokenEnviado) return Promise.resolve(true);
  return renovarSessao();
}

async function enviarComCorpo<T>(metodo: string, caminho: string, corpo: unknown, tentarRenovar = true): Promise<T> {
  const tokenEnviado = sessao?.accessToken;
  const resposta = await fetch(`${base()}${caminho}`, {
    method: metodo,
    headers: {
      "content-type": "application/json",
      ...(sessao?.accessToken ? { authorization: `Bearer ${sessao.accessToken}` } : {}),
    },
    body: JSON.stringify(corpo),
  });
  if (resposta.status === 401 && tentarRenovar && (await renovarSeNecessario(tokenEnviado))) {
    return enviarComCorpo<T>(metodo, caminho, corpo, false);
  }
  const dados = (await resposta.json().catch(() => null)) as
    (T & { erro?: string; mensagem?: string; erros?: { linha: number; mensagem: string }[] }) | null;
  if (!resposta.ok) {
    const linhas = (dados?.erros ?? []).slice(0, 10).map((e) => `Linha ${e.linha}: ${e.mensagem}`);
    const texto = dados?.mensagem ?? dados?.erro ?? `Falha na requisição (${resposta.status}).`;
    throw new ErroApi(resposta.status, [texto, ...linhas].join("\n"));
  }
  return dados as T;
}

async function baixarArquivo(
  caminho: string,
  nomeBase: string,
  formato: "xlsx" | "csv" | "json",
  consulta: Record<string, string | number | undefined> = {},
  corpoPost?: unknown,
  tentarRenovar = true,
): Promise<void> {
  const parametros = new URLSearchParams();
  const todos: Record<string, string | number | undefined> = { ...consulta, formato };
  for (const chave of Object.keys(todos)) {
    const valor = todos[chave];
    if (valor !== undefined && valor !== "") parametros.set(chave, String(valor));
  }
  const url = `${base()}${caminho}?${parametros.toString()}`;
  const tokenEnviado = sessao?.accessToken;
  const resposta = await fetch(url, {
    method: corpoPost ? "POST" : "GET",
    headers: {
      ...(corpoPost ? { "content-type": "application/json" } : {}),
      ...(sessao?.accessToken ? { authorization: `Bearer ${sessao.accessToken}` } : {}),
    },
    body: corpoPost ? JSON.stringify(corpoPost) : undefined,
  });
  if (resposta.status === 401 && tentarRenovar && (await renovarSeNecessario(tokenEnviado))) {
    return baixarArquivo(caminho, nomeBase, formato, consulta, corpoPost, false);
  }
  if (!resposta.ok) {
    const dados = (await resposta.json().catch(() => null)) as { erro?: string } | null;
    throw new ErroApi(resposta.status, dados?.erro ?? `Falha ao exportar (${resposta.status}).`);
  }
  const cabecalho = resposta.headers.get("content-disposition") ?? "";
  const nome = /filename="?([^";]+)"?/.exec(cabecalho)?.[1] ?? `${nomeBase}.${formato}`;
  const blob = await resposta.blob();
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = nome;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

async function arquivoEmBase64(arquivo: File): Promise<string> {
  const bytes = new Uint8Array(await arquivo.arrayBuffer());
  let binario = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binario += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(binario);
}

export async function detectarServidor(
  tempoLimiteMs = 2500,
): Promise<{ disponivel: boolean; latenciaMs?: number; bancoLatenciaMs?: number; versao?: string }> {
  const controle = new AbortController();
  const timer = setTimeout(() => controle.abort(), tempoLimiteMs);
  try {
    const inicio = performance.now();
    const dados = await requisitar<{ ok: boolean; versao: string; banco?: { latenciaMs?: number } }>(
      "GET",
      "/saude",
      undefined,
      {
        auth: false,
        sinal: controle.signal,
      },
    );
    return {
      disponivel: Boolean(dados?.ok),
      latenciaMs: Math.round(performance.now() - inicio),
      bancoLatenciaMs: dados?.banco?.latenciaMs,
      versao: dados?.versao,
    };
  } catch {
    return { disponivel: false };
  } finally {
    clearTimeout(timer);
  }
}

function montarQuery(padrao: Record<string, string | number>, consulta: string): string {
  const params = new URLSearchParams(consulta.replace(/^[?&]+/, ""));
  for (const [chave, valor] of Object.entries(padrao)) {
    if (!params.has(chave)) params.set(chave, String(valor));
  }
  return params.toString();
}

export const api = {
  get: <T>(caminho: string) => requisitar<T>("GET", caminho),
  post: <T>(caminho: string, corpo?: unknown) => requisitar<T>("POST", caminho, corpo),
  put: <T>(caminho: string, corpo?: unknown) => requisitar<T>("PUT", caminho, corpo),
  patch: <T>(caminho: string, corpo?: unknown) => requisitar<T>("PATCH", caminho, corpo),

  async entrar(email: string, senha: string, empresaSlug?: string): Promise<SessaoApi | DesafioDoisFatores> {
    const dados = await requisitar<SessaoApi | DesafioDoisFatores>(
      "POST",
      "/auth/login",
      { email, senha, empresaSlug, dispositivoUuid: idDispositivo(), plataforma: "WEB", versaoApp: "1.0.0" },
      { auth: false },
    );
    if (ehDesafioDoisFatores(dados)) return dados;
    sessao = dados;
    guardarSessao(dados);
    return dados;
  },

  async concluirLoginDoisFatores(desafio: string, codigo: string) {
    const dados = await requisitar<SessaoApi>(
      "POST",
      "/auth/login/totp",
      {
        desafio,
        codigo: codigo.replace(/\s/g, ""),
        dispositivoUuid: idDispositivo(),
        plataforma: "WEB",
        versaoApp: "1.0.0",
      },
      { auth: false },
    );
    sessao = dados;
    guardarSessao(dados);
    return dados;
  },

  auditoria: {
    tipos: () => requisitar<{ tipos: string[] }>("GET", "/auditoria/tipos"),
    baixarCsv: async (filtros: {
      tipo?: string;
      de?: string;
      ate?: string;
    }): Promise<{ arquivo: Blob; nome: string; truncado: boolean }> => {
      const qs = new URLSearchParams({ formato: "csv" });
      if (filtros.tipo) qs.set("tipo", filtros.tipo);
      if (filtros.de) qs.set("de", filtros.de);
      if (filtros.ate) qs.set("ate", filtros.ate);
      const enviar = () =>
        fetch(`${base()}/auditoria?${qs.toString()}`, {
          headers: sessao?.accessToken ? { authorization: `Bearer ${sessao.accessToken}` } : {},
        });
      let resposta = await enviar();
      if (resposta.status === 401 && sessao?.refreshToken) {
        const renovada = await renovarSeNecessario(sessao.accessToken);
        if (renovada) resposta = await enviar();
      }
      if (!resposta.ok) {
        const texto = await resposta.text();
        let msg = `Falha na exportação (${resposta.status}).`;
        try {
          msg = (JSON.parse(texto) as { erro?: string }).erro ?? msg;
        } catch {}
        throw new ErroApi(resposta.status, msg);
      }
      const disposicao = resposta.headers.get("content-disposition") ?? "";
      const nome = /filename="([^"]+)"/.exec(disposicao)?.[1] ?? "auditoria.csv";
      return { arquivo: await resposta.blob(), nome, truncado: resposta.headers.get("x-truncado") === "1" };
    },
  },

  usuarios: {
    listar: () =>
      requisitar<{
        usuarios: {
          id: number;
          nome: string;
          email: string;
          ativo: boolean;
          papel: string;
          papelDescricao?: string;
          trocarSenha: boolean;
          verificacaoEmDuasEtapas: boolean;
          ultimoAcesso: string | null;
          eu: boolean;
        }[];
      }>("GET", "/usuarios"),
    exigirTrocaSenha: (id: number, exigir: boolean) =>
      requisitar<{ ok: true; trocarSenha: boolean }>("PATCH", `/usuarios/${id}/troca-senha`, { exigir }),
    alterarPapel: (id: number, papel: "ADMINISTRATOR" | "SUPERVISOR" | "OPERATOR") =>
      requisitar<{ ok: true; papel: string }>("PATCH", `/usuarios/${id}`, { papel }),
    definirAtivo: (id: number, ativo: boolean) =>
      requisitar<{ ok: true; ativo: boolean }>("PATCH", `/usuarios/${id}/ativo`, { ativo }),
    criar: (corpo: { nome: string; email: string; papel: "ADMINISTRATOR" | "SUPERVISOR" | "OPERATOR" }) =>
      requisitar<{
        usuario: { id: number; nome: string; email: string; papel: string; trocarSenha: boolean; ativo: boolean };
        senhaProvisoria: string;
      }>("POST", "/usuarios", corpo),
  },

  seguranca: {
    sessoes: () =>
      requisitar<{
        sessoes: { id: number; descricao: string; criadaEm: string; ultimoUso: string | null; atual: boolean }[];
      }>("GET", "/seguranca/sessoes"),
    encerrar: (id: number) => requisitar<{ ok: true; atual: boolean }>("POST", `/seguranca/sessoes/${id}/encerrar`, {}),
  },

  papeis: {
    listar: () =>
      requisitar<{
        catalogo: { codigo: string; descricao: string; reservada: boolean }[];
        cargos: {
          nome: string;
          descricao: string | null;
          usuarios: number;
          editavel: boolean;
          permissoes: string[];
        }[];
      }>("GET", "/papeis"),
    salvarPermissoes: (nome: string, permissoes: string[]) =>
      requisitar<{ ok: true; cargo: string; permissoes: string[] }>("PUT", `/papeis/${nome}/permissoes`, {
        permissoes,
      }),
  },

  alterarSenha: async (senhaAtual: string, novaSenha: string) => {
    const resposta = await requisitar<{ ok: true }>(
      "PATCH",
      "/auth/senha",
      { senhaAtual, novaSenha },
      { tentarRenovar: false },
    );
    if (sessao) {
      sessao = { ...sessao, usuario: { ...sessao.usuario, trocarSenha: false } };
      guardarSessao(sessao);
    }
    return resposta;
  },

  totp: {
    estado: () => requisitar<{ ativo: boolean; ativoDesde: string | null; metodo: "EMAIL" }>("GET", "/auth/totp"),
    enviarCodigoAtivacao: () =>
      requisitar<{ emailMascarado: string; codigoDemo?: string }>("POST", "/auth/totp/configurar", {}),
    enviarCodigoDesativacao: () =>
      requisitar<{ emailMascarado: string; codigoDemo?: string }>("POST", "/auth/totp/enviar-desativacao", {}),
    ativar: (codigo: string) => requisitar<{ ok: true; ativo: true }>("POST", "/auth/totp/ativar", { codigo }),
    desativar: (senha: string, codigo: string) =>
      requisitar<{ ok: true; ativo: false }>("POST", "/auth/totp/desativar", { senha, codigo }),
  },

  opcoesAuth: () => requisitar<{ cadastro: boolean }>("GET", "/auth/opcoes", undefined, { auth: false }),

  async cadastrar(dados: {
    nomeCompleto: string;
    email: string;
    senha: string;
    nomeEmpresa: string;
    cnpj?: string;
    telefone?: string;
    aceitouTermos: true;
  }) {
    const resposta = await requisitar<SessaoApi>(
      "POST",
      "/auth/cadastro",
      { ...dados, dispositivoUuid: idDispositivo(), plataforma: "WEB", versaoApp: "1.0.0" },
      { auth: false },
    );
    sessao = resposta;
    guardarSessao(resposta);
    return resposta;
  },

  criarMotorista: (corpo: Record<string, unknown>) =>
    requisitar<{ id: number; nome: string }>("POST", "/motoristas", corpo),
  criarRota: (corpo: Record<string, unknown>) =>
    requisitar<{ id: number; origem: string; destino: string }>("POST", "/rotas", corpo),
  rotasAlternativas: (o: { latO: number; lonO: number; latD: number; lonD: number }) =>
    requisitar<{
      opcoes: {
        id: number;
        rotulo: string;
        fonte: "OSRM" | "LINHA_RETA";
        distanciaKm: number | null;
        duracaoMin: number | null;
        geometria: [number, number][];
        paradasSugeridas: { lat: number; lon: number }[];
      }[];
    }>("GET", `/rotas/alternativas?latOrigem=${o.latO}&lonOrigem=${o.lonO}&latDestino=${o.latD}&lonDestino=${o.lonD}`),

  async sair() {
    try {
      await requisitar("POST", "/auth/logout", { refreshToken: sessao?.refreshToken });
    } catch {}
    guardarSessao(null);
    sessao = null;
  },

  recuperarSenha: (email: string) =>
    requisitar<{ enviado: boolean; mensagem: string; codigoDemo?: string }>(
      "POST",
      "/auth/recuperacao/codigo",
      { email },
      { auth: false },
    ),
  verificarCodigoRecuperacao: (email: string, codigo: string) =>
    requisitar<{ valido: boolean }>("POST", "/auth/recuperacao/verificar", { email, codigo }, { auth: false }),
  novaSenha: (email: string, codigo: string, senha: string) =>
    requisitar<{ alterada: boolean }>(
      "POST",
      "/auth/recuperacao/nova-senha",
      { email, codigo, senha },
      { auth: false },
    ),

  eu: () => requisitar<Record<string, unknown>>("GET", "/auth/eu"),
  painel: (dias = 30) => requisitar<PainelApi>("GET", `/painel?dias=${dias}`),
  operacoes: (consulta = "") =>
    requisitar<{ operacoes: OperacaoApi[]; total: number }>(
      "GET",
      `/operacoes?${montarQuery({ limite: 200 }, consulta)}`,
    ),
  historico: (consulta = "") => requisitar<HistoricoApi>("GET", `/historico?${consulta}`),
  operacoesPagina: (consulta: string) =>
    requisitar<{ operacoes: OperacaoApi[]; total: number; pagina: number; limite: number }>(
      "GET",
      `/operacoes?${consulta}`,
    ),
  exportarPlanilha: (consulta: Record<string, string | number | undefined>, formato: "xlsx" | "csv") =>
    baixarArquivo("/operacoes/exportar", "loadsense-operacoes", formato, consulta),
  exportarOperacao: (id: number, formato: "xlsx" | "csv") =>
    baixarArquivo(`/operacoes/${id}/exportar`, "loadsense-operacao", formato),
  exportarDadosCompletos: () => baixarArquivo("/exportar/dados", "loadsense-dados-completos", "xlsx"),
  async importarPlanilha(arquivo: File, simular: boolean): Promise<ResultadoImportacao> {
    return enviarComCorpo<ResultadoImportacao>("POST", "/operacoes/importar", {
      nomeArquivo: arquivo.name,
      conteudoBase64: await arquivoEmBase64(arquivo),
      simular,
    });
  },
  operacao: (id: number | string) => requisitar<OperacaoDetalheApi>("GET", `/operacoes/${id}`),
  criarOperacao: (corpo: Record<string, unknown>) => requisitar<OperacaoApi>("POST", "/operacoes", corpo),
  registrarLeitura: (operacaoId: number, corpo: Record<string, unknown>) =>
    requisitar<{ leitura: LeituraApi; operacao: OperacaoApi }>("POST", `/operacoes/${operacaoId}/leituras`, corpo),
  aceitarLeitura: (operacaoId: number, leituraId: number) =>
    requisitar<{ leitura: LeituraApi; operacao: OperacaoApi }>(
      "POST",
      `/operacoes/${operacaoId}/leituras/${leituraId}/aceitar`,
    ),
  gerarChaveBalanca: (dispositivoId: number) =>
    requisitar<{ dispositivoId: number; nome: string; chave: string }>("POST", `/dispositivos/${dispositivoId}/chave`),
  definirOperacaoBalanca: (dispositivoId: number, operacaoId: number | null) =>
    requisitar<{ dispositivoId: number; operacaoAtivaId: number | null }>(
      "PUT",
      `/dispositivos/${dispositivoId}/operacao-ativa`,
      { operacaoId },
    ),
  finalizarOperacao: (operacaoId: number) =>
    requisitar<{ operacao: OperacaoApi; alertas: AlertaApi[] }>("POST", `/operacoes/${operacaoId}/finalizar`),
  cancelarOperacao: (operacaoId: number, motivo: string) =>
    requisitar<OperacaoApi>("POST", `/operacoes/${operacaoId}/cancelar`, { motivo }),
  agendarTransporte: (operacaoId: number, saidaPlanejada: string, chegadaPlanejada: string) =>
    requisitar<OperacaoApi>("POST", `/operacoes/${operacaoId}/transporte/agenda`, { saidaPlanejada, chegadaPlanejada }),
  iniciarTransporte: (operacaoId: number) =>
    requisitar<OperacaoApi>("POST", `/operacoes/${operacaoId}/transporte/iniciar`),
  chegadaTransporte: (operacaoId: number) =>
    requisitar<OperacaoApi>("POST", `/operacoes/${operacaoId}/transporte/chegada`),
  ativarRastreio: (operacaoId: number, codigoRfid: string) =>
    requisitar<OperacaoApi>("POST", `/operacoes/${operacaoId}/rastreio/ativar`, { codigoRfid }),
  enviarRastreio: (operacaoId: number, corpo: Record<string, unknown>) =>
    requisitar<{ pontoId: number; operacao: OperacaoApi }>("POST", `/operacoes/${operacaoId}/rastreio`, corpo),
  rastreioDaOperacao: (operacaoId: number) =>
    requisitar<{ operacao: OperacaoApi; pontos: PontoApi[]; waypoints: WaypointApi[] }>(
      "GET",
      `/operacoes/${operacaoId}/rastreio`,
    ),
  rotaOperacao: (operacaoId: number) => requisitar<RotaApi>("GET", `/operacoes/${operacaoId}/rota`),
  rotasRastreio: () => requisitar<{ rotas: Record<string, RotaApi> }>("GET", "/rastreio/rotas"),
  sincronia: () => requisitar<{ versao: string }>("GET", "/sincronia"),
  rastreioAtivo: (concluidas = false) =>
    requisitar<{
      viagens: (OperacaoApi & { waypoints: WaypointApi[] })[];
      aguardandoAtivacao: { id: number; codigo: string; placa: string | null }[];
    }>("GET", concluidas ? "/rastreio/ativo?concluidas=1" : "/rastreio/ativo"),
  alertas: (consulta = "") =>
    requisitar<{ alertas: AlertaApi[]; total: number; abertos: number; criticos: number }>(
      "GET",
      `/alertas?${montarQuery({ limite: 200 }, consulta)}`,
    ),
  alerta: (id: number) => requisitar<AlertaApi & { historico: unknown[] }>("GET", `/alertas/${id}`),
  reconhecerAlerta: (id: number) => requisitar<AlertaApi>("POST", `/alertas/${id}/reconhecer`),
  reabrirAlerta: (id: number) => requisitar<AlertaApi>("POST", `/alertas/${id}/reabrir`),
  resolverAlerta: (id: number, resolucao: { motivo: string; acao: string }) =>
    requisitar<AlertaApi>("POST", `/alertas/${id}/resolver`, resolucao),
  resolverTodosAlertas: () => requisitar<{ resolvidos: number }>("POST", "/alertas/resolver-todos"),
  veiculos: () => requisitar<{ veiculos: VeiculoApi[] }>("GET", "/veiculos"),
  criarVeiculo: (corpo: Record<string, unknown>) => requisitar<VeiculoApi>("POST", "/veiculos", corpo),
  motoristas: () => requisitar<{ motoristas: MotoristaApi[] }>("GET", "/motoristas"),
  produtos: () => requisitar<{ produtos: ProdutoApi[] }>("GET", "/produtos"),
  rotas: () => requisitar<{ rotas: RotaApi[] }>("GET", "/rotas"),
  dispositivos: () =>
    requisitar<{ dispositivos: DispositivoApi[]; resumo: Record<string, number> }>("GET", "/dispositivos"),
  postos: () => requisitar<{ postos: PostoApi[] }>("GET", "/postos"),
  atualizarConfiguracoes: (corpo: Record<string, unknown>) =>
    requisitar<{ configuracoes: Record<string, unknown> }>("PATCH", "/configuracoes", corpo),
  configuracoes: () => requisitar<{ configuracoes: Record<string, unknown> }>("GET", "/configuracoes"),
  preferencias: (corpo: Record<string, unknown>) =>
    requisitar<{ preferencias: Record<string, unknown> }>("PUT", "/preferencias", corpo),
  titular: {
    perfil: () =>
      requisitar<{
        nome: string;
        email: string;
        telefone: string | null;
        alertasCriticos: boolean;
        relatoriosAutomaticos: boolean;
      }>("GET", "/titular/perfil"),
    baixarMeusDados: () => baixarArquivo("/titular/meus-dados", "meus-dados-loadsense", "json"),
    atualizarMeusDados: (corpo: {
      nome?: string;
      telefone?: string;
      alertasCriticos?: boolean;
      relatoriosAutomaticos?: boolean;
    }) => requisitar<{ ok: boolean }>("PATCH", "/titular/meus-dados", corpo),
    excluirConta: (senha: string) =>
      requisitar<{ ok: boolean; mensagem: string }>("POST", "/titular/excluir-conta", { senha }),
  },
  anonimizarMotorista: (id: number) => requisitar<{ ok: boolean }>("POST", `/motoristas/${id}/anonimizar`),
  assinatura: () => requisitar<{ atual: AssinaturaApi | null; historico: AssinaturaApi[] }>("GET", "/assinatura"),
  planos: () => requisitar<{ planos: Record<string, unknown>[] }>("GET", "/planos"),
  documentosPendentes: () => requisitar<{ pendentes: DocumentoPendenteApi[] }>("GET", "/documentos-legais/pendentes"),
  aceitarDocumento: (id: number, corpo: Record<string, unknown> = {}) =>
    requisitar<{ ok: boolean }>("POST", `/documentos-legais/${id}/aceitar`, corpo),
  relatorios: () => requisitar<{ relatorios: RelatorioApi[] }>("GET", "/relatorios"),
  resumoRelatorio: (dias = 30) =>
    requisitar<{ periodo: { inicio: string; fim: string }; resumo: ResumoApi }>(
      "GET",
      `/relatorios/resumo?dias=${dias}`,
    ),
  gerarRelatorio: (corpo: Record<string, unknown>) => requisitar<RelatorioApi>("POST", "/relatorios", corpo),
  relatorio: (id: number) => requisitar<RelatorioApi>("GET", `/relatorios/${id}`),
  exportarRelatorio: (id: number) =>
    baixarArquivo(`/relatorios/${id}/exportar.csv`, `loadsense-relatorio-${id}`, "csv"),
  solicitarEmpresa: (corpo: Record<string, unknown>) =>
    requisitar<{ id: number; situacao: string; mensagem: string }>("POST", "/empresas/solicitacoes", corpo),
};

export interface OperacaoApi {
  id: number;
  codigo: string;
  estado: "DRAFT" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED";
  status: "ANALYSIS" | "NORMAL" | "ATTENTION" | "CRITICAL";
  statusMotivo?: string | null;
  rastreioAtivado?: boolean;
  metodo: "THREE_STAGE" | "GROSS_TARE";
  tipoMovimento: string;
  unidade?: string | null;
  posto?: string | null;
  veiculo: { id: number | null; placa: string | null; frota: string | null; tipo?: string | null };
  motorista?: string | null;
  motoristaId?: number | null;
  produto?: string | null;
  produtoId?: number | null;
  rfid?: string | null;
  rota: { id: number | null; origem: string | null; destino: string | null; distanciaKm: number | null };
  responsavel?: string | null;
  criadoPor?: string | null;
  observacoes?: string | null;
  documentoFiscal?: string | null;
  mdfe?: string | null;
  ciot?: string | null;
  datas: {
    iniciadaEm?: string | null;
    concluidaEm?: string | null;
    saidaPlanejada?: string | null;
    saidaReal?: string | null;
    chegadaPlanejada?: string | null;
    chegadaReal?: string | null;
    canceladaEm?: string | null;
  };
  pesos: {
    taraCadastradaKg: number | null;
    vazioAferidoKg: number | null;
    cargaSeparadaKg: number | null;
    cargaDeclaradaKg: number | null;
    brutoEsperadoKg: number | null;
    brutoAferidoKg: number | null;
    cargaAferidaKg: number | null;
    desvioKg: number | null;
    desvioPct: number | null;
    taraDesvioPct: number | null;
    limiteBrutoKg: number | null;
    limiteCargaKg: number | null;
    toleranciaPct: number | null;
    limiteCriticoPct: number | null;
    toleranciaTaraPct: number | null;
  };
  versaoCalculo: number;
  rastreio: RastreioApi | null;
}

export interface RastreioApi {
  estado: "NOT_STARTED" | "IN_TRANSIT" | "STOPPED" | "ARRIVED" | "SIGNAL_LOST" | "CANCELLED" | null;
  latitude: number | null;
  longitude: number | null;
  velocidadeKmh: number | null;
  rumo: number | null;
  progressoPct: number | null;
  desvioMetros: number | null;
  eta: string | null;
  atrasoMin: number | null;
  ultimaPosicaoEm: string | null;
  paradoDesde?: string | null;
}

export interface LeituraApi {
  id: number;
  estagio: "EMPTY_TRUCK" | "SEPARATED_CARGO" | "LOADED_TRUCK";
  sequencia: number;
  pesoKg: number;
  origem: "DEVICE" | "MANUAL" | "IMPORT";
  estavel: boolean;
  aceita: boolean;
  motivoManual?: string | null;
  medidoEm: string;
  aceitoEm?: string | null;
}

export interface OperacaoDetalheApi extends OperacaoApi {
  motoristaTelefone?: string | null;
  auditoria?: {
    id: number;
    acao: string;
    usuario?: string | null;
    antes?: Record<string, unknown> | null;
    depois?: Record<string, unknown> | null;
    criadoEm: string;
  }[];
  leituras: LeituraApi[];
  eventos: {
    id: number;
    tipo: string;
    usuario?: string | null;
    dados?: Record<string, unknown> | null;
    criadoEm: string;
  }[];
  alertas: AlertaApi[];
  trajeto: PontoApi[];
  waypoints: WaypointApi[];
}

export interface PontoApi {
  id: number;
  latitude: number;
  longitude: number;
  speed_kmh?: number | null;
  progress_percent?: number | null;
  route_deviation_meters?: number | null;
  recorded_at: string;
}

export interface RotaApi {
  operacaoId: number;
  fonte: "OSRM" | "LINHA_RETA" | "SEM_ROTA";
  geometria: [number, number][];
  distanciaKm: number | null;
  duracaoMin: number | null;
  aviso?: string;
  paradas: WaypointApi[];
}

export interface WaypointApi {
  route_id?: number;
  sequence_number: number;
  waypoint_type: "ORIGIN" | "WAYPOINT" | "DESTINATION";
  label: string | null;
  latitude: number;
  longitude: number;
}

export interface AlertaApi {
  id: number;
  operacaoId: number | null;
  operacaoCodigo: string | null;
  contexto: "WEIGHING" | "TRACKING" | "DEVICE" | "SYSTEM";
  tipo: string;
  nivel: "ATTENTION" | "CRITICAL";
  situacao: "OPEN" | "ACKNOWLEDGED" | "RESOLVED";
  titulo: string;
  mensagem: string;
  desvioKg?: number | null;
  desvioPct?: number | null;
  contextoJson?: Record<string, unknown> | null;
  veiculo?: string | null;
  motorista?: string | null;
  origemRota?: string | null;
  destinoRota?: string | null;
  detectadoEm?: string;
  criadoEm: string;
  resolvidoEm?: string | null;
  reconhecidoEm?: string | null;
  motivoResolucao?: string | null;
  notasResolucao?: string | null;
  reconhecidoPor?: string | null;
  resolvidoPor?: string | null;
}

export interface VeiculoApi {
  id: number;
  plate: string;
  fleet_code: string | null;
  vehicle_type: string;
  manufacturer: string | null;
  model: string | null;
  manufacture_year?: number | null;
  axle_count?: number | null;
  registered_tare_kg: number | null;
  gross_weight_limit_kg: number | null;
  payload_limit_kg: number | null;
  active?: number;
  rfid_id?: number | null;
  rfid_code: string | null;
  total_operacoes: number;
}

export interface MotoristaApi {
  id: number;
  full_name: string;
  employee_code: string | null;
  license_number: string | null;
  license_category: string | null;
  phone: string | null;
}

export interface ProdutoApi {
  id: number;
  code: string | null;
  name: string;
  default_unit: string;
}

export interface RotaApi {
  id: number;
  code: string | null;
  origin: string;
  destination: string;
  distance_km: number | null;
  waypoints: WaypointApi[];
}

export interface DispositivoApi {
  id: number;
  name: string;
  device_type: "ESP32" | "RFID_READER" | "SCALE_CONTROLLER" | "LOAD_CELL" | "GPRS_MODEM" | "OTHER";
  serial_number: string | null;
  firmware_version: string | null;
  state: "ONLINE" | "OFFLINE" | "MAINTENANCE" | "DISABLED";
  last_seen_at: string | null;
  last_calibrated_at: string | null;
  operacao_ativa_id?: number | null;
  calibrado_em?: string | null;
  calibracao_valida_ate?: string | null;
  unidade?: string | null;
}

export interface PostoApi {
  id: number;
  code: string;
  name: string;
  unidade: string;
  balanca: string | null;
  balanca_estado: string | null;
  leitor_rfid: string | null;
}

export interface PainelApi {
  periodo: { inicio: string; fim: string; dias: number };
  kpis: {
    operacoes: number;
    concluidas: number;
    emAndamento: number;
    canceladas: number;
    normais: number;
    atencao: number;
    criticas: number;
    toneladas: number;
    mediaCargaKg: number;
    mediaBrutoT: number;
    desvioMedioPct: number;
    eficienciaPct: number;
  };
  rastreio: Record<string, number | null> | null;
  alertas: Record<string, number | null> | null;
  serie: {
    dia: string;
    operacoes: number;
    concluidas: number;
    normais: number;
    atencao: number;
    criticas: number;
    carga_kg: number;
    desvio_pct: number | null;
  }[];
  porTipoCarga: { produto: string; operacoes: number; toneladas: number }[];
  topVeiculos: { plate: string; viagens: number; toneladas: number }[];
  frota: Record<string, number> | null;
  alertasAbertos: AlertaApi[];
}

export interface AssinaturaApi {
  status?: string;
  plan_code?: string;
  plan_name?: string;
  monthly_price_brl?: number | null;
  current_period_end?: string | null;
  starts_at?: string | null;
  features_json?: string | null;
}

export interface DocumentoPendenteApi {
  legal_document_id: number;
  document_type: "TERMS_OF_USE" | "PRIVACY_POLICY";
  version: string;
  title: string;
  content_format: string;
  content?: string;
}

export interface RelatorioApi {
  id: number;
  tipo: string;
  inicio: string;
  fim: string;
  formato: string;
  geradoEm?: string;
  geradoPor?: string | null;
  resumo?: ResumoApi | string | null;
  recomendacoes?: string | null;
}

export interface AtividadeApi {
  id: string;
  tipo: "pesagem" | "criacao" | "evento" | "rastreio" | "alerta" | "edicao" | "cadastro" | "acesso";
  rotulo: string;
  data: string;
  operacaoId: number | null;
  codigo: string | null;
  placa: string | null;
  usuario: string | null;
  detalhe: string;
  temAntes?: boolean;
  antes?: Record<string, string | null> | null;
  depois?: Record<string, string | null> | null;
}

export interface HistoricoApi {
  atividades: AtividadeApi[];
  contagem: Record<string, number>;
  total: number;
  limite: number;
  pagina: number;
  temMais: boolean;
}

export interface ResumoApi {
  operacoes: number;
  concluidas: number;
  normais: number;
  atencao: number;
  criticas: number;
  toneladas: number;
  mediaCargaKg: number;
  desvioMedioPct: number;
  eficienciaPct: number;
  alertas: { total?: number; criticos?: number; resolvidos?: number };
  pesagens: { leituras?: number; manuais?: number; automaticas?: number };
  porProduto: { produto: string; operacoes: number; toneladas: number }[];
}

export interface ResultadoImportacao {
  aplicada: boolean;
  simulacao?: boolean;
  mensagem?: string;
  total: number;
  criar?: number;
  atualizar?: number;
  criadas?: number;
  atualizadas?: number;
  erros: { linha: number; mensagem: string }[];
}
