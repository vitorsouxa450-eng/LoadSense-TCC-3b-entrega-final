import { erroCorpoCaminhao } from "./cadastro-caminhao";
import {
  ErroApi,
  guardarSessao,
  type AlertaApi,
  type OperacaoApi,
  type RelatorioApi,
  type ResumoApi,
  type SessaoApi,
  type VeiculoApi,
  type WaypointApi,
} from "./api";

const PLACAS = ["ABC1D23", "QWE4R56", "JKL7M89", "RTY2U10", "PLM3N45", "ZXC8V67", "BNM5K32", "FGH9J21"];
const MOTORISTAS = [
  "Carlos Mendes",
  "Ana Souza",
  "Roberto Lima",
  "Júlia Castro",
  "Marcos Dias",
  "Felipe Rocha",
  "Patrícia Alves",
  "Bruno Teixeira",
];
const RESPONSAVEIS = ["Op. Sandra", "Op. Diego", "Adm. LoadSense", "Op. Camila"];
const PRODUTOS = ["Grãos", "Cimento", "Bebidas", "Aço", "Madeira", "Fertilizante", "Combustível"];
const CIDADES = ["Curitiba", "Londrina", "Maringá", "Cascavel", "Ponta Grossa", "Foz do Iguaçu", "Pato Branco"];
const COORD: Record<string, [number, number]> = {
  Curitiba: [-25.4284, -49.2733],
  Londrina: [-23.3045, -51.1696],
  Maringá: [-23.4205, -51.9331],
  Cascavel: [-24.9555, -53.4552],
  "Ponta Grossa": [-25.0945, -50.1633],
  "Foz do Iguaçu": [-25.5469, -54.5882],
  "Pato Branco": [-26.229, -52.6711],
};
const TOLERANCIA_PCT = 1.5;
const CRITICO_PCT = 3;
const DIA = 86_400_000;

function sementeFixa(semente: number) {
  let estado = semente >>> 0;
  return () => {
    estado = (estado + 0x6d2b79f5) >>> 0;
    let t = estado;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const aleatorio = sementeFixa(20261009);

type Status = "normal" | "atencao" | "critico" | "analise";

const rfid = (t: number) => "RF-" + (100000 + t * 137).toString(16).toUpperCase().slice(0, 6);
const classificar = (pct: number): Status => {
  const a = Math.abs(pct);
  return a <= TOLERANCIA_PCT ? "normal" : a <= CRITICO_PCT ? "atencao" : "critico";
};
const motivoAlerta = (dif: number, pct: number) =>
  Math.abs(pct) <= TOLERANCIA_PCT
    ? "Sem alerta"
    : dif < 0
      ? "Possível falta de carga"
      : Math.abs(pct) > CRITICO_PCT
        ? "Excesso de peso crítico"
        : "Inconsistência de pesagem";
const STATUS_API: Record<Status, OperacaoApi["status"]> = {
  normal: "NORMAL",
  atencao: "ATTENTION",
  critico: "CRITICAL",
  analise: "ANALYSIS",
};
const NIVEL: Record<Status, AlertaApi["nivel"]> = {
  normal: "ATTENTION",
  atencao: "ATTENTION",
  analise: "ATTENTION",
  critico: "CRITICAL",
};
const agoraIso = () => new Date().toISOString();

function sessaoDemo(): SessaoApi {
  return {
    accessToken: "demo",
    refreshToken: "demo",
    usuario: {
      id: 1,
      nome: "Administrador LoadSense",
      email: "renato@loadsense.local",
      papel: "ADMIN",
      papelDescricao: "Administrador",
    },
    empresa: { id: 1, nome: "LoadSense Transportes", slug: "loadsense-demo" },
    permissoes: ["*"],
  } as unknown as SessaoApi;
}

interface RegistroDemo {
  id: number;
  codigo: string;
  placa: string;
  motorista: string;
  rfid: string;
  produto: string;
  responsavel: string;
  origem: string;
  destino: string;
  data: Date;
  vazio: number;
  carga: number;
  esperado: number;
  real: number;
  status: Status;
  declarado: number | null;
  observacao: string;
}

function paraOperacao(r: RegistroDemo): OperacaoApi {
  const dif = r.real - r.esperado;
  const pct = +((dif / r.esperado) * 100).toFixed(2);
  const veiculoIdx = PLACAS.indexOf(r.placa);
  return {
    id: r.id,
    codigo: r.codigo,
    estado: "COMPLETED",
    status: STATUS_API[r.status],
    statusMotivo: r.status === "normal" ? null : motivoAlerta(dif, pct),
    metodo: "GROSS_TARE",
    tipoMovimento: "EXIT",
    unidade: "Curitiba",
    posto: "Balança 01",
    veiculo: {
      id: veiculoIdx + 1,
      placa: r.placa,
      frota: `F-${String(veiculoIdx + 1).padStart(2, "0")}`,
      tipo: "Caminhão",
    },
    motorista: r.motorista,
    motoristaId: MOTORISTAS.indexOf(r.motorista) + 1,
    produto: r.produto,
    produtoId: PRODUTOS.indexOf(r.produto) + 1,
    rfid: r.rfid,
    rota: { id: 1, origem: r.origem, destino: r.destino, distanciaKm: 180 + (r.id % 7) * 35 },
    responsavel: r.responsavel,
    observacoes: r.observacao,
    datas: {
      iniciadaEm: r.data.toISOString(),
      concluidaEm: new Date(r.data.getTime() + 25 * 60_000).toISOString(),
      saidaReal: r.data.toISOString(),
    },
    pesos: {
      taraCadastradaKg: r.vazio,
      vazioAferidoKg: r.vazio,
      cargaSeparadaKg: r.carga,
      cargaDeclaradaKg: r.declarado,
      brutoEsperadoKg: r.esperado,
      brutoAferidoKg: r.real,
      cargaAferidaKg: r.real - r.vazio,
      desvioKg: dif,
      desvioPct: pct,
      taraDesvioPct: 0,
      limiteBrutoKg: 45000,
      limiteCargaKg: 30000,
      toleranciaPct: TOLERANCIA_PCT,
      limiteCriticoPct: CRITICO_PCT,
      toleranciaTaraPct: 2,
    },
    versaoCalculo: 1,
    rastreio: null,
  } as OperacaoApi;
}

function gerarRegistros(): RegistroDemo[] {
  const hoje = new Date();
  return Array.from({ length: 28 }, (_, t) => {
    const vazio = 12000 + Math.round(aleatorio() * 4000);
    const carga = 8000 + Math.round(aleatorio() * 16000);
    const esperado = vazio + carga;
    const o = aleatorio();
    let ajuste: number;
    if (o > 0.78) ajuste = -(carga * (0.04 + aleatorio() * 0.06));
    else if (o > 0.6) ajuste = esperado * (0.02 + aleatorio() * 0.04);
    else ajuste = esperado * (aleatorio() * 0.014 - 0.007);
    const real = Math.round(esperado + ajuste);
    const pct = +(((real - esperado) / esperado) * 100).toFixed(2);
    let status = classificar(pct);
    if (t % 9 === 0 && status !== "normal") status = "analise";
    const data = new Date(hoje);
    data.setDate(hoje.getDate() - Math.floor(t / 3));
    data.setHours(8 + (t % 10), (t * 13) % 60, 0, 0);
    return {
      id: 2480 - t,
      codigo: "OP-" + String(2480 - t).padStart(4, "0"),
      placa: PLACAS[t % PLACAS.length],
      motorista: MOTORISTAS[t % MOTORISTAS.length],
      rfid: rfid(t),
      produto: PRODUTOS[t % PRODUTOS.length],
      responsavel: RESPONSAVEIS[t % RESPONSAVEIS.length],
      origem: CIDADES[t % CIDADES.length],
      destino: CIDADES[(t + 3) % CIDADES.length],
      data,
      vazio,
      carga,
      esperado,
      real,
      status,
      declarado: null,
      observacao: status === "normal" ? "Operação dentro da tolerância." : "Verificar carga e lacre.",
    };
  }).sort((a, b) => b.data.getTime() - a.data.getTime());
}

let registros = gerarRegistros();
let alertas: AlertaApi[] = [];
let relatorios: RelatorioApi[] = [];
let configuracoes: Record<string, unknown> = {
  tolerance_percent: TOLERANCIA_PCT,
  critical_limit_percent: CRITICO_PCT,
  tare_tolerance_percent: 2,
  route_deviation_tolerance_meters: 500,
};
let proximoId = 3000;

function montarAlertas(): AlertaApi[] {
  return registros
    .filter((r) => r.status !== "normal")
    .slice(0, 12)
    .map((r, i) => {
      const dif = r.real - r.esperado;
      const pct = +((dif / r.esperado) * 100).toFixed(2);
      return {
        id: 100 + i,
        operacaoId: r.id,
        operacaoCodigo: r.codigo,
        contexto: "WEIGHING",
        tipo: motivoAlerta(dif, pct),
        nivel: NIVEL[r.status],
        situacao: "OPEN",
        titulo: motivoAlerta(dif, pct),
        mensagem: `${motivoAlerta(dif, pct)} na operação ${r.codigo} — caminhão ${r.placa}, motorista ${r.motorista}. Diferença de ${dif.toLocaleString("pt-BR")} kg (${pct.toFixed(2)}%).`,
        desvioKg: dif,
        desvioPct: pct,
        veiculo: r.placa,
        motorista: r.motorista,
        origemRota: r.origem,
        destinoRota: r.destino,
        detectadoEm: r.data.toISOString(),
        criadoEm: r.data.toISOString(),
        resolvidoEm: null,
        reconhecidoEm: null,
        notasResolucao: null,
      } as AlertaApi;
    });
}
alertas = montarAlertas();

export function snapshotDemo(): { operacoes: OperacaoApi[]; alertas: AlertaApi[] } {
  return { operacoes: registros.map(paraOperacao), alertas: alertas.slice() };
}

const noPeriodo = (dias: number) => {
  const limite = Date.now() - dias * DIA;
  return registros.filter((r) => r.data.getTime() >= limite);
};

function resumoDe(lista: RegistroDemo[]): ResumoApi {
  const toneladas = lista.reduce((s, r) => s + r.real, 0) / 1000;
  const grupos = new Map<string, { operacoes: number; toneladas: number }>();
  lista.forEach((r) => {
    const g = grupos.get(r.produto) ?? { operacoes: 0, toneladas: 0 };
    g.operacoes += 1;
    g.toneladas += r.real / 1000;
    grupos.set(r.produto, g);
  });
  const desvios = lista.map((r) => Math.abs(((r.real - r.esperado) / r.esperado) * 100));
  const media = desvios.length ? desvios.reduce((a, b) => a + b, 0) / desvios.length : 0;
  const normais = lista.filter((r) => r.status === "normal").length;
  return {
    operacoes: lista.length,
    concluidas: lista.length,
    normais,
    atencao: lista.filter((r) => r.status === "atencao" || r.status === "analise").length,
    criticas: lista.filter((r) => r.status === "critico").length,
    toneladas: +toneladas.toFixed(1),
    mediaCargaKg: lista.length ? Math.round(lista.reduce((s, r) => s + r.carga, 0) / lista.length) : 0,
    desvioMedioPct: +media.toFixed(2),
    eficienciaPct: lista.length ? +((normais / lista.length) * 100).toFixed(1) : 0,
    alertas: {
      total: alertas.length,
      criticos: alertas.filter((a) => a.nivel === "CRITICAL").length,
      resolvidos: alertas.filter((a) => a.situacao === "RESOLVED").length,
    },
    pesagens: { leituras: lista.length * 2, manuais: 0, automaticas: lista.length * 2 },
    porProduto: [...grupos.entries()].map(([produto, g]) => ({
      produto,
      operacoes: g.operacoes,
      toneladas: +g.toneladas.toFixed(1),
    })),
  };
}

const iso = (d: Date) => d.toISOString().slice(0, 10);

export function viagensDemo(): (OperacaoApi & { waypoints: WaypointApi[] })[] {
  const agora = Date.now();
  return registros.map((r) => {
    const op = paraOperacao(r);
    const k = r.id % 97;
    const progresso = 12 + ((k * 37) % 84);
    const [la, lo] = COORD[r.origem];
    const [lb, lbo] = COORD[r.destino];
    const f = progresso / 100;
    const estados = ["IN_TRANSIT", "NOT_STARTED", "STOPPED"] as const;
    const estado = estados[r.id % 3];
    const restanteKm = (op.rota.distanciaKm ?? 0) * (1 - f);
    const velocidade = estado === "STOPPED" ? 0 : 58 + (k % 30);
    const eta = new Date(agora + (velocidade > 0 ? (restanteKm / velocidade) * 3_600_000 : 3_600_000));
    op.rastreio = {
      estado,
      latitude: la + (lb - la) * f,
      longitude: lo + (lbo - lo) * f,
      velocidadeKmh: velocidade,
      rumo: 300,
      progressoPct: progresso,
      desvioMetros: k % 4 === 0 ? 180 : 20 + (k % 5) * 10,
      eta: eta.toISOString(),
      atrasoMin: k % 6 === 0 ? 12 : 0,
      ultimaPosicaoEm: new Date(agora - (k % 10) * 60_000).toISOString(),
      paradoDesde: estado === "STOPPED" ? new Date(agora - 25 * 60_000).toISOString() : null,
    };
    const waypoints: WaypointApi[] = [
      { route_id: 1, sequence_number: 1, waypoint_type: "ORIGIN", label: r.origem, latitude: la, longitude: lo },
      { route_id: 1, sequence_number: 2, waypoint_type: "DESTINATION", label: r.destino, latitude: lb, longitude: lbo },
    ];
    return { ...op, waypoints };
  });
}

const TIPO_LEGIVEL: Record<string, string> = {
  TRUCK: "Caminhão",
  TRACTOR: "Cavalo mecânico",
  SEMI_TRAILER: "Semirreboque",
  TRAILER: "Reboque",
  OTHER: "Outro",
};

let veiculosCadastrados: VeiculoApi[] = [];

function veiculosDemoBase(): VeiculoApi[] {
  return PLACAS.map((plate, i) => ({
    id: i + 1,
    plate,
    fleet_code: `F-${String(i + 1).padStart(2, "0")}`,
    vehicle_type: "Caminhão",
    manufacturer: "Volvo",
    model: "FM 440",
    registered_tare_kg: 12000 + i * 150,
    gross_weight_limit_kg: 45000,
    payload_limit_kg: 30000,
    rfid_code: rfid(i),
    total_operacoes: registros.filter((r) => r.placa === plate).length,
  }));
}

export function veiculosCadastradosDemo(): VeiculoApi[] {
  return veiculosCadastrados;
}

export const apiDemo = {
  async entrar(_email: string, _senha: string) {
    const sessao = sessaoDemo();
    guardarSessao(sessao);
    return sessao;
  },
  async sair() {
    guardarSessao(null);
  },
  async recuperarSenha(email: string) {
    return { enviado: true, mensagem: `Código enviado para ${email}.`, codigoDemo: "123456" };
  },
  async verificarCodigoRecuperacao(_email: string, _codigo: string) {
    return { valido: true };
  },
  async novaSenha(_email: string, _codigo: string, _senha: string) {
    return { alterada: true };
  },
  async eu() {
    return { usuario: sessaoDemo().usuario, empresa: sessaoDemo().empresa, permissoes: ["*"] };
  },

  async painel(dias = 30) {
    const lista = noPeriodo(dias);
    const r = resumoDe(lista);
    const hoje = new Date();
    const serie = Array.from({ length: dias }, (_, i) => {
      const d = new Date(hoje);
      d.setDate(hoje.getDate() - (dias - 1 - i));
      const dia = lista.filter((x) => iso(x.data) === iso(d));
      return {
        dia: iso(d),
        operacoes: dia.length,
        concluidas: dia.length,
        normais: dia.filter((x) => x.status === "normal").length,
        atencao: dia.filter((x) => x.status === "atencao" || x.status === "analise").length,
        criticas: dia.filter((x) => x.status === "critico").length,
        carga_kg: dia.reduce((s, x) => s + x.carga, 0),
        desvio_pct: dia.length
          ? +(dia.reduce((s, x) => s + Math.abs(((x.real - x.esperado) / x.esperado) * 100), 0) / dia.length).toFixed(2)
          : null,
      };
    });
    const porProduto = new Map<string, { operacoes: number; toneladas: number }>();
    const porPlaca = new Map<string, { viagens: number; toneladas: number }>();
    lista.forEach((x) => {
      const p = porProduto.get(x.produto) ?? { operacoes: 0, toneladas: 0 };
      p.operacoes += 1;
      p.toneladas += x.real / 1000;
      porProduto.set(x.produto, p);
      const v = porPlaca.get(x.placa) ?? { viagens: 0, toneladas: 0 };
      v.viagens += 1;
      v.toneladas += x.real / 1000;
      porPlaca.set(x.placa, v);
    });
    const abertos = alertas.filter((a) => a.situacao !== "RESOLVED");
    return {
      periodo: { inicio: iso(new Date(Date.now() - dias * DIA)), fim: iso(hoje), dias },
      kpis: {
        operacoes: r.operacoes,
        concluidas: r.concluidas,
        emAndamento: 0,
        canceladas: 0,
        normais: r.normais,
        atencao: r.atencao,
        criticas: r.criticas,
        toneladas: r.toneladas,
        mediaCargaKg: r.mediaCargaKg,
        mediaBrutoT: +(r.toneladas / Math.max(1, r.operacoes)).toFixed(2),
        desvioMedioPct: r.desvioMedioPct,
        eficienciaPct: r.eficienciaPct,
      },
      rastreio: { em_transito: 3, parados: 0, sem_sinal: 0 },
      alertas: { abertos: abertos.length, criticos_abertos: abertos.filter((a) => a.nivel === "CRITICAL").length },
      serie,
      porTipoCarga: [...porProduto.entries()].map(([produto, p]) => ({
        produto,
        operacoes: p.operacoes,
        toneladas: +p.toneladas.toFixed(1),
      })),
      topVeiculos: [...porPlaca.entries()]
        .map(([plate, v]) => ({ plate, viagens: v.viagens, toneladas: +v.toneladas.toFixed(1) }))
        .sort((a, b) => b.viagens - a.viagens)
        .slice(0, 5),
      frota: { total: PLACAS.length, em_rota: 3, disponiveis: PLACAS.length - 3 },
      alertasAbertos: abertos.slice(0, 5),
    };
  },

  async operacoes(consulta = "") {
    const params = new URLSearchParams(consulta.replace(/^&/, ""));
    const status = params.get("status");
    const busca = (params.get("busca") ?? "").toLowerCase();
    const limite = Number(params.get("limite") ?? 200);
    let lista = registros.map(paraOperacao);
    if (status) lista = lista.filter((o) => o.status === status);
    if (busca)
      lista = lista.filter((o) => `${o.codigo} ${o.veiculo.placa} ${o.motorista}`.toLowerCase().includes(busca));
    return { operacoes: lista.slice(0, limite), total: lista.length };
  },

  async rastreioAtivo() {
    return { viagens: viagensDemo() };
  },

  async alertas(_consulta = "") {
    const abertos = alertas.filter((a) => a.situacao !== "RESOLVED").length;
    const criticos = alertas.filter((a) => a.nivel === "CRITICAL" && a.situacao !== "RESOLVED").length;
    return { alertas: alertas.slice(), total: alertas.length, abertos, criticos };
  },
  async reconhecerAlerta(id: number) {
    return alteraAlerta(id, (a) => ({ ...a, situacao: "ACKNOWLEDGED", reconhecidoEm: agoraIso() }));
  },
  async reabrirAlerta(id: number) {
    return alteraAlerta(id, (a) => ({ ...a, situacao: "OPEN", resolvidoEm: null, notasResolucao: null }));
  },
  async resolverAlerta(id: number, notas?: string) {
    return alteraAlerta(id, (a) => ({
      ...a,
      situacao: "RESOLVED",
      resolvidoEm: agoraIso(),
      notasResolucao: notas ?? null,
    }));
  },

  async veiculos() {
    return {
      veiculos: [...veiculosDemoBase(), ...veiculosCadastradosDemo().map((v) => ({ ...v, total_operacoes: 0 }))],
    };
  },
  async criarVeiculo(corpo: Record<string, unknown>) {
    const erro = erroCorpoCaminhao(corpo);
    if (erro) throw new ErroApi(422, erro);
    const placa = String(corpo.placa);
    const todos = [...veiculosDemoBase(), ...veiculosCadastradosDemo()];
    if (todos.some((v) => v.plate === placa)) throw new ErroApi(409, "Já existe um caminhão com esta placa.");
    const frota = typeof corpo.frota === "string" ? corpo.frota : null;
    if (frota && todos.some((v) => v.fleet_code === frota)) {
      throw new ErroApi(409, "Já existe um caminhão com este código de frota.");
    }
    const rfidCodigo = typeof corpo.rfid === "string" ? corpo.rfid : null;
    if (rfidCodigo && todos.some((v) => v.rfid_code === rfidCodigo)) {
      throw new ErroApi(409, "Esta etiqueta RFID já está vinculada a outro caminhão.");
    }
    const id = proximoId++;
    const novo: VeiculoApi & { total_operacoes: number } = {
      id,
      plate: placa,
      fleet_code: frota,
      vehicle_type: TIPO_LEGIVEL[String(corpo.tipo ?? "TRUCK")] ?? "Caminhão",
      manufacturer: typeof corpo.fabricante === "string" ? corpo.fabricante : null,
      model: typeof corpo.modelo === "string" ? corpo.modelo : null,
      manufacture_year: typeof corpo.anoFabricacao === "number" ? corpo.anoFabricacao : null,
      axle_count: typeof corpo.eixos === "number" ? corpo.eixos : null,
      registered_tare_kg: typeof corpo.taraKg === "number" ? corpo.taraKg : null,
      gross_weight_limit_kg: typeof corpo.limitePbtKg === "number" ? corpo.limitePbtKg : null,
      payload_limit_kg: typeof corpo.limiteCargaKg === "number" ? corpo.limiteCargaKg : null,
      active: 1,
      rfid_id: rfidCodigo ? id : null,
      rfid_code: rfidCodigo,
      total_operacoes: 0,
    };
    veiculosCadastrados = [...veiculosCadastrados, novo];
    return novo;
  },
  async motoristas() {
    return {
      motoristas: MOTORISTAS.map((full_name, i) => ({
        id: i + 1,
        full_name,
        employee_code: `M-${String(i + 1).padStart(3, "0")}`,
        license_number: `0${4000 + i * 37}`,
        license_category: "E",
        phone: null,
      })),
    };
  },
  async produtos() {
    return {
      produtos: PRODUTOS.map((name, i) => ({
        id: i + 1,
        code: `P-${String(i + 1).padStart(2, "0")}`,
        name,
        default_unit: "kg",
      })),
    };
  },
  async rotas() {
    return {
      rotas: CIDADES.map((origin, i) => {
        const destination = CIDADES[(i + 3) % CIDADES.length];
        return {
          id: i + 1,
          code: `R-${String(i + 1).padStart(2, "0")}`,
          origin,
          destination,
          distance_km: 180 + i * 35,
          waypoints: [
            {
              sequence_number: 1,
              waypoint_type: "ORIGIN",
              label: origin,
              latitude: COORD[origin][0],
              longitude: COORD[origin][1],
            },
            {
              sequence_number: 2,
              waypoint_type: "DESTINATION",
              label: destination,
              latitude: COORD[destination][0],
              longitude: COORD[destination][1],
            },
          ] as WaypointApi[],
        };
      }),
    };
  },
  async dispositivos() {
    const agora = agoraIso();
    const base = {
      serial_number: null,
      firmware_version: "2.4.1",
      state: "ONLINE",
      last_seen_at: agora,
      last_calibrated_at: agora,
      calibrado_em: agora,
      calibracao_valida_ate: new Date(Date.now() + 83 * DIA).toISOString(),
      unidade: "Curitiba",
    };
    return {
      dispositivos: [
        { id: 1, name: "ESP32 · Balança 01", device_type: "ESP32", ...base },
        { id: 2, name: "HX711 · Célula de carga", device_type: "LOAD_CELL", ...base },
        { id: 3, name: "Leitor RFID", device_type: "RFID_READER", ...base },
      ] as never,
      resumo: { online: 3, offline: 0, manutencao: 0, desativados: 0 },
    };
  },
  async configuracoes() {
    return { configuracoes: { ...configuracoes } };
  },
  async atualizarConfiguracoes(corpo: Record<string, unknown>) {
    configuracoes = { ...configuracoes, ...corpo };
    return { configuracoes: { ...configuracoes } };
  },

  async resumoRelatorio(dias = 30) {
    const hoje = new Date();
    return {
      periodo: { inicio: iso(new Date(Date.now() - dias * DIA)), fim: iso(hoje) },
      resumo: resumoDe(noPeriodo(dias)),
    };
  },
  async relatorios() {
    return { relatorios: relatorios.slice() };
  },
  async gerarRelatorio(corpo: Record<string, unknown>) {
    const dias = corpo.tipo === "mensal" ? 30 : corpo.tipo === "semanal" ? 7 : 1;
    const salvo: RelatorioApi = {
      id: proximoId++,
      tipo: String(corpo.tipo ?? "personalizado"),
      inicio: String(corpo.inicio ?? iso(new Date(Date.now() - dias * DIA))),
      fim: String(corpo.fim ?? iso(new Date())),
      formato: "PDF",
      geradoEm: agoraIso(),
      geradoPor: "Administrador LoadSense",
      resumo: {
        ...resumoDe(noPeriodo(dias)),
        ...(typeof corpo.titulo === "string" ? { titulo: corpo.titulo } : {}),
        ...(typeof corpo.periodo === "string" ? { periodo: corpo.periodo } : {}),
      } as ResumoApi,
      recomendacoes: typeof corpo.recomendacoes === "string" ? corpo.recomendacoes : null,
    };
    relatorios = [salvo, ...relatorios];
    return salvo;
  },

  async criarOperacao(corpo: Record<string, unknown>) {
    const id = proximoId++;
    const placa = String(corpo.placa ?? PLACAS[0]);
    const motorista = String(corpo.motorista ?? MOTORISTAS[0]);
    const r: RegistroDemo = {
      id,
      codigo: "OP-" + String(id).padStart(4, "0"),
      placa,
      motorista,
      rfid: String(corpo.rfid ?? rfid(0)),
      produto: PRODUTOS[Math.max(0, Number(corpo.produtoId ?? 1) - 1)] ?? PRODUTOS[0],
      responsavel: "Administrador LoadSense",
      origem: CIDADES[0],
      destino: CIDADES[3],
      data: new Date(),
      vazio: 0,
      carga: 0,
      esperado: 0,
      real: 0,
      status: "analise",
      declarado: corpo.pesoDeclaradoKg ? Number(corpo.pesoDeclaradoKg) : null,
      observacao: String(corpo.observacoes ?? ""),
    };
    registros = [r, ...registros];
    return paraOperacao(r);
  },
  async registrarLeitura(operacaoId: number, corpo: Record<string, unknown>) {
    const r = registros.find((x) => x.id === operacaoId);
    if (r) {
      if (corpo.estagio === "EMPTY_TRUCK") r.vazio = Number(corpo.pesoKg);
      if (corpo.estagio === "LOADED_TRUCK") r.real = Number(corpo.pesoKg);
    }
    return {
      id: Date.now(),
      estagio: corpo.estagio,
      sequencia: 1,
      pesoKg: Number(corpo.pesoKg),
      origem: "MANUAL",
      estavel: true,
      aceita: true,
      medidoEm: agoraIso(),
    };
  },
  async finalizarOperacao(operacaoId: number) {
    const r = registros.find((x) => x.id === operacaoId);
    if (!r) throw new Error("Operação não encontrada.");
    r.carga = r.real - r.vazio;
    r.esperado = r.declarado ?? r.real;
    const dif = r.real - r.esperado;
    const pct = +((dif / r.esperado) * 100).toFixed(2);
    r.status = classificar(pct);
    const novos: AlertaApi[] = [];
    if (r.status !== "normal") {
      const alerta = {
        id: proximoId++,
        operacaoId: r.id,
        operacaoCodigo: r.codigo,
        contexto: "WEIGHING",
        tipo: motivoAlerta(dif, pct),
        nivel: NIVEL[r.status],
        situacao: "OPEN",
        titulo: motivoAlerta(dif, pct),
        mensagem: `${motivoAlerta(dif, pct)} na operação ${r.codigo}.`,
        desvioKg: dif,
        desvioPct: pct,
        veiculo: r.placa,
        motorista: r.motorista,
        criadoEm: agoraIso(),
      } as AlertaApi;
      alertas = [alerta, ...alertas];
      novos.push(alerta);
    }
    return { operacao: paraOperacao(r), alertas: novos };
  },
};

function alteraAlerta(id: number, fn: (a: AlertaApi) => AlertaApi): AlertaApi {
  const indice = alertas.findIndex((a) => a.id === id);
  if (indice < 0) throw new Error("Alerta não encontrado.");
  alertas = alertas.map((a, i) => (i === indice ? fn(a) : a));
  return alertas[indice];
}
