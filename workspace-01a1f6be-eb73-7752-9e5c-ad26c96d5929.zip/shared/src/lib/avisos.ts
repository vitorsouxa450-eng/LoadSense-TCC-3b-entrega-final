export type PermissaoAviso = NotificationPermission | "indisponivel";

export function permissaoAviso(): PermissaoAviso {
  if (typeof window === "undefined" || !("Notification" in window)) return "indisponivel";
  return Notification.permission;
}

export async function pedirPermissaoAviso(): Promise<PermissaoAviso> {
  if (permissaoAviso() !== "default") return permissaoAviso();
  try {
    return await Notification.requestPermission();
  } catch {
    return permissaoAviso();
  }
}

export function avisoDoSistema(titulo: string, corpo: string) {
  if (permissaoAviso() !== "granted") return;
  try {
    new Notification(titulo, { body: corpo, tag: "loadsense-alerta" });
  } catch {}
}

let contexto: AudioContext | null = null;

export function tocarSomAlerta() {
  try {
    const Ctx =
      window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    contexto ??= new Ctx();
    if (contexto.state === "suspended") void contexto.resume();
    const agora = contexto.currentTime;
    [0, 0.22].forEach((atraso) => {
      const osc = contexto!.createOscillator();
      const ganho = contexto!.createGain();
      osc.type = "sine";
      osc.frequency.value = 880;
      ganho.gain.setValueAtTime(0.0001, agora + atraso);
      ganho.gain.exponentialRampToValueAtTime(0.25, agora + atraso + 0.02);
      ganho.gain.exponentialRampToValueAtTime(0.0001, agora + atraso + 0.16);
      osc.connect(ganho).connect(contexto!.destination);
      osc.start(agora + atraso);
      osc.stop(agora + atraso + 0.18);
    });
  } catch {}
}
