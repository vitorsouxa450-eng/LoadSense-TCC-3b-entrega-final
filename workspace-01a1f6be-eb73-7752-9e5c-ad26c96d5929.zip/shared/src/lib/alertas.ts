export const MOTIVOS_RESOLUCAO = [
  {
    codigo: "FALSO_POSITIVO",
    rotulo: "Falso positivo",
    descricao: "A leitura ou o cálculo estava incorreto e não houve divergência real.",
  },
  {
    codigo: "CARGA_CORRIGIDA",
    rotulo: "Carga corrigida",
    descricao: "A carga foi ajustada ou houve nova pesagem.",
  },
  {
    codigo: "DIVERGENCIA_JUSTIFICADA",
    rotulo: "Divergência justificada",
    descricao: "A diferença tem explicação aceita, como umidade, perda técnica ou quebra.",
  },
  {
    codigo: "DOCUMENTO_REGULARIZADO",
    rotulo: "Documento regularizado",
    descricao: "NF-e, MDF-e ou CIOT foram corrigidos ou emitidos.",
  },
  {
    codigo: "EQUIPAMENTO_NORMALIZADO",
    rotulo: "Equipamento normalizado",
    descricao: "A balança, o sensor ou o rastreador voltou a funcionar.",
  },
  {
    codigo: "OPERACAO_ENCERRADA",
    rotulo: "Operação encerrada",
    descricao: "A operação foi concluída ou cancelada.",
  },
  {
    codigo: "OUTRO",
    rotulo: "Outro",
    descricao: "Descreva a resolução no campo de ação.",
  },
] as const;

export type CodigoMotivo = (typeof MOTIVOS_RESOLUCAO)[number]["codigo"];

export const MOTIVO_EM_LOTE = "EM_LOTE";
export const ROTULO_EM_LOTE = "Resolvido em lote";

export const ACAO_MINIMA = 10;

export interface ResolucaoAlerta {
  motivo: CodigoMotivo;
  acao: string;
}

export function rotuloMotivo(codigo?: string | null): string {
  if (!codigo) return "";
  if (codigo === MOTIVO_EM_LOTE) return ROTULO_EM_LOTE;
  return MOTIVOS_RESOLUCAO.find((m) => m.codigo === codigo)?.rotulo ?? codigo;
}

export function validarResolucao(entrada: { motivo?: string | null; acao?: string | null }): string | null {
  if (!MOTIVOS_RESOLUCAO.some((m) => m.codigo === entrada.motivo)) return "Escolha o motivo da resolução.";
  if ((entrada.acao ?? "").trim().length < ACAO_MINIMA)
    return `Descreva como o alerta foi resolvido (mínimo de ${ACAO_MINIMA} caracteres).`;
  return null;
}
