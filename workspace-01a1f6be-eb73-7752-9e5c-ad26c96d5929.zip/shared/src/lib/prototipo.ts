import type { OperacaoApi, RastreioApi } from "./api";

export const ROTULO_STATUS: Record<OperacaoApi["status"], string> = {
  NORMAL: "Normal",
  ATTENTION: "Atenção",
  CRITICAL: "Crítico",
  ANALYSIS: "Análise",
};

export const CLASSE_STATUS: Record<OperacaoApi["status"], string> = {
  NORMAL: "text-success border-success/40 bg-success/10",
  ATTENTION: "text-warning border-warning/40 bg-warning/10",
  CRITICAL: "text-destructive border-destructive/40 bg-destructive/10",
  ANALYSIS: "text-primary border-primary/40 bg-primary/10",
};

export const CLASSE_TEXTO_STATUS: Record<OperacaoApi["status"], string> = {
  NORMAL: "text-success",
  ATTENTION: "text-warning",
  CRITICAL: "text-destructive",
  ANALYSIS: "text-primary",
};

export const FILTROS_STATUS = ["Todos", "Normal", "Atenção", "Crítico", "Análise"] as const;

export function kg(valor: number | null | undefined): string {
  return valor == null ? "—" : Math.round(valor).toLocaleString("pt-BR");
}

export function difKg(valor: number | null | undefined): string {
  if (valor == null) return "—";
  return (valor > 0 ? "+" : "") + Math.round(valor).toLocaleString("pt-BR");
}

export function difPct(valor: number | null | undefined): string {
  if (valor == null) return "—";
  return (valor > 0 ? "+" : "") + valor.toFixed(2) + "%";
}

export function dataHora(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}, ${p(d.getHours())}:${p(d.getMinutes())}`;
}

export function horaCurta(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

export function rotuloRastreio(rastreio: RastreioApi | null | undefined): string {
  switch (rastreio?.estado) {
    case "IN_TRANSIT":
      return "Em trânsito";
    case "NOT_STARTED":
      return "Em andamento";
    case "STOPPED":
      return "Parado";
    case "ARRIVED":
      return "Chegou";
    case "SIGNAL_LOST":
      return "Sem sinal";
    default:
      return "Em rota";
  }
}

export const CLASSE_RASTREIO: Record<string, string> = {
  "Em trânsito": "text-success",
  "Em andamento": "text-warning",
  Parado: "text-warning",
  Chegou: "text-success",
  "Sem sinal": "text-destructive",
  "Em rota": "text-success",
};

export const MAPA = { oeste: -55.2, leste: -48.5, sul: -26.8, norte: -22.6 };

const mercator = (lat: number) => Math.log(Math.tan(Math.PI / 4 + (lat * Math.PI) / 360));

export const PROPORCAO_MAPA = ((MAPA.leste - MAPA.oeste) * Math.PI) / 180 / (mercator(MAPA.norte) - mercator(MAPA.sul));

export function posicaoNoMapa(lat: number, lon: number): { x: number; y: number } {
  const x = ((lon - MAPA.oeste) / (MAPA.leste - MAPA.oeste)) * 100;
  const y = ((mercator(MAPA.norte) - mercator(lat)) / (mercator(MAPA.norte) - mercator(MAPA.sul))) * 100;
  return { x, y };
}

export const URL_MAPA_OSM = `https://www.openstreetmap.org/export/embed.html?bbox=${MAPA.oeste}%2C${MAPA.sul}%2C${MAPA.leste}%2C${MAPA.norte}&layer=mapnik`;

export function baixarCsv(nome: string, linhas: (string | number)[][]) {
  const conteudo = linhas.map((l) => l.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(";")).join("\n");
  const blob = new Blob(["\ufeff" + conteudo], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = nome;
  a.click();
  URL.revokeObjectURL(url);
}

export interface ParametrosPlanilha {
  pagina: number;
  limite: number;
  busca: string;
  status: "" | OperacaoApi["status"];
  ordem: string;
  direcao: "asc" | "desc";
}

export interface ResultadoPlanilha {
  operacoes: OperacaoApi[];
  total: number;
}

const VALOR_ORDEM: Record<string, (o: OperacaoApi) => string | number> = {
  data: (o) => new Date(o.datas.iniciadaEm ?? o.datas.saidaReal ?? 0).getTime(),
  codigo: (o) => o.codigo,
  placa: (o) => o.veiculo.placa ?? "",
  motorista: (o) => o.motorista ?? "",
  rfid: (o) => o.rfid ?? "",
  status: (o) => o.status,
  vazio: (o) => o.pesos.vazioAferidoKg ?? 0,
  carga: (o) => o.pesos.cargaAferidaKg ?? 0,
  esperado: (o) => o.pesos.brutoEsperadoKg ?? 0,
  real: (o) => o.pesos.brutoAferidoKg ?? 0,
  difKg: (o) => o.pesos.desvioKg ?? 0,
  difPct: (o) => o.pesos.desvioPct ?? 0,
};

export function consultarLocal(operacoes: OperacaoApi[], p: ParametrosPlanilha): ResultadoPlanilha {
  const termo = p.busca.trim().toLowerCase();
  const filtradas = operacoes
    .filter((o) => !p.status || o.status === p.status)
    .filter(
      (o) =>
        !termo ||
        `${o.codigo} ${o.veiculo.placa ?? ""} ${o.motorista ?? ""} ${o.rfid ?? ""}`.toLowerCase().includes(termo),
    );
  const valor = VALOR_ORDEM[p.ordem] ?? VALOR_ORDEM.data;
  const sentido = p.direcao === "asc" ? 1 : -1;
  const ordenadas = [...filtradas].sort((a, b) => {
    const va = valor(a);
    const vb = valor(b);
    return (va > vb ? 1 : va < vb ? -1 : 0) * sentido;
  });
  const inicio = (p.pagina - 1) * p.limite;
  return { operacoes: ordenadas.slice(inicio, inicio + p.limite), total: filtradas.length };
}

export function queryPlanilha(p: ParametrosPlanilha): string {
  const q = new URLSearchParams({
    pagina: String(p.pagina),
    limite: String(p.limite),
    ordem: p.ordem,
    direcao: p.direcao,
  });
  if (p.busca.trim()) q.set("busca", p.busca.trim());
  if (p.status) q.set("status", p.status);
  return q.toString();
}
