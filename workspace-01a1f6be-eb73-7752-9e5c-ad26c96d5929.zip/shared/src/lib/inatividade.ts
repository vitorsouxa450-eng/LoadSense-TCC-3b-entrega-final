import { useEffect, useRef } from "react";

export function useInatividade(ativo: boolean, aoExpirar: () => void, minutos = 30) {
  const aoExpirarRef = useRef(aoExpirar);
  aoExpirarRef.current = aoExpirar;

  useEffect(() => {
    if (!ativo) return;
    const limite = minutos * 60_000;
    let timer = window.setTimeout(() => aoExpirarRef.current(), limite);
    const reiniciar = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => aoExpirarRef.current(), limite);
    };
    const eventos = ["pointerdown", "keydown", "mousemove", "touchstart", "scroll"] as const;
    eventos.forEach((e) => window.addEventListener(e, reiniciar, { passive: true }));
    return () => {
      window.clearTimeout(timer);
      eventos.forEach((e) => window.removeEventListener(e, reiniciar));
    };
  }, [ativo, minutos]);
}
