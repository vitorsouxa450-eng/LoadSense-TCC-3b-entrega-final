const env = import.meta.env as Record<string, string | undefined>;

export const MAPA_TILES = {
  url: env.VITE_MAPA_TILES_URL || "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
  atribuicao: env.VITE_MAPA_ATRIBUICAO || '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  maxZoom: 18,
};
