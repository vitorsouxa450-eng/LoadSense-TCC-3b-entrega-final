import { useEffect, useMemo, useState } from "react";
import { api } from "../lib/api";

export interface PontoRota {
  sequence_number: number;
  latitude: number | string;
  longitude: number | string;
}

export interface RotaEscolhivel {
  id: number;
  origem: string;
  destino: string;
  km: number | null;
  waypoints?: PontoRota[];
}

type Estimativa = { km: number | null; min: number | null; fonte: "OSRM" | "LINHA_RETA" | null };

export function RotaPorDestino({
  rotas,
  valor,
  onChange,
  erro,
}: {
  rotas: RotaEscolhivel[];
  valor: number | null;
  onChange: (rotaId: number) => void;
  erro?: string;
}) {
  const destinos = useMemo(() => [...new Set(rotas.map((r) => r.destino))], [rotas]);
  const rotaAtual = rotas.find((r) => r.id === valor) ?? null;
  const [destino, setDestino] = useState<string>(rotaAtual?.destino ?? destinos[0] ?? "");
  const [estimativas, setEstimativas] = useState<Record<number, Estimativa>>({});

  const opcoes = useMemo(() => rotas.filter((r) => r.destino === destino), [rotas, destino]);

  useEffect(() => {
    if (!destino && destinos.length) setDestino(destinos[0]);
    if (opcoes.length && !opcoes.some((r) => r.id === valor)) onChange(opcoes[0].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [destino, rotas]);

  useEffect(() => {
    let ativo = true;
    opcoes.forEach((r) => {
      const pontos = [...(r.waypoints ?? [])].sort((a, b) => a.sequence_number - b.sequence_number);
      if (pontos.length < 2 || estimativas[r.id]) return;
      const origem = pontos[0];
      const fim = pontos[pontos.length - 1];
      api
        .rotasAlternativas({
          latO: Number(origem.latitude),
          lonO: Number(origem.longitude),
          latD: Number(fim.latitude),
          lonD: Number(fim.longitude),
        })
        .then(({ opcoes: lista }) => {
          const melhor = lista[0];
          if (ativo && melhor) {
            setEstimativas((antes) => ({
              ...antes,
              [r.id]: { km: melhor.distanciaKm, min: melhor.duracaoMin, fonte: melhor.fonte },
            }));
          }
        })
        .catch(() => undefined);
    });
    return () => {
      ativo = false;
    };
  }, [opcoes, estimativas]);

  if (rotas.length === 0) return <p className="text-[13px] text-slate-500">Nenhuma rota cadastrada.</p>;

  return (
    <div className="space-y-3">
      <label className="block text-[12px] font-medium text-slate-600">
        Destino
        <select
          className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-[13px]"
          value={destino}
          onChange={(e) => setDestino(e.target.value)}
        >
          {destinos.map((d) => (
            <option key={d} value={d}>
              {d}
            </option>
          ))}
        </select>
      </label>

      <fieldset>
        <legend className="mb-1 text-[12px] font-medium text-slate-600">Rota até {destino}</legend>
        <div className="space-y-2">
          {opcoes.map((r) => {
            const est = estimativas[r.id];
            const km = est?.km ?? r.km;
            const tempo =
              est?.min != null
                ? `${Math.round(est.min)} min${est.fonte === "LINHA_RETA" ? " (linha reta, estimativa)" : ""}`
                : "tempo indisponível";
            return (
              <label
                key={r.id}
                className={`flex cursor-pointer items-start gap-3 rounded-md border p-3 text-[13px] ${
                  valor === r.id ? "border-slate-900 bg-slate-50" : "border-slate-200"
                }`}
              >
                <input
                  type="radio"
                  name="rota-por-destino"
                  className="mt-1"
                  checked={valor === r.id}
                  onChange={() => onChange(r.id)}
                />
                <span>
                  <span className="block font-medium text-slate-800">
                    {r.origem} → {r.destino}
                  </span>
                  <span className="block text-slate-600">
                    {km != null ? `${Number(km).toFixed(1).replace(".", ",")} km` : "distância não cadastrada"} ·{" "}
                    {tempo}
                  </span>
                </span>
              </label>
            );
          })}
        </div>
      </fieldset>
      {erro && <p className="text-[12px] text-red-600">{erro}</p>}
    </div>
  );
}
