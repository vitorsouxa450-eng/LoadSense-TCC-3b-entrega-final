import { useEffect, useState } from "react";
import { chaveGuia, type PassoGuia, type PlataformaAjuda } from "../../lib/ajuda";

export function guiaJaVisto(plataforma: PlataformaAjuda): boolean {
  try {
    return window.localStorage.getItem(chaveGuia(plataforma)) === "1";
  } catch {
    return true;
  }
}

function marcarGuiaVisto(plataforma: PlataformaAjuda) {
  try {
    window.localStorage.setItem(chaveGuia(plataforma), "1");
  } catch {}
}

export function GuiaPrimeirosPassos({
  plataforma,
  passos,
  aberto,
  onFechar,
}: {
  plataforma: PlataformaAjuda;
  passos: PassoGuia[];
  aberto: boolean;
  onFechar: () => void;
}) {
  const [indice, setIndice] = useState(0);

  useEffect(() => {
    if (aberto) setIndice(0);
  }, [aberto]);

  useEffect(() => {
    if (!aberto) return;
    const aoTeclar = (e: KeyboardEvent) => {
      if (e.key === "Escape") fechar();
    };
    window.addEventListener("keydown", aoTeclar);
    return () => window.removeEventListener("keydown", aoTeclar);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aberto]);

  if (!aberto || passos.length === 0) return null;

  function fechar() {
    marcarGuiaVisto(plataforma);
    onFechar();
  }

  const ultimo = indice === passos.length - 1;
  const passo = passos[indice];

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4"
      role="presentation"
      onClick={(e) => {
        if (e.target === e.currentTarget) fechar();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="guia-titulo"
        className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-xl"
      >
        <div className="mb-4 flex items-center justify-between text-[11px] text-muted-foreground">
          <span>
            Passo {indice + 1} de {passos.length}
          </span>
          <button type="button" onClick={fechar} className="underline underline-offset-2">
            Pular guia
          </button>
        </div>

        <h2 id="guia-titulo" className="text-[18px] font-bold">
          {passo.titulo}
        </h2>
        <p className="mt-3 text-[14px] leading-relaxed text-muted-foreground">{passo.texto}</p>

        <div className="mt-5 flex justify-center gap-1.5" aria-hidden="true">
          {passos.map((_, i) => (
            <span key={i} className={`h-1.5 rounded-full ${i === indice ? "w-5 bg-primary" : "w-1.5 bg-border"}`} />
          ))}
        </div>

        <div className="mt-6 flex gap-2">
          <button
            type="button"
            onClick={() => setIndice((i) => Math.max(0, i - 1))}
            disabled={indice === 0}
            className="flex-1 rounded-xl border border-border py-2.5 text-[13px] font-semibold disabled:opacity-40"
          >
            Anterior
          </button>
          {ultimo ? (
            <button
              type="button"
              onClick={fechar}
              className="flex-1 rounded-xl bg-primary py-2.5 text-[13px] font-semibold text-primary-foreground"
            >
              Concluir
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setIndice((i) => Math.min(passos.length - 1, i + 1))}
              className="flex-1 rounded-xl bg-primary py-2.5 text-[13px] font-semibold text-primary-foreground"
            >
              Próximo
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
