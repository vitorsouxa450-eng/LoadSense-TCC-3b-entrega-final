import type { Funcao } from "../../lib/ajuda";

export function AjudaFuncionalidades({ funcoes }: { funcoes: Funcao[] }) {
  return (
    <ul className="divide-y divide-border/60 overflow-hidden rounded-2xl border border-border/60 bg-card">
      {funcoes.map((f) => (
        <li key={f.id}>
          <details className="group p-4">
            <summary className="flex cursor-pointer list-none items-start justify-between gap-3">
              <span>
                <span className="block text-[14px] font-semibold">{f.nome}</span>
                <span className="mt-0.5 block text-[12px] text-muted-foreground">{f.paraQueServe}</span>
              </span>
              <span aria-hidden="true" className="text-muted-foreground transition-transform group-open:rotate-90">
                ›
              </span>
            </summary>
            <div className="mt-3 space-y-2">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Como usar</p>
              <ul className="list-disc space-y-1 pl-5 text-[13px] leading-relaxed">
                {f.comoUsar.map((passo) => (
                  <li key={passo}>{passo}</li>
                ))}
              </ul>
              <p className="text-[12px] text-muted-foreground">
                <span className="font-semibold">Onde fica:</span> {f.onde}
              </p>
            </div>
          </details>
        </li>
      ))}
    </ul>
  );
}
