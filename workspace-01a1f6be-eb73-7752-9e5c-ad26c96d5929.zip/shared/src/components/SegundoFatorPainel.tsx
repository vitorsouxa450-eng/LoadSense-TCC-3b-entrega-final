import { useEffect, useState, type FormEvent } from "react";
import { api, ErroApi } from "../lib/api";

export function SegundoFatorPainel() {
  const [carregando, setCarregando] = useState(true);
  const [ativo, setAtivo] = useState(false);
  const [ativoDesde, setAtivoDesde] = useState<string | null>(null);
  const [enviado, setEnviado] = useState<{ emailMascarado: string; codigoDemo?: string } | null>(null);
  const [codigo, setCodigo] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [aviso, setAviso] = useState<string | null>(null);
  const [enviando, setEnviando] = useState(false);

  async function carregar() {
    setCarregando(true);
    try {
      const estado = await api.totp.estado();
      setAtivo(estado.ativo);
      setAtivoDesde(estado.ativoDesde);
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => {
    void carregar();
  }, []);

  async function enviarParaAtivar() {
    setErro(null);
    setAviso(null);
    setEnviando(true);
    try {
      setEnviado(await api.totp.enviarCodigoAtivacao());
      setCodigo("");
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setEnviando(false);
    }
  }

  async function enviarParaDesativar() {
    setErro(null);
    setAviso(null);
    if (!senha) return setErro("Informe sua senha atual antes de pedir o código.");
    setEnviando(true);
    try {
      setEnviado(await api.totp.enviarCodigoDesativacao());
      setCodigo("");
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setEnviando(false);
    }
  }

  async function ativar(evento: FormEvent) {
    evento.preventDefault();
    setErro(null);
    if (!/^\d{6}$/.test(codigo.replace(/\s/g, ""))) return setErro("Digite os 6 números enviados para o seu e-mail.");
    setEnviando(true);
    try {
      await api.totp.ativar(codigo.replace(/\s/g, ""));
      setEnviado(null);
      setCodigo("");
      setAviso("Verificação em duas etapas ativada. No próximo login, o código será enviado para o seu e-mail.");
      await carregar();
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setEnviando(false);
    }
  }

  async function desativar(evento: FormEvent) {
    evento.preventDefault();
    setErro(null);
    if (!senha) return setErro("Informe sua senha atual.");
    if (!/^\d{6}$/.test(codigo.replace(/\s/g, ""))) return setErro("Digite o código enviado para o seu e-mail.");
    setEnviando(true);
    try {
      await api.totp.desativar(senha, codigo.replace(/\s/g, ""));
      setSenha("");
      setCodigo("");
      setEnviado(null);
      setAviso("Verificação em duas etapas desativada.");
      await carregar();
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setEnviando(false);
    }
  }

  const campo =
    "w-full rounded-xl border border-border/60 bg-background px-3 py-2.5 text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-primary";
  const botao =
    "flex w-full items-center justify-center rounded-xl bg-primary py-2.5 text-[13px] font-semibold text-primary-foreground disabled:opacity-60";

  if (carregando) return <p className="text-[12px] text-muted-foreground">Carregando segurança da conta…</p>;

  const avisoEnvio = enviado && (
    <p role="status" className="rounded-xl bg-primary/10 px-3 py-2 text-[12px] text-foreground">
      {enviado.codigoDemo ? (
        <>
          Este servidor não envia e-mails. O código de 6 números aparece aqui, nesta máquina:{" "}
          <strong className="tracking-widest">{enviado.codigoDemo}</strong>. Ele vale por 10 minutos e só pode ser usado
          uma vez.
        </>
      ) : (
        <>
          Enviamos um código de 6 números para {enviado.emailMascarado}. Ele vale por 10 minutos e só pode ser usado uma
          vez.
        </>
      )}
    </p>
  );

  return (
    <div className="space-y-3">
      <p className="text-[12px] text-muted-foreground">
        {ativo
          ? `Ativa${ativoDesde ? ` desde ${new Date(ativoDesde).toLocaleDateString("pt-BR")}` : ""}. Um código é enviado para o seu e-mail a cada entrada.`
          : "Quando ativa, um código de 6 números é enviado para o e-mail da sua conta a cada entrada."}
      </p>

      {aviso && (
        <p role="status" className="rounded-xl bg-success/10 px-3 py-2 text-[12px] text-success">
          {aviso}
        </p>
      )}
      {erro && (
        <p role="alert" className="rounded-xl bg-destructive/10 px-3 py-2 text-[12px] text-destructive">
          {erro}
        </p>
      )}

      {!ativo && (
        <form onSubmit={ativar} className="space-y-3">
          {!enviado && (
            <button type="button" onClick={enviarParaAtivar} disabled={enviando} className={botao}>
              Enviar código para o meu e-mail
            </button>
          )}
          {avisoEnvio}
          {enviado && (
            <>
              <label className="block">
                <span className="mb-1 block text-[12px] font-medium">Código de 6 números recebido por e-mail</span>
                <input
                  value={codigo}
                  onChange={(e) => setCodigo(e.target.value)}
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  maxLength={7}
                  className={campo}
                />
              </label>
              <button type="submit" disabled={enviando} className={botao}>
                Confirmar e ativar
              </button>
              <button
                type="button"
                onClick={enviarParaAtivar}
                disabled={enviando}
                className="text-[12px] font-semibold text-primary underline"
              >
                Reenviar código
              </button>
            </>
          )}
        </form>
      )}

      {ativo && (
        <form onSubmit={desativar} className="space-y-3">
          <label className="block">
            <span className="mb-1 block text-[12px] font-medium">Senha atual</span>
            <input
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              autoComplete="current-password"
              className={campo}
            />
          </label>
          {!enviado && (
            <button
              type="button"
              onClick={enviarParaDesativar}
              disabled={enviando}
              className="flex w-full items-center justify-center rounded-xl border border-border/60 py-2.5 text-[13px] font-semibold"
            >
              Enviar código para o meu e-mail
            </button>
          )}
          {avisoEnvio}
          {enviado && (
            <>
              <label className="block">
                <span className="mb-1 block text-[12px] font-medium">Código recebido por e-mail</span>
                <input
                  value={codigo}
                  onChange={(e) => setCodigo(e.target.value)}
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  maxLength={7}
                  className={campo}
                />
              </label>
              <button
                type="submit"
                disabled={enviando}
                className="flex w-full items-center justify-center rounded-xl border border-destructive/40 py-2.5 text-[13px] font-semibold text-destructive disabled:opacity-60"
              >
                Desativar verificação em duas etapas
              </button>
            </>
          )}
        </form>
      )}
    </div>
  );
}

function mensagem(erro: unknown): string {
  if (erro instanceof ErroApi) return erro.message;
  return "Não foi possível falar com o servidor. Tente de novo.";
}
