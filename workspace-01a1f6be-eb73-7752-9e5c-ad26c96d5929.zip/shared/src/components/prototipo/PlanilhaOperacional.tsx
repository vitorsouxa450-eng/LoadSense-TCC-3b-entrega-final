import { useEffect, useState } from "react";
import { ArrowDown, ArrowUp, ArrowUpDown, ChevronLeft, ChevronRight, Download, Upload } from "lucide-react";
import { api, type OperacaoApi } from "../../lib/api";
import { ImportarPlanilha } from "./ImportarPlanilha";
import { DetalheOperacaoModal } from "./DetalheOperacaoModal";
import {
  CLASSE_STATUS,
  CLASSE_TEXTO_STATUS,
  dataHora,
  difKg,
  difPct,
  FILTROS_STATUS,
  kg,
  ROTULO_STATUS,
  type ParametrosPlanilha,
  type ResultadoPlanilha,
} from "../../lib/prototipo";

type Coluna = {
  chave: string;
  rotulo: string;
  valor: (o: OperacaoApi) => string | number;
  ordenavel: boolean;
  alinhar?: "left" | "right";
};

const COLUNAS: Coluna[] = [
  { chave: "codigo", rotulo: "ID", valor: (o) => o.codigo, ordenavel: true },
  {
    chave: "data",
    rotulo: "Data/Hora",
    valor: (o) => dataHora(o.datas.iniciadaEm ?? o.datas.saidaReal),
    ordenavel: true,
  },
  { chave: "placa", rotulo: "Placa", valor: (o) => o.veiculo.placa ?? "—", ordenavel: true },
  { chave: "motorista", rotulo: "Motorista", valor: (o) => o.motorista ?? "—", ordenavel: true },
  { chave: "rfid", rotulo: "RFID", valor: (o) => o.rfid ?? "—", ordenavel: true },
  { chave: "vazio", rotulo: "Vazio (kg)", alinhar: "right", valor: (o) => kg(o.pesos.vazioAferidoKg), ordenavel: true },
  { chave: "carga", rotulo: "Carga (kg)", alinhar: "right", valor: (o) => kg(o.pesos.cargaAferidaKg), ordenavel: true },
  {
    chave: "esperado",
    rotulo: "Esperado (kg)",
    alinhar: "right",
    valor: (o) => kg(o.pesos.brutoEsperadoKg),
    ordenavel: true,
  },
  { chave: "real", rotulo: "Real (kg)", alinhar: "right", valor: (o) => kg(o.pesos.brutoAferidoKg), ordenavel: true },
  { chave: "difKg", rotulo: "Dif. kg", alinhar: "right", valor: (o) => difKg(o.pesos.desvioKg), ordenavel: true },
  { chave: "difPct", rotulo: "Dif. %", alinhar: "right", valor: (o) => difPct(o.pesos.desvioPct), ordenavel: true },
  { chave: "status", rotulo: "Status", valor: (o) => ROTULO_STATUS[o.status], ordenavel: true },
  { chave: "alerta", rotulo: "Alerta", valor: (o) => o.statusMotivo ?? "Sem alerta", ordenavel: false },
  { chave: "responsavel", rotulo: "Responsável", valor: (o) => o.responsavel ?? "—", ordenavel: false },
  { chave: "observacoes", rotulo: "Observações", valor: (o) => o.observacoes ?? "—", ordenavel: false },
];

const POR_PAGINA = 25;
const CODIGO_STATUS: Record<string, ParametrosPlanilha["status"]> = {
  Normal: "NORMAL",
  Atenção: "ATTENTION",
  Crítico: "CRITICAL",
  Análise: "ANALYSIS",
};

export function PlanilhaOperacional({
  buscar,
  titulo = true,
  aoAbrirDetalhe,
}: {
  buscar: (p: ParametrosPlanilha) => Promise<ResultadoPlanilha>;
  titulo?: boolean;
  aoAbrirDetalhe?: (operacao: OperacaoApi) => void;
}) {
  const [filtro, setFiltro] = useState<(typeof FILTROS_STATUS)[number]>("Todos");
  const [busca, setBusca] = useState("");
  const [buscaAplicada, setBuscaAplicada] = useState("");
  const [ordem, setOrdem] = useState<{ chave: string; direcao: "asc" | "desc" }>({ chave: "codigo", direcao: "desc" });
  const [pagina, setPagina] = useState(1);
  const [resultado, setResultado] = useState<ResultadoPlanilha>({ operacoes: [], total: 0 });
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [selecionadoId, setSelecionadoId] = useState<number | null>(null);
  const [versao, setVersao] = useState(0);
  const [importando, setImportando] = useState(false);
  const [exportando, setExportando] = useState(false);
  const [avisoExport, setAvisoExport] = useState<string | null>(null);

  useEffect(() => {
    const t = setTimeout(() => {
      setBuscaAplicada(busca);
      setPagina(1);
    }, 300);
    return () => clearTimeout(t);
  }, [busca]);

  const status = filtro === "Todos" ? "" : CODIGO_STATUS[filtro];
  const parametros: ParametrosPlanilha = {
    pagina,
    limite: POR_PAGINA,
    busca: buscaAplicada,
    status,
    ordem: ordem.chave,
    direcao: ordem.direcao,
  };
  const chaveConsulta = JSON.stringify(parametros);

  useEffect(() => {
    let cancelado = false;
    setCarregando(true);
    setErro(null);
    buscar(JSON.parse(chaveConsulta) as ParametrosPlanilha)
      .then((r) => {
        if (!cancelado) setResultado(r);
      })
      .catch((e) => {
        if (!cancelado) setErro(e instanceof Error ? e.message : "Falha ao carregar a planilha.");
      })
      .finally(() => {
        if (!cancelado) setCarregando(false);
      });
    return () => {
      cancelado = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chaveConsulta, versao]);

  const totalPaginas = Math.max(1, Math.ceil(resultado.total / POR_PAGINA));
  const selecionada = resultado.operacoes.find((o) => o.id === selecionadoId) ?? null;

  function alternarOrdem(chave: string) {
    setOrdem((atual) =>
      atual.chave === chave ? { chave, direcao: atual.direcao === "asc" ? "desc" : "asc" } : { chave, direcao: "asc" },
    );
    setPagina(1);
  }

  async function exportarFiltradas(formato: "xlsx" | "csv") {
    await executarExportacao(() =>
      api.exportarPlanilha({ busca: buscaAplicada, status, ordem: ordem.chave, direcao: ordem.direcao }, formato),
    );
  }

  async function exportarTodos() {
    await executarExportacao(() => api.exportarDadosCompletos());
  }

  async function exportarOperacao(id: number) {
    await executarExportacao(() => api.exportarOperacao(id, "xlsx"));
  }

  async function executarExportacao(acao: () => Promise<void>) {
    setExportando(true);
    setAvisoExport(null);
    try {
      await acao();
    } catch (e) {
      setAvisoExport(e instanceof Error ? e.message : "Não foi possível exportar.");
    } finally {
      setExportando(false);
    }
  }

  return (
    <div className="space-y-4">
      {titulo && (
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold">Planilha Operacional</h1>
            <p className="mt-1 text-[13px] text-muted-foreground">
              Pesagens registradas nas balanças, com comparação automática entre o peso esperado e o real
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => exportarFiltradas("xlsx")}
              disabled={exportando}
              title="Exporta as operações da tela (com os filtros e a busca atuais) em XLSX"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-[13px] font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-40"
            >
              <Download className="h-4 w-4" /> XLSX (filtradas)
            </button>
            <button
              onClick={() => exportarFiltradas("csv")}
              disabled={exportando}
              title="Exporta as operações da tela (com os filtros e a busca atuais) em CSV"
              className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-[13px] font-medium hover:bg-card-elev disabled:opacity-40"
            >
              <Download className="h-4 w-4" /> CSV (filtradas)
            </button>
            <button
              onClick={exportarTodos}
              disabled={exportando}
              title="Todos os dados da empresa, uma aba por tabela (XLSX)"
              className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-[13px] font-medium hover:bg-card-elev disabled:opacity-40"
            >
              <Download className="h-4 w-4" /> Todos os dados
            </button>
            <button
              onClick={() => setImportando((v) => !v)}
              aria-expanded={importando}
              className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-[13px] font-medium hover:bg-card-elev"
            >
              <Upload className="h-4 w-4" /> Importar planilha
            </button>
          </div>
        </div>
      )}

      {importando && <ImportarPlanilha onConcluido={() => setVersao((v) => v + 1)} />}

      <div className="rounded-2xl border border-border bg-card p-3">
        <div className="flex flex-wrap items-center gap-2">
          <input
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Buscar por ID, placa, motorista, RFID..."
            aria-label="Buscar operações"
            className="min-w-[200px] flex-1 rounded-lg border border-border bg-background px-3 py-2 text-[13px] outline-none focus:border-primary"
          />
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-1.5" role="group" aria-label="Filtrar por status">
          {FILTROS_STATUS.map((f) => (
            <button
              key={f}
              onClick={() => {
                setFiltro(f);
                setPagina(1);
              }}
              aria-pressed={filtro === f}
              className={`rounded-full border px-3 py-1.5 text-[12px] font-medium ${
                filtro === f
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border text-muted-foreground hover:bg-card-elev"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {erro && (
          <p className="mt-3 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-[12px] text-destructive">
            {erro}
          </p>
        )}
        {avisoExport && (
          <p className="mt-3 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-[12px] text-destructive">
            {avisoExport}
          </p>
        )}

        <div className="mt-3 hidden overflow-x-auto rounded-xl border border-border md:block">
          <table className="w-full min-w-[1500px] border-collapse text-[12px]">
            <thead>
              <tr className="bg-card-elev text-center text-[10px] uppercase tracking-wider text-muted-foreground">
                {COLUNAS.map((c) =>
                  c.chave === "vazio" ? (
                    <th
                      key="grupo-pesagem"
                      colSpan={4}
                      className="border-l border-border bg-card-elev px-3 pb-0 pt-2 font-semibold text-primary"
                    >
                      Pesagem (kg)
                    </th>
                  ) : ["carga", "esperado", "real"].includes(c.chave) ? null : (
                    <th key={`g-${c.chave}`} className="bg-card-elev" aria-hidden="true" />
                  ),
                )}
              </tr>
              <tr className="bg-card-elev text-left text-[10px] uppercase tracking-wider text-muted-foreground">
                {COLUNAS.map((c) => (
                  <th
                    key={c.chave}
                    className={`whitespace-nowrap bg-card-elev px-3 py-2.5 font-semibold ${c.alinhar === "right" ? "text-right" : ""} ${c.chave === COLUNAS[0].chave ? "sticky left-0 z-10" : ""}`}
                  >
                    {c.ordenavel ? (
                      <button
                        onClick={() => alternarOrdem(c.chave)}
                        className="inline-flex items-center gap-1 hover:text-foreground"
                      >
                        {c.rotulo}
                        {ordem.chave !== c.chave ? (
                          <ArrowUpDown className="h-3 w-3 opacity-50" />
                        ) : ordem.direcao === "asc" ? (
                          <ArrowUp className="h-3 w-3 text-primary" />
                        ) : (
                          <ArrowDown className="h-3 w-3 text-primary" />
                        )}
                      </button>
                    ) : (
                      c.rotulo
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {resultado.operacoes.map((o) => (
                <tr
                  key={o.id}
                  onClick={() => setSelecionadoId(selecionadoId === o.id ? null : o.id)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      setSelecionadoId(selecionadoId === o.id ? null : o.id);
                    }
                  }}
                  tabIndex={0}
                  aria-selected={selecionadoId === o.id}
                  className={`cursor-pointer border-t border-border/60 hover:bg-card-elev focus-visible:bg-card-elev ${selecionadoId === o.id ? "bg-primary/10" : ""}`}
                >
                  {COLUNAS.map((c) => {
                    const texto = String(c.valor(o));
                    const classe =
                      c.chave === "codigo"
                        ? "font-bold text-primary"
                        : c.chave === "placa"
                          ? "font-semibold"
                          : c.chave === "rfid"
                            ? "font-mono text-muted-foreground"
                            : c.chave === "difKg" || c.chave === "difPct" || c.chave === "status"
                              ? `font-semibold ${CLASSE_TEXTO_STATUS[o.status]}`
                              : c.chave === "alerta" || c.chave === "observacoes"
                                ? "text-muted-foreground"
                                : "";
                    return (
                      <td
                        key={c.chave}
                        title={texto === "—" ? "Sem dado registrado para esta operação" : undefined}
                        className={`whitespace-nowrap px-3 py-2 ${c.alinhar === "right" ? "text-right tabular-nums" : ""} ${texto === "—" ? "text-muted-foreground/60" : ""} ${classe} ${c.chave === COLUNAS[0].chave ? "sticky left-0 z-[1] bg-background" : ""}`}
                      >
                        {c.chave === "status" ? (
                          <span
                            className={`rounded-md border px-2 py-0.5 text-[11px] font-semibold ${CLASSE_STATUS[o.status]}`}
                          >
                            {texto}
                          </span>
                        ) : (
                          texto
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
              {!carregando && resultado.operacoes.length === 0 && (
                <tr>
                  <td colSpan={COLUNAS.length} className="px-3 py-8 text-center text-muted-foreground">
                    Nenhuma operação encontrada com esses filtros.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <ul className="mt-3 space-y-2 md:hidden" aria-label="Operações">
          {resultado.operacoes.map((o) => (
            <li key={o.id}>
              <button
                onClick={() => setSelecionadoId(selecionadoId === o.id ? null : o.id)}
                aria-expanded={selecionadoId === o.id}
                className={`w-full rounded-xl border border-border bg-background p-3 text-left ${selecionadoId === o.id ? "border-primary" : ""}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-bold text-primary">{o.codigo}</span>
                  <span
                    className={`rounded-md border px-2 py-0.5 text-[11px] font-semibold ${CLASSE_STATUS[o.status]}`}
                  >
                    {ROTULO_STATUS[o.status]}
                  </span>
                </div>
                <div className="mt-1 flex items-center justify-between text-[12px]">
                  <span className="font-semibold">{o.veiculo.placa ?? "—"}</span>
                  <span className="text-muted-foreground">{dataHora(o.datas.iniciadaEm ?? o.datas.saidaReal)}</span>
                </div>
                <div className="mt-1 text-[12px] text-muted-foreground">{o.motorista ?? "—"}</div>
                <div className="mt-2 grid grid-cols-3 gap-2 text-[11px]">
                  <div>
                    <p className="text-muted-foreground">Esperado</p>
                    <p className="tabular-nums">{kg(o.pesos.brutoEsperadoKg)} kg</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Real</p>
                    <p className="tabular-nums">{kg(o.pesos.brutoAferidoKg)} kg</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Dif.</p>
                    <p className={`font-semibold tabular-nums ${CLASSE_TEXTO_STATUS[o.status]}`}>
                      {difKg(o.pesos.desvioKg)} kg · {difPct(o.pesos.desvioPct)}
                    </p>
                  </div>
                </div>
              </button>
            </li>
          ))}
          {!carregando && resultado.operacoes.length === 0 && (
            <li className="px-3 py-8 text-center text-[13px] text-muted-foreground">
              Nenhuma operação encontrada com esses filtros.
            </li>
          )}
        </ul>

        <div className="mt-2 flex flex-wrap items-center justify-between gap-2 px-1 text-[11px] text-muted-foreground">
          <span>
            {carregando ? "Carregando..." : `${resultado.total} operações · página ${pagina} de ${totalPaginas}`}
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPagina((p) => Math.max(1, p - 1))}
              disabled={pagina <= 1 || carregando}
              className="inline-flex h-7 w-7 items-center justify-center rounded-md border border-border disabled:opacity-40"
              aria-label="Página anterior"
            >
              <ChevronLeft className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setPagina((p) => Math.min(totalPaginas, p + 1))}
              disabled={pagina >= totalPaginas || carregando}
              className="inline-flex h-7 w-7 items-center justify-center rounded-md border border-border disabled:opacity-40"
              aria-label="Próxima página"
            >
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {selecionada && (
          <DetalheOperacaoModal
            op={selecionada}
            onFechar={() => setSelecionadoId(null)}
            onExportar={() => exportarOperacao(selecionada.id)}
            onAbrirDetalhe={aoAbrirDetalhe ? () => aoAbrirDetalhe(selecionada) : undefined}
          />
        )}
      </div>
    </div>
  );
}
