import { useState } from "react";
import { CheckCircle2, Upload, XCircle } from "lucide-react";
import { api, type ResultadoImportacao } from "../../lib/api";

export function ImportarPlanilha({ onConcluido }: { onConcluido: () => void }) {
  const [arquivo, setArquivo] = useState<File | null>(null);
  const [verificado, setVerificado] = useState(false);
  const [ocupado, setOcupado] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [resultado, setResultado] = useState<ResultadoImportacao | null>(null);

  function escolher(f: File | null) {
    setArquivo(f);
    setVerificado(false);
    setResultado(null);
    setErro(null);
  }

  async function executar(simular: boolean) {
    if (!arquivo || ocupado) return;
    setOcupado(true);
    setErro(null);
    try {
      const r = await api.importarPlanilha(arquivo, simular);
      setResultado(r);
      if (simular) setVerificado(true);
      if (!simular) {
        setVerificado(false);
        onConcluido();
      }
    } catch (e) {
      setResultado(null);
      setVerificado(false);
      setErro(e instanceof Error ? e.message : "Não foi possível importar a planilha.");
    } finally {
      setOcupado(false);
    }
  }

  return (
    <section aria-label="Importar planilha" className="rounded-2xl border border-border bg-card p-4">
      <div className="flex flex-wrap items-center gap-3">
        <input
          type="file"
          accept=".xlsx,.csv,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
          onChange={(e) => escolher(e.target.files?.[0] ?? null)}
          className="text-[13px] file:mr-3 file:rounded-lg file:border file:border-border file:bg-background file:px-3 file:py-2 file:text-[12px]"
          aria-label="Arquivo da planilha"
        />
        <button
          onClick={() => executar(true)}
          disabled={!arquivo || ocupado}
          className="rounded-lg border border-border px-4 py-2 text-[13px] font-medium hover:bg-card-elev disabled:opacity-40"
        >
          {ocupado ? "Verificando..." : "Verificar planilha"}
        </button>
        <button
          onClick={() => executar(false)}
          disabled={!verificado || ocupado}
          className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-[13px] font-semibold text-primary-foreground disabled:opacity-40"
        >
          <Upload className="h-4 w-4" /> Importar e atualizar o sistema
        </button>
      </div>

      <p className="mt-2 text-[11px] text-muted-foreground">
        Use a planilha exportada pelo sistema como modelo. Código vazio cria operação nova; código existente atualiza
        observações, nota fiscal, MDF-e, CIOT e peso declarado (quando a operação ainda permite). Máximo de 2000 linhas.
      </p>

      {erro && (
        <p className="mt-3 flex items-start gap-2 whitespace-pre-line rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-[12px] text-destructive">
          <XCircle className="mt-0.5 h-4 w-4 shrink-0" /> {erro}
        </p>
      )}

      {resultado && resultado.simulacao && (
        <div className="mt-3 rounded-lg border border-success/40 bg-success/10 px-3 py-2 text-[12px]">
          <p className="flex items-center gap-2 font-medium text-success">
            <CheckCircle2 className="h-4 w-4" /> Planilha válida: {resultado.total} linha(s) lida(s).
          </p>
          <p className="mt-1 text-muted-foreground">
            Serão criadas {resultado.criar ?? 0} operação(ões) e atualizadas {resultado.atualizar ?? 0}. Nada foi
            gravado ainda.
          </p>
        </div>
      )}

      {resultado && !resultado.simulacao && resultado.aplicada && (
        <p className="mt-3 flex items-center gap-2 rounded-lg border border-success/40 bg-success/10 px-3 py-2 text-[12px] text-success">
          <CheckCircle2 className="h-4 w-4" /> Importação concluída: {resultado.criadas ?? 0} criada(s),{" "}
          {resultado.atualizadas ?? 0} atualizada(s).
        </p>
      )}
    </section>
  );
}
