import { useEffect } from "react";
import { Download, Package, Radio, Route, Truck, User, UserCheck, X } from "lucide-react";
import type { OperacaoApi } from "../../lib/api";
import { CLASSE_STATUS, CLASSE_TEXTO_STATUS, ROTULO_STATUS } from "../../lib/prototipo";

function kgTexto(valor: number | null | undefined): string {
  return valor == null ? "—" : `${Math.round(valor).toLocaleString("pt-BR")} kg`;
}

function kgComSinal(valor: number | null | undefined): string {
  if (valor == null) return "—";
  const arredondado = Math.round(valor);
  return `${arredondado > 0 ? "+" : ""}${arredondado.toLocaleString("pt-BR")} kg`;
}

function dataCurta(iso: string | null | undefined): string {
  if (!iso) return "—";
  const data = new Date(iso);
  if (Number.isNaN(data.getTime())) return "—";
  const partes = new Intl.DateTimeFormat("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(data);
  const pega = (tipo: string) => partes.find((p) => p.type === tipo)?.value ?? "";
  return `${pega("day")}/${pega("month")}, ${pega("hour")}:${pega("minute")}`;
}

function Cartao({ icone, rotulo, valor }: { icone: React.ReactNode; rotulo: string; valor: string }) {
  return (
    <div className="rounded-xl border border-border bg-background px-3 py-2.5">
      <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
        {icone}
        {rotulo}
      </p>
      <p className="mt-0.5 text-[14px] font-semibold text-foreground">{valor}</p>
    </div>
  );
}

function Linha({ rotulo, valor, destaque = false }: { rotulo: string; valor: string; destaque?: boolean }) {
  return (
    <div className={`flex items-center justify-between gap-3 ${destaque ? "border-t border-border pt-2 mt-1" : ""}`}>
      <span className={destaque ? "font-semibold text-[13px]" : "text-[13px] text-muted-foreground"}>{rotulo}</span>
      <span className={`font-mono tabular-nums text-[13px] ${destaque ? "font-bold" : ""}`}>{valor}</span>
    </div>
  );
}

export function DetalheOperacaoModal({
  op,
  onFechar,
  onExportar,
  onAbrirDetalhe,
}: {
  op: OperacaoApi;
  onFechar: () => void;
  onExportar?: () => void;
  onAbrirDetalhe?: () => void;
}) {
  useEffect(() => {
    const aoTeclar = (e: KeyboardEvent) => {
      if (e.key === "Escape") onFechar();
    };
    window.addEventListener("keydown", aoTeclar);
    return () => window.removeEventListener("keydown", aoTeclar);
  }, [onFechar]);

  const semAlerta = op.status === "NORMAL";
  const diferenca = op.pesos.desvioKg;
  const percentual = op.pesos.desvioPct;
  const rotuloDiferenca =
    diferenca == null
      ? "—"
      : `${kgComSinal(diferenca)}${percentual != null ? ` (${percentual > 0 ? "+" : ""}${percentual.toFixed(1)}%)` : ""}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onFechar();
      }}
      role="presentation"
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={`Detalhes da operação ${op.codigo}`}
        className="relative max-h-[92vh] w-full max-w-[520px] overflow-y-auto rounded-2xl border border-border bg-card p-5 shadow-xl"
      >
        <button
          type="button"
          onClick={onFechar}
          aria-label="Fechar"
          className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full border border-primary/60 text-primary hover:bg-primary/10"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="flex flex-wrap items-center gap-2 pr-10">
          <p className="text-[18px] font-bold text-primary">{op.codigo}</p>
          <span className={`rounded-md border px-2 py-0.5 text-[11px] font-semibold ${CLASSE_STATUS[op.status]}`}>
            {ROTULO_STATUS[op.status]}
          </span>
        </div>
        <p className="mt-1 text-[13px] text-muted-foreground">{dataCurta(op.datas.iniciadaEm ?? op.datas.saidaReal)}</p>

        <div className="mt-4 grid grid-cols-2 gap-2.5">
          <Cartao icone={<Truck className="h-3.5 w-3.5" />} rotulo="Placa" valor={op.veiculo.placa ?? "—"} />
          <Cartao icone={<User className="h-3.5 w-3.5" />} rotulo="Motorista" valor={op.motorista ?? "—"} />
          <Cartao icone={<Radio className="h-3.5 w-3.5" />} rotulo="RFID" valor={op.rfid ?? "—"} />
          <Cartao icone={<Package className="h-3.5 w-3.5" />} rotulo="Tipo de carga" valor={op.produto ?? "—"} />
          <Cartao
            icone={<Route className="h-3.5 w-3.5" />}
            rotulo="Rota"
            valor={`${op.rota.origem ?? "—"} → ${op.rota.destino ?? "—"}`}
          />
          <Cartao icone={<UserCheck className="h-3.5 w-3.5" />} rotulo="Responsável" valor={op.responsavel ?? "—"} />
        </div>

        <div className="mt-3 space-y-2 rounded-xl border border-border bg-background p-4">
          <Linha rotulo="Peso caminhão vazio" valor={kgTexto(op.pesos.vazioAferidoKg)} />
          <Linha rotulo="Peso da carga" valor={kgTexto(op.pesos.cargaAferidaKg ?? op.pesos.cargaDeclaradaKg)} />
          <Linha rotulo="Peso esperado" valor={kgTexto(op.pesos.brutoEsperadoKg)} />
          <Linha rotulo="Peso total real" valor={kgTexto(op.pesos.brutoAferidoKg)} />
          <Linha rotulo="Diferença" valor={rotuloDiferenca} destaque />
        </div>

        <div
          className={`mt-3 rounded-xl border p-3.5 ${
            semAlerta ? "border-border bg-background" : "border-primary/40 bg-primary/10"
          }`}
        >
          <p className={`text-[13px] font-semibold ${semAlerta ? "text-foreground" : CLASSE_TEXTO_STATUS[op.status]}`}>
            Alerta: {semAlerta ? "Sem alerta" : ROTULO_STATUS[op.status]}
          </p>
          <p className="mt-0.5 text-[12px] text-muted-foreground">
            {op.statusMotivo ?? (semAlerta ? "Operação dentro da tolerância." : "Verificar a operação.")}
          </p>
        </div>

        {(onExportar || onAbrirDetalhe) && (
          <div className="mt-4 flex flex-wrap justify-end gap-2">
            {onAbrirDetalhe && (
              <button
                type="button"
                onClick={onAbrirDetalhe}
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-1.5 text-[12px] font-semibold text-primary-foreground"
              >
                Ver detalhes completos
              </button>
            )}
            {onExportar && (
              <button
                type="button"
                onClick={onExportar}
                className="inline-flex items-center gap-2 rounded-lg border border-border px-3 py-1.5 text-[12px] font-medium hover:bg-card-elev"
              >
                <Download className="h-3.5 w-3.5" /> Exportar operação (XLSX)
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
