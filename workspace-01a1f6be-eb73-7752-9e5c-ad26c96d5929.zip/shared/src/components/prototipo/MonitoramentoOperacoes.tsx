import { useEffect, useMemo, useRef, useState } from "react";
import type * as LeafletTipos from "leaflet";
import "leaflet/dist/leaflet.css";
import { Map as IconeMapa, List, Search, Truck } from "lucide-react";
import { api, type OperacaoApi, type RotaApi, type WaypointApi } from "../../lib/api";
import { CLASSE_RASTREIO, horaCurta, kg, rotuloRastreio } from "../../lib/prototipo";
import { MAPA_TILES } from "../../lib/mapa";

export type ViagemMonitorada = OperacaoApi & { waypoints?: WaypointApi[] };

export function MonitoramentoOperacoes({
  viagens,
  titulo = true,
  trajetos,
}: {
  viagens: ViagemMonitorada[];
  titulo?: boolean;
  trajetos?: Record<number, [number, number][]>;
}) {
  const [aba, setAba] = useState<"mapa" | "lista">("mapa");
  const [busca, setBusca] = useState("");
  const [selecionadaId, setSelecionadaId] = useState<number | null>(null);

  const filtradas = useMemo(() => {
    const termo = busca.trim().toLowerCase();
    return viagens.filter(
      (v) =>
        !termo ||
        `${v.veiculo.placa ?? ""} ${v.motorista ?? ""} ${v.rota.origem ?? ""} ${v.rota.destino ?? ""}`
          .toLowerCase()
          .includes(termo),
    );
  }, [viagens, busca]);

  const selecionada = filtradas.find((v) => v.id === selecionadaId) ?? filtradas[0] ?? null;
  const outras = filtradas.filter((v) => v.id !== selecionada?.id);

  return (
    <div className="space-y-4">
      {titulo && (
        <div>
          <h1 className="text-2xl font-bold">Monitoramento</h1>
          <p className="mt-1 text-[13px] text-muted-foreground">
            Rastreamento das operações em andamento em tempo real
          </p>
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex rounded-lg border border-border bg-card p-1">
          <button
            onClick={() => setAba("mapa")}
            className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[12px] font-medium ${aba === "mapa" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
          >
            <IconeMapa className="h-3.5 w-3.5" /> Mapa
          </button>
          <button
            onClick={() => setAba("lista")}
            className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[12px] font-medium ${aba === "lista" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
          >
            <List className="h-3.5 w-3.5" /> Lista
          </button>
        </div>
        <div className="relative min-w-[200px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <input
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Buscar caminhão, rota ou motorista"
            className="w-full rounded-lg border border-border bg-card py-2 pl-9 pr-3 text-[13px] outline-none focus:border-primary"
          />
        </div>
        <span className="rounded-full border border-success/40 bg-success/10 px-3 py-1 text-[12px] font-medium text-success">
          {viagens.length} em trânsito
        </span>
      </div>

      {aba === "lista" ? (
        <div className="overflow-x-auto rounded-2xl border border-border bg-card">
          <table className="w-full min-w-[800px] text-[12px]">
            <thead>
              <tr className="bg-card-elev text-left text-[10px] uppercase tracking-wider text-muted-foreground">
                {["Operação", "Placa", "Motorista", "Rota", "Estado", "Progresso", "Velocidade", "ETA", "Atraso"].map(
                  (h) => (
                    <th key={h} className="px-3 py-2.5 font-semibold">
                      {h}
                    </th>
                  ),
                )}
              </tr>
            </thead>
            <tbody>
              {filtradas.map((v) => {
                const r = v.rastreio;
                const estado = rotuloRastreio(r);
                return (
                  <tr
                    key={v.id}
                    onClick={() => {
                      setSelecionadaId(v.id);
                      setAba("mapa");
                    }}
                    className="cursor-pointer border-t border-border/60 hover:bg-card-elev"
                  >
                    <td className="px-3 py-2.5 font-bold text-primary">{v.codigo}</td>
                    <td className="px-3 py-2.5 font-semibold">{v.veiculo.placa}</td>
                    <td className="px-3 py-2.5">{v.motorista}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">
                      {v.rota.origem} → {v.rota.destino}
                    </td>
                    <td className={`px-3 py-2.5 font-semibold ${CLASSE_RASTREIO[estado] ?? ""}`}>{estado}</td>
                    <td className="px-3 py-2.5 tabular-nums">{r?.progressoPct ?? 0}%</td>
                    <td className="px-3 py-2.5 tabular-nums">{r?.velocidadeKmh ?? 0} km/h</td>
                    <td className="px-3 py-2.5 tabular-nums">{horaCurta(r?.eta)}</td>
                    <td className="px-3 py-2.5 tabular-nums">{r?.atrasoMin ? `${r.atrasoMin} min` : "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="grid gap-4">
          <MapaRastreio
            viagens={filtradas}
            selecionada={selecionada}
            onSelecionar={(id) => setSelecionadaId(id)}
            trajetos={trajetos}
          />

          <div className="space-y-4">
            {selecionada && <CartaoSelecionada v={selecionada} />}
            <div className="rounded-2xl border border-border bg-card p-4">
              <p className="mb-3 text-[13px] font-semibold">Outras operações</p>
              <ul className="space-y-1.5">
                {outras.map((v) => {
                  const estado = rotuloRastreio(v.rastreio);
                  return (
                    <li key={v.id}>
                      <button
                        onClick={() => setSelecionadaId(v.id)}
                        className="flex w-full items-center justify-between rounded-lg border border-border px-3 py-2 text-left text-[12px] hover:bg-card-elev"
                      >
                        <span className="font-mono font-semibold">{v.veiculo.placa}</span>
                        <span className={`font-semibold ${CLASSE_RASTREIO[estado] ?? ""}`}>{estado}</span>
                        <span className="tabular-nums text-muted-foreground">{v.rastreio?.progressoPct ?? 0}%</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MapaRastreio({
  viagens,
  selecionada,
  onSelecionar,
  trajetos,
}: {
  viagens: ViagemMonitorada[];
  selecionada: ViagemMonitorada | null;
  onSelecionar: (id: number) => void;
  trajetos?: Record<number, [number, number][]>;
}) {
  const elementoRef = useRef<HTMLDivElement>(null);
  const mapaRef = useRef<LeafletTipos.Map | null>(null);
  const camadaRef = useRef<LeafletTipos.LayerGroup | null>(null);
  const leafletRef = useRef<typeof LeafletTipos | null>(null);
  const [pronto, setPronto] = useState(false);
  const enquadradoRef = useRef(false);
  const [rotasPorOperacao, setRotasPorOperacao] = useState<Record<string, RotaApi>>({});
  const chaveViagens = viagens.map((v) => v.id).join(",");
  useEffect(() => {
    let vivo = true;
    api
      .rotasRastreio()
      .then((r) => {
        if (vivo) setRotasPorOperacao(r.rotas);
      })
      .catch(() => {
        if (vivo) setRotasPorOperacao({});
      });
    return () => {
      vivo = false;
    };
  }, [chaveViagens]);
  const idSelecionada = selecionada?.id ?? null;
  const rotaDaSelecionada = idSelecionada != null ? (rotasPorOperacao[String(idSelecionada)] ?? null) : null;
  const selecionarRef = useRef(onSelecionar);
  selecionarRef.current = onSelecionar;

  useEffect(() => {
    let cancelado = false;
    import("leaflet").then((modulo) => {
      const Lf = modulo.default;
      if (cancelado || !elementoRef.current || mapaRef.current) return;
      leafletRef.current = Lf as unknown as typeof LeafletTipos;
      const mapa = Lf.map(elementoRef.current, { zoomControl: true, attributionControl: true }).setView(
        [-25.3, -51.5],
        7,
      );
      Lf.tileLayer(MAPA_TILES.url, { maxZoom: MAPA_TILES.maxZoom, attribution: MAPA_TILES.atribuicao }).addTo(mapa);
      camadaRef.current = Lf.layerGroup().addTo(mapa);
      mapaRef.current = mapa;
      setPronto(true);
    });
    return () => {
      cancelado = true;
      mapaRef.current?.remove();
      mapaRef.current = null;
      camadaRef.current = null;
      enquadradoRef.current = false;
      setPronto(false);
    };
  }, []);

  useEffect(() => {
    const mapa = mapaRef.current;
    const camada = camadaRef.current;
    const L = leafletRef.current;
    if (!mapa || !camada || !L) return;
    camada.clearLayers();

    for (const v of viagens) {
      const ativa = selecionada?.id === v.id;
      const rota = rotasPorOperacao[String(v.id)];
      const paradas = v.waypoints ?? [];
      const traçado: [number, number][] = rota?.geometria?.length
        ? rota.geometria
        : paradas.map((w) => [w.latitude, w.longitude] as [number, number]);
      if (traçado.length > 1) {
        const cor = COR_ESTADO[rotuloRastreio(v.rastreio)] ?? "#1d4ed8";
        if (ativa) {
          L.polyline(traçado, { color: "#ffffff", weight: 9, opacity: 0.9, lineCap: "round", lineJoin: "round" }).addTo(
            camada,
          );
        }
        L.polyline(traçado, {
          color: ativa ? "#1d4ed8" : cor,
          weight: ativa ? 5 : 3,
          opacity: ativa ? 0.95 : 0.6,
          lineCap: "round",
          lineJoin: "round",
          dashArray: rota?.fonte === "OSRM" ? undefined : "6 6",
        })
          .on("click", () => selecionarRef.current(v.id))
          .addTo(camada);
      }
      const percorrido = trajetos?.[v.id];
      if (percorrido && percorrido.length > 1) {
        L.polyline(percorrido, {
          color: "#16a34a",
          weight: ativa ? 6 : 4,
          opacity: 0.95,
          lineCap: "round",
          lineJoin: "round",
        }).addTo(camada);
      }
      for (const w of paradas) {
        if (w.waypoint_type !== "ORIGIN" && w.waypoint_type !== "DESTINATION") continue;
        const origem = w.waypoint_type === "ORIGIN";
        L.circleMarker([w.latitude, w.longitude], {
          radius: ativa ? 6 : 4,
          color: "#ffffff",
          weight: 2,
          fillColor: origem ? "#1d4ed8" : "#16a34a",
          fillOpacity: 1,
        })
          .bindTooltip(`${origem ? "Origem" : "Destino"}: ${w.label ?? ""}`)
          .addTo(camada);
      }
    }

    const pontos: [number, number][] = [];
    for (const v of viagens) {
      const pos = posicaoViagem(v);
      if (!pos) continue;
      pontos.push([pos.lat, pos.lon]);
      const estado = rotuloRastreio(v.rastreio);
      const ativa = selecionada?.id === v.id;
      const marcador = L.circleMarker([pos.lat, pos.lon], {
        radius: ativa ? 9 : 6,
        color: "#ffffff",
        weight: 2,
        fillColor: COR_ESTADO[estado] ?? "#C2410C",
        fillOpacity: 1,
      }).addTo(camada);
      marcador.bindTooltip(`${v.veiculo.placa} · ${estado} · ${v.rastreio?.progressoPct ?? 0}%`);
      marcador.on("click", () => selecionarRef.current(v.id));
    }

    if (!enquadradoRef.current && pontos.length > 0) {
      mapa.fitBounds(L.latLngBounds(pontos), { padding: [30, 30] });
      enquadradoRef.current = true;
    } else if (selecionada) {
      const pos = posicaoViagem(selecionada);
      if (pos) mapa.panTo([pos.lat, pos.lon]);
    }
  }, [viagens, selecionada, pronto, rotasPorOperacao, trajetos]);

  return (
    <div className="relative">
      <div
        ref={elementoRef}
        className="h-[320px] w-full overflow-hidden rounded-2xl border border-border bg-muted md:h-[520px]"
        role="region"
        aria-label="Mapa das operações"
      />
      {rotaDaSelecionada?.fonte === "OSRM" && (
        <div className="pointer-events-none absolute left-3 top-3 z-[1000] rounded-xl border border-border bg-card/95 px-3 py-2 text-[12px] shadow-lg">
          <span className="font-semibold">{rotaDaSelecionada.distanciaKm} km</span>
          {rotaDaSelecionada.duracaoMin != null && <> · {formatarDuracao(rotaDaSelecionada.duracaoMin)}</>}
          <span className="text-muted-foreground"> · rota por estradas</span>
        </div>
      )}
      {rotaDaSelecionada?.aviso && (
        <div className="pointer-events-none absolute bottom-3 left-3 right-3 z-[1000] rounded-xl border border-warning/40 bg-card/95 px-3 py-2 text-[11px] text-warning shadow-lg">
          {rotaDaSelecionada.aviso}
        </div>
      )}
    </div>
  );
}

function formatarDuracao(minutos: number): string {
  const h = Math.floor(minutos / 60);
  const m = minutos % 60;
  return h > 0 ? `~${h} h ${String(m).padStart(2, "0")} min` : `~${m} min`;
}

function posicaoViagem(v: ViagemMonitorada): { lat: number; lon: number } | null {
  const r = v.rastreio;
  if (r?.latitude != null && r?.longitude != null) return { lat: r.latitude, lon: r.longitude };
  const origem = v.waypoints?.find((w) => w.waypoint_type === "ORIGIN") ?? v.waypoints?.[0];
  return origem ? { lat: origem.latitude, lon: origem.longitude } : null;
}

const COR_ESTADO: Record<string, string> = {
  "Em trânsito": "#22c55e",
  "Em andamento": "#C2410C",
  Parado: "#eab308",
  "Em rota": "#22c55e",
  "Sem sinal": "#ef4444",
  Chegou: "#3b82f6",
};

function CartaoSelecionada({ v }: { v: ViagemMonitorada }) {
  const r = v.rastreio;
  const progresso = r?.progressoPct ?? 0;
  const restante = Math.round(((v.rota.distanciaKm ?? 0) * (100 - progresso)) / 100);
  const estado = rotuloRastreio(r);
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <p className="text-[12px] text-muted-foreground">Operação selecionada</p>
      <div className="mt-2 flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15 text-primary">
            <Truck className="h-5 w-5" />
          </span>
          <div>
            <p className="font-mono text-[15px] font-bold">{v.veiculo.placa}</p>
            <p className={`text-[12px] font-semibold ${CLASSE_RASTREIO[estado] ?? ""}`}>{estado}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-[11px] text-muted-foreground">ETA {horaCurta(r?.eta)}</p>
          <p className="text-[11px] text-muted-foreground">{restante} km restantes</p>
        </div>
      </div>
      <p className="mt-3 text-[12px] text-muted-foreground">
        {v.rota.origem} → {v.rota.destino}
      </p>
      <p className="text-[12px] text-muted-foreground">
        Motorista: <span className="font-semibold text-foreground">{v.motorista}</span> · {v.codigo}
      </p>
      <div className="mt-3 flex items-center justify-between text-[12px]">
        <span className="text-muted-foreground">Progresso da rota</span>
        <span className="font-bold tabular-nums">{progresso}%</span>
      </div>
      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-muted">
        <div className="h-full rounded-full bg-primary" style={{ width: `${progresso}%` }} />
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2 text-[11px]">
        <div>
          <p className="text-muted-foreground">Velocidade</p>
          <p className="font-semibold">{r?.velocidadeKmh ?? 0} km/h</p>
        </div>
        <div>
          <p className="text-muted-foreground">Atraso</p>
          <p className="font-semibold">{r?.atrasoMin ? `${r.atrasoMin} min` : "0 min"}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Carga aferida</p>
          <p className="font-semibold">{kg(v.pesos.cargaAferidaKg)}</p>
        </div>
      </div>
    </div>
  );
}

export function MonitoramentoDaOperacao({
  op,
  trajeto,
}: {
  op: ViagemMonitorada;
  trajeto?: { latitude: number | string | null; longitude: number | string | null; recorded_at?: string }[];
}) {
  const trajetos = useMemo(() => {
    const percorrido: [number, number][] = [...(trajeto ?? [])]
      .filter((p) => p.latitude != null && p.longitude != null)
      .sort((a, b) => new Date(a.recorded_at ?? 0).getTime() - new Date(b.recorded_at ?? 0).getTime())
      .map((p) => [Number(p.latitude), Number(p.longitude)] as [number, number]);
    return percorrido.length > 1 ? { [op.id]: percorrido } : undefined;
  }, [trajeto, op.id]);
  return <MonitoramentoOperacoes viagens={[op]} titulo={false} trajetos={trajetos} />;
}
