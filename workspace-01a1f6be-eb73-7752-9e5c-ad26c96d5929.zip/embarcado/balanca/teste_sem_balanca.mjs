const [, , servidor, chave] = process.argv;

if (!servidor || !chave) {
  console.log("Uso: node teste_sem_balanca.mjs http://IP-DO-COMPUTADOR:5174 CHAVE_DA_BALANCA");
  process.exit(1);
}

const url = `${servidor.replace(/\/$/, "")}/api/dispositivos/leituras`;
const pesagens = [
  { etapa: "EMPTY_TRUCK", pesoKg: 6.5 },
  { etapa: "SEPARATED_CARGO", pesoKg: 12.25 },
  { etapa: "LOADED_TRUCK", pesoKg: 18.75 },
];

let falhas = 0;
for (const p of pesagens) {
  try {
    const r = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json", "x-device-key": chave },
      body: JSON.stringify({ ...p, estavel: true, firmware: "teste-computador" }),
    });
    const corpo = await r.json().catch(() => ({}));
    if (r.status === 201) {
      console.log(`[OK]    ${p.etapa} ${p.pesoKg} kg -> enviado (${corpo.situacao})`);
    } else {
      falhas++;
      console.log(`[FALHA] ${p.etapa} -> HTTP ${r.status}: ${corpo.erro ?? "sem detalhe"}`);
    }
  } catch (erro) {
    falhas++;
    console.log(`[FALHA] não consegui chegar em ${url}. Confira o IP, a porta 5174 e o firewall.`);
    console.log(`        (${erro.message})`);
    break;
  }
}
console.log(falhas ? "\nTeste NÃO passou." : "\nTeste passou: o computador recebe as leituras.");
process.exit(falhas ? 1 : 0);
