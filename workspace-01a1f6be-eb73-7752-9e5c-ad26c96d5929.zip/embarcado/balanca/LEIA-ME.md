# Ligar a balança ao sistema pela mesma rede (Windows, roteador e Arduino IDE)

Tudo roda no computador. A balança conversa com ele pela rede Wi-Fi do roteador.

## 1. Rodar o sistema no computador
Siga o `guia_rodar_localmente.md`. A API precisa estar rodando na porta 5174.

## 2. Liberar a porta no firewall do Windows
1. Abra "Firewall do Windows Defender com Segurança Avançada".
2. Regras de Entrada > Nova Regra > Porta > TCP > Porta específica: `5174`.
3. Permitir a conexão > marque "Privado" > dê o nome "LoadSense API".

## 3. Conectar o computador ao roteador
Use o Wi-Fi ou cabo de rede no mesmo roteador que a balança vai usar.
A balança (ESP32) só conecta em Wi-Fi de **2,4 GHz**. No roteador, use a rede 2,4 GHz (às vezes ela tem o mesmo nome da de 5 GHz com "2G" no final).

## 4. Descobrir o IP do computador
Abra o Prompt de Comando e rode `ipconfig`. Anote o "Endereço IPv4" da rede usada (ex.: `192.168.0.10`).
Esse IP pode mudar quando o roteador reinicia. Confira antes da apresentação.

## 5. Preparar o Arduino IDE (uma vez)
1. Instale o Arduino IDE 2.x (site oficial arduino.cc).
2. Arquivo > Preferências > "URLs Adicionais para Gerenciadores de Placas", cole:
   `https://espressif.github.io/arduino-esp32/package_esp32_index.json`
3. Ferramentas > Placa > Gerenciador de Placas > pesquise "esp32" (Espressif Systems) > Instalar.
4. Gerenciador de Bibliotecas, instale:
   - **HX711 Arduino Library** (Bogdan Necula)
   - **LiquidCrystal I2C** (Frank de Brabander, ou outra com esse nome)
5. Placa: **ESP32 Dev Module** (serve para o DevKit C V4).
6. Se a porta COM não aparecer ao conectar o ESP32, instale o driver **CP210x** (Silicon Labs) e reinicie o Arduino IDE.

## 6. Montar a pasta do programa
1. Crie uma pasta chamada `balanca` (o nome precisa ser igual ao do arquivo `.ino`).
2. Coloque dentro dela: `balanca.ino`, `config.h` (criado no passo 7). O `teste_sem_balanca.mjs` pode ficar fora.

## 7. Configurar a balança
1. Copie `config.h.exemplo` para `config.h` na pasta `balanca`.
2. Preencha:
   - `WIFI_SSID` e `WIFI_PASS`: nome e senha da rede 2,4 GHz do roteador.
   - `SERVIDOR_URL`: `http://SEU-IP:5174` (IP do passo 4).
   - `DEVICE_KEY`: a chave gerada no sistema (passo 8).

## 8. Gerar a chave e testar sem a balança
1. No sistema, abra uma operação em rascunho e, em "Balança", clique em "Gerar chave". Copie a chave na hora (ela não aparece de novo).
2. Teste a conexão com o computador, no Prompt de Comando, dentro da pasta com o script (Node.js instalado):

       node teste_sem_balanca.mjs http://SEU-IP:5174 SUA_CHAVE

3. Se aparecer "Teste passou", as três leituras de teste ficaram pendentes na operação. Aceite ou ignore essas leituras antes da pesagem real.

## 9. Gravar a balança
1. No Arduino IDE, abra `balanca/balanca.ino`.
2. Clique em **Verificar** (compila). Se der erro, copie a mensagem e me envie.
3. Clique em **Enviar** (grava). Pode ser preciso segurar o botão BOOT da placa no início.
4. Abra o Monitor Serial (115200 bauds). Deve aparecer "HX711 OK", "Wi-Fi conectado" e "=== LoadSense pronto ===".

## 10. Fazer a pesagem
1. No sistema, abra a operação e clique em "Receber leituras desta operação" na balança.
2. Coloque o caminhão vazio, depois com carga, depois o total. Cada etapa estável aparece no site.
3. Clique em "Aceitar" nas leituras.
4. Quando o caminhão sair da balança, o LCD volta sozinho para "Aguardando...", pronto para a próxima pesagem. Não é preciso reiniciar a balança.

A balança envia um sinal de vida a cada 60 s (com Wi-Fi conectado). Assim, o site mostra "Online" mesmo sem pesagem em andamento.

## Se algo falhar
- **Tela do LCD em branco ou com caracteres estranhos:** o endereço do LCD pode ser `0x3F` em vez de `0x27`. Troque em `balanca.ino` (`LiquidCrystal_I2C lcd(0x27, 16, 2);`).
- **LCD mostra "WiFi ERRO":** confira nome e senha da rede, e se é 2,4 GHz.
- **Teste do computador falha:** confira o IP com `ipconfig`, o firewall (passo 2) e se a API está rodando.
- **Leitura não aparece no site:** a operação escolhida no site precisa ser a mesma em que a balança está recebendo.
- **Porta COM não aparece:** driver CP210x (passo 5.6).
- **LCD mostra "NAO enviado" e "Escolha operacao":** a operação não foi escolhida no sistema. Clique em "Receber leituras desta operação".
- **LCD mostra "NAO enviado" e "Chave invalida":** gere uma nova chave e atualize `DEVICE_KEY` (a chave antiga deixa de funcionar).
- **Site mostra "Sem sinal recente":** a balança não enviou o sinal de vida nos últimos 3 minutos. Confira ligação, Wi-Fi e a chave (`DEVICE_KEY`). Com a versão 1.1, isso só acontece se a balança estiver desligada ou sem Wi-Fi.
- **LCD mostra "NAO enviado" e "Servidor offline" ou "Erro HTTP 5xx":** a balança tenta de novo até 3 vezes. Se continuar, verifique se a API está rodando e o firewall (passo 2).
