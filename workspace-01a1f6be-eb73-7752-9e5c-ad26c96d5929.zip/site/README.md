# Site LoadSense — central web

Site e central web do LoadSense. Reproduz o site publicado e **compartilha a API e o banco com o aplicativo**:
o que é gravado aqui aparece no app, e vice-versa.

## Rodar

```bash
cd ../api && node server/index.js     # API na porta 5174
cd site && npm install && npm run dev # http://localhost:5175 (proxy /api → 5174)
```

Ou tudo de uma vez, na raiz do projeto: `./iniciar.sh`.

Build de produção: `npm run build` gera `dist/`. Publique com fallback SPA para `index.html`.

## Telas

| Rota | Tela | Dados |
| --- | --- | --- |
| `/` | Início (landing) | estático |
| `/login` | Login | `POST /api/auth/login` (senha no banco, sessão auditada) |
| `/esqueci-senha` → `/verificar-codigo` → `/nova-senha` → `/senha-alterada` | Recuperação de senha | `POST /api/auth/recuperacao/*` |
| `/termos`, `/privacidade`, `/cookies`, `/lgpd` | Documentos legais | estático |
| `/app` | Dashboard | `GET /api/painel` |
| `/app/planilha`, `/app/historico` | Planilha e histórico | `GET /api/operacoes` |
| `/app/nova-pesagem` | Pesagem em 3 etapas | criar operação, leituras, finalizar |
| `/app/alertas` | Alertas (reconhecer, resolver, reabrir) | `/api/alertas/*` |
| `/app/monitoramento` | Rastreio das viagens | `GET /api/rastreio/ativo` |
| `/app/relatorios` | Resumo e relatórios salvos | `/api/relatorios/*` |
| `/app/configuracoes` | Parâmetros de pesagem e dispositivos | `/api/configuracoes`, `/api/dispositivos` |

## Dados

O site sempre usa a API e o banco MySQL (login obrigatório). Não há modo sem API. Para a versão de entrega sem dados de demonstração, veja `banco/README.md`.

## Estrutura

```
site/
├── src/
│   ├── App.tsx             rotas e guarda do painel
│   ├── pages/publicas.tsx  início, login, recuperação, legais
│   ├── pages/central/      dashboard, planilha, pesagem, alertas, monitoramento, relatórios, configurações
│   ├── components/         casca do painel (layout.tsx) e componentes (ui.tsx)
│   └── lib/format.ts       formatação e rótulos
└── scripts/fluxo-site.cjs  teste de navegador (requer app/node_modules/playwright-core)
```

O cliente HTTP vem de `../app/src/lib/api.ts` (alias `@app`), o mesmo usado pelo aplicativo.

## Teste

Com a API no ar e o site em `:5175`, o site pode ser testado pelo navegador.
