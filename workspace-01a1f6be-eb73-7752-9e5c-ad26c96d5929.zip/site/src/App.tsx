import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { exigeSessao, LayoutCentral } from "@/components/layout";
import { SemServidorGate } from "@/components/SemServidorGate";
import { EsqueciSenha, Inicio, Legal, Login, NovaSenha, SenhaAlterada, VerificarCodigo } from "@/pages/publicas";
import { Dashboard, Historico, Planilha } from "@/pages/central/painel";
import { Alertas } from "@/pages/central/operar";
import { Configuracoes, Monitoramento, Relatorios } from "@/pages/central/gestao";
import { NovaOperacao } from "@/pages/central/nova-operacao";
import { OperacaoDetalhe } from "@/pages/central/operacao";
import { EditarOperacao } from "@/pages/central/editar-operacao";

function Protegida({ children }: { children: React.ReactNode }) {
  if (!exigeSessao()) return <Navigate to="/login" replace />;
  return <LayoutCentral>{children}</LayoutCentral>;
}

export default function App() {
  return (
    <SemServidorGate>
      <BrowserRouter basename={import.meta.env.BASE_URL.replace(/\/$/, "") || undefined}>
        <Routes>
          <Route path="/" element={<Inicio />} />
          <Route path="/login" element={<Login />} />
          <Route path="/esqueci-senha" element={<EsqueciSenha />} />
          <Route path="/verificar-codigo" element={<VerificarCodigo />} />
          <Route path="/nova-senha" element={<NovaSenha />} />
          <Route path="/senha-alterada" element={<SenhaAlterada />} />
          <Route path="/termos" element={<Legal documento="termos" />} />
          <Route path="/privacidade" element={<Legal documento="privacidade" />} />
          <Route path="/cookies" element={<Legal documento="cookies" />} />
          <Route path="/lgpd" element={<Legal documento="lgpd" />} />

          <Route
            path="/app"
            element={
              <Protegida>
                <Dashboard />
              </Protegida>
            }
          />
          <Route
            path="/app/planilha"
            element={
              <Protegida>
                <Planilha />
              </Protegida>
            }
          />
          <Route
            path="/app/nova-operacao"
            element={
              <Protegida>
                <NovaOperacao />
              </Protegida>
            }
          />
          <Route
            path="/app/operacoes/:id/editar"
            element={
              <Protegida>
                <EditarOperacao />
              </Protegida>
            }
          />
          <Route
            path="/app/operacoes/:id"
            element={
              <Protegida>
                <OperacaoDetalhe />
              </Protegida>
            }
          />
          <Route
            path="/app/alertas"
            element={
              <Protegida>
                <Alertas />
              </Protegida>
            }
          />
          <Route
            path="/app/relatorios"
            element={
              <Protegida>
                <Relatorios />
              </Protegida>
            }
          />
          <Route
            path="/app/historico"
            element={
              <Protegida>
                <Historico />
              </Protegida>
            }
          />
          <Route
            path="/app/monitoramento"
            element={
              <Protegida>
                <Monitoramento />
              </Protegida>
            }
          />
          <Route
            path="/app/configuracoes"
            element={
              <Protegida>
                <Configuracoes />
              </Protegida>
            }
          />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </SemServidorGate>
  );
}
