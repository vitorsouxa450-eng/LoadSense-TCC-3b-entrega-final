import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { api as servidor } from "@shared/lib/api";
import { Aviso, Botao, CampoTexto, Cartao } from "@/components/ui";

const mensagem = (e: unknown) => (e instanceof Error ? e.message : "Falha na comunicação com o servidor.");

function Campo({ rotulo, children }: { rotulo: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[12px] font-semibold text-muted-foreground">{rotulo}</span>
      {children}
    </label>
  );
}

const numero = (valor: string) => Number(valor.replace(",", "."));
const coordValida = (valor: string, limite: number) => {
  const n = numero(valor);
  return Number.isFinite(n) && Math.abs(n) <= limite;
};

export function FormMotorista({ aoCadastrar }: { aoCadastrar?: () => void }) {
  const [nome, setNome] = useState("");
  const [cpf, setCpf] = useState("");
  const [matricula, setMatricula] = useState("");
  const [cnh, setCnh] = useState("");
  const [categoria, setCategoria] = useState("");
  const [validadeCnh, setValidadeCnh] = useState("");
  const [telefone, setTelefone] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [sucesso, setSucesso] = useState<string | null>(null);
  const [salvando, setSalvando] = useState(false);

  async function salvar(e: FormEvent) {
    e.preventDefault();
    setErro(null);
    setSucesso(null);
    if (nome.trim().length < 3) return setErro("Informe o nome do motorista.");
    setSalvando(true);
    try {
      const criado = await servidor.criarMotorista({
        nome: nome.trim(),
        cpf: cpf.trim() || undefined,
        matricula: matricula.trim() || undefined,
        cnh: cnh.trim() || undefined,
        categoriaCnh: categoria.trim() || undefined,
        validadeCnh: validadeCnh || undefined,
        telefone: telefone.trim() || undefined,
      });
      setSucesso(`Motorista ${criado.nome} cadastrado.`);
      aoCadastrar?.();
      setNome("");
      setCpf("");
      setMatricula("");
      setCnh("");
      setCategoria("");
      setValidadeCnh("");
      setTelefone("");
    } catch (err) {
      setErro(mensagem(err));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <Cartao>
      <h2 className="mb-3 text-[15px] font-bold">Novo motorista</h2>
      <form onSubmit={salvar} className="space-y-3" noValidate>
        <Campo rotulo="Nome completo *">
          <input className={CampoTexto} value={nome} onChange={(e) => setNome(e.target.value)} />
        </Campo>
        <div className="grid grid-cols-2 gap-3">
          <Campo rotulo="CPF">
            <input className={CampoTexto} value={cpf} onChange={(e) => setCpf(e.target.value)} inputMode="numeric" />
          </Campo>
          <Campo rotulo="Matrícula">
            <input className={CampoTexto} value={matricula} onChange={(e) => setMatricula(e.target.value)} />
          </Campo>
          <Campo rotulo="Número da CNH">
            <input className={CampoTexto} value={cnh} onChange={(e) => setCnh(e.target.value)} />
          </Campo>
          <Campo rotulo="Categoria">
            <input
              className={CampoTexto}
              value={categoria}
              onChange={(e) => setCategoria(e.target.value)}
              placeholder="E"
            />
          </Campo>
          <Campo rotulo="Validade da CNH">
            <input
              className={CampoTexto}
              type="date"
              value={validadeCnh}
              onChange={(e) => setValidadeCnh(e.target.value)}
            />
          </Campo>
          <Campo rotulo="Telefone">
            <input className={CampoTexto} value={telefone} onChange={(e) => setTelefone(e.target.value)} type="tel" />
          </Campo>
        </div>
        {erro && <Aviso tom="erro">{erro}</Aviso>}
        {sucesso && <Aviso tom="sucesso">{sucesso}</Aviso>}
        <Botao tipo="submit" carregando={salvando}>
          {salvando ? "Salvando…" : "Cadastrar motorista"}
        </Botao>
      </form>
    </Cartao>
  );
}

export function FormRota({ aoCadastrar }: { aoCadastrar?: () => void }) {
  const [origem, setOrigem] = useState("");
  const [destino, setDestino] = useState("");
  const [latO, setLatO] = useState("");
  const [lonO, setLonO] = useState("");
  const [latD, setLatD] = useState("");
  const [lonD, setLonD] = useState("");
  const [distancia, setDistancia] = useState("");
  const [codigo, setCodigo] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [sucesso, setSucesso] = useState<string | null>(null);
  const [salvando, setSalvando] = useState(false);
  type Opcao = Awaited<ReturnType<typeof servidor.rotasAlternativas>>["opcoes"][number];
  const [opcoes, setOpcoes] = useState<Opcao[]>([]);
  const [escolhida, setEscolhida] = useState<number | null>(null);
  const [buscando, setBuscando] = useState(false);
  useEffect(() => {
    setOpcoes([]);
    setEscolhida(null);
  }, [latO, lonO, latD, lonD]);

  async function buscarOpcoes() {
    setErro(null);
    if (!coordValida(latO, 90) || !coordValida(lonO, 180) || !coordValida(latD, 90) || !coordValida(lonD, 180))
      return setErro("Informe as coordenadas de origem e destino para buscar as opções de traçado.");
    setBuscando(true);
    try {
      const { opcoes: lista } = await servidor.rotasAlternativas({
        latO: numero(latO),
        lonO: numero(lonO),
        latD: numero(latD),
        lonD: numero(lonD),
      });
      setOpcoes(lista);
      setEscolhida(lista[0]?.id ?? null);
    } catch (err) {
      setErro(mensagem(err));
    } finally {
      setBuscando(false);
    }
  }

  async function salvar(e: FormEvent) {
    e.preventDefault();
    setErro(null);
    setSucesso(null);
    if (origem.trim().length < 2 || destino.trim().length < 2) return setErro("Informe a origem e o destino.");
    if (!coordValida(latO, 90) || !coordValida(lonO, 180))
      return setErro("Informe a latitude e a longitude da origem.");
    if (!coordValida(latD, 90) || !coordValida(lonD, 180))
      return setErro("Informe a latitude e a longitude do destino.");
    const opcao = opcoes.find((o) => o.id === escolhida) ?? null;
    const km = numero(distancia) > 0 ? numero(distancia) : (opcao?.distanciaKm ?? 0);
    if (!(km > 0)) return setErro("Informe a distância da rota em km ou busque as opções de traçado.");
    setSalvando(true);
    try {
      const criada = await servidor.criarRota({
        origem: origem.trim(),
        destino: destino.trim(),
        latOrigem: numero(latO),
        lonOrigem: numero(lonO),
        latDestino: numero(latD),
        lonDestino: numero(lonD),
        distanciaKm: km,
        codigo: codigo.trim() || undefined,
        paradas:
          opcao?.fonte === "OSRM"
            ? opcao.paradasSugeridas.map((p, i) => ({ nome: `Trecho ${i + 1}`, lat: p.lat, lon: p.lon }))
            : [],
      });
      setSucesso(`Rota ${criada.origem} → ${criada.destino} cadastrada.`);
      aoCadastrar?.();
      setOrigem("");
      setDestino("");
      setLatO("");
      setLonO("");
      setLatD("");
      setLonD("");
      setDistancia("");
      setCodigo("");
    } catch (err) {
      setErro(mensagem(err));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <Cartao>
      <h2 className="mb-1 text-[15px] font-bold">Nova rota</h2>
      <p className="mb-3 text-[11px] text-muted-foreground">
        As coordenadas aparecem no Google Maps: clique com o botão direito no ponto e copie “latitude, longitude”.
      </p>
      <form onSubmit={salvar} className="space-y-3" noValidate>
        <div className="grid grid-cols-2 gap-3">
          <Campo rotulo="Origem *">
            <input className={CampoTexto} value={origem} onChange={(e) => setOrigem(e.target.value)} />
          </Campo>
          <Campo rotulo="Destino *">
            <input className={CampoTexto} value={destino} onChange={(e) => setDestino(e.target.value)} />
          </Campo>
          <Campo rotulo="Latitude da origem *">
            <input
              className={CampoTexto}
              value={latO}
              onChange={(e) => setLatO(e.target.value)}
              placeholder="-23.5861"
            />
          </Campo>
          <Campo rotulo="Longitude da origem *">
            <input
              className={CampoTexto}
              value={lonO}
              onChange={(e) => setLonO(e.target.value)}
              placeholder="-46.8200"
            />
          </Campo>
          <Campo rotulo="Latitude do destino *">
            <input
              className={CampoTexto}
              value={latD}
              onChange={(e) => setLatD(e.target.value)}
              placeholder="-23.9608"
            />
          </Campo>
          <Campo rotulo="Longitude do destino *">
            <input
              className={CampoTexto}
              value={lonD}
              onChange={(e) => setLonD(e.target.value)}
              placeholder="-46.3336"
            />
          </Campo>
          <Campo rotulo="Distância (km) *">
            <input
              className={CampoTexto}
              value={distancia}
              onChange={(e) => setDistancia(e.target.value)}
              inputMode="decimal"
            />
          </Campo>
          <Campo rotulo="Código (opcional)">
            <input
              className={CampoTexto}
              value={codigo}
              onChange={(e) => setCodigo(e.target.value)}
              placeholder="ROT-010"
            />
          </Campo>
        </div>
        <div className="rounded-xl border border-border/60 p-3">
          <div className="mb-2 flex items-center justify-between gap-3">
            <div>
              <div className="text-[12px] font-semibold">Opções de traçado</div>
              <div className="text-[11px] text-muted-foreground">
                Compare as rotas por estradas e escolha a que a operação deve seguir.
              </div>
            </div>
            <button
              type="button"
              onClick={buscarOpcoes}
              disabled={buscando}
              className="rounded-xl border border-border/60 px-3 py-2 text-[12px] font-semibold disabled:opacity-60"
            >
              {buscando ? "Buscando…" : opcoes.length ? "Buscar de novo" : "Buscar opções"}
            </button>
          </div>
          {opcoes.length > 0 && (
            <ul className="space-y-2">
              {opcoes.map((o) => (
                <li key={o.id}>
                  <label
                    className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 text-[12px] ${
                      escolhida === o.id ? "border-primary bg-primary/5" : "border-border/60"
                    }`}
                  >
                    <input
                      type="radio"
                      name="opcao-rota"
                      checked={escolhida === o.id}
                      onChange={() => setEscolhida(o.id)}
                    />
                    <span className="flex-1 font-semibold">{o.rotulo}</span>
                    <span className="text-muted-foreground">
                      {o.distanciaKm != null ? `${o.distanciaKm} km` : "distância não calculada"}
                      {o.duracaoMin != null ? ` · ${Math.floor(o.duracaoMin / 60)} h ${o.duracaoMin % 60} min` : ""}
                    </span>
                  </label>
                </li>
              ))}
              {opcoes[0]?.fonte === "LINHA_RETA" && (
                <li>
                  <Aviso tom="erro">
                    Sem conexão com o serviço de rotas. Informe a distância manualmente; a operação mostrará a linha
                    reta.
                  </Aviso>
                </li>
              )}
            </ul>
          )}
        </div>
        {erro && <Aviso tom="erro">{erro}</Aviso>}
        {sucesso && <Aviso tom="sucesso">{sucesso}</Aviso>}
        <Botao tipo="submit" carregando={salvando}>
          {salvando ? "Salvando…" : "Cadastrar rota"}
        </Botao>
      </form>
    </Cartao>
  );
}
