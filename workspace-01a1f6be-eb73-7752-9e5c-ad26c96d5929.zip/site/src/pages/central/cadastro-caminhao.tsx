import { useState, type FormEvent, type ReactNode } from "react";
import {
  FORM_CAMINHAO_VAZIO,
  TIPOS_VEICULO,
  validarCaminhao,
  type ErrosCaminhao,
  type FormCaminhao as FormCaminhaoDados,
} from "@shared/lib/cadastro-caminhao";
import { api } from "@/lib/dados";
import { Aviso, Botao, CampoTexto, Cartao } from "@/components/ui";

const mensagem = (e: unknown) => (e instanceof Error ? e.message : "Falha na comunicação com o servidor.");

function Campo({ rotulo, erro, children }: { rotulo: string; erro?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-[12px] font-semibold text-muted-foreground">{rotulo}</span>
      <div className="mt-1.5">{children}</div>
      {erro && <span className="mt-1 block text-[11px] text-destructive">{erro}</span>}
    </label>
  );
}

export function FormCaminhao({ aoCadastrar }: { aoCadastrar?: () => void }) {
  const [form, setForm] = useState<FormCaminhaoDados>(FORM_CAMINHAO_VAZIO);
  const [erros, setErros] = useState<ErrosCaminhao>({});
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [sucesso, setSucesso] = useState<string | null>(null);

  const alterar = (campo: keyof FormCaminhaoDados) => (valor: string) => {
    setForm((f) => ({ ...f, [campo]: valor }));
    setErros((e) => ({ ...e, [campo]: undefined }));
  };

  async function salvar(e: FormEvent) {
    e.preventDefault();
    setErro(null);
    setSucesso(null);
    const { erros: novosErros, corpo } = validarCaminhao(form);
    setErros(novosErros);
    if (!corpo) return;
    setSalvando(true);
    try {
      const criado = await api.criarVeiculo(corpo);
      setSucesso(
        `Caminhão ${criado.plate} cadastrado${criado.rfid_code ? ` com a etiqueta ${criado.rfid_code}` : ""}.`,
      );
      setForm(FORM_CAMINHAO_VAZIO);
      aoCadastrar?.();
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <Cartao>
      <form onSubmit={salvar} className="space-y-4" noValidate>
        <h2 className="text-[15px] font-bold">Novo caminhão</h2>
        {erro && <Aviso tom="erro">{erro}</Aviso>}
        {sucesso && <Aviso tom="sucesso">{sucesso}</Aviso>}

        <div className="grid gap-4 sm:grid-cols-2">
          <Campo rotulo="Placa *" erro={erros.placa}>
            <input
              className={`${CampoTexto} uppercase`}
              value={form.placa}
              onChange={(e) => alterar("placa")(e.target.value)}
              placeholder="ABC1D23"
              maxLength={10}
              autoComplete="off"
            />
          </Campo>
          <Campo rotulo="Etiqueta RFID (ID)" erro={erros.rfid}>
            <input
              className={CampoTexto}
              value={form.rfid}
              onChange={(e) => alterar("rfid")(e.target.value)}
              placeholder="RF-000123"
              maxLength={100}
              autoComplete="off"
            />
          </Campo>
          <Campo rotulo="Tipo" erro={erros.tipo}>
            <select className={CampoTexto} value={form.tipo} onChange={(e) => alterar("tipo")(e.target.value)}>
              {TIPOS_VEICULO.map((t) => (
                <option key={t.valor} value={t.valor}>
                  {t.rotulo}
                </option>
              ))}
            </select>
          </Campo>
          <Campo rotulo="Código da frota" erro={erros.frota}>
            <input
              className={CampoTexto}
              value={form.frota}
              onChange={(e) => alterar("frota")(e.target.value)}
              placeholder="F-09"
              maxLength={40}
            />
          </Campo>
          <Campo rotulo="Fabricante" erro={erros.fabricante}>
            <input
              className={CampoTexto}
              value={form.fabricante}
              onChange={(e) => alterar("fabricante")(e.target.value)}
              placeholder="Volvo"
              maxLength={80}
            />
          </Campo>
          <Campo rotulo="Modelo" erro={erros.modelo}>
            <input
              className={CampoTexto}
              value={form.modelo}
              onChange={(e) => alterar("modelo")(e.target.value)}
              placeholder="FH 540"
              maxLength={100}
            />
          </Campo>
          <Campo rotulo="Ano de fabricação" erro={erros.ano}>
            <input
              className={CampoTexto}
              inputMode="numeric"
              value={form.ano}
              onChange={(e) => alterar("ano")(e.target.value)}
              placeholder="2023"
            />
          </Campo>
          <Campo rotulo="Número de eixos" erro={erros.eixos}>
            <input
              className={CampoTexto}
              inputMode="numeric"
              value={form.eixos}
              onChange={(e) => alterar("eixos")(e.target.value)}
              placeholder="3"
            />
          </Campo>
          <Campo rotulo="Tara cadastrada (kg)" erro={erros.tara}>
            <input
              className={CampoTexto}
              inputMode="decimal"
              value={form.tara}
              onChange={(e) => alterar("tara")(e.target.value)}
              placeholder="8200"
            />
          </Campo>
          <Campo rotulo="Limite de peso bruto (kg)" erro={erros.pbt}>
            <input
              className={CampoTexto}
              inputMode="decimal"
              value={form.pbt}
              onChange={(e) => alterar("pbt")(e.target.value)}
              placeholder="23000"
            />
          </Campo>
          <Campo rotulo="Limite de carga (kg)" erro={erros.carga}>
            <input
              className={CampoTexto}
              inputMode="decimal"
              value={form.carga}
              onChange={(e) => alterar("carga")(e.target.value)}
              placeholder="14800"
            />
          </Campo>
        </div>
        <p className="text-[11px] text-muted-foreground">* Campos obrigatórios. Os demais são opcionais.</p>

        <div className="flex flex-wrap gap-3">
          <Botao tipo="submit" carregando={salvando}>
            Cadastrar caminhão
          </Botao>
          <Botao
            variante="secundario"
            onClick={() => {
              setForm(FORM_CAMINHAO_VAZIO);
              setErros({});
              setErro(null);
              setSucesso(null);
            }}
          >
            Limpar
          </Botao>
        </div>
      </form>
    </Cartao>
  );
}
