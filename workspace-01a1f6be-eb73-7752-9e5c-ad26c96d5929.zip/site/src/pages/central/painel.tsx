import { useEffect, useMemo, useState } from "react";
import { useSincronia } from "@shared/lib/sincronia";
import { Link, useNavigate } from "react-router-dom";
import {
  Activity,
  AlertTriangle,
  Gauge,
  KeyRound,
  Package,
  Pencil,
  Radio,
  Scale,
  TrendingUp,
  Users,
} from "lucide-react";
import { type AtividadeApi, type HistoricoApi, type OperacaoApi, type PainelApi } from "@shared/lib/api";
import { api } from "@/lib/dados";
import { Badge, Botao, Cartao, CampoTexto, Carregando, Aviso, Titulo, Vazio } from "@/components/ui";
import { STATUS_OPERACAO, dataCurta, kg, pct, sinal, toneladas } from "@/lib/format";
import { useCarga } from "./useCarga";
import { PlanilhaOperacional } from "@shared/components/prototipo/PlanilhaOperacional";
import { queryPlanilha, type ParametrosPlanilha } from "@shared/lib/prototipo";
import { GuiaPrimeirosPassos, guiaJaVisto } from "@shared/components/ajuda/GuiaPrimeirosPassos";
import { PASSOS_GUIA_SITE } from "@shared/lib/ajuda";

export function Dashboard() {
  const [painel, setPainel] = useState<PainelApi | null>(null);
  const [guiaAberto, setGuiaAberto] = useState(false);
  useEffect(() => {
    if (!guiaJaVisto("site")) setGuiaAberto(true);
  }, []);
  const [recentes, setRecentes] = useState<OperacaoApi[]>([]);
  const { carregando, erro, recarregar } = useCarga(async () => {
    const [p, o] = await Promise.all([api.painel(30), api.operacoes("&limite=6")]);
    setPainel(p);
    setRecentes(o.operacoes.slice(0, 6));
  });
  useSincronia(() => {
    void recarregar();
  }, true);

  if (carregando) return <Carregando />;
  if (erro || !painel) return <Aviso tom="erro">{erro ?? "Sem dados do servidor."}</Aviso>;

  const k = painel.kpis;
  const porStatus = [
    { rotulo: "Normal", valor: k.normais, cor: "bg-success" },
    { rotulo: "Atenção", valor: k.atencao, cor: "bg-warning" },
    { rotulo: "Crítico", valor: k.criticas, cor: "bg-destructive" },
  ];
  const totalStatus = Math.max(1, k.normais + k.atencao + k.criticas);
  const maxSerie = Math.max(1, ...painel.serie.map((d) => d.operacoes));
  const serie = painel.serie.slice(-14);

  const cards = [
    { icone: Package, rotulo: "Operações no período", valor: String(k.operacoes), nota: `${k.concluidas} concluídas` },
    {
      icone: AlertTriangle,
      rotulo: "Cargas com divergência",
      valor: String(k.atencao + k.criticas),
      nota: "necessitam revisão",
      cor: "text-warning",
    },
    {
      icone: Scale,
      rotulo: "Peso total processado",
      valor: toneladas(k.toneladas),
      nota: `média ${kg(k.mediaCargaKg)} por carga`,
    },
    {
      icone: TrendingUp,
      rotulo: "Alertas abertos",
      valor: String(painel.alertas?.abertos ?? 0),
      nota: `${painel.alertas?.criticos_abertos ?? 0} críticos`,
      cor: "text-destructive",
    },
    {
      icone: Gauge,
      rotulo: "Eficiência operacional",
      valor: pct(k.eficienciaPct, 1),
      nota: `desvio médio ${pct(k.desvioMedioPct)}`,
      cor: "text-success",
    },
  ];

  return (
    <>
      <Titulo
        titulo="Dashboard"
        subtitulo="Visão geral das operações de pesagem — últimos 30 dias, lidos do banco de dados"
      />

      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {cards.map((c) => (
          <Cartao key={c.rotulo} className="p-4">
            <c.icone className={`mb-3 h-5 w-5 ${c.cor ?? "text-primary"}`} />
            <div className={`text-[26px] font-bold leading-none ${c.cor ?? ""}`}>{c.valor}</div>
            <div className="mt-2 text-[12px] font-medium">{c.rotulo}</div>
            <div className="text-[11px] text-muted-foreground">{c.nota}</div>
          </Cartao>
        ))}
      </div>

      <div className="mb-6 grid gap-4 xl:grid-cols-3">
        <Cartao className="xl:col-span-2">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-[15px] font-semibold">Operações por dia (últimos 14 dias)</h2>
            <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-sm bg-success" /> Normal
              </span>
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-sm bg-warning" /> Atenção
              </span>
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-sm bg-destructive" /> Crítico
              </span>
            </div>
          </div>
          <div className="flex h-56 items-end gap-2">
            {serie.map((d) => (
              <div key={d.dia} className="flex h-full flex-1 flex-col items-center gap-1">
                <div className="relative w-full flex-1">
                  <div
                    className="absolute bottom-0 flex w-full flex-col-reverse overflow-hidden rounded-t-md bg-card-elev"
                    style={{ height: `${Math.max(2, (d.operacoes / maxSerie) * 100)}%` }}
                    title={`${d.operacoes} operações: ${d.normais ?? 0} normais, ${d.atencao ?? 0} em atenção, ${d.criticas ?? 0} críticas`}
                  >
                    {[
                      { valor: d.normais ?? 0, cor: "bg-success" },
                      { valor: d.atencao ?? 0, cor: "bg-warning" },
                      { valor: d.criticas ?? 0, cor: "bg-destructive" },
                    ].map((seg, i) =>
                      seg.valor > 0 ? <div key={i} className={seg.cor} style={{ flexGrow: seg.valor }} /> : null,
                    )}
                  </div>
                </div>
                <span className="text-[10px] text-muted-foreground">
                  {new Date(d.dia).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}
                </span>
              </div>
            ))}
          </div>
        </Cartao>
        <Cartao>
          <h2 className="mb-4 text-[15px] font-semibold">Distribuição por status</h2>
          <div className="mb-5 flex h-4 overflow-hidden rounded-full bg-card-elev">
            {porStatus.map((s) => (
              <div key={s.rotulo} className={s.cor} style={{ width: `${(s.valor / totalStatus) * 100}%` }} />
            ))}
          </div>
          <ul className="space-y-3 text-[13px]">
            {porStatus.map((s) => (
              <li key={s.rotulo} className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <span className={`h-2.5 w-2.5 rounded-full ${s.cor}`} /> {s.rotulo}
                </span>
                <span className="font-semibold">{s.valor}</span>
              </li>
            ))}
          </ul>
          <div className="mt-6 border-t border-border pt-4 text-[12px] text-muted-foreground">
            Rastreio agora: {painel.rastreio?.em_transito ?? 0} em trânsito · {painel.rastreio?.parados ?? 0} parados ·{" "}
            {painel.rastreio?.sem_sinal ?? 0} sem sinal
          </div>
        </Cartao>
      </div>

      <Cartao>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-[15px] font-semibold">Operações recentes</h2>
          <Link to="/app/planilha" className="text-[12px] font-semibold text-primary">
            Ver planilha completa →
          </Link>
        </div>
        {recentes.length === 0 ? (
          <Vazio texto="Nenhuma operação registrada ainda." />
        ) : (
          <TabelaOperacoes operacoes={recentes} compacta />
        )}
      </Cartao>
      <GuiaPrimeirosPassos
        plataforma="site"
        passos={PASSOS_GUIA_SITE}
        aberto={guiaAberto}
        onFechar={() => setGuiaAberto(false)}
      />
    </>
  );
}

function celulaKg(valor: number | null | undefined) {
  return valor == null ? (
    <span className="text-muted-foreground/60" title="Sem pesagem registrada para esta operação">
      —
    </span>
  ) : (
    kg(valor)
  );
}

export function TabelaOperacoes({ operacoes, compacta = false }: { operacoes: OperacaoApi[]; compacta?: boolean }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[760px] text-left text-[12px]">
        <thead className="text-[11px] uppercase tracking-wide text-muted-foreground">
          <tr className="border-b border-border">
            <th className="py-2 pr-3">Código</th>
            <th className="py-2 pr-3">Data</th>
            <th className="py-2 pr-3">Placa</th>
            <th className="py-2 pr-3">Motorista</th>
            {!compacta && <th className="py-2 pr-3">RFID</th>}
            {!compacta && <th className="py-2 pr-3 text-right">Vazio</th>}
            <th className="py-2 pr-3 text-right">Carga</th>
            {!compacta && <th className="py-2 pr-3 text-right">Esperado</th>}
            {!compacta && <th className="py-2 pr-3 text-right">Real</th>}
            <th className="py-2 pr-3 text-right">Dif. kg</th>
            <th className="py-2 pr-3 text-right">Dif. %</th>
            <th className="py-2">Status</th>
          </tr>
        </thead>
        <tbody>
          {operacoes.map((o) => {
            const st = STATUS_OPERACAO[o.status] ?? STATUS_OPERACAO.ANALYSIS;
            return (
              <tr key={o.id} className="border-b border-border/60 hover:bg-card-elev/60">
                <td className="py-2.5 pr-3 font-semibold text-primary">{o.codigo}</td>
                <td className="py-2.5 pr-3 text-muted-foreground">
                  {dataCurta(o.datas?.concluidaEm ?? o.datas?.iniciadaEm)}
                </td>
                <td className="py-2.5 pr-3 font-semibold">{o.veiculo?.placa ?? "—"}</td>
                <td className="py-2.5 pr-3">{o.motorista ?? "—"}</td>
                {!compacta && <td className="py-2.5 pr-3 text-muted-foreground">{o.rfid ?? "—"}</td>}
                {!compacta && <td className="py-2.5 pr-3 text-right">{celulaKg(o.pesos?.vazioAferidoKg)}</td>}
                <td className="py-2.5 pr-3 text-right">{celulaKg(o.pesos?.cargaAferidaKg)}</td>
                {!compacta && <td className="py-2.5 pr-3 text-right">{celulaKg(o.pesos?.brutoEsperadoKg)}</td>}
                {!compacta && <td className="py-2.5 pr-3 text-right">{celulaKg(o.pesos?.brutoAferidoKg)}</td>}
                <td className="py-2.5 pr-3 text-right">{sinal(o.pesos?.desvioKg)}</td>
                <td className="py-2.5 pr-3 text-right">
                  {o.pesos?.desvioPct == null ? "—" : `${sinal(o.pesos.desvioPct)}%`}
                </td>
                <td className="py-2.5">
                  <Badge cor={st.cor}>{st.rotulo}</Badge>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function Planilha() {
  const navigate = useNavigate();
  const buscar = (p: ParametrosPlanilha) => api.operacoesPagina(queryPlanilha(p));
  return <PlanilhaOperacional buscar={buscar} aoAbrirDetalhe={(op) => navigate(`/app/operacoes/${op.id}`)} />;
}

const TIPOS_HISTORICO = [
  { id: "", rotulo: "Todas" },
  { id: "pesagem", rotulo: "Pesagens" },
  { id: "criacao", rotulo: "Operações criadas" },
  { id: "evento", rotulo: "Eventos" },
  { id: "rastreio", rotulo: "Rastreio" },
  { id: "alerta", rotulo: "Alertas" },
  { id: "edicao", rotulo: "Edições" },
  { id: "cadastro", rotulo: "Cadastros" },
  { id: "acesso", rotulo: "Acessos" },
];

const ICONE_TIPO: Record<string, typeof Scale> = {
  pesagem: Scale,
  criacao: Package,
  evento: Activity,
  rastreio: Radio,
  alerta: AlertTriangle,
  edicao: Pencil,
  cadastro: Users,
  acesso: KeyRound,
};

const COR_TIPO: Record<string, string> = {
  pesagem: "primary",
  criacao: "success",
  evento: "primary",
  rastreio: "primary",
  alerta: "warning",
  edicao: "warning",
  cadastro: "primary",
  acesso: "primary",
};

const CAMPOS_EDICAO: [string, string][] = [
  ["motorista", "Motorista"],
  ["produto", "Produto"],
  ["observacoes", "Observações"],
  ["documentoFiscal", "Nota fiscal"],
  ["mdfe", "MDF-e"],
  ["ciot", "CIOT"],
];

function ComparacaoEdicao({
  antes,
  depois,
  temAntes,
}: {
  antes?: AtividadeApi["antes"];
  depois?: AtividadeApi["depois"];
  temAntes?: boolean;
}) {
  if (!temAntes || !antes) {
    return (
      <Aviso tom="info">
        Versão anterior não registrada nesta edição (feita antes da atualização do histórico). Edições a partir de agora
        guardam antes e depois.
      </Aviso>
    );
  }
  return (
    <div className="overflow-x-auto rounded-xl border border-border">
      <table className="w-full text-left text-[12px]">
        <thead className="bg-card-elev text-[11px] uppercase text-muted-foreground">
          <tr>
            <th className="px-3 py-2 font-semibold">Campo</th>
            <th className="px-3 py-2 font-semibold">Antes</th>
            <th className="px-3 py-2 font-semibold">Agora</th>
          </tr>
        </thead>
        <tbody>
          {CAMPOS_EDICAO.map(([chave, rotulo]) => {
            const valorAntes = antes[chave] ?? "—";
            const valorDepois = depois?.[chave] ?? "—";
            const mudou = valorAntes !== valorDepois;
            return (
              <tr key={chave} className="border-t border-border/60">
                <td className="px-3 py-2 font-medium">{rotulo}</td>
                <td className={`px-3 py-2 ${mudou ? "text-muted-foreground line-through" : "text-muted-foreground"}`}>
                  {valorAntes}
                </td>
                <td className={`px-3 py-2 ${mudou ? "font-semibold text-warning" : ""}`}>{valorDepois}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function Historico() {
  const [aba, setAba] = useState<"atividades" | "operacoes">("atividades");
  const [tipo, setTipo] = useState("");
  const [busca, setBusca] = useState("");
  const [operacaoId, setOperacaoId] = useState("");
  const [de, setDe] = useState("");
  const [ate, setAte] = useState("");
  const [pagina, setPagina] = useState(1);
  const [historico, setHistorico] = useState<HistoricoApi | null>(null);
  const [listaOperacoes, setListaOperacoes] = useState<OperacaoApi[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const [abertas, setAbertas] = useState<Record<string, boolean>>({});

  useEffect(() => {
    Promise.resolve()
      .then(() => api.operacoes("&limite=500"))
      .then((r) => setListaOperacoes(r.operacoes))
      .catch(() => setListaOperacoes([]));
  }, []);

  useEffect(() => {
    setPagina(1);
  }, [tipo, busca, operacaoId, de, ate]);

  const consulta = useMemo(() => {
    const p = new URLSearchParams();
    if (tipo) p.set("tipo", tipo);
    if (busca.trim()) p.set("busca", busca.trim());
    if (operacaoId) p.set("operacaoId", operacaoId);
    if (de) p.set("de", de);
    if (ate) p.set("ate", ate);
    p.set("limite", "100");
    p.set("pagina", String(pagina));
    return p.toString();
  }, [tipo, busca, operacaoId, de, ate, pagina]);

  useEffect(() => {
    if (aba !== "atividades") return;
    let ativo = true;
    const espera = setTimeout(() => {
      setCarregando(true);
      setErro(null);
      Promise.resolve()
        .then(() => api.historico(consulta))
        .then(
          (r) =>
            ativo &&
            setHistorico((anterior) =>
              r.pagina > 1 && anterior ? { ...r, atividades: [...anterior.atividades, ...r.atividades] } : r,
            ),
        )
        .catch((e) => ativo && setErro(e instanceof Error ? e.message : "Falha ao consultar o histórico."))
        .finally(() => ativo && setCarregando(false));
    }, 250);
    return () => {
      ativo = false;
      clearTimeout(espera);
    };
  }, [consulta, aba]);

  const total = historico ? Object.values(historico.contagem).reduce((soma, n) => soma + n, 0) : 0;
  const limpar = () => {
    setTipo("");
    setBusca("");
    setOperacaoId("");
    setDe("");
    setAte("");
  };

  return (
    <>
      <Titulo
        titulo="Histórico"
        subtitulo="Todas as atividades do sistema: pesagens, operações, edições, alertas e acessos"
      />

      <div
        role="tablist"
        aria-label="Seções do histórico"
        className="mb-6 inline-flex gap-1 rounded-xl bg-card-elev p-1"
      >
        {(
          [
            ["atividades", "Atividades"],
            ["operacoes", "Operações"],
          ] as const
        ).map(([valor, rotulo]) => (
          <button
            key={valor}
            type="button"
            role="tab"
            aria-selected={aba === valor}
            onClick={() => setAba(valor)}
            className={`rounded-lg px-4 py-2 text-[13px] font-semibold ${
              aba === valor ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {rotulo}
          </button>
        ))}
      </div>

      {aba === "operacoes" ? (
        <HistoricoOperacoes />
      ) : (
        <div className="grid gap-6 xl:grid-cols-[260px_1fr]">
          <Cartao className="h-fit">
            <h2 className="mb-3 text-[14px] font-semibold">Filtrar atividades</h2>
            <div className="space-y-4">
              <label className="block text-[12px] font-medium">
                Buscar
                <input
                  value={busca}
                  onChange={(e) => setBusca(e.target.value)}
                  placeholder="Placa, código, usuário, texto"
                  className={`${CampoTexto} mt-1`}
                />
              </label>
              <label className="block text-[12px] font-medium">
                Operação
                <select
                  value={operacaoId}
                  onChange={(e) => setOperacaoId(e.target.value)}
                  className={`${CampoTexto} mt-1`}
                >
                  <option value="">Todas as operações</option>
                  {listaOperacoes.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.codigo} · {o.veiculo?.placa ?? "sem placa"}
                    </option>
                  ))}
                </select>
              </label>
              <div className="grid grid-cols-2 gap-2">
                <label className="block text-[12px] font-medium">
                  De
                  <input
                    type="date"
                    value={de}
                    onChange={(e) => setDe(e.target.value)}
                    className={`${CampoTexto} mt-1`}
                  />
                </label>
                <label className="block text-[12px] font-medium">
                  Até
                  <input
                    type="date"
                    value={ate}
                    onChange={(e) => setAte(e.target.value)}
                    className={`${CampoTexto} mt-1`}
                  />
                </label>
              </div>
              <button type="button" onClick={limpar} className="text-[12px] font-semibold text-primary">
                Limpar filtros
              </button>
            </div>
          </Cartao>

          <div className="min-w-0">
            <div className="mb-4 flex flex-wrap gap-2">
              {TIPOS_HISTORICO.map((t) => {
                const n = t.id === "" ? total : (historico?.contagem[t.id] ?? 0);
                const ativo = tipo === t.id;
                return (
                  <button
                    key={t.id || "todas"}
                    type="button"
                    onClick={() => setTipo(t.id)}
                    className={`rounded-full border px-3 py-1.5 text-[12px] font-semibold ${
                      ativo
                        ? "border-primary bg-primary/15 text-primary"
                        : "border-border text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {t.rotulo} <span className="tabular-nums">({n})</span>
                  </button>
                );
              })}
            </div>

            {erro && (
              <div className="mb-4">
                <Aviso tom="erro">{erro}</Aviso>
              </div>
            )}

            {carregando && !historico ? (
              <Carregando />
            ) : !historico || historico.atividades.length === 0 ? (
              <Vazio texto="Nenhuma atividade encontrada com estes filtros." />
            ) : (
              <ul className="space-y-2">
                {historico.atividades.map((a) => {
                  const Icone = ICONE_TIPO[a.tipo] ?? Activity;
                  const aberta = Boolean(abertas[a.id]);
                  const rotuloTipo = TIPOS_HISTORICO.find((t) => t.id === a.tipo)?.rotulo ?? a.tipo;
                  return (
                    <li key={a.id} className="rounded-xl border border-border bg-card p-3">
                      <div className="flex items-start gap-3">
                        <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
                          <Icone className="h-4 w-4" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[13px] font-semibold">{a.rotulo}</span>
                            <Badge cor={COR_TIPO[a.tipo] ?? "primary"}>{rotuloTipo}</Badge>
                          </div>
                          <div className="mt-0.5 text-[11px] text-muted-foreground">
                            {dataCurta(a.data)} · {a.usuario ?? "sistema"}
                            {a.codigo && (
                              <>
                                {" · "}
                                {a.operacaoId ? (
                                  <Link to={`/app/operacoes/${a.operacaoId}`} className="font-semibold text-primary">
                                    {a.codigo}
                                  </Link>
                                ) : (
                                  a.codigo
                                )}
                              </>
                            )}
                            {a.placa && <> · {a.placa}</>}
                          </div>
                          {a.detalhe && <div className="mt-1 text-[12px] text-muted-foreground">{a.detalhe}</div>}

                          {a.tipo === "edicao" && (
                            <button
                              type="button"
                              onClick={() => setAbertas((prev) => ({ ...prev, [a.id]: !aberta }))}
                              className="mt-2 text-[12px] font-semibold text-primary"
                            >
                              {aberta ? "Ocultar antes e depois" : "Ver antes e depois"}
                            </button>
                          )}
                          {a.tipo === "edicao" && aberta && (
                            <div className="mt-3">
                              <ComparacaoEdicao antes={a.antes} depois={a.depois} temAntes={a.temAntes} />
                            </div>
                          )}
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
            {historico && historico.atividades.length > 0 && (
              <p className="mt-3 text-center text-[12px] text-muted-foreground">
                Mostrando {historico.atividades.length} de {historico.total} atividades
              </p>
            )}
            {historico?.temMais && (
              <div className="mt-3 text-center">
                <Botao tipo="button" carregando={carregando} onClick={() => setPagina((p) => p + 1)}>
                  Carregar mais
                </Botao>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}

function HistoricoOperacoes() {
  const [operacoes, setOperacoes] = useState<OperacaoApi[]>([]);
  const [status, setStatus] = useState("");
  const [busca, setBusca] = useState("");
  const [consultaFeita, setConsultaFeita] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(true);

  async function buscar() {
    setCarregando(true);
    setErro(null);
    try {
      const partes = ["&limite=200"];
      if (status) partes.push(`&status=${status}`);
      if (busca.trim()) partes.push(`&busca=${encodeURIComponent(busca.trim())}`);
      setOperacoes((await api.operacoes(partes.join(""))).operacoes);
    } catch (e) {
      setErro(e instanceof Error ? e.message : "Falha ao consultar o histórico.");
    } finally {
      setCarregando(false);
      setConsultaFeita(true);
    }
  }

  useEffect(() => {
    buscar();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Cartao>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          buscar();
        }}
        className="mb-5 grid gap-3 md:grid-cols-[1fr_200px_auto]"
      >
        <input
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          placeholder="Buscar operação, placa, motorista..."
          className={CampoTexto}
        />
        <select value={status} onChange={(e) => setStatus(e.target.value)} className={CampoTexto}>
          <option value="">Todos os status</option>
          <option value="NORMAL">Normal</option>
          <option value="ATTENTION">Atenção</option>
          <option value="CRITICAL">Crítico</option>
          <option value="ANALYSIS">Análise</option>
        </select>
        <Botao tipo="submit" carregando={carregando}>
          Filtrar
        </Botao>
      </form>
      {erro && <Aviso tom="erro">{erro}</Aviso>}
      {!erro && carregando && !consultaFeita && <Carregando />}
      {consultaFeita &&
        !erro &&
        (operacoes.length ? (
          <TabelaOperacoes operacoes={operacoes} />
        ) : (
          <Vazio texto="Nenhuma operação encontrada com estes filtros." />
        ))}
    </Cartao>
  );
}
