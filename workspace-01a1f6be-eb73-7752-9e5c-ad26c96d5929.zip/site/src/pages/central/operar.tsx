import { useEffect, useMemo, useState, type FormEvent } from "react";
import { CheckCircle2, ChevronLeft, ChevronRight, Scale, Truck } from "lucide-react";
import {
  type AlertaApi,
  type MotoristaApi,
  type OperacaoApi,
  type ProdutoApi,
  type RotaApi,
  type VeiculoApi,
} from "@shared/lib/api";
import { Link } from "react-router-dom";
import { api } from "@/lib/dados";
import { AcoesAlerta } from "@/components/AcoesAlerta";
import { Aviso, Badge, Botao, CampoTexto, Cartao, Carregando, Titulo, Vazio } from "@/components/ui";
import { NIVEL_ALERTA, SITUACAO_ALERTA, STATUS_OPERACAO, dataCurta, kg, pct, sinal } from "@/lib/format";
import { useCarga } from "./useCarga";

const mensagem = (e: unknown) => (e instanceof Error ? e.message : "Falha na comunicação com o servidor.");

export function Alertas() {
  const [alertas, setAlertas] = useState<AlertaApi[]>([]);
  const [filtro, setFiltro] = useState<"ABERTOS" | "RESOLVIDOS" | "TODOS">("ABERTOS");
  const { carregando, recarregar } = useCarga(async () => {
    setAlertas((await api.alertas("&limite=200")).alertas);
  });

  const visiveis = alertas.filter((a) => {
    if (filtro === "TODOS") return true;
    if (filtro === "RESOLVIDOS") return a.situacao === "RESOLVED";
    return a.situacao !== "RESOLVED";
  });

  return (
    <>
      <Titulo titulo="Alertas" subtitulo="Alertas automáticos gerados pelo banco de dados (pesagem e rastreamento)" />
      <div className="mb-4 flex gap-2">
        {(["ABERTOS", "RESOLVIDOS", "TODOS"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFiltro(f)}
            className={`rounded-lg px-3 py-1.5 text-[12px] font-semibold ${filtro === f ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground"}`}
          >
            {f === "ABERTOS" ? "Em aberto" : f === "RESOLVIDOS" ? "Resolvidos" : "Todos"}
          </button>
        ))}
      </div>
      {carregando ? (
        <Carregando />
      ) : visiveis.length === 0 ? (
        <Vazio texto="Nenhum alerta nesta visão." />
      ) : (
        <div className="space-y-3">
          {visiveis.map((a) => {
            const nivel = NIVEL_ALERTA[a.nivel] ?? NIVEL_ALERTA.ATTENTION;
            return (
              <Cartao key={a.id} className="p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="mb-1 flex flex-wrap items-center gap-2">
                      <Badge cor={nivel.cor}>{nivel.rotulo}</Badge>
                      <Badge cor={a.situacao === "RESOLVED" ? "success" : "muted"}>{SITUACAO_ALERTA[a.situacao]}</Badge>
                      <span className="text-[11px] text-muted-foreground">{dataCurta(a.criadoEm)}</span>
                    </div>
                    <div className="text-[14px] font-semibold">{a.titulo}</div>
                    <p className="mt-1 text-[13px] text-muted-foreground">{a.mensagem}</p>
                    <p className="mt-2 text-[12px]">
                      Operação <span className="font-semibold text-primary">{a.operacaoCodigo ?? "—"}</span>
                      {a.veiculo && <> · {a.veiculo}</>}
                      {a.motorista && <> · {a.motorista}</>}
                      {a.operacaoId && (
                        <>
                          {" · "}
                          <Link
                            to={`/app/operacoes/${a.operacaoId}`}
                            className="font-semibold text-primary hover:underline"
                          >
                            Ver operação →
                          </Link>
                        </>
                      )}
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-2">
                    <AcoesAlerta alerta={a} onAlterado={recarregar} />
                  </div>
                </div>
              </Cartao>
            );
          })}
        </div>
      )}
    </>
  );
}
