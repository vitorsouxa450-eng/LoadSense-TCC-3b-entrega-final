import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { useSincronia } from "@shared/lib/sincronia";
import { Link } from "react-router-dom";
import { AlertTriangle, CalendarDays, Download, FileText, Gauge, Package, Radio, Scale, Settings } from "lucide-react";
import { sessaoSalva, type OperacaoApi, type PainelApi, type RelatorioApi, type WaypointApi } from "@shared/lib/api";
import { api } from "@/lib/dados";
import { Aviso, Badge, Botao, CampoTexto, Cartao, Carregando, Titulo, Vazio } from "@/components/ui";
import { RASTREIO_ROTULO, dataCurta, kg, pct, sinal, sinalRecente, toneladas } from "@/lib/format";
import { BarrasHorizontais, BarrasVerticais, Rosca, Tendencia } from "@/components/Graficos";
import { useCarga } from "./useCarga";
import { MonitoramentoOperacoes } from "@shared/components/prototipo/MonitoramentoOperacoes";
import { Cadastros } from "./cadastros";
import { PlanosCartao } from "@/components/PlanosCartao";
import { SegundoFatorPainel } from "@shared/components/SegundoFatorPainel";
import { EquipePainel } from "@/components/EquipePainel";
import { SessoesPainel } from "@/components/SessoesPainel";
import { MeusDadosPainel } from "@/components/MeusDadosPainel";
import { CriarContaPainel } from "@/components/CriarContaPainel";
import { AjudaFuncionalidades } from "@shared/components/ajuda/AjudaFuncionalidades";
import { GuiaPrimeirosPassos } from "@shared/components/ajuda/GuiaPrimeirosPassos";
import { FUNCOES_SITE, PASSOS_GUIA_SITE } from "@shared/lib/ajuda";

const mensagem = (e: unknown) => (e instanceof Error ? e.message : "Falha na comunicação com o servidor.");

export function Monitoramento() {
  const [viagens, setViagens] = useState<(OperacaoApi & { waypoints?: WaypointApi[] })[]>([]);
  const [aguardando, setAguardando] = useState<{ id: number; codigo: string; placa: string | null }[]>([]);
  const [erro, setErro] = useState<string | null>(null);
  const [aba, setAba] = useState<"andamento" | "concluidas">("andamento");
  const carregar = useCallback(() => {
    api
      .rastreioAtivo(aba === "concluidas")
      .then((r) => {
        setViagens(r.viagens);
        setAguardando(aba === "concluidas" ? [] : r.aguardandoAtivacao);
        setErro(null);
      })
      .catch((e) => setErro(mensagem(e)));
  }, [aba]);
  useEffect(() => {
    carregar();
  }, [carregar]);
  useSincronia(carregar, true);
  if (erro) return <Aviso tom="erro">{erro}</Aviso>;
  return (
    <>
      <div className="mb-3 flex gap-2" role="tablist" aria-label="Abas do monitoramento">
        {(
          [
            ["andamento", "Em andamento"],
            ["concluidas", "Concluídas"],
          ] as const
        ).map(([id, rotulo]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={aba === id}
            onClick={() => setAba(id)}
            className={`rounded-md border px-3 py-1.5 text-[13px] font-medium ${
              aba === id ? "border-slate-900 bg-slate-900 text-white" : "border-slate-300 bg-white text-slate-700"
            }`}
          >
            {rotulo}
          </button>
        ))}
      </div>
      {aba === "concluidas" && (
        <div className="mb-3">
          <Aviso tom="info">Operações concluídas com rastreio ativado. Elas não aparecem na aba Em andamento.</Aviso>
        </div>
      )}
      {aguardando.length > 0 && (
        <div className="mb-3">
          <Aviso tom="info">
            {aguardando.length} operação(ões) sem rastreio ativado não aparecem aqui:{" "}
            {aguardando
              .slice(0, 3)
              .map((o) => o.codigo)
              .join(", ")}
            {aguardando.length > 3 ? ` e mais ${aguardando.length - 3}` : ""}. Ative o rastreio pelo detalhe da
            operação, com o código RFID fornecido pela empresa.
          </Aviso>
        </div>
      )}
      <MonitoramentoOperacoes viagens={viagens} />
    </>
  );
}

const PERIODOS = [
  { id: "semanal", rotulo: "7 dias", dias: 7 },
  { id: "mensal", rotulo: "30 dias", dias: 30 },
  { id: "bimestral", rotulo: "60 dias", dias: 60 },
  { id: "trimestral", rotulo: "90 dias", dias: 90 },
] as const;

type Periodo = (typeof PERIODOS)[number];

function KpiRelatorio({
  icone: Icone,
  valor,
  rotulo,
  nota,
  cor = "text-foreground",
}: {
  icone: typeof Package;
  valor: string;
  rotulo: string;
  nota?: string;
  cor?: string;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="mb-3 flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 text-primary">
        <Icone className="h-4 w-4" />
      </div>
      <div className={`text-[24px] font-bold leading-none tabular-nums ${cor}`}>{valor}</div>
      <div className="mt-2 text-[12px] font-medium">{rotulo}</div>
      {nota && <div className="text-[11px] text-muted-foreground">{nota}</div>}
    </div>
  );
}

export function Relatorios() {
  const [periodo, setPeriodo] = useState<Periodo>(PERIODOS[1]);
  const [painel, setPainel] = useState<PainelApi | null>(null);
  const [resumo, setResumo] = useState<Awaited<ReturnType<typeof api.resumoRelatorio>> | null>(null);
  const [salvos, setSalvos] = useState<RelatorioApi[]>([]);
  const [divergencias, setDivergencias] = useState<OperacaoApi[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [gerando, setGerando] = useState(false);
  const [mensagemOk, setMensagemOk] = useState<string | null>(null);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    let ativo = true;
    setCarregando(true);
    setErro(null);
    Promise.all([
      api.painel(periodo.dias),
      api.resumoRelatorio(periodo.dias),
      api.relatorios(),
      api.operacoes("&limite=500"),
    ])
      .then(([p, r, lista, ops]) => {
        if (!ativo) return;
        setPainel(p);
        setResumo(r);
        setSalvos(lista.relatorios);
        const inicio = p.periodo.inicio.slice(0, 10);
        const fim = p.periodo.fim.slice(0, 10);
        setDivergencias(
          ops.operacoes
            .filter((o) => o.pesos.desvioKg != null && o.pesos.desvioKg !== 0)
            .filter((o) => {
              const data = (o.datas.iniciadaEm ?? o.datas.concluidaEm ?? "").slice(0, 10);
              return data >= inicio && data <= fim;
            })
            .sort((a, b) => Math.abs(b.pesos.desvioKg ?? 0) - Math.abs(a.pesos.desvioKg ?? 0))
            .slice(0, 8),
        );
      })
      .catch((e) => ativo && setErro(mensagem(e)))
      .finally(() => ativo && setCarregando(false));
    return () => {
      ativo = false;
    };
  }, [periodo.dias]);

  async function exportarOperacoes(formato: "xlsx" | "csv") {
    setErro(null);
    setMensagemOk(null);
    try {
      await api.exportarPlanilha({ dias: periodo.dias }, formato);
      setMensagemOk(`Operações do período ${periodo.rotulo.toLowerCase()} exportadas em ${formato.toUpperCase()}.`);
    } catch (e) {
      setErro(e instanceof Error ? e.message : "Não foi possível exportar.");
    }
  }

  async function gerar() {
    if (!resumo) return;
    setGerando(true);
    setErro(null);
    setMensagemOk(null);
    try {
      const salvo = await api.gerarRelatorio({
        tipo: periodo.id,
        inicio: resumo.periodo.inicio,
        fim: resumo.periodo.fim,
      });
      setMensagemOk(`Relatório ${periodo.rotulo.toLowerCase()} #${salvo.id} gerado e salvo no banco.`);
      setSalvos((await api.relatorios()).relatorios);
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setGerando(false);
    }
  }

  const k = painel?.kpis;
  const serie = painel?.serie ?? [];
  const ultimos = serie.slice(-14);
  const produtos = resumo?.resumo.porProduto ?? [];
  const totalProdutos = produtos.reduce((soma, p) => soma + p.toneladas, 0);
  const emDivergencia = k ? k.atencao + k.criticas : 0;
  const taxaDivergencia = k && k.operacoes > 0 ? (emDivergencia / k.operacoes) * 100 : 0;

  return (
    <>
      <Titulo
        titulo="Relatórios"
        subtitulo="Indicadores e gráficos calculados sobre os dados do banco"
        acoes={
          <div className="flex flex-wrap gap-2">
            {
              <>
                <Botao variante="secundario" onClick={() => exportarOperacoes("csv")} disabled={!resumo || carregando}>
                  <Download className="h-4 w-4" /> Operações (CSV)
                </Botao>
                <Botao variante="secundario" onClick={() => exportarOperacoes("xlsx")} disabled={!resumo || carregando}>
                  <Download className="h-4 w-4" /> Operações (XLSX)
                </Botao>
              </>
            }
            <Botao onClick={gerar} carregando={gerando} disabled={!resumo || carregando}>
              <FileText className="h-4 w-4" /> Gerar e salvar
            </Botao>
          </div>
        }
      />

      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div role="tablist" aria-label="Período do relatório" className="inline-flex gap-1 rounded-xl bg-card-elev p-1">
          {PERIODOS.map((p) => (
            <button
              key={p.id}
              type="button"
              role="tab"
              aria-selected={periodo.id === p.id}
              onClick={() => setPeriodo(p)}
              className={`rounded-lg px-4 py-2 text-[13px] font-semibold transition ${
                periodo.id === p.id
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {p.rotulo}
            </button>
          ))}
        </div>
        {painel && (
          <span className="flex items-center gap-2 text-[12px] text-muted-foreground">
            <CalendarDays className="h-4 w-4 text-primary" />
            Dados de {dataCurtaSemHora(painel.periodo.inicio)} a {dataCurtaSemHora(painel.periodo.fim)}
          </span>
        )}
      </div>

      {mensagemOk && (
        <div className="mb-4">
          <Aviso tom="sucesso">{mensagemOk}</Aviso>
        </div>
      )}
      {erro && (
        <div className="mb-4">
          <Aviso tom="erro">{erro}</Aviso>
        </div>
      )}

      {carregando || !painel || !resumo || !k ? (
        <Carregando />
      ) : (
        <>
          <div className="mb-6 grid grid-cols-2 gap-4 xl:grid-cols-4">
            <KpiRelatorio
              icone={Package}
              valor={String(k.operacoes)}
              rotulo="Operações no período"
              nota={`${k.concluidas} concluídas · ${k.emAndamento} em andamento`}
            />
            <KpiRelatorio
              icone={Scale}
              valor={toneladas(k.toneladas)}
              rotulo="Volume transportado"
              nota={`média ${kg(k.mediaCargaKg)} por carga`}
            />
            <KpiRelatorio
              icone={Gauge}
              valor={pct(k.eficienciaPct, 1)}
              rotulo="Eficiência"
              nota={`desvio médio ${pct(k.desvioMedioPct)}`}
              cor="text-success"
            />
            <KpiRelatorio
              icone={AlertTriangle}
              valor={pct(taxaDivergencia, 1)}
              rotulo="Taxa de divergência"
              nota={`${emDivergencia} cargas com atenção ou crítico`}
              cor="text-warning"
            />
          </div>

          <div className="grid gap-6 xl:grid-cols-[1fr_320px]">
            <div className="space-y-6">
              <Cartao>
                <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
                  <div>
                    <h2 className="text-[15px] font-semibold">Desempenho operacional</h2>
                    <p className="text-[12px] text-muted-foreground">
                      Toneladas transportadas por dia (últimos 14 dias)
                    </p>
                  </div>
                  <span className="text-[12px] text-muted-foreground">
                    pico {toneladas(Math.max(0, ...ultimos.map((d) => d.carga_kg / 1000)))}
                  </span>
                </div>
                {ultimos.length === 0 ? (
                  <Vazio texto="Sem operações no período." />
                ) : (
                  <BarrasVerticais
                    altura={200}
                    valores={ultimos.map((d) => d.carga_kg / 1000)}
                    rotulos={ultimos.map((d) => rotuloDia(d.dia))}
                    formatar={(v) => v.toLocaleString("pt-BR", { maximumFractionDigits: 1 })}
                  />
                )}
              </Cartao>

              <div className="grid gap-6 md:grid-cols-2">
                <Cartao>
                  <h2 className="mb-1 text-[15px] font-semibold">Status das pesagens</h2>
                  <p className="mb-5 text-[12px] text-muted-foreground">Operações por classificação no período</p>
                  <div className="flex items-center gap-5">
                    <Rosca
                      fatias={[
                        { rotulo: "Normal", valor: k.normais, cor: "hsl(var(--success))" },
                        { rotulo: "Atenção", valor: k.atencao, cor: "hsl(var(--warning))" },
                        { rotulo: "Crítico", valor: k.criticas, cor: "hsl(var(--destructive))" },
                      ]}
                    />
                    <ul className="flex-1 space-y-2.5 text-[13px]">
                      {[
                        { rotulo: "Normal", valor: k.normais, cor: "bg-success" },
                        { rotulo: "Atenção", valor: k.atencao, cor: "bg-warning" },
                        { rotulo: "Crítico", valor: k.criticas, cor: "bg-destructive" },
                      ].map((s) => (
                        <li key={s.rotulo} className="flex items-center justify-between">
                          <span className="flex items-center gap-2">
                            <span className={`h-2.5 w-2.5 rounded-sm ${s.cor}`} /> {s.rotulo}
                          </span>
                          <span className="font-semibold tabular-nums">{s.valor}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </Cartao>

                <Cartao>
                  <h2 className="mb-1 text-[15px] font-semibold">Carga por produto</h2>
                  <p className="mb-5 text-[12px] text-muted-foreground">
                    {produtos.length} produto(s) · {toneladas(totalProdutos)} no período
                  </p>
                  {produtos.length === 0 ? (
                    <Vazio texto="Nenhum produto registrado no período." />
                  ) : (
                    <BarrasHorizontais
                      itens={produtos.map((p) => ({
                        rotulo: p.produto,
                        valor: p.toneladas,
                        detalhe: `${p.operacoes} op. · ${toneladas(p.toneladas)}`,
                      }))}
                    />
                  )}
                </Cartao>
              </div>

              <Cartao>
                <h2 className="mb-1 text-[15px] font-semibold">Viagens iniciadas</h2>
                <p className="mb-4 text-[12px] text-muted-foreground">Operações criadas por dia (últimos 14 dias)</p>
                <Tendencia valores={ultimos.map((d) => d.operacoes)} altura={110} />
                <div className="mt-2 flex justify-between text-[11px] text-muted-foreground">
                  <span>{ultimos[0] ? rotuloDia(ultimos[0].dia) : ""}</span>
                  <span>{ultimos.length ? rotuloDia(ultimos[ultimos.length - 1].dia) : ""}</span>
                </div>
              </Cartao>

              <Cartao>
                <h2 className="mb-1 text-[15px] font-semibold">Principais divergências</h2>
                <p className="mb-4 text-[12px] text-muted-foreground">
                  Operações do período com maior diferença entre o peso esperado e o aferido
                </p>
                {divergencias.length === 0 ? (
                  <Vazio texto="Nenhuma divergência de peso registrada no período." />
                ) : (
                  <ul className="divide-y divide-border/60">
                    {divergencias.map((o) => (
                      <li key={o.id} className="flex flex-wrap items-center gap-3 py-2.5 text-[13px]">
                        <Link to={`/app/operacoes/${o.id}`} className="min-w-[120px] font-semibold text-primary">
                          {o.veiculo?.placa ?? o.codigo}
                        </Link>
                        <span className="text-[12px] text-muted-foreground">{o.codigo}</span>
                        <span className="ml-auto font-semibold tabular-nums text-destructive">
                          {sinal(o.pesos.desvioKg)} kg
                        </span>
                        <span className="w-[110px] text-right text-[11px] text-muted-foreground">
                          {dataCurta(o.datas.iniciadaEm ?? o.datas.concluidaEm)}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </Cartao>
            </div>

            <div className="space-y-6">
              <Cartao>
                <h2 className="mb-4 flex items-center gap-2 text-[15px] font-semibold">
                  <Download className="h-4 w-4 text-primary" /> Relatórios salvos
                </h2>
                {salvos.length === 0 ? (
                  <Vazio texto="Nenhum relatório gerado ainda." />
                ) : (
                  <ul className="divide-y divide-border/60">
                    {salvos.slice(0, 10).map((s) => (
                      <li key={s.id} className="flex items-center gap-3 py-3">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary">
                          <FileText className="h-4 w-4" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-[13px] font-semibold">
                            Relatório {NOME_TIPO[s.tipo] ?? s.tipo} #{s.id}
                          </div>
                          <div className="text-[11px] text-muted-foreground">
                            {dataCurta(s.geradoEm)} · {s.geradoPor ?? "sistema"}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => api.exportarRelatorio(s.id).catch((e: Error) => setErro(e.message))}
                          className="inline-flex items-center gap-1 rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-medium hover:bg-card-elev"
                        >
                          <Download className="h-3 w-3" /> CSV
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </Cartao>

              <Cartao>
                <h2 className="mb-3 text-[15px] font-semibold">Alertas no período</h2>
                <div className="text-[30px] font-bold leading-none text-warning tabular-nums">
                  {resumo.resumo.alertas.total ?? 0}
                </div>
                <p className="mt-2 text-[12px] text-muted-foreground">
                  {resumo.resumo.alertas.criticos ?? 0} críticos · {resumo.resumo.alertas.resolvidos ?? 0} resolvidos
                </p>
              </Cartao>
            </div>
          </div>
        </>
      )}
    </>
  );
}

const NOME_TIPO: Record<string, string> = {
  semanal: "semanal",
  mensal: "mensal",
  bimestral: "bimestral",
  trimestral: "trimestral",
};

function rotuloDia(valor: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(valor);
  return m ? `${m[3]}/${m[2]}` : valor;
}

function dataCurtaSemHora(valor: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(valor);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : valor;
}

type AbaConfig = "cadastros" | "parametros" | "equipe" | "cargos" | "criar" | "lgpd" | "ajuda";

const ABAS_CONFIG: { id: AbaConfig; rotulo: string }[] = [
  { id: "cadastros", rotulo: "Planos e cadastros" },
  { id: "parametros", rotulo: "Parâmetros e hardware" },
  { id: "equipe", rotulo: "Equipe e segurança" },
  { id: "cargos", rotulo: "Cargos e permissões" },
  { id: "criar", rotulo: "Criar conta" },
  { id: "lgpd", rotulo: "Meus dados (LGPD)" },
  { id: "ajuda", rotulo: "Ajuda e primeiros passos" },
];

function situacaoDispositivo(d: { state: string; last_seen_at: string | null }): {
  rotulo: string;
  cor: "success" | "warning" | "destructive";
} {
  if (d.state === "ONLINE")
    return sinalRecente(d.last_seen_at)
      ? { rotulo: "Conectado", cor: "success" }
      : { rotulo: d.last_seen_at ? "Sem sinal recente" : "Sem sinal", cor: "warning" };
  if (d.state === "OFFLINE") return { rotulo: "Offline", cor: "destructive" };
  if (d.state === "MAINTENANCE") return { rotulo: "Manutenção", cor: "warning" };
  return { rotulo: "Desativado", cor: "warning" };
}

export function Configuracoes() {
  const sessaoAtual = sessaoSalva();
  const podeEditarParametros = !!sessaoAtual?.permissoes?.includes("SETTINGS_MANAGE");
  const [cfg, setCfg] = useState<Record<string, unknown>>({});
  const [dispositivos, setDispositivos] = useState<Awaited<ReturnType<typeof api.dispositivos>>["dispositivos"]>([]);
  const [tolerancia, setTolerancia] = useState("");
  const [critico, setCritico] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [aviso, setAviso] = useState<{ tom: "erro" | "sucesso"; texto: string } | null>(null);
  const [aba, setAba] = useState<AbaConfig>("cadastros");
  const [guiaAberto, setGuiaAberto] = useState(false);

  const { carregando } = useCarga(async () => {
    const [c, d] = await Promise.all([api.configuracoes(), api.dispositivos()]);
    setCfg(c.configuracoes);
    setDispositivos(d.dispositivos);
    setTolerancia(String(c.configuracoes.tolerance_percent ?? ""));
    setCritico(String(c.configuracoes.critical_limit_percent ?? ""));
  });

  async function salvar(event: FormEvent) {
    event.preventDefault();
    setSalvando(true);
    setAviso(null);
    try {
      const r = await api.atualizarConfiguracoes({
        tolerance_percent: Number(tolerancia.replace(",", ".")),
        critical_limit_percent: Number(critico.replace(",", ".")),
      });
      setCfg(r.configuracoes);
      setAviso({ tom: "sucesso", texto: "Configurações gravadas no banco. Valem para as próximas pesagens." });
    } catch (e) {
      setAviso({ tom: "erro", texto: mensagem(e) });
    } finally {
      setSalvando(false);
    }
  }

  return (
    <>
      <Titulo titulo="Configurações" subtitulo="Parâmetros de pesagem e integrações da empresa" />
      {carregando ? (
        <Carregando />
      ) : (
        <>
          <div role="tablist" className="mb-6 flex flex-wrap gap-2 border-b border-border pb-4">
            {ABAS_CONFIG.filter((a) => a.id !== "criar" || sessaoSalva()?.usuario.papel === "ADMINISTRATOR").map(
              (a) => (
                <button
                  key={a.id}
                  type="button"
                  role="tab"
                  aria-selected={aba === a.id}
                  onClick={() => setAba(a.id)}
                  className={
                    aba === a.id
                      ? "rounded-xl bg-primary px-4 py-2 text-[13px] font-semibold text-primary-foreground"
                      : "rounded-xl border border-border px-4 py-2 text-[13px] font-semibold text-muted-foreground hover:text-foreground"
                  }
                >
                  {a.rotulo}
                </button>
              ),
            )}
          </div>

          {aba === "cadastros" && (
            <div className="grid gap-6 xl:grid-cols-2">
              <PlanosCartao />
              <Cartao className="xl:col-span-2">
                <h2 className="mb-4 flex items-center gap-2 text-[15px] font-semibold">Cadastros</h2>
                <Cadastros />
              </Cartao>
            </div>
          )}

          {aba === "parametros" && (
            <div className="grid gap-6 xl:grid-cols-2">
              <Cartao>
                <h2 className="mb-4 flex items-center gap-2 text-[15px] font-semibold">
                  <Settings className="h-4 w-4 text-primary" /> Parâmetros de pesagem
                </h2>
                {podeEditarParametros ? (
                  <form onSubmit={salvar} className="space-y-4">
                    <label className="block text-[12px] font-medium">
                      Tolerância de peso (%)
                      <span className="block text-[11px] font-normal text-muted-foreground">
                        Diferença aceitável sem alerta
                      </span>
                      <input
                        inputMode="decimal"
                        value={tolerancia}
                        onChange={(e) => setTolerancia(e.target.value)}
                        className={`${CampoTexto} mt-1.5`}
                      />
                    </label>
                    <label className="block text-[12px] font-medium">
                      Limite crítico (%)
                      <span className="block text-[11px] font-normal text-muted-foreground">
                        Acima deste percentual, a operação vira crítica
                      </span>
                      <input
                        inputMode="decimal"
                        value={critico}
                        onChange={(e) => setCritico(e.target.value)}
                        className={`${CampoTexto} mt-1.5`}
                      />
                    </label>
                    {aviso && <Aviso tom={aviso.tom}>{aviso.texto}</Aviso>}
                    <Botao tipo="submit" carregando={salvando}>
                      Salvar parâmetros
                    </Botao>
                  </form>
                ) : (
                  <Aviso tom="info">
                    Somente quem tem permissão de configurações da empresa pode alterar estes parâmetros.
                  </Aviso>
                )}
                <dl className="mt-6 grid grid-cols-2 gap-3 border-t border-border pt-5 text-[12px]">
                  <div>
                    <dt className="text-muted-foreground">Tolerância de tara</dt>
                    <dd className="font-semibold">{pct(Number(cfg.tare_tolerance_percent), 1)}</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Leituras estáveis mínimas</dt>
                    <dd className="font-semibold">{String(cfg.minimum_stable_readings ?? "—")}</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Desvio de rota</dt>
                    <dd className="font-semibold">{String(cfg.route_deviation_tolerance_meters ?? "—")} m</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Atraso para alerta</dt>
                    <dd className="font-semibold">{String(cfg.delivery_delay_alert_minutes ?? "—")} min</dd>
                  </div>
                </dl>
              </Cartao>

              <Cartao>
                <h2 className="mb-4 text-[15px] font-semibold">Integração de hardware</h2>
                {dispositivos.length === 0 ? (
                  <Vazio texto="Nenhum dispositivo cadastrado." />
                ) : (
                  <ul className="space-y-3">
                    {dispositivos.map((d) => {
                      const situacao = situacaoDispositivo(d);
                      return (
                        <li
                          key={d.id}
                          className="flex items-center justify-between gap-3 rounded-xl border border-border p-4"
                        >
                          <div>
                            <div className="font-semibold">{d.name}</div>
                            <div className="text-[12px] text-muted-foreground">
                              {d.device_type}
                              {d.firmware_version ? ` · firmware ${d.firmware_version}` : ""}
                            </div>
                            <div className="text-[11px] text-muted-foreground">
                              {d.last_seen_at
                                ? `Último sinal: ${dataCurta(d.last_seen_at)}`
                                : "Ainda não enviou leituras"}
                              {d.calibracao_valida_ate
                                ? ` · calibração válida até ${dataCurta(d.calibracao_valida_ate)}`
                                : ""}
                            </div>
                          </div>
                          <Badge cor={situacao.cor}>{situacao.rotulo}</Badge>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </Cartao>
            </div>
          )}

          {aba === "equipe" && (
            <div className="grid gap-6 xl:grid-cols-2">
              {sessaoSalva()?.usuario.papel === "ADMINISTRATOR" && (
                <Cartao className="xl:col-span-2">
                  <h2 className="mb-4 text-[15px] font-semibold">Equipe</h2>
                  <EquipePainel secao="pessoas" />
                </Cartao>
              )}
              <Cartao className={sessaoSalva()?.usuario.papel === "ADMINISTRATOR" ? "xl:col-span-2" : undefined}>
                <h2 className="mb-2 text-[15px] font-semibold">Segurança da conta</h2>
                <p className="mb-4 text-[12px] text-muted-foreground">
                  Recomendamos ativar a verificação em duas etapas: um código de 6 números chega ao seu e-mail a cada
                  entrada.
                </p>
                <SegundoFatorPainel />
                {
                  <div className="mt-6 border-t border-border pt-5">
                    <h3 className="mb-3 text-[13px] font-semibold">Sessões ativas</h3>
                    <SessoesPainel />
                  </div>
                }
              </Cartao>
            </div>
          )}

          {aba === "cargos" && sessaoSalva()?.usuario.papel === "ADMINISTRATOR" && (
            <Cartao>
              <h2 className="mb-4 text-[15px] font-semibold">Cargos e permissões</h2>
              <EquipePainel secao="cargos" />
            </Cartao>
          )}

          {aba === "ajuda" && (
            <div className="grid gap-6 xl:grid-cols-2">
              <Cartao className="xl:col-span-2">
                <h2 className="mb-2 text-[15px] font-semibold">Guia de primeiros passos</h2>
                <p className="mb-4 text-[13px] leading-relaxed text-muted-foreground">
                  Passo a passo do sistema, com a finalidade de cada área. Abre automaticamente na primeira vez e pode
                  ser revisto quando quiser.
                </p>
                <Botao onClick={() => setGuiaAberto(true)}>Rever guia de primeiros passos</Botao>
              </Cartao>
              <Cartao className="xl:col-span-2">
                <h2 className="mb-2 text-[15px] font-semibold">O que cada função faz</h2>
                <p className="mb-4 text-[13px] text-muted-foreground">
                  Toque em uma função para ver para que serve, como usar e onde fica.
                </p>
                <AjudaFuncionalidades funcoes={FUNCOES_SITE} />
              </Cartao>
            </div>
          )}

          {aba === "criar" && sessaoSalva()?.usuario.papel === "ADMINISTRATOR" && (
            <div className="grid gap-6">
              <CriarContaPainel />
            </div>
          )}

          {aba === "lgpd" && (
            <Cartao>
              <h2 className="mb-4 text-[15px] font-semibold">Meus dados (LGPD)</h2>
              <MeusDadosPainel />
            </Cartao>
          )}
        </>
      )}
      <GuiaPrimeirosPassos
        plataforma="site"
        passos={PASSOS_GUIA_SITE}
        aberto={guiaAberto}
        onFechar={() => setGuiaAberto(false)}
      />
    </>
  );
}
