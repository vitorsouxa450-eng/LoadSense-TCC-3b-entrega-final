import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { FormCaminhao } from "@/pages/central/cadastro-caminhao";
import { FormMotorista, FormRota } from "@/pages/central/apoio";
import { Pencil, Power } from "lucide-react";
import { api } from "@/lib/dados";
import { Aviso, Badge, Botao, CampoTexto, Cartao, Carregando, Vazio } from "@/components/ui";
import { ErroApi, type MotoristaApi, type RotaApi, type VeiculoApi } from "@shared/lib/api";

export function Cadastros() {
  const [versao, setVersao] = useState(0);
  const atualizar = () => setVersao((v) => v + 1);
  return (
    <div className="space-y-6">
      <p className="text-[12px] text-muted-foreground">
        Cadastre e corrija motoristas, caminhões e rotas. Alterações ficam gravadas no banco e aparecem em Nova
        operação.
      </p>
      <Secao titulo="Motoristas" rotuloNovo="Novo motorista" formulario={<FormMotorista aoCadastrar={atualizar} />}>
        <ListaMotoristas key={`m-${versao}`} />
      </Secao>
      <Secao titulo="Caminhões" rotuloNovo="Novo caminhão" formulario={<FormCaminhao aoCadastrar={atualizar} />}>
        <ListaCaminhoes key={`c-${versao}`} />
      </Secao>
      <Secao titulo="Rotas" rotuloNovo="Nova rota" formulario={<FormRota aoCadastrar={atualizar} />}>
        <ListaRotas key={`r-${versao}`} />
      </Secao>
    </div>
  );
}

function Secao({
  titulo,
  rotuloNovo,
  formulario,
  children,
}: {
  titulo: string;
  rotuloNovo: string;
  formulario: ReactNode;
  children: ReactNode;
}) {
  const [aberto, setAberto] = useState(false);
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="text-[14px] font-semibold">{titulo}</h3>
        <button
          type="button"
          onClick={() => setAberto((v) => !v)}
          aria-expanded={aberto}
          className="rounded-xl border border-border px-3 py-2 text-[12px] font-semibold"
        >
          {aberto ? "Fechar" : `+ ${rotuloNovo}`}
        </button>
      </div>
      {aberto && <div className="rounded-xl border border-border p-4">{formulario}</div>}
      {children}
    </div>
  );
}

function mensagem(erro: unknown): string {
  return erro instanceof ErroApi ? erro.message : "Não foi possível falar com o servidor. Tente de novo.";
}

function useLista<T>(carregar: () => Promise<T>) {
  const [itens, setItens] = useState<T | null>(null);
  const [erro, setErro] = useState<string | null>(null);
  const [versao, setVersao] = useState(0);
  useEffect(() => {
    let ativo = true;
    setErro(null);
    carregar()
      .then((lista) => ativo && setItens(lista))
      .catch((e) => ativo && setErro(mensagem(e)));
    return () => {
      ativo = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [versao]);
  return { itens, erro, recarregar: () => setVersao((v) => v + 1) };
}

interface Campo {
  nome: string;
  rotulo: string;
  tipo?: "text" | "number";
}

function LinhaCadastro({
  titulo,
  detalhe,
  ativo,
  campos,
  valores,
  salvar,
  alternar,
  eliminar,
}: {
  titulo: string;
  detalhe: string;
  ativo: boolean;
  campos: Campo[];
  valores: Record<string, string>;
  salvar: (corpo: Record<string, unknown>) => Promise<void>;
  alternar: () => Promise<void>;
  eliminar?: () => Promise<void>;
}) {
  const [editando, setEditando] = useState(false);
  const [rascunho, setRascunho] = useState<Record<string, string>>(valores);
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  async function aoSalvar(evento: FormEvent) {
    evento.preventDefault();
    setEnviando(true);
    setErro(null);
    try {
      const corpo: Record<string, unknown> = {};
      for (const campo of campos) {
        const v = rascunho[campo.nome] ?? "";
        corpo[campo.nome] = campo.tipo === "number" ? (v === "" ? null : Number(v.replace(",", "."))) : v;
      }
      await salvar(corpo);
      setEditando(false);
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setEnviando(false);
    }
  }

  async function aoAlternar() {
    if (
      ativo &&
      !window.confirm(
        "Desativar este cadastro? Ele sai das listas para novas operações, mas continua listado como Inativo. Operações já criadas não mudam. Dá para reativar depois.",
      )
    )
      return;
    setEnviando(true);
    setErro(null);
    try {
      await alternar();
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <li className="rounded-xl border border-border p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-semibold">{titulo}</span>
            {!ativo && <Badge cor="warning">Inativo</Badge>}
          </div>
          <div className="text-[12px] text-muted-foreground">{detalhe}</div>
        </div>
        <div className="flex gap-2">
          {campos.length > 0 && (
            <button
              type="button"
              onClick={() => {
                setRascunho(valores);
                setEditando((v) => !v);
              }}
              className="flex items-center gap-1 rounded-xl border border-border px-3 py-2 text-[12px] font-semibold"
            >
              <Pencil className="h-3.5 w-3.5" /> {editando ? "Fechar" : "Editar"}
            </button>
          )}
          <button
            type="button"
            onClick={aoAlternar}
            disabled={enviando}
            className="flex items-center gap-1 rounded-xl border border-border px-3 py-2 text-[12px] font-semibold disabled:opacity-60"
          >
            <Power className="h-3.5 w-3.5" /> {ativo ? "Desativar" : "Reativar"}
          </button>
          {eliminar && (
            <button
              type="button"
              disabled={enviando}
              onClick={async () => {
                if (
                  !window.confirm(
                    "Eliminar os dados pessoais deste motorista (CPF, CNH, telefone)? Não é possível desfazer.",
                  )
                )
                  return;
                setEnviando(true);
                setErro(null);
                try {
                  await eliminar();
                } catch (e) {
                  setErro(mensagem(e));
                } finally {
                  setEnviando(false);
                }
              }}
              className="flex items-center gap-1 rounded-xl border border-destructive/40 px-3 py-2 text-[12px] font-semibold text-destructive disabled:opacity-60"
            >
              Excluir dados pessoais
            </button>
          )}
        </div>
      </div>
      {erro && (
        <div className="mt-3">
          <Aviso tom="erro">{erro}</Aviso>
        </div>
      )}
      {editando && (
        <form onSubmit={aoSalvar} className="mt-4 grid gap-3 sm:grid-cols-2">
          {campos.map((campo) => (
            <label key={campo.nome} className="block text-[12px] font-medium">
              {campo.rotulo}
              <input
                inputMode={campo.tipo === "number" ? "decimal" : undefined}
                value={rascunho[campo.nome] ?? ""}
                onChange={(e) => setRascunho({ ...rascunho, [campo.nome]: e.target.value })}
                className={`${CampoTexto} mt-1.5`}
              />
            </label>
          ))}
          <div className="sm:col-span-2">
            <Botao tipo="submit" carregando={enviando}>
              Salvar alterações
            </Botao>
          </div>
        </form>
      )}
    </li>
  );
}

function Lista<T>({
  itens,
  erro,
  vazio,
  renderItem,
}: {
  itens: T[] | null;
  erro: string | null;
  vazio: string;
  renderItem: (item: T) => ReactNode;
}) {
  if (erro) return <Aviso tom="erro">{erro}</Aviso>;
  if (itens === null) return <Carregando />;
  if (itens.length === 0) return <Vazio texto={vazio} />;
  return <ul className="space-y-3">{itens.map(renderItem)}</ul>;
}

function ListaMotoristas() {
  const { itens, erro, recarregar } = useLista(
    async () =>
      (await api.get<{ motoristas: (MotoristaApi & { active?: number })[] }>("/motoristas?incluirInativos=1"))
        .motoristas,
  );
  return (
    <Cartao>
      <Lista
        itens={itens}
        erro={erro}
        vazio="Nenhum motorista cadastrado."
        renderItem={(m) => (
          <LinhaCadastro
            key={m.id}
            titulo={m.full_name}
            detalhe={`CNH ${m.license_number ?? "—"}${m.phone ? ` · ${m.phone}` : ""}`}
            ativo={m.active !== 0}
            campos={[
              { nome: "nome", rotulo: "Nome completo" },
              { nome: "telefone", rotulo: "Telefone" },
            ]}
            valores={{ nome: m.full_name, telefone: m.phone ?? "" }}
            salvar={async (corpo) => {
              await api.patch(`/motoristas/${m.id}`, corpo);
              recarregar();
            }}
            alternar={async () => {
              await api.patch(`/motoristas/${m.id}`, { ativo: m.active === 0 });
              recarregar();
            }}
            eliminar={async () => {
              await api.post(`/motoristas/${m.id}/anonimizar`, {});
              recarregar();
            }}
          />
        )}
      />
    </Cartao>
  );
}

function ListaCaminhoes() {
  const { itens, erro, recarregar } = useLista(
    async () =>
      (await api.get<{ veiculos: (VeiculoApi & { active?: number })[] }>("/veiculos?incluirInativos=1")).veiculos,
  );
  return (
    <Cartao>
      <Lista
        itens={itens}
        erro={erro}
        vazio="Nenhum caminhão cadastrado."
        renderItem={(v) => (
          <LinhaCadastro
            key={v.id}
            titulo={v.plate}
            detalhe={`${[v.manufacturer, v.model].filter(Boolean).join(" ") || "Modelo não informado"}${v.fleet_code ? ` · frota ${v.fleet_code}` : ""}`}
            ativo={v.active !== 0}
            campos={[
              { nome: "frota", rotulo: "Código da frota" },
              { nome: "fabricante", rotulo: "Fabricante" },
              { nome: "modelo", rotulo: "Modelo" },
              { nome: "tara", rotulo: "Tara (kg)", tipo: "number" },
              { nome: "limiteBruto", rotulo: "Limite bruto (kg)", tipo: "number" },
            ]}
            valores={{
              frota: v.fleet_code ?? "",
              fabricante: v.manufacturer ?? "",
              modelo: v.model ?? "",
              tara: v.registered_tare_kg != null ? String(v.registered_tare_kg) : "",
              limiteBruto: v.gross_weight_limit_kg != null ? String(v.gross_weight_limit_kg) : "",
            }}
            salvar={async (corpo) => {
              await api.patch(`/veiculos/${v.id}`, corpo);
              recarregar();
            }}
            alternar={async () => {
              await api.patch(`/veiculos/${v.id}`, { ativo: v.active === 0 });
              recarregar();
            }}
          />
        )}
      />
    </Cartao>
  );
}

function ListaRotas() {
  const { itens, erro, recarregar } = useLista(
    async () => (await api.get<{ rotas: (RotaApi & { active?: number })[] }>("/rotas?incluirInativos=1")).rotas,
  );
  return (
    <Cartao>
      <Lista
        itens={itens}
        erro={erro}
        vazio="Nenhuma rota cadastrada."
        renderItem={(r) => (
          <LinhaCadastro
            key={r.id}
            titulo={`${r.origin} → ${r.destination}`}
            detalhe={`${r.code ?? "Sem código"}${r.distance_km != null ? ` · ${r.distance_km} km` : ""}`}
            ativo={r.active !== 0}
            campos={[
              { nome: "origem", rotulo: "Origem" },
              { nome: "destino", rotulo: "Destino" },
              { nome: "distanciaKm", rotulo: "Distância (km)", tipo: "number" },
            ]}
            valores={{
              origem: r.origin,
              destino: r.destination,
              distanciaKm: r.distance_km != null ? String(r.distance_km) : "",
            }}
            salvar={async (corpo) => {
              await api.patch(`/rotas/${r.id}`, corpo);
              recarregar();
            }}
            alternar={async () => {
              await api.patch(`/rotas/${r.id}`, { ativo: r.active === 0 });
              recarregar();
            }}
          />
        )}
      />
    </Cartao>
  );
}
