import { useCallback, useEffect, useRef, useState } from "react";

export function useCarga(carregar: () => Promise<void>) {
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const jaCarregou = useRef(false);

  const recarregar = useCallback(async () => {
    if (!jaCarregou.current) setCarregando(true);
    setErro(null);
    try {
      await carregar();
    } catch (e) {
      setErro(e instanceof Error ? e.message : "Falha ao carregar os dados do servidor.");
    } finally {
      jaCarregou.current = true;
      setCarregando(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    recarregar();
  }, [recarregar]);

  return { carregando, erro, recarregar };
}
