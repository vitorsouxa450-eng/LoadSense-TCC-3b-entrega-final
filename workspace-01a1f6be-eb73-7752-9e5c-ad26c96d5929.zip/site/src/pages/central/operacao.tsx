import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Download, Phone } from "lucide-react";
import {
  ErroApi,
  type AlertaApi,
  type DispositivoApi,
  type MotoristaApi,
  type OperacaoDetalheApi,
} from "@shared/lib/api";
import { useSincronia } from "@shared/lib/sincronia";
import { MonitoramentoDaOperacao } from "@shared/components/prototipo/MonitoramentoOperacoes";
import { api } from "@/lib/dados";
import { AcoesAlerta } from "@/components/AcoesAlerta";
import { Aviso, Badge, Botao, CampoTexto, Cartao, Carregando, Titulo } from "@/components/ui";
import {
  ESTADO_OPERACAO,
  NIVEL_ALERTA,
  RASTREIO_ROTULO,
  SITUACAO_ALERTA,
  STATUS_OPERACAO,
  dataCurta,
  kg,
  pct,
  sinal,
  sinalRecente,
} from "@/lib/format";
import { useCarga } from "./useCarga";

const EVENTO: Record<string, string> = {
  TRACKING_STARTED: "Rastreio iniciado",
  TRACKING_RESUMED: "Rastreio retomado",
  TRACKING_STOPPED: "Veículo parado",
  TRACKING_ARRIVED: "Chegada ao destino",
  TRACKING_CANCELLED: "Transporte cancelado",
  FINALIZED: "Pesagem finalizada",
  READING_ACCEPTED: "Leitura aceita",
  CREATED: "Operação criada",
  STARTED: "Transporte iniciado",
  CANCELLED: "Operação cancelada",
};
const ACAO: Record<string, string> = {
  UPDATE_OPERATION: "Dados corrigidos",
  CANCEL_OPERATION: "Operação cancelada",
  COMPLETE_OPERATION: "Pesagem concluída",
};
const ESTAGIO: Record<string, string> = {
  EMPTY_TRUCK: "Caminhão vazio",
  SEPARATED_CARGO: "Carga separada",
  LOADED_TRUCK: "Caminhão carregado",
};
const CAMPOS_AUDITORIA: Record<string, string> = {
  motoristaId: "Motorista",
  observacoes: "Observações",
  estado: "Estado",
  status: "Status",
};

const mercatorY = (lat: number) => Math.log(Math.tan(Math.PI / 4 + (lat * Math.PI) / 360));

const ATRASO_RASTREIO_MIN = 15;
const DESVIO_ALERTA_M = 500;

function Secao({ titulo, children }: { titulo: string; children: ReactNode }) {
  return (
    <Cartao>
      <h2 className="mb-3 text-[14px] font-semibold">{titulo}</h2>
      {children}
    </Cartao>
  );
}

function Campo({ rotulo, valor }: { rotulo: string; valor: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-border/60 py-2 last:border-0">
      <span className="text-[12px] text-muted-foreground">{rotulo}</span>
      <span className="text-right text-[13px] font-medium">{valor ?? "—"}</span>
    </div>
  );
}

function minutosDesde(iso: string | null | undefined): number | null {
  if (!iso) return null;
  const t = new Date(iso).getTime();
  return Number.isNaN(t) ? null : Math.round((Date.now() - t) / 60000);
}

export function OperacaoDetalhe() {
  const { id } = useParams<{ id: string }>();
  const [op, setOp] = useState<OperacaoDetalheApi | null>(null);
  const [exportando, setExportando] = useState(false);
  const [erroExport, setErroExport] = useState<string | null>(null);
  const [aceitando, setAceitando] = useState<number | null>(null);
  const [erroLeitura, setErroLeitura] = useState<string | null>(null);
  const { carregando, erro, recarregar } = useCarga(async () => {
    setOp(await api.operacao(Number(id)));
  });
  useSincronia(() => {
    void recarregar();
  }, true);

  if (carregando) return <Carregando />;
  if (erro || !op) return <Aviso tom="erro">{erro ?? "Operação não encontrada."}</Aviso>;

  const st = STATUS_OPERACAO[op.status] ?? { rotulo: op.status, cor: "muted" };
  const alertasAbertos = op.alertas.filter((a: AlertaApi) => a.situacao !== "RESOLVED");
  const r = op.rastreio;
  const semAtualizacao = r?.estado === "IN_TRANSIT" ? minutosDesde(r.ultimaPosicaoEm) : null;
  const desvioAlto = (r?.desvioMetros ?? 0) > DESVIO_ALERTA_M;

  const podeOperar = op.estado === "DRAFT" || op.estado === "IN_PROGRESS";

  async function aceitarLeitura(leituraId: number) {
    setErroLeitura(null);
    setAceitando(leituraId);
    try {
      await api.aceitarLeitura(op!.id, leituraId);
      await recarregar();
    } catch (e) {
      setErroLeitura(e instanceof ErroApi ? e.message : "Não foi possível aceitar a leitura.");
    } finally {
      setAceitando(null);
    }
  }

  async function exportar(formato: "xlsx" | "csv") {
    setExportando(true);
    setErroExport(null);
    try {
      await api.exportarOperacao(op!.id, formato);
    } catch (e) {
      setErroExport(e instanceof Error ? e.message : "Não foi possível exportar.");
    } finally {
      setExportando(false);
    }
  }

  return (
    <>
      <Link
        to="/app/planilha"
        className="mb-3 inline-flex items-center gap-1 text-[12px] text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Voltar para a planilha
      </Link>
      <Titulo
        titulo="Detalhes da operação"
        subtitulo={`${op.codigo} · ${op.veiculo.placa ?? "Sem placa"} · ${op.motorista ?? "Sem motorista"} · ${op.rota.origem ?? "—"} → ${op.rota.destino ?? "—"}`}
        acoes={
          <div className="flex flex-wrap gap-2">
            <Botao variante="secundario" carregando={exportando} onClick={() => exportar("xlsx")}>
              <Download className="h-4 w-4" /> Excel
            </Botao>
            <Botao variante="secundario" carregando={exportando} onClick={() => exportar("csv")}>
              <Download className="h-4 w-4" /> CSV
            </Botao>
          </div>
        }
      />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <Badge cor={st.cor}>{st.rotulo}</Badge>
        <Badge cor="muted">{ESTADO_OPERACAO[op.estado] ?? op.estado}</Badge>
        {op.statusMotivo && <span className="text-[12px] text-muted-foreground">{op.statusMotivo}</span>}
      </div>
      {erroExport && (
        <div className="mb-4">
          <Aviso tom="erro">{erroExport}</Aviso>
        </div>
      )}

      {alertasAbertos.length > 0 && (
        <div className="mb-4 space-y-3">
          <h2 className="text-[14px] font-semibold">Alertas desta operação</h2>
          {alertasAbertos.map((a: AlertaApi) => {
            const nivel = NIVEL_ALERTA[a.nivel] ?? NIVEL_ALERTA.ATTENTION;
            return (
              <Cartao key={a.id} className="p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="mb-1 flex flex-wrap items-center gap-2">
                      <Badge cor={nivel.cor}>{nivel.rotulo}</Badge>
                      <Badge cor="muted">{SITUACAO_ALERTA[a.situacao]}</Badge>
                      <span className="text-[11px] text-muted-foreground">{dataCurta(a.criadoEm)}</span>
                    </div>
                    <div className="text-[14px] font-semibold">{a.titulo}</div>
                    <p className="mt-1 text-[13px] text-muted-foreground">{a.mensagem}</p>
                    {a.reconhecidoPor && (
                      <p className="mt-1 text-[11px] text-muted-foreground">Reconhecido por {a.reconhecidoPor}</p>
                    )}
                    {a.situacao === "RESOLVED" && a.resolvidoPor && (
                      <p className="mt-1 text-[11px] text-muted-foreground">
                        Resolvido por {a.resolvidoPor}
                        {a.resolvidoEm ? ` em ${dataCurta(a.resolvidoEm)}` : ""}
                      </p>
                    )}
                  </div>
                  <AcoesAlerta alerta={a} onAlterado={recarregar} />
                </div>
              </Cartao>
            );
          })}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        <Secao titulo="Motorista e veículo">
          <Campo rotulo="Motorista" valor={op.motorista} />
          <Campo
            rotulo="Telefone"
            valor={
              op.motoristaTelefone ? (
                <a
                  className="inline-flex items-center gap-1 text-primary hover:underline"
                  href={`tel:${op.motoristaTelefone.replace(/\D/g, "")}`}
                >
                  <Phone className="h-3.5 w-3.5" /> {op.motoristaTelefone}
                </a>
              ) : (
                "—"
              )
            }
          />
          <Campo rotulo="Placa" valor={op.veiculo.placa} />
          <Campo rotulo="Frota" valor={op.veiculo.frota} />
          <Campo rotulo="Tipo de veículo" valor={op.veiculo.tipo} />
          <Campo rotulo="RFID" valor={op.rfid} />
        </Secao>

        <Secao titulo="Carga e documentos">
          <Campo rotulo="Produto" valor={op.produto} />
          <Campo rotulo="Movimento" valor={op.tipoMovimento} />
          <Campo rotulo="Método de pesagem" valor={op.metodo === "THREE_STAGE" ? "Três etapas" : "Bruto/tara"} />
          <Campo rotulo="Nota fiscal" valor={op.documentoFiscal} />
          <Campo rotulo="MDF-e" valor={op.mdfe} />
          <Campo rotulo="CIOT" valor={op.ciot} />
          <Campo rotulo="Unidade" valor={op.unidade} />
          <Campo rotulo="Posto de pesagem" valor={op.posto} />
          <Campo rotulo="Responsável" valor={op.responsavel} />
          <Campo rotulo="Criada por" valor={op.criadoPor} />
        </Secao>

        <Secao titulo="Rota e datas">
          <Campo rotulo="Origem" valor={op.rota.origem} />
          <Campo rotulo="Destino" valor={op.rota.destino} />
          <Campo rotulo="Distância" valor={op.rota.distanciaKm != null ? `${op.rota.distanciaKm} km` : "—"} />
          <Campo rotulo="Saída planejada" valor={dataCurta(op.datas.saidaPlanejada)} />
          <Campo rotulo="Saída real" valor={dataCurta(op.datas.saidaReal)} />
          <Campo rotulo="Chegada planejada" valor={dataCurta(op.datas.chegadaPlanejada)} />
          <Campo rotulo="Chegada real" valor={dataCurta(op.datas.chegadaReal)} />
          <Campo rotulo="Concluída em" valor={dataCurta(op.datas.concluidaEm)} />
          {op.datas.canceladaEm && <Campo rotulo="Cancelada em" valor={dataCurta(op.datas.canceladaEm)} />}
        </Secao>

        <Secao titulo="Rastreio em tempo real">
          <AtivarRastreio operacao={op} aoSalvar={recarregar} />
          {op.rastreioAtivado && (
            <div className="mb-3">
              <MonitoramentoDaOperacao op={op} trajeto={op.trajeto} />
            </div>
          )}
          {!r || r.estado === null ? (
            <Aviso tom="info">O transporte ainda não foi iniciado.</Aviso>
          ) : (
            <>
              {semAtualizacao != null && semAtualizacao > ATRASO_RASTREIO_MIN && (
                <div className="mb-3">
                  <Aviso tom="erro">Sem atualização do rastreio há {semAtualizacao} min.</Aviso>
                </div>
              )}
              {desvioAlto && (
                <div className="mb-3">
                  <Aviso tom="erro">Desvio de {Math.round(r.desvioMetros ?? 0)} m da rota prevista.</Aviso>
                </div>
              )}
              {r.atrasoMin != null && r.atrasoMin > 0 && (
                <div className="mb-3">
                  <Aviso tom="info">Previsão com atraso de {r.atrasoMin} min.</Aviso>
                </div>
              )}
              <Campo rotulo="Situação" valor={RASTREIO_ROTULO[r.estado] ?? r.estado} />
              <Campo rotulo="Progresso" valor={pct(r.progressoPct ?? null, 0)} />
              <Campo
                rotulo="Velocidade"
                valor={r.velocidadeKmh != null ? `${Math.round(r.velocidadeKmh)} km/h` : "—"}
              />
              <Campo rotulo="Desvio da rota" valor={r.desvioMetros != null ? `${Math.round(r.desvioMetros)} m` : "—"} />
              <Campo rotulo="Previsão de chegada" valor={dataCurta(r.eta)} />
              <Campo rotulo="Última posição" valor={dataCurta(r.ultimaPosicaoEm)} />
              {r.paradoDesde && <Campo rotulo="Parado desde" valor={dataCurta(r.paradoDesde)} />}
              <Campo
                rotulo="Posição"
                valor={r.latitude != null ? `${r.latitude.toFixed(4)}, ${r.longitude?.toFixed(4)}` : "—"}
              />
            </>
          )}
        </Secao>

        <Secao titulo="Pesagem">
          <Campo rotulo="Tara cadastrada" valor={kg(op.pesos.taraCadastradaKg)} />
          <Campo rotulo="Caminhão vazio (aferido)" valor={kg(op.pesos.vazioAferidoKg)} />
          <Campo rotulo="Carga separada" valor={kg(op.pesos.cargaSeparadaKg)} />
          <Campo rotulo="Carga declarada" valor={kg(op.pesos.cargaDeclaradaKg)} />
          <Campo rotulo="Bruto esperado" valor={kg(op.pesos.brutoEsperadoKg)} />
          <Campo rotulo="Bruto aferido" valor={kg(op.pesos.brutoAferidoKg)} />
          <Campo rotulo="Carga aferida" valor={kg(op.pesos.cargaAferidaKg)} />
          <Campo
            rotulo="Diferença"
            valor={
              op.pesos.desvioKg != null
                ? `${sinal(op.pesos.desvioKg)} kg${op.pesos.desvioPct != null ? ` (${pct(op.pesos.desvioPct)})` : ""}`
                : "—"
            }
          />
          <Campo rotulo="Limite bruto" valor={kg(op.pesos.limiteBrutoKg)} />
          <Campo rotulo="Limite da carga" valor={kg(op.pesos.limiteCargaKg)} />
          <Campo rotulo="Tolerância" valor={op.pesos.toleranciaPct != null ? `${op.pesos.toleranciaPct}%` : "—"} />
          <Campo
            rotulo="Limite crítico"
            valor={op.pesos.limiteCriticoPct != null ? `${op.pesos.limiteCriticoPct}%` : "—"}
          />
        </Secao>

        <Secao titulo="Leituras">
          {erroLeitura && <Aviso tom="erro">{erroLeitura}</Aviso>}
          {op.leituras.length === 0 ? (
            <Aviso tom="info">Nenhuma leitura registrada.</Aviso>
          ) : (
            <ul className="divide-y divide-border/60">
              {op.leituras.map((l) => (
                <li key={l.id} className="flex flex-wrap items-center justify-between gap-2 py-2 text-[13px]">
                  <span>
                    {ESTAGIO[l.estagio] ?? l.estagio}{" "}
                    <span className="text-muted-foreground">· leitura {l.sequencia}</span>
                  </span>
                  <span className="flex items-center gap-2">
                    <span className="font-semibold">{`${l.pesoKg.toLocaleString("pt-BR", { maximumFractionDigits: 3 })} kg`}</span>
                    <Badge cor={l.aceita ? "success" : "muted"}>{l.aceita ? "Aceita" : "Não aceita"}</Badge>
                    {!l.aceita && podeOperar && (
                      <Botao variante="secundario" carregando={aceitando === l.id} onClick={() => aceitarLeitura(l.id)}>
                        Aceitar
                      </Botao>
                    )}
                  </span>
                  <span className="w-full text-[11px] text-muted-foreground">
                    {l.origem === "MANUAL" ? "Manual" : l.origem === "IMPORT" ? "Importada" : "Balança"} ·{" "}
                    {l.estavel ? "estável" : "instável"} · {dataCurta(l.medidoEm)}
                    {l.motivoManual ? ` · ${l.motivoManual}` : ""}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Secao>

        <BalancaDaOperacao operacaoId={op.id} status={op.estado} recarregar={recarregar} />

        <Secao titulo="Histórico de eventos">
          {op.eventos.length === 0 ? (
            <Aviso tom="info">Nenhum evento registrado.</Aviso>
          ) : (
            <ul className="max-h-80 divide-y divide-border/60 overflow-y-auto">
              {op.eventos.map((e) => (
                <li key={e.id} className="py-2 text-[13px]">
                  <div className="flex justify-between gap-3">
                    <span className="font-medium">{EVENTO[e.tipo] ?? e.tipo.replace(/_/g, " ").toLowerCase()}</span>
                    <span className="text-[11px] text-muted-foreground">{dataCurta(e.criadoEm)}</span>
                  </div>
                  <div className="text-[11px] text-muted-foreground">{e.usuario ?? "Sistema / dispositivo"}</div>
                </li>
              ))}
            </ul>
          )}
        </Secao>

        <Secao titulo="Alterações manuais">
          {(op.auditoria ?? []).length === 0 ? (
            <Aviso tom="info">Nenhuma correção manual registrada nesta operação.</Aviso>
          ) : (
            <ul className="max-h-80 divide-y divide-border/60 overflow-y-auto">
              {(op.auditoria ?? []).map((a) => {
                const campos = Object.keys(a.depois ?? {}).filter((c) => c in CAMPOS_AUDITORIA);
                return (
                  <li key={a.id} className="py-2 text-[13px]">
                    <div className="flex justify-between gap-3">
                      <span className="font-medium">{ACAO[a.acao] ?? a.acao}</span>
                      <span className="text-[11px] text-muted-foreground">{dataCurta(a.criadoEm)}</span>
                    </div>
                    <div className="text-[11px] text-muted-foreground">
                      {a.usuario ?? "Usuário removido"}
                      {campos.length > 0 && ` · ${campos.map((c) => CAMPOS_AUDITORIA[c]).join(", ")}`}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </Secao>

        <Secao titulo="Pesagem">
          {op.estado === "DRAFT" || op.estado === "IN_PROGRESS" ? (
            <RegistrarPesagem operacao={op} aoSalvar={recarregar} />
          ) : (
            <p className="text-[12px] text-muted-foreground">
              Esta operação já está encerrada. Os pesos estão na seção acima.
            </p>
          )}
        </Secao>

        <Secao titulo="Transporte">
          <Transporte operacao={op} aoSalvar={recarregar} />
        </Secao>

        {(op.estado === "DRAFT" || op.estado === "IN_PROGRESS") && (
          <Secao titulo="Editar operação">
            <Link
              to={`/app/operacoes/${op.id}/editar`}
              className="inline-flex items-center rounded-xl border border-border px-3 py-2 text-[12px] font-semibold"
            >
              Editar motorista, produto, documentos e observações
            </Link>
          </Secao>
        )}

        {(op.estado === "DRAFT" || op.estado === "IN_PROGRESS") && (
          <Secao titulo="Cancelar operação">
            <CancelarOperacao operacao={op} aoSalvar={recarregar} />
          </Secao>
        )}

        <Secao titulo="Observações">
          <p className="whitespace-pre-line text-[13px] text-muted-foreground">
            {op.observacoes || "Sem observações."}
          </p>
        </Secao>
      </div>
    </>
  );
}

function RegistrarPesagem({ operacao, aoSalvar }: { operacao: OperacaoDetalheApi; aoSalvar: () => void }) {
  const [vazio, setVazio] = useState("");
  const [carregado, setCarregado] = useState("");
  const [motivo, setMotivo] = useState("Pesagem registrada pela central web (sem balança conectada)");
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  const numeroBr = (texto: string) => Number(texto.replace(",", "."));

  async function registrar(evento: FormEvent) {
    evento.preventDefault();
    const v = numeroBr(vazio);
    const c = numeroBr(carregado);
    if (!(v > 0)) return setErro("Informe o peso do caminhão vazio.");
    if (!(c > v)) return setErro("O caminhão carregado precisa pesar mais que o vazio.");
    if (motivo.trim().length < 5) return setErro("Informe o motivo do registro manual.");
    setEnviando(true);
    setErro(null);
    try {
      await api.registrarLeitura(operacao.id, {
        estagio: "EMPTY_TRUCK",
        pesoKg: v,
        origem: "MANUAL",
        motivoManual: motivo.trim(),
      });
      await api.registrarLeitura(operacao.id, {
        estagio: "LOADED_TRUCK",
        pesoKg: c,
        origem: "MANUAL",
        motivoManual: motivo.trim(),
      });
      await api.finalizarOperacao(operacao.id);
      aoSalvar();
    } catch (e) {
      setErro(e instanceof ErroApi ? e.message : "Não foi possível registrar a pesagem.");
    } finally {
      setEnviando(false);
    }
  }

  return (
    <form onSubmit={registrar} className="space-y-3">
      <p className="text-[12px] text-muted-foreground">
        Sem balança conectada, informe os pesos lidos. Ao registrar, a pesagem é finalizada e a operação é encerrada.
      </p>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block text-[12px] font-medium">
          Caminhão vazio (kg)
          <input
            inputMode="decimal"
            value={vazio}
            onChange={(e) => setVazio(e.target.value)}
            className={`${CampoTexto} mt-1.5`}
            placeholder="ex.: 8200"
          />
        </label>
        <label className="block text-[12px] font-medium">
          Caminhão carregado (kg)
          <input
            inputMode="decimal"
            value={carregado}
            onChange={(e) => setCarregado(e.target.value)}
            className={`${CampoTexto} mt-1.5`}
            placeholder="ex.: 29336"
          />
        </label>
      </div>
      <label className="block text-[12px] font-medium">
        Motivo do registro manual
        <input
          value={motivo}
          onChange={(e) => setMotivo(e.target.value)}
          maxLength={200}
          className={`${CampoTexto} mt-1.5`}
        />
      </label>
      {erro && <Aviso tom="erro">{erro}</Aviso>}
      <Botao tipo="submit" carregando={enviando}>
        Registrar pesagem
      </Botao>
    </form>
  );
}

function CancelarOperacao({ operacao, aoSalvar }: { operacao: OperacaoDetalheApi; aoSalvar: () => void }) {
  const [confirmando, setConfirmando] = useState(false);
  const [motivo, setMotivo] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  async function confirmar() {
    setEnviando(true);
    setErro(null);
    try {
      await api.cancelarOperacao(operacao.id, motivo.trim());
      setConfirmando(false);
      setMotivo("");
      aoSalvar();
    } catch (e) {
      setErro(e instanceof ErroApi ? e.message : "Não foi possível cancelar a operação.");
    } finally {
      setEnviando(false);
    }
  }

  if (!confirmando) {
    return (
      <div className="space-y-2">
        <p className="text-[12px] text-muted-foreground">
          Use apenas se a operação não vai ser realizada. A operação fica no histórico como cancelada.
        </p>
        <Botao variante="secundario" onClick={() => setConfirmando(true)}>
          Cancelar operação
        </Botao>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <Aviso tom="erro">
        <strong>Atenção:</strong> ao cancelar, a operação não pode mais ser pesada, finalizada nem reaberta. Os dados já
        registrados ficam guardados no histórico.
      </Aviso>
      <label className="block space-y-1.5">
        <span className="text-[12px] font-medium">Motivo do cancelamento</span>
        <input
          className={CampoTexto}
          value={motivo}
          onChange={(e) => setMotivo(e.target.value)}
          placeholder="Ex.: motorista desistiu da viagem"
        />
      </label>
      {erro && <Aviso tom="erro">{erro}</Aviso>}
      <div className="flex gap-2">
        <Botao variante="secundario" onClick={() => setConfirmando(false)} disabled={enviando}>
          Voltar
        </Botao>
        <Botao variante="perigo" carregando={enviando} disabled={motivo.trim().length < 3} onClick={confirmar}>
          Confirmar cancelamento
        </Botao>
      </div>
    </div>
  );
}

function AtivarRastreio({ operacao, aoSalvar }: { operacao: OperacaoDetalheApi; aoSalvar: () => void }) {
  const [codigo, setCodigo] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  if (operacao.estado === "CANCELLED" || operacao.estado === "COMPLETED") return null;

  if (operacao.rastreioAtivado) {
    return (
      <p className="mb-3 text-[12px] text-muted-foreground">
        Rastreio ativado com a etiqueta RFID {operacao.rfid ?? "—"}.
      </p>
    );
  }

  async function ativar(evento: FormEvent) {
    evento.preventDefault();
    if (!codigo.trim()) return setErro("Informe o código RFID fornecido pela empresa.");
    setEnviando(true);
    setErro(null);
    try {
      await api.ativarRastreio(operacao.id, codigo.trim());
      setCodigo("");
      aoSalvar();
    } catch (e) {
      setErro(e instanceof ErroApi ? e.message : "Não foi possível ativar o rastreio.");
    } finally {
      setEnviando(false);
    }
  }

  return (
    <form onSubmit={ativar} className="mb-4 space-y-3">
      <p className="text-[12px] text-muted-foreground">
        Para acompanhar o transporte, informe o código RFID fornecido pela empresa parceira. Ele precisa ser a etiqueta
        do caminhão desta operação.
      </p>
      <label className="block text-[12px] font-medium">
        Código RFID da empresa
        <input
          value={codigo}
          onChange={(e) => setCodigo(e.target.value)}
          maxLength={100}
          className={`${CampoTexto} mt-1.5`}
          placeholder="ex.: RFID-0001"
        />
      </label>
      {erro && <Aviso tom="erro">{erro}</Aviso>}
      <Botao tipo="submit" carregando={enviando}>
        Ativar rastreio
      </Botao>
    </form>
  );
}

function Transporte({ operacao, aoSalvar }: { operacao: OperacaoDetalheApi; aoSalvar: () => void }) {
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const estado = operacao.rastreio?.estado ?? null;
  const emViagem = estado === "IN_TRANSIT" || estado === "STOPPED" || estado === "SIGNAL_LOST";

  if (operacao.estado === "CANCELLED") {
    return <p className="text-[12px] text-muted-foreground">Operação cancelada: não há transporte a acompanhar.</p>;
  }
  if (estado === "ARRIVED") {
    return (
      <p className="text-[12px] text-muted-foreground">
        Carga chegou ao destino{operacao.datas.chegadaReal ? ` em ${dataCurta(operacao.datas.chegadaReal)}` : ""}.
      </p>
    );
  }
  if (operacao.estado !== "COMPLETED") {
    return (
      <p className="text-[12px] text-muted-foreground">
        Conclua a pesagem para iniciar o transporte. Depois disso, a operação aparece em andamento no Monitoramento.
      </p>
    );
  }

  async function acionar(acao: () => Promise<unknown>) {
    setEnviando(true);
    setErro(null);
    try {
      await acao();
      aoSalvar();
    } catch (e) {
      setErro(e instanceof ErroApi ? e.message : "Não foi possível atualizar o transporte.");
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div className="space-y-3">
      <p className="text-[12px] text-muted-foreground">
        {emViagem
          ? "Em viagem. Registre a chegada quando a carga chegar ao destino."
          : "Pesagem concluída. Inicie o transporte quando o caminhão sair."}
      </p>
      {erro && <Aviso tom="erro">{erro}</Aviso>}
      {emViagem ? (
        <Botao carregando={enviando} onClick={() => acionar(() => api.chegadaTransporte(operacao.id))}>
          Registrar chegada
        </Botao>
      ) : (
        <Botao carregando={enviando} onClick={() => acionar(() => api.iniciarTransporte(operacao.id))}>
          Iniciar transporte
        </Botao>
      )}
    </div>
  );
}

function BalancaDaOperacao({
  operacaoId,
  status,
  recarregar,
}: {
  operacaoId: number;
  status: string;
  recarregar: () => unknown;
}) {
  const [balancas, setBalancas] = useState<DispositivoApi[] | null>(null);
  const [erro, setErro] = useState<string | null>(null);
  const [enviando, setEnviando] = useState<number | null>(null);
  const [chaveNova, setChaveNova] = useState<{ nome: string; chave: string } | null>(null);
  const [copiada, setCopiada] = useState(false);
  const [verificada, setVerificada] = useState<{ id: number; ok: boolean; texto: string } | null>(null);
  const podeOperar = status === "DRAFT" || status === "IN_PROGRESS";

  async function carregar() {
    try {
      const d = await api.dispositivos();
      setBalancas(
        d.dispositivos.filter(
          (x) => x.device_type === "ESP32" || x.device_type === "SCALE_CONTROLLER" || x.device_type === "LOAD_CELL",
        ),
      );
      setErro(null);
    } catch (e) {
      setErro(e instanceof ErroApi ? e.message : "Não foi possível carregar as balanças.");
    }
  }

  useEffect(() => {
    void carregar();
  }, []);
  useSincronia(() => {
    void carregar();
  }, true);

  async function alternar(b: DispositivoApi) {
    const esta = b.operacao_ativa_id === operacaoId;
    setEnviando(b.id);
    setErro(null);
    try {
      await api.definirOperacaoBalanca(b.id, esta ? null : operacaoId);
      await carregar();
      await recarregar();
    } catch (e) {
      setErro(e instanceof ErroApi ? e.message : "Não foi possível alterar a balança.");
    } finally {
      setEnviando(null);
    }
  }

  async function verificarSinal(b: DispositivoApi) {
    setVerificada(null);
    setEnviando(b.id);
    try {
      await carregar();
      const d = await api.dispositivos();
      const atual = d.dispositivos.find((x) => x.id === b.id) ?? b;
      const min = minutosDesde(atual.last_seen_at) ?? 0;
      if (sinalRecente(atual.last_seen_at)) {
        setVerificada({
          id: b.id,
          ok: true,
          texto: `Sinal recebido há ${min <= 0 ? "menos de 1" : min} min. A balança está enviando.`,
        });
      } else if (!atual.last_seen_at) {
        setVerificada({
          id: b.id,
          ok: false,
          texto: "A balança ainda não enviou nada. Confira energia, Wi-Fi, o endereço do servidor e a chave.",
        });
      } else {
        setVerificada({
          id: b.id,
          ok: false,
          texto: `Último sinal há ${min} min. Confira se a balança está ligada e com Wi-Fi.`,
        });
      }
    } catch (e) {
      setVerificada({
        id: b.id,
        ok: false,
        texto: e instanceof ErroApi ? e.message : "Não foi possível verificar a balança.",
      });
    } finally {
      setEnviando(null);
    }
  }

  async function gerarChave(b: DispositivoApi) {
    if (
      !window.confirm(
        `Gerar nova chave para ${b.name}? A chave atual deixa de funcionar e a balança precisa ser reconfigurada.`,
      )
    )
      return;
    setEnviando(b.id);
    setErro(null);
    setCopiada(false);
    try {
      const r = await api.gerarChaveBalanca(b.id);
      setChaveNova({ nome: r.nome, chave: r.chave });
    } catch (e) {
      setErro(e instanceof ErroApi ? e.message : "Não foi possível gerar a chave.");
    } finally {
      setEnviando(null);
    }
  }

  const recebendo = balancas?.find((b) => b.operacao_ativa_id === operacaoId);
  const recebendoSemSinal = !!recebendo && !sinalRecente(recebendo.last_seen_at);

  return (
    <Secao titulo="Balança">
      {erro && <Aviso tom="erro">{erro}</Aviso>}
      {recebendoSemSinal && (
        <Aviso tom="atencao">
          {`${recebendo.name} está sem sinal${recebendo.last_seen_at ? ` há ${minutosDesde(recebendo.last_seen_at)} min` : ""}. As pesagens feitas nela só aparecem aqui quando ela voltar a enviar.`}
        </Aviso>
      )}
      {!recebendo && podeOperar && balancas !== null && balancas.length > 0 && (
        <Aviso tom="info">
          Nenhuma balança recebe leituras desta operação. Escolha uma abaixo para as pesagens chegarem automaticamente.
        </Aviso>
      )}
      {balancas === null ? (
        <Carregando />
      ) : balancas.length === 0 ? (
        <Aviso tom="info">Nenhuma balança cadastrada.</Aviso>
      ) : (
        <ul className="divide-y divide-border/60">
          {balancas.map((b) => {
            const aqui = b.operacao_ativa_id === operacaoId;
            const outra = !!b.operacao_ativa_id && !aqui;
            return (
              <li key={b.id} className="space-y-2 py-3 text-[13px]">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-medium">{b.name}</span>
                  {(() => {
                    const online = b.state === "ONLINE" && sinalRecente(b.last_seen_at);
                    return (
                      <Badge cor={online ? "success" : "muted"}>
                        {online ? "Online" : b.last_seen_at ? "Sem sinal recente" : "Sem sinal"}
                      </Badge>
                    );
                  })()}
                </div>
                <p className="text-[11px] text-muted-foreground">
                  {b.last_seen_at ? `Último sinal ${dataCurta(b.last_seen_at)}` : "Ainda não enviou leituras"}
                  {b.firmware_version ? ` · firmware ${b.firmware_version}` : ""}
                </p>
                <p className="text-[12px]">
                  {aqui
                    ? "Recebendo leituras desta operação."
                    : outra
                      ? `Recebendo leituras de outra operação (#${b.operacao_ativa_id}).`
                      : "Não está recebendo leituras."}
                </p>
                <div className="flex flex-wrap gap-2">
                  {aqui ? (
                    <Botao variante="secundario" carregando={enviando === b.id} onClick={() => alternar(b)}>
                      Parar de receber nesta operação
                    </Botao>
                  ) : podeOperar ? (
                    <Botao carregando={enviando === b.id} onClick={() => alternar(b)}>
                      {outra ? "Passar a receber nesta operação" : "Receber leituras desta operação"}
                    </Botao>
                  ) : null}
                  <Botao variante="secundario" carregando={enviando === b.id} onClick={() => verificarSinal(b)}>
                    Verificar sinal
                  </Botao>
                  <Botao variante="secundario" carregando={enviando === b.id} onClick={() => gerarChave(b)}>
                    Gerar chave
                  </Botao>
                </div>
                {verificada?.id === b.id && (
                  <Aviso tom={verificada.ok ? "sucesso" : "atencao"}>{verificada.texto}</Aviso>
                )}
              </li>
            );
          })}
        </ul>
      )}
      {chaveNova && (
        <div className="mt-3 rounded-xl border border-border/60 bg-card-elev p-3 text-[12px]">
          <p className="font-semibold">Chave de {chaveNova.nome}</p>
          <p className="mt-1 text-muted-foreground">
            Copie agora: ela não será mostrada de novo. Cole na balança, no campo DEVICE_KEY do config.h.
          </p>
          <code className="mt-2 block break-all rounded bg-background p-2 font-mono text-[11px]">
            {chaveNova.chave}
          </code>
          <div className="mt-2 flex flex-wrap gap-2">
            <Botao
              variante="secundario"
              onClick={() => {
                void navigator.clipboard?.writeText(chaveNova.chave);
                setCopiada(true);
              }}
            >
              {copiada ? "Chave copiada" : "Copiar chave"}
            </Botao>
            <Botao variante="secundario" onClick={() => setChaveNova(null)}>
              Fechar
            </Botao>
          </div>
        </div>
      )}
    </Secao>
  );
}
