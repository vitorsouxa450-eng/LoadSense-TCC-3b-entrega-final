import { useState, type FormEvent } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { ErroApi, type MotoristaApi, type OperacaoDetalheApi, type ProdutoApi } from "@shared/lib/api";
import { api } from "@/lib/dados";
import { Aviso, Botao, CampoTexto, Cartao, Carregando, Titulo } from "@/components/ui";
import { useCarga } from "@/pages/central/useCarga";

export function EditarOperacao() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [operacao, setOperacao] = useState<OperacaoDetalheApi | null>(null);
  const [motoristas, setMotoristas] = useState<MotoristaApi[]>([]);
  const [produtos, setProdutos] = useState<ProdutoApi[]>([]);
  const [motoristaId, setMotoristaId] = useState("");
  const [produtoId, setProdutoId] = useState("");
  const [documentoFiscal, setDocumentoFiscal] = useState("");
  const [mdfe, setMdfe] = useState("");
  const [ciot, setCiot] = useState("");
  const [observacoes, setObservacoes] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  const { carregando, erro: erroCarga } = useCarga(async () => {
    const [op, mot, prod] = await Promise.all([api.operacao(Number(id)), api.motoristas(), api.produtos()]);
    setOperacao(op);
    setMotoristas(mot.motoristas);
    setProdutos(prod.produtos);
    setMotoristaId(op.motoristaId ? String(op.motoristaId) : "");
    setProdutoId(op.produtoId ? String(op.produtoId) : "");
    setDocumentoFiscal(op.documentoFiscal ?? "");
    setMdfe(op.mdfe ?? "");
    setCiot(op.ciot ?? "");
    setObservacoes(op.observacoes ?? "");
  });

  const motoristasOpcoes = [...motoristas];
  if (operacao && operacao.motoristaId && !motoristas.some((m) => m.id === operacao.motoristaId)) {
    motoristasOpcoes.push({
      id: operacao.motoristaId,
      full_name: operacao.motorista ?? `Motorista #${operacao.motoristaId}`,
      employee_code: null,
      license_number: null,
      license_category: null,
      phone: null,
      inativo: true,
    } as MotoristaApi);
  }
  const produtosOpcoes = [...produtos];
  if (operacao && operacao.produtoId && !produtos.some((p) => p.id === operacao.produtoId)) {
    produtosOpcoes.push({
      id: operacao.produtoId,
      code: null,
      name: operacao.produto ?? `Produto #${operacao.produtoId}`,
      default_unit: "KG",
      inativo: true,
    } as ProdutoApi);
  }

  if (carregando) return <Carregando />;
  if (erroCarga || !operacao) return <Aviso tom="erro">{erroCarga ?? "Operação não encontrada."}</Aviso>;

  const editavel = operacao.estado === "DRAFT" || operacao.estado === "IN_PROGRESS";

  async function salvar(evento: FormEvent) {
    evento.preventDefault();
    setEnviando(true);
    setErro(null);
    try {
      await api.patch(`/operacoes/${operacao!.id}/manutencao`, {
        motoristaId: motoristaId ? Number(motoristaId) : null,
        produtoId: produtoId ? Number(produtoId) : null,
        documentoFiscal: documentoFiscal.trim() || null,
        mdfe: mdfe.trim() || null,
        ciot: ciot.trim() || null,
        observacoes: observacoes.trim() || null,
      });
      navigate(`/app/operacoes/${operacao!.id}`);
    } catch (e) {
      setErro(e instanceof ErroApi ? e.message : "Não foi possível salvar as alterações.");
    } finally {
      setEnviando(false);
    }
  }

  return (
    <>
      <Titulo
        titulo="Editar operação"
        subtitulo={`${operacao.codigo} · ${operacao.veiculo.placa ?? "Sem placa"} · ${operacao.rota.origem ?? "—"} → ${operacao.rota.destino ?? "—"}`}
        acoes={
          <Link
            to={`/app/operacoes/${operacao.id}`}
            className="inline-flex items-center gap-1.5 rounded-xl border border-border px-3 py-2 text-[12px] font-semibold"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Voltar aos detalhes
          </Link>
        }
      />

      {!editavel && (
        <Aviso tom="info">
          Esta operação está {operacao.estado === "CANCELLED" ? "cancelada" : "concluída"} e fica como registro. Não
          pode ser alterada.
        </Aviso>
      )}

      <Cartao className="mt-4 max-w-2xl">
        <form onSubmit={salvar} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="block text-[12px] font-medium">
              Motorista
              <select
                value={motoristaId}
                onChange={(e) => setMotoristaId(e.target.value)}
                disabled={!editavel}
                className={`${CampoTexto} mt-1.5`}
              >
                <option value="">Sem motorista</option>
                {motoristasOpcoes.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.full_name}
                    {(m as MotoristaApi & { inativo?: boolean }).inativo ? " (Inativo)" : ""}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-[12px] font-medium">
              Produto
              <select
                value={produtoId}
                onChange={(e) => setProdutoId(e.target.value)}
                disabled={!editavel}
                className={`${CampoTexto} mt-1.5`}
              >
                <option value="">Sem produto</option>
                {produtosOpcoes.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                    {(p as ProdutoApi & { inativo?: boolean }).inativo ? " (Inativo)" : ""}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-[12px] font-medium">
              Nota fiscal
              <input
                value={documentoFiscal}
                onChange={(e) => setDocumentoFiscal(e.target.value)}
                disabled={!editavel}
                maxLength={80}
                className={`${CampoTexto} mt-1.5`}
              />
            </label>
            <label className="block text-[12px] font-medium">
              MDF-e
              <input
                value={mdfe}
                onChange={(e) => setMdfe(e.target.value)}
                disabled={!editavel}
                maxLength={80}
                className={`${CampoTexto} mt-1.5`}
              />
            </label>
            <label className="block text-[12px] font-medium md:col-span-2">
              CIOT
              <input
                value={ciot}
                onChange={(e) => setCiot(e.target.value)}
                disabled={!editavel}
                maxLength={80}
                className={`${CampoTexto} mt-1.5`}
              />
            </label>
          </div>
          <label className="block text-[12px] font-medium">
            Observações
            <textarea
              value={observacoes}
              onChange={(e) => setObservacoes(e.target.value)}
              disabled={!editavel}
              maxLength={500}
              rows={3}
              className={`${CampoTexto} mt-1.5`}
            />
          </label>

          <p className="text-[12px] text-muted-foreground">
            Caminhão e rota não podem ser trocados aqui, porque mudam a tara e o trajeto. Para isso, cancele esta
            operação e crie outra.
          </p>

          {erro && <Aviso tom="erro">{erro}</Aviso>}

          <div className="flex gap-2">
            <Link
              to={`/app/operacoes/${operacao.id}`}
              className="rounded-xl border border-border px-4 py-2.5 text-[13px] font-semibold"
            >
              Cancelar
            </Link>
            {editavel && (
              <Botao tipo="submit" carregando={enviando}>
                Salvar alterações
              </Botao>
            )}
          </div>
        </form>
      </Cartao>
    </>
  );
}
