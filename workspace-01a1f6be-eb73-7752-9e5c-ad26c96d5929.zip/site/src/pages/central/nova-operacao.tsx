import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { type MotoristaApi, type ProdutoApi, type RotaApi, type VeiculoApi } from "@shared/lib/api";
import { RotaPorDestino } from "@shared/components/RotaPorDestino";
import { api } from "@/lib/dados";
import { Aviso, Botao, CampoTexto, Cartao, Carregando, Titulo } from "@/components/ui";

const mensagem = (e: unknown) => (e instanceof Error ? e.message : "Falha na comunicação com o servidor.");

function Campo({ rotulo, erro, children }: { rotulo: string; erro?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-[12px] font-semibold text-muted-foreground">{rotulo}</span>
      <div className="mt-1.5">{children}</div>
      {erro && <span className="mt-1 block text-[11px] text-destructive">{erro}</span>}
    </label>
  );
}

interface Dados {
  veiculoId: string;
  motoristaId: string;
  produtoId: string;
  rotaId: string;
  cargaDeclarada: string;
  notaFiscal: string;
  mdfe: string;
  ciot: string;
  saida: string;
  chegada: string;
  observacoes: string;
  vazio: string;
  carregado: string;
  motivo: string;
}

const numeroBr = (texto: string) => Number(texto.replace(",", "."));

const temPesagem = (dados: Dados) => Boolean(dados.vazio || dados.carregado);

const VAZIO: Dados = {
  veiculoId: "",
  motoristaId: "",
  produtoId: "",
  rotaId: "",
  cargaDeclarada: "",
  notaFiscal: "",
  mdfe: "",
  ciot: "",
  saida: "",
  chegada: "",
  observacoes: "",
  vazio: "",
  carregado: "",
  motivo: "Pesagem registrada pela central web (sem balança conectada)",
};

export function NovaOperacao() {
  const navigate = useNavigate();
  const [veiculos, setVeiculos] = useState<VeiculoApi[] | null>(null);
  const [motoristas, setMotoristas] = useState<MotoristaApi[]>([]);
  const [produtos, setProdutos] = useState<ProdutoApi[]>([]);
  const [rotas, setRotas] = useState<RotaApi[]>([]);
  const [dados, setDados] = useState<Dados>(VAZIO);
  const [erros, setErros] = useState<Partial<Record<keyof Dados, string>>>({});
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.veiculos(), api.motoristas(), api.produtos(), api.rotas()])
      .then(([v, m, p, r]) => {
        setVeiculos(v.veiculos);
        setMotoristas(m.motoristas);
        setProdutos(p.produtos);
        setRotas(r.rotas);
      })
      .catch((e) => setErro(mensagem(e)));
  }, []);

  const alterar = (campo: keyof Dados) => (valor: string) => {
    setDados((d) => ({ ...d, [campo]: valor }));
    setErros((e) => ({ ...e, [campo]: undefined }));
  };

  function validar(): Partial<Record<keyof Dados, string>> {
    const novos: Partial<Record<keyof Dados, string>> = {};
    if (!dados.veiculoId) novos.veiculoId = "Escolha o caminhão.";
    if (!dados.motoristaId) novos.motoristaId = "Escolha o motorista.";
    if (!dados.produtoId) novos.produtoId = "Escolha o produto transportado.";
    if (!dados.rotaId) novos.rotaId = "Escolha o trajeto.";
    if (dados.cargaDeclarada && !(Number(dados.cargaDeclarada.replace(",", ".")) > 0))
      novos.cargaDeclarada = "Informe um peso maior que zero.";
    if (dados.saida && !dados.chegada) novos.chegada = "Informe a chegada prevista.";
    if (dados.chegada && !dados.saida) novos.saida = "Informe a saída prevista.";
    if (temPesagem(dados)) {
      const vazio = numeroBr(dados.vazio);
      const carregado = numeroBr(dados.carregado);
      if (!(vazio > 0)) novos.vazio = "Informe o peso do caminhão vazio.";
      if (!(carregado > vazio)) novos.carregado = "O caminhão carregado precisa pesar mais que o vazio.";
      if (dados.motivo.trim().length < 5) novos.motivo = "Informe o motivo do registro manual.";
    }
    if (dados.saida && dados.chegada && new Date(dados.chegada) <= new Date(dados.saida))
      novos.chegada = "A chegada precisa ser depois da saída.";
    return novos;
  }

  async function salvar(evento: FormEvent) {
    evento.preventDefault();
    setErro(null);
    const novos = validar();
    setErros(novos);
    if (Object.keys(novos).length > 0) return;

    setSalvando(true);
    try {
      const criada = await api.criarOperacao({
        veiculoId: Number(dados.veiculoId),
        motoristaId: Number(dados.motoristaId),
        produtoId: Number(dados.produtoId),
        rotaId: Number(dados.rotaId),
        pesoDeclaradoKg: dados.cargaDeclarada ? Number(dados.cargaDeclarada.replace(",", ".")) : undefined,
        notaFiscal: dados.notaFiscal.trim() || undefined,
        mdfe: dados.mdfe.trim() || undefined,
        ciot: dados.ciot.trim() || undefined,
        metodo: "GROSS_TARE",
        tipoMovimento: "EXIT",
        observacoes: dados.observacoes.trim() || "Operação registrada pela central web",
      });
      if (dados.saida && dados.chegada) {
        await api.agendarTransporte(
          criada.id,
          new Date(dados.saida).toISOString(),
          new Date(dados.chegada).toISOString(),
        );
      }
      if (temPesagem(dados)) {
        await api.registrarLeitura(criada.id, {
          estagio: "EMPTY_TRUCK",
          pesoKg: numeroBr(dados.vazio),
          origem: "MANUAL",
          motivoManual: dados.motivo.trim(),
        });
        await api.registrarLeitura(criada.id, {
          estagio: "LOADED_TRUCK",
          pesoKg: numeroBr(dados.carregado),
          origem: "MANUAL",
          motivoManual: dados.motivo.trim(),
        });
        await api.finalizarOperacao(criada.id);
      }
      navigate(`/app/operacoes/${criada.id}`);
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setSalvando(false);
    }
  }

  if (veiculos === null && !erro) return <Carregando />;

  return (
    <div>
      <Titulo
        titulo="Nova operação"
        subtitulo="Defina o transporte e a carga. Se já houver os pesos, registre a pesagem aqui mesmo; sem pesos, a operação fica em rascunho."
      />
      <Cartao>
        <form onSubmit={salvar} className="space-y-5" noValidate>
          {erro && <Aviso tom="erro">{erro}</Aviso>}

          <fieldset className="space-y-4">
            <legend className="mb-2 text-[13px] font-bold">Transporte</legend>
            <div className="grid gap-4 sm:grid-cols-2">
              <Campo rotulo="Caminhão *" erro={erros.veiculoId}>
                <select
                  className={CampoTexto}
                  value={dados.veiculoId}
                  onChange={(e) => alterar("veiculoId")(e.target.value)}
                >
                  <option value="">Escolha o caminhão</option>
                  {(veiculos ?? []).map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.plate}
                      {v.fleet_code ? ` · frota ${v.fleet_code}` : ""}
                    </option>
                  ))}
                </select>
              </Campo>
              <Campo rotulo="Motorista *" erro={erros.motoristaId}>
                <select
                  className={CampoTexto}
                  value={dados.motoristaId}
                  onChange={(e) => alterar("motoristaId")(e.target.value)}
                >
                  <option value="">Escolha o motorista</option>
                  {motoristas.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.full_name}
                    </option>
                  ))}
                </select>
              </Campo>
              <Campo rotulo="Trajeto *" erro={erros.rotaId}>
                <RotaPorDestino
                  rotas={rotas.map((r) => ({
                    id: r.id,
                    origem: r.origin,
                    destino: r.destination,
                    km: r.distance_km,
                    waypoints: r.waypoints,
                  }))}
                  valor={dados.rotaId ? Number(dados.rotaId) : null}
                  onChange={(id) => alterar("rotaId")(String(id))}
                />
              </Campo>
              <Campo rotulo="Saída prevista" erro={erros.saida}>
                <input
                  type="datetime-local"
                  className={CampoTexto}
                  value={dados.saida}
                  onChange={(e) => alterar("saida")(e.target.value)}
                />
              </Campo>
              <Campo rotulo="Chegada prevista" erro={erros.chegada}>
                <input
                  type="datetime-local"
                  className={CampoTexto}
                  value={dados.chegada}
                  onChange={(e) => alterar("chegada")(e.target.value)}
                />
              </Campo>
            </div>
          </fieldset>

          <fieldset className="space-y-4">
            <legend className="mb-2 text-[13px] font-bold">Carga</legend>
            <div className="grid gap-4 sm:grid-cols-2">
              <Campo rotulo="Produto transportado *" erro={erros.produtoId}>
                <select
                  className={CampoTexto}
                  value={dados.produtoId}
                  onChange={(e) => alterar("produtoId")(e.target.value)}
                >
                  <option value="">Escolha o produto</option>
                  {produtos.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </Campo>
              <Campo rotulo="Carga declarada (kg)" erro={erros.cargaDeclarada}>
                <input
                  inputMode="decimal"
                  className={CampoTexto}
                  value={dados.cargaDeclarada}
                  onChange={(e) => alterar("cargaDeclarada")(e.target.value)}
                  placeholder="14800"
                />
              </Campo>
            </div>
          </fieldset>

          <fieldset className="space-y-4">
            <legend className="mb-2 text-[13px] font-bold">Pesagem (opcional)</legend>
            <p className="text-[11px] text-muted-foreground">
              Sem balança conectada, informe os pesos lidos. Com os dois pesos, a pesagem é finalizada ao criar a
              operação.
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              <Campo rotulo="Caminhão vazio (kg)" erro={erros.vazio}>
                <input
                  inputMode="decimal"
                  className={CampoTexto}
                  value={dados.vazio}
                  onChange={(e) => alterar("vazio")(e.target.value)}
                  placeholder="ex.: 8200"
                />
              </Campo>
              <Campo rotulo="Caminhão carregado (kg)" erro={erros.carregado}>
                <input
                  inputMode="decimal"
                  className={CampoTexto}
                  value={dados.carregado}
                  onChange={(e) => alterar("carregado")(e.target.value)}
                  placeholder="ex.: 29336"
                />
              </Campo>
            </div>
            <Campo rotulo="Motivo do registro manual" erro={erros.motivo}>
              <input
                className={CampoTexto}
                value={dados.motivo}
                onChange={(e) => alterar("motivo")(e.target.value)}
                maxLength={200}
              />
            </Campo>
          </fieldset>

          <fieldset className="space-y-4">
            <legend className="mb-2 text-[13px] font-bold">Documentos (opcionais)</legend>
            <div className="grid gap-4 sm:grid-cols-3">
              <Campo rotulo="Nota fiscal">
                <input
                  className={CampoTexto}
                  value={dados.notaFiscal}
                  onChange={(e) => alterar("notaFiscal")(e.target.value)}
                  maxLength={60}
                />
              </Campo>
              <Campo rotulo="MDF-e">
                <input
                  className={CampoTexto}
                  value={dados.mdfe}
                  onChange={(e) => alterar("mdfe")(e.target.value)}
                  maxLength={60}
                />
              </Campo>
              <Campo rotulo="CIOT">
                <input
                  className={CampoTexto}
                  value={dados.ciot}
                  onChange={(e) => alterar("ciot")(e.target.value)}
                  maxLength={60}
                />
              </Campo>
            </div>
            <Campo rotulo="Observações">
              <textarea
                className={CampoTexto}
                rows={3}
                maxLength={500}
                value={dados.observacoes}
                onChange={(e) => alterar("observacoes")(e.target.value)}
              />
            </Campo>
          </fieldset>

          <p className="text-[11px] text-muted-foreground">
            * Campos obrigatórios. Sem caminhão, motorista, produto ou trajeto cadastrados, cadastre-os em Configurações
            &gt; Cadastros.
          </p>
          <Botao tipo="submit" carregando={salvando}>
            {dados.vazio || dados.carregado ? "Criar operação e registrar pesagem" : "Criar operação"}
          </Botao>
        </form>
      </Cartao>
    </div>
  );
}
