import { useState, type FormEvent } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  CheckCircle2,
  Database,
  Gauge,
  KeyRound,
  Lock,
  Mail,
  Radio,
  Scale,
  ShieldCheck,
} from "lucide-react";
import { ehDesafioDoisFatores, ErroApi } from "@shared/lib/api";
import { api } from "@/lib/dados";
import { DOCUMENTOS_LEGAIS } from "@/data/legal";
import { ShellPublico } from "@/components/layout";
import { Aviso, Botao, CampoTexto, Cartao, Logo } from "@/components/ui";

const mensagemErro = (e: unknown) =>
  e instanceof ErroApi ? e.message : "Não foi possível conectar ao servidor LoadSense. Tente novamente em instantes.";

export const senhaForte = (s: string) => s.length >= 8 && /[A-Z]/.test(s) && /[0-9]/.test(s) && /[^A-Za-z0-9]/.test(s);

export function Inicio() {
  const recursos = [
    {
      icone: Scale,
      titulo: "Pesagem em tempo real",
      texto: "Células de carga HX711 e ESP32 enviam o peso direto para o banco de dados.",
    },
    {
      icone: Gauge,
      titulo: "Divergências automáticas",
      texto: "Cada operação é comparada com o peso esperado e recebe alerta quando sai da tolerância.",
    },
    {
      icone: Radio,
      titulo: "Rastreamento de cargas",
      texto: "Acompanhe viagens, paradas, atrasos e perda de sinal em um mapa único.",
    },
    {
      icone: ShieldCheck,
      titulo: "Dados protegidos",
      texto: "Acesso por login, sessões auditadas e conformidade com a LGPD.",
    },
  ];
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Logo />
        <div className="flex gap-3">
          <Link
            to="/login"
            className="rounded-xl border border-border px-4 py-2 text-[13px] font-semibold hover:border-primary/50"
          >
            Entrar
          </Link>
          <Link
            to="/login"
            className="rounded-xl bg-primary px-4 py-2 text-[13px] font-semibold text-primary-foreground"
          >
            Acessar a central
          </Link>
        </div>
      </header>
      <section className="mx-auto max-w-6xl px-6 pb-16 pt-10 md:pt-20">
        <p className="mb-4 text-[12px] font-semibold uppercase tracking-[0.2em] text-primary">
          Pesagem inteligente e gestão de cargas
        </p>
        <h1 className="max-w-3xl text-[40px] font-extrabold leading-[1.1] tracking-tight md:text-[56px]">
          Sua logística <span className="text-primary">em tempo real</span>.
        </h1>
        <p className="mt-6 max-w-2xl text-[16px] text-muted-foreground">
          O LoadSense conecta a balança ao banco de dados e à central web: cada pesagem do caminhão aparece no painel,
          no aplicativo e nos relatórios ao mesmo tempo.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link
            to="/login"
            className="rounded-xl bg-primary px-6 py-3 text-[14px] font-semibold text-primary-foreground"
          >
            Entrar na central →
          </Link>
          <a
            href="/app/monitoramento"
            className="rounded-xl border border-border px-6 py-3 text-[14px] font-semibold hover:border-primary/50"
          >
            Ver monitoramento
          </a>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-4 px-6 pb-20 md:grid-cols-2 lg:grid-cols-4">
        {recursos.map((r) => (
          <Cartao key={r.titulo}>
            <r.icone className="mb-4 h-6 w-6 text-primary" />
            <h3 className="text-[15px] font-semibold">{r.titulo}</h3>
            <p className="mt-2 text-[13px] text-muted-foreground">{r.texto}</p>
          </Cartao>
        ))}
      </section>
      <footer className="border-t border-border px-6 py-8 text-center text-[12px] text-muted-foreground">
        <div className="mb-3 flex flex-wrap justify-center gap-4">
          <Link to="/termos" className="hover:text-primary">
            Termos de Uso
          </Link>
          <Link to="/privacidade" className="hover:text-primary">
            Política de Privacidade
          </Link>
          <Link to="/cookies" className="hover:text-primary">
            Cookies
          </Link>
          <Link to="/lgpd" className="hover:text-primary">
            LGPD e Dados
          </Link>
        </div>
        LoadSense · TCC ETEC de Taboão da Serra (Centro Paula Souza) · 2026
      </footer>
    </div>
  );
}

export function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [desafio, setDesafio] = useState<string | null>(null);
  const [codigoTeste, setCodigoTeste] = useState<string | null>(null);
  const [codigo, setCodigo] = useState("");

  async function aoEnviar(event: FormEvent) {
    event.preventDefault();
    setEnviando(true);
    setErro(null);
    try {
      if (desafio) {
        if (!/^\d{6}$/.test(codigo.replace(/\s/g, "")))
          throw new Error("Digite os 6 números do código enviado para o seu e-mail.");
        await api.concluirLoginDoisFatores(desafio, codigo);
      } else {
        const resposta = await api.entrar(email.trim(), senha);
        if (ehDesafioDoisFatores(resposta)) {
          setDesafio(resposta.desafio);
          setCodigoTeste(resposta.codigoDemo ?? null);
          setCodigo("");
          return;
        }
      }
      navigate("/app", { replace: true });
    } catch (e) {
      setErro(mensagemErro(e));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <ShellPublico>
      <Cartao className="p-8">
        <div className="mb-6 text-center">
          <h1 className="text-[22px] font-bold">Acesse a plataforma</h1>
          <p className="mt-1 text-[13px] text-muted-foreground">Central de pesagem inteligente e gestão de cargas</p>
        </div>
        {desafio ? (
          <form onSubmit={aoEnviar} className="space-y-4">
            <p className="text-[13px] text-foreground">
              {codigoTeste ? (
                <>
                  Este servidor não envia e-mails. Por isso o código de 6 números aparece aqui, nesta máquina:{" "}
                  <strong className="tracking-widest">{codigoTeste}</strong>. Ele vale por 10 minutos e só pode ser
                  usado uma vez.
                </>
              ) : (
                <>
                  Enviamos um código de 6 números para o e-mail da sua conta. Ele vale por 10 minutos e só pode ser
                  usado uma vez.
                </>
              )}
            </p>
            <input
              inputMode="numeric"
              maxLength={7}
              required
              placeholder="000000"
              autoComplete="one-time-code"
              autoFocus
              value={codigo}
              onChange={(e) => setCodigo(e.target.value.replace(/[^\d\s]/g, ""))}
              className={`${CampoTexto} text-center text-[20px] tracking-[0.5em]`}
            />
            {erro && <Aviso tom="erro">{erro}</Aviso>}
            <Botao tipo="submit" carregando={enviando} className="w-full">
              Confirmar e entrar
            </Botao>
            <button
              type="button"
              onClick={() => {
                setDesafio(null);
                setCodigo("");
                setErro(null);
              }}
              className="block w-full text-center text-[12px] font-semibold text-primary"
            >
              Voltar
            </button>
          </form>
        ) : (
          <form onSubmit={aoEnviar} className="space-y-4">
            <label className="block">
              <span className="mb-1.5 block text-[13px] font-medium">E-mail</span>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="username"
                  className={`${CampoTexto} pl-9`}
                />
              </div>
            </label>
            <label className="block">
              <span className="mb-1.5 block text-[13px] font-medium">Senha</span>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <input
                  type="password"
                  required
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  autoComplete="current-password"
                  className={`${CampoTexto} pl-9`}
                />
              </div>
            </label>
            <div className="flex justify-end">
              <Link to="/esqueci-senha" className="text-[12px] font-semibold text-primary">
                Esqueci minha senha
              </Link>
            </div>
            {erro && <Aviso tom="erro">{erro}</Aviso>}
            <Botao tipo="submit" carregando={enviando} className="w-full">
              Entrar →
            </Botao>
          </form>
        )}
        <p className="mt-5 text-center text-[11px] text-muted-foreground">
          Ao entrar você concorda com os{" "}
          <Link to="/termos" className="text-primary">
            Termos de Uso
          </Link>
          ,{" "}
          <Link to="/privacidade" className="text-primary">
            Política de Privacidade
          </Link>{" "}
          e{" "}
          <Link to="/cookies" className="text-primary">
            Cookies
          </Link>
          .
        </p>
      </Cartao>
      <p className="mt-6 flex items-center justify-center gap-2 text-[11px] text-muted-foreground">
        <>
          <Database className="h-3 w-3 text-success" /> Login validado no banco de dados MySQL do LoadSense
        </>
      </p>
    </ShellPublico>
  );
}

export function EsqueciSenha() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  async function aoEnviar(event: FormEvent) {
    event.preventDefault();
    setEnviando(true);
    setErro(null);
    try {
      const r = await api.recuperarSenha(email.trim());
      navigate("/verificar-codigo", { state: { email: email.trim(), codigoDemo: r.codigoDemo ?? null } });
    } catch (e) {
      setErro(mensagemErro(e));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <ShellPublico>
      <Cartao className="p-8">
        <h1 className="mb-2 text-center text-[22px] font-bold">Recuperar senha</h1>
        <p className="mb-6 text-center text-[13px] text-muted-foreground">
          Informe seu e-mail corporativo e enviaremos um código de verificação.
        </p>
        <form onSubmit={aoEnviar} className="space-y-4">
          <input
            type="email"
            required
            placeholder="E-mail corporativo"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className={CampoTexto}
          />
          {erro && <Aviso tom="erro">{erro}</Aviso>}
          <Botao tipo="submit" carregando={enviando} className="w-full">
            Enviar código
          </Botao>
          <Link to="/login" className="flex items-center justify-center gap-1 text-[12px] font-semibold text-primary">
            <ArrowLeft className="h-3 w-3" /> Voltar para o login
          </Link>
        </form>
      </Cartao>
    </ShellPublico>
  );
}

export function VerificarCodigo() {
  const navigate = useNavigate();
  const estado = (useLocation().state ?? {}) as { email?: string; codigoDemo?: string | null };
  const [codigo, setCodigo] = useState("");
  const [validando, setValidando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  if (!estado.email) return <Navigate to="/esqueci-senha" replace />;

  async function aoEnviar(event: FormEvent) {
    event.preventDefault();
    setValidando(true);
    setErro(null);
    try {
      await api.verificarCodigoRecuperacao(estado.email!, codigo);
      navigate("/nova-senha", { state: { email: estado.email, codigo } });
    } catch (e) {
      setErro(mensagemErro(e));
    } finally {
      setValidando(false);
    }
  }

  return (
    <ShellPublico>
      <Cartao className="p-8">
        <h1 className="mb-2 text-center text-[22px] font-bold">Código de verificação</h1>
        <p className="mb-6 text-center text-[13px] text-muted-foreground">
          {estado.codigoDemo ? (
            "Digite os 6 dígitos mostrados abaixo."
          ) : (
            <>
              Digite os 6 dígitos enviados para <strong className="text-foreground">{estado.email}</strong>.
            </>
          )}
        </p>
        {estado.codigoDemo && (
          <div className="mb-4">
            <Aviso tom="info">
              Este servidor não envia e-mails. O código aparece aqui, nesta máquina:{" "}
              <strong className="tracking-widest">{estado.codigoDemo}</strong>
            </Aviso>
          </div>
        )}
        <form onSubmit={aoEnviar} className="space-y-4">
          <input
            inputMode="numeric"
            maxLength={6}
            required
            placeholder="000000"
            autoComplete="one-time-code"
            value={codigo}
            onChange={(e) => setCodigo(e.target.value.replace(/\D/g, ""))}
            className={`${CampoTexto} text-center text-[20px] tracking-[0.5em]`}
          />
          {erro && <Aviso tom="erro">{erro}</Aviso>}
          <Botao tipo="submit" carregando={validando} disabled={codigo.length !== 6} className="w-full">
            Validar código
          </Botao>
          <Link to="/esqueci-senha" className="block text-center text-[12px] font-semibold text-primary">
            Alterar e-mail
          </Link>
        </form>
      </Cartao>
    </ShellPublico>
  );
}

export function NovaSenha() {
  const navigate = useNavigate();
  const estado = (useLocation().state ?? {}) as { email?: string; codigo?: string };
  const [senha, setSenha] = useState("");
  const [confirmacao, setConfirmacao] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  if (!estado.email || !estado.codigo) return <Navigate to="/esqueci-senha" replace />;

  const regras = [
    { ok: senha.length >= 8, texto: "Mínimo de 8 caracteres" },
    { ok: /[A-Z]/.test(senha), texto: "Uma letra maiúscula" },
    { ok: /[0-9]/.test(senha), texto: "Um número" },
    { ok: /[^A-Za-z0-9]/.test(senha), texto: "Um caractere especial" },
  ];

  async function aoEnviar(event: FormEvent) {
    event.preventDefault();
    if (!senhaForte(senha)) return setErro("A senha não atende a todas as regras.");
    if (senha !== confirmacao) return setErro("As senhas não coincidem.");
    setSalvando(true);
    setErro(null);
    try {
      await api.novaSenha(estado.email!, estado.codigo!, senha);
      navigate("/senha-alterada", { replace: true });
    } catch (e) {
      setErro(mensagemErro(e));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <ShellPublico>
      <Cartao className="p-8">
        <h1 className="mb-2 text-center text-[22px] font-bold">Criar nova senha</h1>
        <p className="mb-6 text-center text-[13px] text-muted-foreground">
          Escolha uma senha forte para proteger sua conta.
        </p>
        <form onSubmit={aoEnviar} className="space-y-4">
          <div className="relative">
            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <input
              type="password"
              placeholder="Nova senha"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              autoComplete="new-password"
              className={`${CampoTexto} pl-9`}
            />
          </div>
          <div className="relative">
            <KeyRound className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <input
              type="password"
              placeholder="Confirmar senha"
              value={confirmacao}
              onChange={(e) => setConfirmacao(e.target.value)}
              autoComplete="new-password"
              className={`${CampoTexto} pl-9`}
            />
          </div>
          <ul className="space-y-1 text-[12px]">
            {regras.map((r) => (
              <li key={r.texto} className={r.ok ? "text-success" : "text-muted-foreground"}>
                {r.ok ? "✓" : "•"} {r.texto}
              </li>
            ))}
          </ul>
          {erro && <Aviso tom="erro">{erro}</Aviso>}
          <Botao tipo="submit" carregando={salvando} className="w-full">
            Salvar nova senha
          </Botao>
          <Link to="/login" className="block text-center text-[12px] font-semibold text-primary">
            Voltar para o login
          </Link>
        </form>
      </Cartao>
    </ShellPublico>
  );
}

export function SenhaAlterada() {
  return (
    <ShellPublico largura="max-w-[440px]">
      <Cartao className="p-8 text-center">
        <CheckCircle2 className="mx-auto mb-4 h-12 w-12 text-success" />
        <h1 className="text-[22px] font-bold">Senha alterada com sucesso</h1>
        <p className="mt-2 text-[13px] text-muted-foreground">
          Sua senha foi atualizada. Use as novas credenciais para acessar a central LoadSense.
        </p>
        <Link
          to="/login"
          className="mt-6 inline-flex w-full items-center justify-center rounded-xl bg-primary px-4 py-2.5 text-[13px] font-semibold text-primary-foreground"
        >
          Ir para o login
        </Link>
      </Cartao>
    </ShellPublico>
  );
}

export function Legal({ documento }: { documento: string }) {
  const doc = DOCUMENTOS_LEGAIS[documento];
  if (!doc) return <Navigate to="/" replace />;
  const abas = Object.entries(DOCUMENTOS_LEGAIS);
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="mx-auto flex max-w-4xl items-center justify-between px-6 py-6">
        <Logo />
        <Link to="/login" className="text-[13px] font-semibold text-primary">
          ← Voltar ao login
        </Link>
      </header>
      <main className="mx-auto max-w-4xl px-6 pb-20">
        <nav className="mb-8 flex flex-wrap gap-2">
          {abas.map(([chave, d]) => (
            <Link
              key={chave}
              to={`/${chave}`}
              className={`rounded-lg px-3 py-1.5 text-[12px] ${chave === documento ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:text-foreground"}`}
            >
              {d.titulo}
            </Link>
          ))}
        </nav>
        <Cartao className="p-8">
          <h1 className="mb-4 text-[26px] font-bold">{doc.titulo}</h1>
          <div className="whitespace-pre-line text-[14px] leading-7 text-muted-foreground">{doc.texto}</div>
        </Cartao>
      </main>
    </div>
  );
}
