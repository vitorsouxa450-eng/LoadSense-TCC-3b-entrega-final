import { useCallback, useEffect, useState } from "react";

export type Tema = "dark" | "light";
const CHAVE = "loadsense-theme";

function temaInicial(): Tema {
  try {
    const salvo = localStorage.getItem(CHAVE);
    if (salvo === "light" || salvo === "dark") return salvo;
  } catch {}
  return "dark";
}

export function useTema() {
  const [tema, setTema] = useState<Tema>(temaInicial);

  useEffect(() => {
    const raiz = document.documentElement;
    raiz.classList.toggle("light", tema === "light");
    raiz.classList.toggle("dark", tema === "dark");
    raiz.style.colorScheme = tema;
    try {
      localStorage.setItem(CHAVE, tema);
    } catch {}
  }, [tema]);

  const alternar = useCallback(() => setTema((t) => (t === "dark" ? "light" : "dark")), []);
  return { tema, alternar };
}
