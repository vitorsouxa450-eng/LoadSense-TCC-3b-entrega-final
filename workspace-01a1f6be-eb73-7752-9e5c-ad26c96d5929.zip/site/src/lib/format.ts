export const kg = (valor: number | null | undefined) =>
  valor == null ? "—" : `${Math.round(valor).toLocaleString("pt-BR")} kg`;

export const toneladas = (valor: number | null | undefined) =>
  valor == null ? "—" : `${Number(valor).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} t`;

export const pct = (valor: number | null | undefined, casas = 2) =>
  valor == null
    ? "—"
    : `${Number(valor).toLocaleString("pt-BR", { minimumFractionDigits: casas, maximumFractionDigits: casas })}%`;

export const sinal = (valor: number | null | undefined) =>
  valor == null ? "—" : `${valor > 0 ? "+" : ""}${Math.round(valor).toLocaleString("pt-BR")}`;

export function dataCurta(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}

export const STATUS_OPERACAO: Record<string, { rotulo: string; cor: string }> = {
  NORMAL: { rotulo: "Normal", cor: "success" },
  ATTENTION: { rotulo: "Atenção", cor: "warning" },
  CRITICAL: { rotulo: "Crítico", cor: "destructive" },
  ANALYSIS: { rotulo: "Análise", cor: "primary" },
};

export const ESTADO_OPERACAO: Record<string, string> = {
  DRAFT: "Rascunho",
  IN_PROGRESS: "Em andamento",
  COMPLETED: "Concluída",
  CANCELLED: "Cancelada",
};

export const RASTREIO_ROTULO: Record<string, string> = {
  NOT_STARTED: "Não iniciado",
  IN_TRANSIT: "Em rota",
  STOPPED: "Parado",
  ARRIVED: "Chegou",
  SIGNAL_LOST: "Sem sinal",
  CANCELLED: "Cancelado",
};

export const NIVEL_ALERTA: Record<string, { rotulo: string; cor: string }> = {
  CRITICAL: { rotulo: "Crítico", cor: "destructive" },
  ATTENTION: { rotulo: "Atenção", cor: "warning" },
};

export const SITUACAO_ALERTA: Record<string, string> = {
  OPEN: "Aberto",
  ACKNOWLEDGED: "Reconhecido",
  RESOLVED: "Resolvido",
};

export function tom(cor: string): string {
  switch (cor) {
    case "success":
      return "border-success/40 bg-success/10 text-success";
    case "warning":
      return "border-warning/40 bg-warning/10 text-warning";
    case "destructive":
      return "border-destructive/40 bg-destructive/10 text-destructive";
    case "primary":
      return "border-primary/40 bg-primary/10 text-primary";
    default:
      return "border-border bg-card-elev text-muted-foreground";
  }
}

export const JANELA_SINAL_MS = 3 * 60_000;
export function sinalRecente(iso: string | null | undefined): boolean {
  return !!iso && Date.now() - new Date(iso).getTime() < JANELA_SINAL_MS;
}
