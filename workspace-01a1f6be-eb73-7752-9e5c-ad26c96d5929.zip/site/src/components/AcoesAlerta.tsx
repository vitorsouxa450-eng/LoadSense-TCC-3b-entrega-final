import { useState } from "react";
import { type AlertaApi } from "@shared/lib/api";
import {
  ACAO_MINIMA,
  MOTIVOS_RESOLUCAO,
  rotuloMotivo,
  type CodigoMotivo,
  type ResolucaoAlerta,
  validarResolucao,
} from "@shared/lib/alertas";
import { api } from "@/lib/dados";
import { Aviso, Botao, CampoTexto } from "@/components/ui";
import { dataCurta } from "@/lib/format";

export function AcoesAlerta({ alerta, onAlterado }: { alerta: AlertaApi; onAlterado: () => void }) {
  const [resolvendo, setResolvendo] = useState(false);
  const [motivo, setMotivo] = useState<CodigoMotivo | "">("");
  const [acao, setAcao] = useState("");
  const [tentou, setTentou] = useState(false);
  const [ocupado, setOcupado] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  async function executar(fn: () => Promise<unknown>) {
    setOcupado(true);
    setErro(null);
    try {
      await fn();
      setResolvendo(false);
      setMotivo("");
      setAcao("");
      setTentou(false);
      onAlterado();
    } catch (e) {
      setErro(e instanceof Error ? e.message : "Não foi possível concluir a ação.");
    } finally {
      setOcupado(false);
    }
  }

  if (alerta.situacao === "RESOLVED") {
    return (
      <div className="flex w-full min-w-[260px] flex-col items-end gap-2">
        {(alerta.motivoResolucao || alerta.notasResolucao || alerta.resolvidoPor) && (
          <dl className="w-full rounded-xl bg-card-elev px-3 py-2.5 text-right text-[11px]">
            {alerta.motivoResolucao && (
              <div>
                <dt className="inline font-semibold">Motivo: </dt>
                <dd className="inline text-muted-foreground">{rotuloMotivo(alerta.motivoResolucao)}</dd>
              </div>
            )}
            {alerta.notasResolucao && (
              <div className="mt-1">
                <dt className="inline font-semibold">Como foi resolvido: </dt>
                <dd className="inline whitespace-pre-line text-muted-foreground">{alerta.notasResolucao}</dd>
              </div>
            )}
            {alerta.resolvidoPor && (
              <div className="mt-1">
                <dt className="inline font-semibold">Resolvido por: </dt>
                <dd className="inline text-muted-foreground">
                  {alerta.resolvidoPor}
                  {alerta.resolvidoEm ? ` em ${dataCurta(alerta.resolvidoEm)}` : ""}
                </dd>
              </div>
            )}
          </dl>
        )}
        <Botao variante="secundario" carregando={ocupado} onClick={() => executar(() => api.reabrirAlerta(alerta.id))}>
          Reabrir
        </Botao>
        {erro && <Aviso tom="erro">{erro}</Aviso>}
      </div>
    );
  }

  if (resolvendo) {
    const problema = validarResolucao({ motivo, acao });
    const descricao = MOTIVOS_RESOLUCAO.find((m) => m.codigo === motivo)?.descricao;
    return (
      <div className="flex w-full min-w-[260px] flex-col gap-3">
        <div className="text-[12px] font-semibold">Resolver alerta</div>
        <label className="flex flex-col gap-1">
          <span className="text-[11px] font-semibold text-muted-foreground">Motivo *</span>
          <select
            value={motivo}
            onChange={(e) => setMotivo(e.target.value as CodigoMotivo | "")}
            className={CampoTexto}
            aria-label="Motivo da resolução"
          >
            <option value="">Escolha um motivo</option>
            {MOTIVOS_RESOLUCAO.map((m) => (
              <option key={m.codigo} value={m.codigo}>
                {m.rotulo}
              </option>
            ))}
          </select>
          {descricao && <span className="text-[11px] text-muted-foreground">{descricao}</span>}
        </label>
        <label className="flex flex-col gap-1">
          <span className="text-[11px] font-semibold text-muted-foreground">
            Como foi resolvido * (mínimo {ACAO_MINIMA} caracteres)
          </span>
          <textarea
            value={acao}
            onChange={(e) => setAcao(e.target.value)}
            rows={3}
            maxLength={2000}
            placeholder="Ex.: conferido com o motorista, carga redistribuída e nova pesagem registrada."
            className={CampoTexto}
            aria-label="Como foi resolvido"
          />
          <span className="text-right text-[11px] text-muted-foreground">{acao.length}/2000</span>
        </label>
        {tentou && problema && <Aviso tom="erro">{problema}</Aviso>}
        <div className="flex flex-wrap justify-end gap-2">
          <Botao
            variante="secundario"
            onClick={() => {
              setResolvendo(false);
              setTentou(false);
            }}
            disabled={ocupado}
          >
            Cancelar
          </Botao>
          <Botao
            variante="perigo"
            carregando={ocupado}
            onClick={() => {
              setTentou(true);
              if (problema) return;
              const resolucao: ResolucaoAlerta = { motivo: motivo as CodigoMotivo, acao: acao.trim() };
              executar(() => api.resolverAlerta(alerta.id, resolucao));
            }}
          >
            Confirmar resolução
          </Botao>
        </div>
        {erro && <Aviso tom="erro">{erro}</Aviso>}
      </div>
    );
  }

  return (
    <div className="flex flex-col items-end gap-2">
      <div className="flex flex-wrap gap-2">
        {alerta.situacao === "OPEN" && (
          <Botao
            variante="secundario"
            carregando={ocupado}
            onClick={() => executar(() => api.reconhecerAlerta(alerta.id))}
          >
            Reconhecer
          </Botao>
        )}
        <Botao variante="primario" onClick={() => setResolvendo(true)} disabled={ocupado}>
          Resolver
        </Botao>
      </div>
      {erro && <Aviso tom="erro">{erro}</Aviso>}
    </div>
  );
}
