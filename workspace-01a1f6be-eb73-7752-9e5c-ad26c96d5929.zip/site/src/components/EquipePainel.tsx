import { useEffect, useState } from "react";
import { Users } from "lucide-react";
import { api, ErroApi } from "@shared/lib/api";
import { Aviso, Badge, Botao, CampoTexto, Carregando } from "@/components/ui";

type Papel = "ADMINISTRATOR" | "SUPERVISOR" | "OPERATOR";
type Usuario = Awaited<ReturnType<typeof api.usuarios.listar>>["usuarios"][number];
type Permissoes = Awaited<ReturnType<typeof api.papeis.listar>>;

const OPCOES_CARGO: { valor: Papel; rotulo: string }[] = [
  { valor: "OPERATOR", rotulo: "Operador de Pesagem" },
  { valor: "SUPERVISOR", rotulo: "Supervisor de Operações" },
  { valor: "ADMINISTRATOR", rotulo: "Administrador" },
];
const NOME_CARGO: Record<string, string> = Object.fromEntries(OPCOES_CARGO.map((o) => [o.valor, o.rotulo]));

const mensagem = (e: unknown) => (e instanceof ErroApi ? e.message : "Não foi possível falar com o servidor.");

type Tom = "erro" | "sucesso" | "info";

export function EquipePainel({ secao = "tudo" }: { secao?: "pessoas" | "cargos" | "tudo" }) {
  const [usuarios, setUsuarios] = useState<Usuario[] | null>(null);
  const [dados, setDados] = useState<Permissoes | null>(null);
  const [rascunho, setRascunho] = useState<Record<string, string[]>>({});
  const [ocupado, setOcupado] = useState<string | null>(null);
  const [aviso, setAviso] = useState<{ tom: Tom; texto: string } | null>(null);
  const [confirmandoId, setConfirmandoId] = useState<number | null>(null);

  async function carregar() {
    try {
      const [u, p] = await Promise.all([api.usuarios.listar(), api.papeis.listar()]);
      setUsuarios(u.usuarios);
      setDados(p);
      setRascunho(Object.fromEntries(p.cargos.map((c) => [c.nome, c.permissoes])));
    } catch (e) {
      setAviso({ tom: "erro", texto: mensagem(e) });
    }
  }

  useEffect(() => {
    void carregar();
  }, []);

  async function executar(chave: string, acao: () => Promise<unknown>, sucesso: string) {
    setOcupado(chave);
    setAviso(null);
    try {
      await acao();
      setAviso({ tom: "sucesso", texto: sucesso });
      await carregar();
    } catch (e) {
      setAviso({ tom: "erro", texto: mensagem(e) });
      await carregar();
    } finally {
      setOcupado(null);
    }
  }

  if (!usuarios || !dados) {
    return aviso ? <Aviso tom={aviso.tom}>{aviso.texto}</Aviso> : <Carregando />;
  }

  const configuraveis = dados.catalogo.filter((p) => !p.reservada && p.codigo !== "AUDIT_VIEW");
  const cargos = dados.cargos.filter((c) => c.editavel);

  return (
    <div className="space-y-6">
      {aviso && <Aviso tom={aviso.tom}>{aviso.texto}</Aviso>}

      {(secao === "tudo" || secao === "pessoas") && (
        <section>
          <h3 className="mb-3 flex items-center gap-2 text-[13px] font-semibold">
            <Users className="h-4 w-4 text-primary" /> Pessoas da empresa
          </h3>
          <ul className="divide-y divide-border rounded-xl border border-border">
            {usuarios.map((u) => (
              <li key={u.id} className="flex flex-wrap items-center gap-3 p-3">
                <div className="min-w-[180px] flex-1">
                  <div className="text-[13px] font-semibold">
                    {u.nome}
                    {u.eu && <span className="ml-1 text-[11px] font-normal text-muted-foreground">(você)</span>}
                  </div>
                  <div className="text-[11px] text-muted-foreground">{u.email}</div>
                </div>
                {u.ativo && !u.eu ? (
                  <select
                    aria-label={`Cargo de ${u.nome}`}
                    value={u.papel}
                    disabled={ocupado !== null}
                    onChange={(e) =>
                      void executar(
                        `papel-${u.id}`,
                        () => api.usuarios.alterarPapel(u.id, e.target.value as Papel),
                        `Cargo de ${u.nome} alterado.`,
                      )
                    }
                    className={CampoTexto}
                  >
                    {OPCOES_CARGO.map((o) => (
                      <option key={o.valor} value={o.valor}>
                        {o.rotulo}
                      </option>
                    ))}
                  </select>
                ) : (
                  <span className="text-[12px] text-muted-foreground">{NOME_CARGO[u.papel] ?? u.papel}</span>
                )}
                {!u.ativo ? (
                  <Badge cor="destructive">Inativo</Badge>
                ) : u.trocarSenha ? (
                  <Badge cor="warning">Troca de senha exigida</Badge>
                ) : (
                  <Badge cor="success">Ativo</Badge>
                )}
                {u.ativo && !u.eu && (
                  <Botao
                    variante="secundario"
                    carregando={ocupado === `senha-${u.id}`}
                    disabled={ocupado !== null}
                    onClick={() =>
                      void executar(
                        `senha-${u.id}`,
                        () => api.usuarios.exigirTrocaSenha(u.id, !u.trocarSenha),
                        u.trocarSenha
                          ? `Troca de senha dispensada para ${u.nome}.`
                          : `${u.nome} deverá trocar a senha no próximo acesso.`,
                      )
                    }
                  >
                    {u.trocarSenha ? "Dispensar troca" : "Exigir troca de senha"}
                  </Botao>
                )}
                {!u.eu &&
                  (u.ativo && confirmandoId === u.id ? (
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-muted-foreground">
                        Desativar? A pessoa perde o acesso agora.
                      </span>
                      <Botao variante="secundario" onClick={() => setConfirmandoId(null)}>
                        Cancelar
                      </Botao>
                      <Botao
                        variante="perigo"
                        carregando={ocupado === `ativo-${u.id}`}
                        onClick={() => {
                          setConfirmandoId(null);
                          void executar(
                            `ativo-${u.id}`,
                            () => api.usuarios.definirAtivo(u.id, false),
                            `${u.nome} foi desativado e as sessões encerradas.`,
                          );
                        }}
                      >
                        Sim, desativar
                      </Botao>
                    </div>
                  ) : (
                    <Botao
                      variante={u.ativo ? "perigo" : "secundario"}
                      carregando={ocupado === `ativo-${u.id}`}
                      disabled={ocupado !== null}
                      onClick={() =>
                        u.ativo
                          ? setConfirmandoId(u.id)
                          : void executar(
                              `ativo-${u.id}`,
                              () => api.usuarios.definirAtivo(u.id, true),
                              `${u.nome} foi reativado.`,
                            )
                      }
                    >
                      {u.ativo ? "Desativar" : "Reativar"}
                    </Botao>
                  ))}
              </li>
            ))}
          </ul>
        </section>
      )}

      {(secao === "tudo" || secao === "cargos") && (
        <section>
          <h3 className="mb-1 text-[13px] font-semibold">Permissões por cargo</h3>
          <p className="mb-3 text-[12px] text-muted-foreground">
            Defina o que Supervisores e Operadores podem fazer. Vale na próxima ação de cada pessoa. O Administrador
            mantém acesso total.
          </p>
          <div className="grid gap-4 xl:grid-cols-2">
            {cargos.map((cargo) => {
              const marcadas = rascunho[cargo.nome] ?? [];
              const mudou =
                marcadas.length !== cargo.permissoes.length || marcadas.some((c) => !cargo.permissoes.includes(c));
              return (
                <div key={cargo.nome} className="rounded-xl border border-border p-4">
                  <div className="mb-3 flex items-center justify-between text-[13px] font-semibold">
                    {NOME_CARGO[cargo.nome] ?? cargo.nome}
                    <span className="text-[11px] font-normal text-muted-foreground">
                      {cargo.usuarios} {cargo.usuarios === 1 ? "pessoa" : "pessoas"}
                    </span>
                  </div>
                  <ul className="grid gap-1.5 md:grid-cols-2">
                    {configuraveis.map((p) => (
                      <li key={p.codigo}>
                        <label className="flex cursor-pointer items-start gap-2 rounded-lg px-1 py-1 hover:bg-muted/50">
                          <input
                            type="checkbox"
                            className="mt-0.5 h-4 w-4 accent-[hsl(var(--primary))]"
                            checked={marcadas.includes(p.codigo)}
                            onChange={() =>
                              setRascunho((prev) => {
                                const atual = prev[cargo.nome] ?? [];
                                const novo = atual.includes(p.codigo)
                                  ? atual.filter((c) => c !== p.codigo)
                                  : [...atual, p.codigo];
                                return { ...prev, [cargo.nome]: novo };
                              })
                            }
                          />
                          <span className="text-[12px]">
                            <span className="block font-medium">{p.descricao}</span>
                          </span>
                        </label>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-4">
                    <Botao
                      disabled={!mudou || ocupado !== null}
                      carregando={ocupado === `perm-${cargo.nome}`}
                      onClick={() =>
                        void executar(
                          `perm-${cargo.nome}`,
                          () => api.papeis.salvarPermissoes(cargo.nome, marcadas),
                          `Permissões de ${NOME_CARGO[cargo.nome] ?? cargo.nome} salvas.`,
                        )
                      }
                    >
                      {mudou ? "Salvar permissões" : "Nenhuma alteração"}
                    </Botao>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
