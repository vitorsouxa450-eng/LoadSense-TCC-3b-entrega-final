import { useEffect, useState } from "react";
import { Monitor } from "lucide-react";
import { api, ErroApi } from "@shared/lib/api";
import { Aviso, Badge, Botao, Carregando, Vazio } from "@/components/ui";

type Sessao = Awaited<ReturnType<typeof api.seguranca.sessoes>>["sessoes"][number];
const mensagem = (e: unknown) => (e instanceof ErroApi ? e.message : "Não foi possível falar com o servidor.");
const data = (v: string | null) =>
  v ? new Date(v).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "—";

export function SessoesPainel() {
  const [sessoes, setSessoes] = useState<Sessao[] | null>(null);
  const [erro, setErro] = useState<string | null>(null);
  const [ocupado, setOcupado] = useState<number | null>(null);

  async function carregar() {
    try {
      setSessoes((await api.seguranca.sessoes()).sessoes);
      setErro(null);
    } catch (e) {
      setErro(mensagem(e));
    }
  }

  useEffect(() => {
    void carregar();
  }, []);

  async function encerrar(s: Sessao) {
    setOcupado(s.id);
    try {
      await api.seguranca.encerrar(s.id);
      await carregar();
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setOcupado(null);
    }
  }

  if (erro && !sessoes) return <Aviso tom="erro">{erro}</Aviso>;
  if (!sessoes) return <Carregando />;
  if (sessoes.length === 0) return <Vazio texto="Nenhuma sessão ativa." />;

  return (
    <div className="space-y-3">
      {erro && <Aviso tom="erro">{erro}</Aviso>}
      <ul className="divide-y divide-border">
        {sessoes.map((s) => (
          <li key={s.id} className="flex items-center gap-3 py-3">
            <Monitor className="h-5 w-5 shrink-0 text-muted-foreground" />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2 text-[13px] font-semibold">
                {s.descricao}
                {s.atual && <Badge cor="success">Esta sessão</Badge>}
              </div>
              <div className="text-[11px] text-muted-foreground">
                Entrou em {data(s.criadaEm)} · último uso {data(s.ultimoUso ?? s.criadaEm)}
              </div>
            </div>
            {!s.atual && (
              <Botao
                variante="perigo"
                carregando={ocupado === s.id}
                disabled={ocupado !== null}
                onClick={() => void encerrar(s)}
              >
                Encerrar
              </Botao>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
