import { Fragment, useEffect, useState, type ReactNode } from "react";
import {
  Bell,
  FileText,
  History,
  LayoutDashboard,
  LogOut,
  MapPin,
  Plus,
  Settings,
  Table2,
  Moon,
  Sun,
} from "lucide-react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { guardarSessao, sessaoSalva, type SessaoApi } from "@shared/lib/api";
import { useInatividade } from "@shared/lib/inatividade";
import { api } from "@/lib/dados";
import { Logo } from "./ui";
import { AvisosAlertas, BotaoAvisos } from "./AvisosAlertas";
import { useTema } from "@/lib/tema";

export function ShellPublico({ children, largura = "max-w-[440px]" }: { children: ReactNode; largura?: string }) {
  return (
    <div className="flex min-h-screen flex-col bg-background bg-[radial-gradient(circle_at_20%_10%,hsl(16_100%_50%/0.12),transparent_40%),radial-gradient(circle_at_85%_90%,hsl(16_100%_50%/0.08),transparent_40%)]">
      <header className="flex items-center justify-between px-6 py-5">
        <a href="/">
          <Logo />
        </a>
        <span className="hidden items-center gap-2 rounded-full border border-success/30 bg-success/10 px-3 py-1 text-[11px] font-medium text-success sm:flex">
          <span className="h-1.5 w-1.5 rounded-full bg-success" /> Sistema online
        </span>
      </header>
      <main className="flex flex-1 items-center justify-center px-4 pb-16">
        <div className={`w-full ${largura}`}>{children}</div>
      </main>
    </div>
  );
}

const MENU: { to: string; rotulo: string; icone: typeof LayoutDashboard; fim?: boolean; grupo: string }[] = [
  { to: "/app", rotulo: "Dashboard", icone: LayoutDashboard, fim: true, grupo: "Operação" },
  { to: "/app/planilha", rotulo: "Planilha Operacional", icone: Table2, grupo: "Operação" },
  { to: "/app/nova-operacao", rotulo: "Nova operação", icone: Plus, grupo: "Operação" },
  { to: "/app/monitoramento", rotulo: "Monitoramento", icone: MapPin, grupo: "Operação" },
  { to: "/app/alertas", rotulo: "Alertas", icone: Bell, grupo: "Operação" },
  { to: "/app/historico", rotulo: "Histórico", icone: History, grupo: "Dados" },
  { to: "/app/relatorios", rotulo: "Relatórios", icone: FileText, grupo: "Dados" },
  { to: "/app/configuracoes", rotulo: "Configurações", icone: Settings, grupo: "Conta" },
];

export function LayoutCentral({ children, alertasAbertos }: { children: ReactNode; alertasAbertos?: number }) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { tema, alternar: alternarTema } = useTema();
  const [sessao, setSessao] = useState<SessaoApi | null>(sessaoSalva());
  const [servidor, setServidor] = useState<boolean | null>(null);

  useEffect(() => {
    api
      .eu()
      .then(() => setServidor(true))
      .catch(() => setServidor(false));
  }, []);

  async function sair() {
    await api.sair();
    setSessao(null);
    navigate("/login", { replace: true });
  }

  useInatividade(!!sessao, () => {
    void sair();
  });

  const nome = sessao?.usuario?.nome ?? "Visitante";
  const papel = sessao?.usuario?.papelDescricao ?? sessao?.usuario?.papel ?? "";
  const iniciais = nome
    .split(" ")
    .slice(0, 2)
    .map((p) => p[0])
    .join("")
    .toUpperCase();

  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-border bg-card p-5 md:flex">
        <a href="/app" className="mb-8">
          <Logo />
        </a>
        <nav className="flex-1 space-y-1">
          {MENU.map((item, indice) => (
            <Fragment key={item.to}>
              {item.grupo !== MENU[indice - 1]?.grupo && (
                <p className="px-3 pb-1 pt-4 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground first:pt-0">
                  {item.grupo}
                </p>
              )}
              <NavLink
                to={item.to}
                end={item.fim}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium transition ${
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-card-elev hover:text-foreground"
                  }`
                }
              >
                <item.icone className="h-4 w-4" />
                <span className="flex-1">{item.rotulo}</span>
                {item.to === "/app/alertas" && !!alertasAbertos && (
                  <span className="rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-primary-foreground">
                    {alertasAbertos}
                  </span>
                )}
              </NavLink>
            </Fragment>
          ))}
        </nav>
        <div className="rounded-xl border border-border bg-card-elev p-3 text-[11px] text-muted-foreground">
          <>
            <div className="flex items-center gap-2 text-foreground">
              <span className={`h-2 w-2 rounded-full ${servidor ? "bg-success" : "bg-warning"}`} />
              {servidor ? "Conectado ao banco" : servidor === false ? "Servidor indisponível" : "Verificando…"}
            </div>
          </>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between gap-4 border-b border-border bg-background/80 px-4 backdrop-blur md:px-6">
          <div className="md:hidden">
            <Logo />
          </div>
          <div className="hidden items-center gap-2 rounded-full border border-success/30 bg-success/10 px-3 py-1.5 text-[12px] font-medium text-success md:flex">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Sistema online
          </div>
          <div className="flex items-center gap-3">
            <BotaoAvisos />
            <button
              onClick={alternarTema}
              className="flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground hover:bg-card-elev hover:text-foreground"
              aria-label={tema === "dark" ? "Ativar modo claro" : "Ativar modo escuro"}
              title={tema === "dark" ? "Ativar modo claro" : "Ativar modo escuro"}
            >
              {tema === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-[12px] font-bold text-primary-foreground">
              {iniciais || "?"}
            </div>
            <div className="hidden text-right leading-tight sm:block">
              <div className="text-[13px] font-semibold">{nome}</div>
              <div className="text-[11px] text-muted-foreground">{papel}</div>
            </div>
            <button
              onClick={sair}
              title="Sair"
              aria-label="Sair"
              className="rounded-lg p-2 text-muted-foreground hover:bg-card-elev hover:text-foreground"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </header>
        {}
        <nav className="flex gap-2 overflow-x-auto border-b border-border px-4 py-2 md:hidden">
          {MENU.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.fim}
              className={({ isActive }) =>
                `whitespace-nowrap rounded-lg px-3 py-1.5 text-[12px] ${isActive ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground"}`
              }
            >
              {item.rotulo}
            </NavLink>
          ))}
        </nav>
        <main className="flex-1 p-4 md:p-8">
          {}
          <div key={pathname} className="animate-ls-tela">
            {children}
          </div>
        </main>
      </div>
      <AvisosAlertas />
    </div>
  );
}

export function exigeSessao(): boolean {
  const sessao = sessaoSalva();
  if (!sessao) return false;
  guardarSessao(sessao);
  return true;
}
