import { useEffect, useState } from "react";
import { Bell, BellOff } from "lucide-react";
import { sessaoSalva } from "@shared/lib/api";
import {
  avisoDoSistema,
  pedirPermissaoAviso,
  permissaoAviso,
  tocarSomAlerta,
  type PermissaoAviso,
} from "@shared/lib/avisos";
import { api } from "@/lib/dados";

const CHAVE_LIGADO = "ls_avisos_alertas";
const INTERVALO_MS = 30_000;

let conhecidos: Set<string> | null = null;
let dono: number | null = null;

interface Aviso {
  id: number;
  titulo: string;
  descricao: string;
  critico: boolean;
}

export function BotaoAvisos() {
  const [ligado, setLigado] = useState(() => localStorage.getItem(CHAVE_LIGADO) !== "0");
  const [permissao, setPermissao] = useState<PermissaoAviso>(permissaoAviso());

  if (!sessaoSalva()) return null;

  async function alternar() {
    const novo = !ligado;
    setLigado(novo);
    localStorage.setItem(CHAVE_LIGADO, novo ? "1" : "0");
    if (novo) setPermissao(await pedirPermissaoAviso());
  }

  const rotulo = !ligado
    ? "Avisos de alerta desligados"
    : permissao === "granted"
      ? "Avisos de alerta ligados"
      : "Avisos de alerta ligados (sem notificação do sistema)";

  return (
    <button
      type="button"
      onClick={alternar}
      aria-pressed={ligado}
      aria-label={rotulo}
      title={rotulo}
      className="flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground hover:bg-card-elev hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
    >
      {ligado ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
    </button>
  );
}

export function AvisosAlertas() {
  const [avisos, setAvisos] = useState<Aviso[]>([]);
  const logado = !!sessaoSalva();

  useEffect(() => {
    if (!logado) return;
    let ativo = true;

    async function verificar() {
      if (localStorage.getItem(CHAVE_LIGADO) === "0") return;
      const usuario = sessaoSalva()?.usuario?.id ?? null;
      try {
        const { alertas } = await api.alertas();
        if (!ativo) return;
        if (dono !== usuario) {
          dono = usuario;
          conhecidos = null;
        }
        const abertos = alertas.filter((a) => a.situacao === "OPEN");
        const anteriores = conhecidos;
        conhecidos = new Set(abertos.map((a) => String(a.id)));
        if (!anteriores) return;
        const novos = abertos.filter((a) => !anteriores.has(String(a.id)));
        if (novos.length === 0) return;

        const primeiro = novos[0];
        const critico = novos.some((a) => a.nivel === "CRITICAL");
        setAvisos((atuais) =>
          [
            ...atuais,
            {
              id: primeiro.id,
              titulo: critico ? "Alerta crítico" : "Atenção: novo alerta",
              descricao: novos.length === 1 ? primeiro.titulo : `${novos.length} novos alertas`,
              critico,
            },
          ].slice(-3),
        );
        tocarSomAlerta();
        avisoDoSistema(
          `LoadSense: ${novos.length === 1 ? primeiro.titulo : `${novos.length} novos alertas`}`,
          novos.length === 1 ? primeiro.mensagem : "Abra a central para ver os detalhes.",
        );
      } catch {}
    }

    void verificar();
    const timer = window.setInterval(verificar, INTERVALO_MS);
    return () => {
      ativo = false;
      window.clearInterval(timer);
    };
  }, [logado]);

  useEffect(() => {
    if (avisos.length === 0) return;
    const timer = window.setTimeout(() => setAvisos((atuais) => atuais.slice(1)), 8000);
    return () => window.clearTimeout(timer);
  }, [avisos]);

  if (avisos.length === 0) return null;
  return (
    <div
      className="fixed bottom-4 right-4 z-50 flex w-[min(360px,calc(100vw-2rem))] flex-col gap-2"
      aria-live="assertive"
    >
      {avisos.map((aviso) => (
        <div
          key={aviso.id}
          role="alert"
          className={`rounded-xl border bg-card p-4 text-[13px] shadow-lg ${aviso.critico ? "border-destructive/50" : "border-warning/50"}`}
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="font-semibold">{aviso.titulo}</div>
              <div className="text-[12px] text-muted-foreground">{aviso.descricao}</div>
            </div>
            <button
              type="button"
              onClick={() => setAvisos((atuais) => atuais.filter((a) => a.id !== aviso.id))}
              aria-label="Fechar aviso"
              className="text-muted-foreground hover:text-foreground"
            >
              ×
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
