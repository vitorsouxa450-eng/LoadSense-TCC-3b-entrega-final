import type { ReactNode } from "react";
import { Loader2 } from "lucide-react";
import { tom } from "@/lib/format";

export function Logo({ tamanho = "md" }: { tamanho?: "md" | "lg" }) {
  const altura = tamanho === "lg" ? "h-14 w-14" : "h-10 w-10";
  const texto = tamanho === "lg" ? "text-[28px]" : "text-[18px]";
  return (
    <div className="flex items-center gap-3">
      <img src="/loadsense-icon.png" alt="" className={`${altura} rounded-xl`} />
      <div className="leading-none">
        <div className={`font-brand font-extrabold tracking-tight ${texto}`}>
          LOAD<span className="text-primary">SENSE</span>
        </div>
        <div className="mt-1 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          Sua logística em tempo real
        </div>
      </div>
    </div>
  );
}

export function Cartao({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-2xl border border-border bg-card p-5 ${className}`}>{children}</div>;
}

export function Badge({ cor, children }: { cor: string; children: ReactNode }) {
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-semibold ${tom(cor)}`}
    >
      {children}
    </span>
  );
}

export function Botao({
  children,
  onClick,
  tipo = "button",
  variante = "primario",
  carregando = false,
  disabled = false,
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  tipo?: "button" | "submit";
  variante?: "primario" | "secundario" | "perigo";
  carregando?: boolean;
  disabled?: boolean;
  className?: string;
}) {
  const estilo =
    variante === "primario"
      ? "bg-primary text-primary-foreground hover:brightness-110"
      : variante === "perigo"
        ? "border border-destructive/40 text-destructive hover:bg-destructive/10"
        : "border border-border bg-card-elev text-foreground hover:border-primary/50";
  return (
    <button
      type={tipo}
      onClick={onClick}
      disabled={disabled || carregando}
      className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-[13px] font-semibold transition disabled:opacity-60 ${estilo} ${className}`}
    >
      {carregando && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  );
}

export const CampoTexto =
  "w-full rounded-xl border border-border bg-input px-3 py-2.5 text-[13px] text-foreground outline-none placeholder:text-muted-foreground focus:border-primary";

export function Aviso({ tom: t, children }: { tom: "erro" | "sucesso" | "info" | "atencao"; children: ReactNode }) {
  const cor = t === "erro" ? "destructive" : t === "sucesso" ? "success" : t === "atencao" ? "warning" : "primary";
  return <p className={`rounded-xl border px-3 py-2 text-[12px] ${tom(cor)}`}>{children}</p>;
}

export function Titulo({ titulo, subtitulo, acoes }: { titulo: string; subtitulo: string; acoes?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-[26px] font-bold tracking-tight">{titulo}</h1>
        <p className="mt-1 text-[13px] text-muted-foreground">{subtitulo}</p>
      </div>
      {acoes}
    </div>
  );
}

export function Vazio({ texto }: { texto: string }) {
  return (
    <div className="rounded-xl border border-dashed border-border p-8 text-center text-[13px] text-muted-foreground">
      {texto}
    </div>
  );
}

export function Carregando() {
  return (
    <div className="flex items-center justify-center gap-2 p-10 text-[13px] text-muted-foreground">
      <Loader2 className="h-4 w-4 animate-spin" /> Carregando dados do servidor…
    </div>
  );
}
