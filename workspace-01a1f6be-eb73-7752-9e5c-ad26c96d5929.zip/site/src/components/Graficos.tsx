export function BarrasVerticais({
  valores,
  rotulos,
  altura = 200,
  cor = "hsl(var(--primary))",
  formatar = (v: number) => v.toLocaleString("pt-BR", { maximumFractionDigits: 1 }),
}: {
  valores: number[];
  rotulos?: string[];
  altura?: number;
  cor?: string;
  formatar?: (valor: number) => string;
}) {
  const maximo = Math.max(...valores, 1);
  return (
    <div className="flex w-full items-end gap-2" style={{ height: altura }}>
      {valores.map((valor, indice) => (
        <div key={indice} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
          <span className="text-[10px] tabular-nums text-muted-foreground">{valor > 0 ? formatar(valor) : ""}</span>
          <div
            className="w-full rounded-t-md transition-all duration-500"
            style={{
              height: `${Math.max(valor > 0 ? 4 : 2, (valor / maximo) * (altura - 44))}px`,
              background: cor,
              opacity: valor > 0 ? 0.45 + (valor / maximo) * 0.55 : 0.2,
            }}
            title={formatar(valor)}
          />
          {rotulos && <span className="text-[10px] text-muted-foreground">{rotulos[indice]}</span>}
        </div>
      ))}
    </div>
  );
}

export function BarrasHorizontais({ itens }: { itens: { rotulo: string; valor: number; detalhe?: string }[] }) {
  const maximo = Math.max(...itens.map((i) => i.valor), 1);
  return (
    <ul className="space-y-3">
      {itens.map((item) => (
        <li key={item.rotulo}>
          <div className="mb-1 flex items-center justify-between gap-3 text-[13px]">
            <span className="font-medium">{item.rotulo}</span>
            <span className="text-[12px] text-muted-foreground">{item.detalhe}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-card-elev">
            <div className="h-full rounded-full bg-primary" style={{ width: `${(item.valor / maximo) * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}

export function Rosca({
  fatias,
  tamanho = 128,
}: {
  fatias: { rotulo: string; valor: number; cor: string }[];
  tamanho?: number;
}) {
  const total = fatias.reduce((soma, f) => soma + f.valor, 0);
  let acumulado = 0;
  const gradiente =
    total > 0
      ? fatias
          .map((f) => {
            const inicio = acumulado;
            acumulado += (f.valor / total) * 100;
            return `${f.cor} ${inicio}% ${acumulado}%`;
          })
          .join(", ")
      : "hsl(var(--muted)) 0% 100%";
  return (
    <div
      className="relative shrink-0 rounded-full"
      style={{ height: tamanho, width: tamanho, background: `conic-gradient(${gradiente})` }}
    >
      <div className="absolute inset-4 flex items-center justify-center rounded-full bg-card text-center">
        <span className="text-[16px] font-bold tabular-nums">{total}</span>
      </div>
    </div>
  );
}

export function Tendencia({
  valores,
  altura = 120,
  cor = "hsl(var(--primary))",
}: {
  valores: number[];
  altura?: number;
  cor?: string;
}) {
  const largura = 320;
  const serie = valores.length > 1 ? valores : [0, 0];
  const maximo = Math.max(...serie, 1);
  const minimo = Math.min(...serie, 0);
  const amplitude = maximo - minimo || 1;
  const passo = largura / (serie.length - 1);
  const pontos = serie.map((v, i) => [i * passo, altura - ((v - minimo) / amplitude) * (altura - 16) - 8] as const);
  const linha = pontos.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const area = `${linha} L${largura},${altura} L0,${altura} Z`;
  const id = `grad-${serie.length}-${altura}`;
  return (
    <svg viewBox={`0 0 ${largura} ${altura}`} className="w-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={cor} stopOpacity="0.35" />
          <stop offset="100%" stopColor={cor} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${id})`} />
      <path d={linha} fill="none" stroke={cor} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
