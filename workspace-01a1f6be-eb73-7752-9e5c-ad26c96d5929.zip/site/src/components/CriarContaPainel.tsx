import { useState, type FormEvent } from "react";
import { Copy, UserPlus } from "lucide-react";
import { api, ErroApi } from "@shared/lib/api";
import { Aviso, Botao, CampoTexto, Cartao } from "@/components/ui";

type Papel = "ADMINISTRATOR" | "SUPERVISOR" | "OPERATOR";

const OPCOES_CARGO: { valor: Papel; rotulo: string }[] = [
  { valor: "OPERATOR", rotulo: "Operador de Pesagem" },
  { valor: "SUPERVISOR", rotulo: "Supervisor de Operações" },
  { valor: "ADMINISTRATOR", rotulo: "Administrador" },
];

const mensagem = (e: unknown) => (e instanceof ErroApi ? e.message : "Não foi possível falar com o servidor.");

export function CriarContaPainel() {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [papel, setPapel] = useState<Papel>("OPERATOR");
  const [ocupado, setOcupado] = useState(false);
  const [aviso, setAviso] = useState<{ tom: "erro" | "sucesso"; texto: string } | null>(null);
  const [novaConta, setNovaConta] = useState<{ nome: string; email: string; senha: string } | null>(null);

  async function criarConta(event: FormEvent) {
    event.preventDefault();
    if (nome.trim().length < 3) return setAviso({ tom: "erro", texto: "Informe o nome completo." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return setAviso({ tom: "erro", texto: "E-mail inválido." });
    setOcupado(true);
    setAviso(null);
    try {
      const r = await api.usuarios.criar({ nome: nome.trim(), email: email.trim(), papel });
      setNovaConta({ nome: r.usuario.nome, email: r.usuario.email, senha: r.senhaProvisoria });
      setNome("");
      setEmail("");
      setPapel("OPERATOR");
    } catch (e) {
      setAviso({ tom: "erro", texto: mensagem(e) });
    } finally {
      setOcupado(false);
    }
  }

  return (
    <Cartao>
      <h2 className="mb-2 text-[15px] font-semibold">Criar conta</h2>
      <p className="mb-4 text-[12px] text-muted-foreground">
        Crie contas para as pessoas da sua empresa e defina o cargo de cada uma. Só administradores podem criar contas.
      </p>

      {aviso && <Aviso tom={aviso.tom}>{aviso.texto}</Aviso>}

      {novaConta && (
        <div className="mb-4 rounded-xl border border-success/40 bg-success/10 p-4">
          <div className="text-[13px] font-semibold">Conta criada para {novaConta.nome}</div>
          <div className="text-[12px] text-muted-foreground">{novaConta.email}</div>
          <p className="mt-2 text-[12px]">
            Senha provisória (mostrada só agora). Entregue por um canal seguro. A pessoa troca a senha no primeiro
            acesso.
          </p>
          <div className="mt-2 flex items-center gap-2">
            <code className="flex-1 select-all rounded-lg bg-card px-3 py-2 font-mono text-[13px]">
              {novaConta.senha}
            </code>
            <Botao variante="secundario" onClick={() => void navigator.clipboard?.writeText(novaConta.senha)}>
              <Copy className="h-4 w-4" /> Copiar
            </Botao>
          </div>
          <button
            type="button"
            onClick={() => setNovaConta(null)}
            className="mt-3 text-[12px] font-semibold text-primary"
          >
            Entendi, ocultar a senha
          </button>
        </div>
      )}

      <p className="mb-3 text-[12px] text-muted-foreground">
        A pessoa recebe uma senha provisória e cria a própria senha no primeiro acesso (mínimo de 8 caracteres, com
        maiúscula, número e símbolo).
      </p>
      <form
        onSubmit={criarConta}
        className="grid gap-3 rounded-xl border border-border p-4 md:grid-cols-[1fr_1fr_200px_auto] md:items-end"
      >
        <label className="block text-[12px] font-medium">
          Nome completo
          <input
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            maxLength={140}
            className={`${CampoTexto} mt-1.5 w-full`}
          />
        </label>
        <label className="block text-[12px] font-medium">
          E-mail
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className={`${CampoTexto} mt-1.5 w-full`}
          />
        </label>
        <label className="block text-[12px] font-medium">
          Cargo
          <select
            value={papel}
            onChange={(e) => setPapel(e.target.value as Papel)}
            className={`${CampoTexto} mt-1.5 w-full`}
          >
            {OPCOES_CARGO.map((o) => (
              <option key={o.valor} value={o.valor}>
                {o.rotulo}
              </option>
            ))}
          </select>
        </label>
        <Botao tipo="submit" carregando={ocupado}>
          <UserPlus className="h-4 w-4" /> Criar conta
        </Botao>
      </form>
    </Cartao>
  );
}
