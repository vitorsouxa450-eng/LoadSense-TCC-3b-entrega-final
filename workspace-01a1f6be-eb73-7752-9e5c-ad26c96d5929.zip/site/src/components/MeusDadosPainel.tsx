import { useEffect, useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { Download } from "lucide-react";
import { api, ErroApi, guardarSessao } from "@shared/lib/api";
import { Aviso, Botao, CampoTexto } from "@/components/ui";

const mensagem = (e: unknown) => (e instanceof ErroApi ? e.message : "Tente novamente.");

export function MeusDadosPainel() {
  const navigate = useNavigate();
  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");
  const [alertas, setAlertas] = useState(true);
  const [relatorios, setRelatorios] = useState(true);
  const [senha, setSenha] = useState("");
  const [excluindo, setExcluindo] = useState(false);
  const [ocupado, setOcupado] = useState(false);
  const [aviso, setAviso] = useState<{ tom: "erro" | "sucesso"; texto: string } | null>(null);

  useEffect(() => {
    api.titular
      .perfil()
      .then((p) => {
        setNome(p.nome);
        setTelefone(p.telefone ?? "");
        setAlertas(p.alertasCriticos);
        setRelatorios(p.relatoriosAutomaticos);
      })
      .catch(() => undefined);
  }, []);

  async function baixar() {
    setOcupado(true);
    try {
      await api.titular.baixarMeusDados();
    } catch (e) {
      setAviso({ tom: "erro", texto: mensagem(e) });
    } finally {
      setOcupado(false);
    }
  }

  async function salvar(event: FormEvent) {
    event.preventDefault();
    setOcupado(true);
    setAviso(null);
    try {
      await api.titular.atualizarMeusDados({
        nome: nome.trim(),
        telefone: telefone.trim() || undefined,
        alertasCriticos: alertas,
        relatoriosAutomaticos: relatorios,
      });
      setAviso({ tom: "sucesso", texto: "Dados atualizados." });
    } catch (e) {
      setAviso({ tom: "erro", texto: mensagem(e) });
    } finally {
      setOcupado(false);
    }
  }

  async function excluir() {
    setOcupado(true);
    try {
      await api.titular.excluirConta(senha);
      guardarSessao(null);
      navigate("/login", { replace: true });
    } catch (e) {
      setAviso({ tom: "erro", texto: mensagem(e) });
    } finally {
      setOcupado(false);
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="space-y-4">
        <div>
          <div className="text-[13px] font-semibold">Baixar meus dados</div>
          <p className="mb-3 text-[12px] text-muted-foreground">
            Arquivo JSON com sua conta, sessões, aceites de termos e pesagens vinculadas.
          </p>
          <Botao variante="secundario" carregando={ocupado} onClick={() => void baixar()}>
            <Download className="h-4 w-4" /> Baixar arquivo (JSON)
          </Botao>
        </div>

        <form onSubmit={salvar} className="space-y-3">
          <div className="text-[13px] font-semibold">Corrigir dados e comunicações</div>
          <label className="block text-[12px] font-medium">
            Nome completo
            <input
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              maxLength={140}
              className={`${CampoTexto} mt-1.5 w-full`}
            />
          </label>
          <label className="block text-[12px] font-medium">
            Telefone
            <input
              value={telefone}
              onChange={(e) => setTelefone(e.target.value)}
              maxLength={30}
              placeholder="(11) 90000-0000"
              className={`${CampoTexto} mt-1.5 w-full`}
            />
          </label>
          <label className="flex items-center gap-2 text-[12px]">
            <input type="checkbox" checked={alertas} onChange={(e) => setAlertas(e.target.checked)} />
            Receber alertas críticos por e-mail
          </label>
          <label className="flex items-center gap-2 text-[12px]">
            <input type="checkbox" checked={relatorios} onChange={(e) => setRelatorios(e.target.checked)} />
            Receber relatórios automáticos
          </label>
          <Botao tipo="submit" carregando={ocupado} disabled={nome.trim().length < 3}>
            Salvar alterações
          </Botao>
        </form>
      </div>

      <div className="space-y-3 rounded-xl border border-destructive/30 p-4">
        <div className="text-[13px] font-semibold text-destructive">Excluir minha conta</div>
        <p className="text-[12px] text-muted-foreground">
          Sua conta é desativada e seus dados pessoais são anonimizados. As pesagens permanecem na empresa, sem o seu
          nome. Não é possível desfazer.
        </p>
        {!excluindo ? (
          <Botao variante="perigo" onClick={() => setExcluindo(true)}>
            Quero excluir minha conta
          </Botao>
        ) : (
          <div className="space-y-3">
            <label className="block text-[12px] font-medium">
              Confirme com sua senha
              <input
                type="password"
                autoComplete="current-password"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                className={`${CampoTexto} mt-1.5 w-full`}
              />
            </label>
            <div className="flex gap-2">
              <Botao variante="perigo" carregando={ocupado} disabled={!senha} onClick={() => void excluir()}>
                Excluir definitivamente
              </Botao>
              <Botao
                variante="secundario"
                onClick={() => {
                  setExcluindo(false);
                  setSenha("");
                }}
              >
                Cancelar
              </Botao>
            </div>
          </div>
        )}
        {aviso && <Aviso tom={aviso.tom}>{aviso.texto}</Aviso>}
      </div>
    </div>
  );
}
