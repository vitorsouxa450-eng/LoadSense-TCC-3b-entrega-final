import { CircleCheck, MessageCircle } from "lucide-react";
import { Cartao } from "@/components/ui";

interface Plano {
  nome: string;
  limites: string;
  precoMensal: string;
  precoAnual: string;
  descricao: string;
  itens: string[];
  destaque?: boolean;
}

const PLANOS: Plano[] = [
  {
    nome: "Essencial",
    limites: "até 3 veículos",
    precoMensal: "R$ 149,90",
    precoAnual: "R$ 1.529,90 por ano",
    descricao: "Para começar a controlar a operação.",
    itens: [
      "Operações de pesagem ilimitadas",
      "Cadastros de caminhões, motoristas, produtos e rotas",
      "Painel, alertas e monitoramento",
      "Relatórios em CSV e XLSX",
      "Histórico dos últimos 90 dias",
    ],
  },
  {
    nome: "Profissional",
    limites: "até 10 veículos",
    precoMensal: "R$ 349,90",
    precoAnual: "R$ 3.569,90 por ano",
    descricao: "Para parar de digitar e não perder histórico.",
    itens: [
      "Tudo do Essencial",
      "Importação e exportação de planilha",
      "Histórico completo, sem limite de 90 dias",
      "Suporte prioritário",
    ],
    destaque: true,
  },
  {
    nome: "Avançado",
    limites: "até 25 veículos",
    precoMensal: "R$ 749,90",
    precoAnual: "R$ 7.649,90 por ano",
    descricao: "Para operações em crescimento, com mais veículos e usuários.",
    itens: ["Tudo do Profissional", "Usuários ilimitados"],
  },
  {
    nome: "Enterprise",
    limites: "acima de 25 veículos",
    precoMensal: "Sob consulta",
    precoAnual: "",
    descricao: "Para operações maiores e com necessidades específicas.",
    itens: ["Tudo do Avançado", "Implantação assistida e treinamento", "SLA e suporte dedicado"],
  },
];

const CONTATO = import.meta.env.VITE_CONTATO_COMERCIAL as string | undefined;

function linkConsultoria(plano: string): string | undefined {
  const assunto = `Contratação do plano ${plano}`;
  if (!CONTATO) return undefined;
  return CONTATO.includes("@") ? `mailto:${CONTATO}?subject=${encodeURIComponent(assunto)}` : CONTATO;
}

export function PlanosCartao() {
  return (
    <Cartao className="xl:col-span-2">
      <div className="mb-1 flex flex-wrap items-end justify-between gap-2">
        <div>
          <h2 className="text-[15px] font-semibold">Planos</h2>
          <p className="text-[12px] text-muted-foreground">
            Escolha o plano pelo tamanho da sua frota e pelo que a sua operação precisa. Cada plano tem um botão para
            falar com a consultoria LoadSense, que orienta a contratação.
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {PLANOS.map((plano) => {
          const link = linkConsultoria(plano.nome);
          return (
            <div
              key={plano.nome}
              className={`flex flex-col rounded-2xl border p-5 ${
                plano.destaque ? "border-primary/60 bg-card-elev" : "border-border/60 bg-card"
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="text-[15px] font-bold">{plano.nome}</div>
              </div>
              <div className="text-[12px] text-muted-foreground">{plano.limites}</div>

              <div className="mt-3 text-[20px] font-extrabold tabular-nums">
                {plano.precoMensal}
                {plano.precoMensal.startsWith("R$") && (
                  <span className="text-[12px] font-normal text-muted-foreground"> /mês</span>
                )}
              </div>
              {plano.precoAnual && <div className="text-[11px] text-muted-foreground">ou {plano.precoAnual}</div>}

              <p className="mt-3 text-[12px] leading-relaxed text-muted-foreground">{plano.descricao}</p>

              <ul className="mt-4 flex-1 space-y-2">
                {plano.itens.map((item) => (
                  <li key={item} className="flex gap-2 text-[12px]">
                    <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <a
                href={link}
                target={link?.startsWith("http") ? "_blank" : undefined}
                rel="noreferrer"
                aria-disabled={!link}
                className={`mt-5 flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-[12px] font-semibold ${
                  link
                    ? "bg-primary text-primary-foreground hover:brightness-110"
                    : "pointer-events-none bg-muted text-muted-foreground"
                }`}
              >
                <MessageCircle className="h-3.5 w-3.5 shrink-0" />
                {link ? `Falar com a consultoria sobre ${plano.nome}` : "Contato comercial indisponível"}
              </a>
            </div>
          );
        })}
      </div>

      <p className="mt-5 text-center text-[11px] text-muted-foreground">
        Teste grátis de 14 dias no plano Profissional. Enterprise é sob consulta. Esta página não realiza compra. ·
        LoadSense Tecnologia e Logística LTDA
      </p>
    </Cartao>
  );
}
