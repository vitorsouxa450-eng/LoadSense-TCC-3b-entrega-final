import { useEffect, useState, type ReactNode } from "react";
import { detectarServidor } from "@shared/lib/api";

export function SemServidorGate({ children }: { children: ReactNode }) {
  const [estado, setEstado] = useState<"verificando" | "online" | "offline">("verificando");
  const [tentativa, setTentativa] = useState(0);

  useEffect(() => {
    let vivo = true;
    let temporizador: ReturnType<typeof setTimeout> | undefined;
    (async () => {
      const { disponivel } = await detectarServidor(3000);
      if (!vivo) return;
      setEstado(disponivel ? "online" : "offline");
      if (!disponivel) temporizador = setTimeout(() => setTentativa((n) => n + 1), 5000);
    })();
    return () => {
      vivo = false;
      if (temporizador) clearTimeout(temporizador);
    };
  }, [tentativa]);

  if (estado === "online") return <>{children}</>;
  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-6">
      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 text-center shadow-sm">
        {estado === "verificando" ? (
          <p className="text-sm text-muted-foreground">Verificando o servidor…</p>
        ) : (
          <>
            <h1 className="text-lg font-semibold">Sem servidor disponível</h1>
            <p className="mt-3 text-sm text-muted-foreground">
              O LoadSense precisa do servidor (API e banco de dados) para mostrar as informações. Por isso, nenhum dado
              de exemplo é exibido.
            </p>
            <ol className="mt-4 space-y-2 text-left text-sm">
              <li>1. Confira se a janela da API está mostrando “ouvindo em http://0.0.0.0:5174”.</li>
              <li>2. Se a API mostrar erro de banco de dados, confirme que o MySQL está no ar (porta 3307).</li>
            </ol>
            <button
              type="button"
              onClick={() => {
                setEstado("verificando");
                setTentativa((n) => n + 1);
              }}
              className="mt-6 w-full rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground"
            >
              Tentar novamente
            </button>
            <p className="mt-3 text-xs text-muted-foreground">Verificando sozinho a cada 5 segundos.</p>
          </>
        )}
      </div>
    </div>
  );
}
