

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


/*!40000 DROP DATABASE IF EXISTS `loadsense`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `loadsense` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `loadsense`;


DROP TABLE IF EXISTS `alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alerts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `operation_id` bigint unsigned NOT NULL,
  `alert_context` enum('WEIGHING','TRACKING','DEVICE','SYSTEM') NOT NULL DEFAULT 'WEIGHING',
  `calculation_version` int unsigned DEFAULT NULL,
  `alert_type` enum('OVER_GROSS_LIMIT','OVER_PAYLOAD_LIMIT','POSSIBLE_MISSING_CARGO','POSSIBLE_EXTRA_CARGO','TARE_DIVERGENCE','UNSTABLE_READING','MANUAL_READING','WEIGHING_INCONSISTENCY','DEVICE_OFFLINE','UNPLANNED_STOP','DELIVERY_DELAY','ROUTE_DEVIATION','TRACKING_SIGNAL_LOST') NOT NULL,
  `severity` enum('ATTENTION','CRITICAL') NOT NULL,
  `state` enum('OPEN','ACKNOWLEDGED','RESOLVED') NOT NULL DEFAULT 'OPEN',
  `source` enum('SYSTEM','MANUAL') NOT NULL DEFAULT 'SYSTEM',
  `deduplication_key` varchar(190) DEFAULT NULL,
  `title` varchar(180) NOT NULL,
  `message` text NOT NULL,
  `difference_kg` decimal(14,3) DEFAULT NULL,
  `difference_percent` decimal(10,4) DEFAULT NULL,
  `context_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `detected_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `created_by_user_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `acknowledged_by_user_id` bigint unsigned DEFAULT NULL,
  `acknowledged_at` datetime(3) DEFAULT NULL,
  `resolved_by_user_id` bigint unsigned DEFAULT NULL,
  `resolved_at` datetime(3) DEFAULT NULL,
  `resolution_reason` varchar(40) DEFAULT NULL,
  `resolution_notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_alerts_company_id` (`company_id`,`id`),
  UNIQUE KEY `uq_alerts_calculation_type` (`operation_id`,`calculation_version`,`alert_type`),
  UNIQUE KEY `uq_alerts_company_dedup` (`company_id`,`deduplication_key`),
  KEY `idx_alerts_state_severity_date` (`company_id`,`state`,`severity`,`created_at`),
  KEY `idx_alerts_operation` (`company_id`,`operation_id`),
  KEY `fk_alerts_created_user` (`company_id`,`created_by_user_id`),
  KEY `fk_alerts_ack_user` (`company_id`,`acknowledged_by_user_id`),
  KEY `fk_alerts_resolved_user` (`company_id`,`resolved_by_user_id`),
  KEY `idx_alerts_company_created_period` (`company_id`,`created_at`),
  KEY `idx_alerts_context_state_date` (`company_id`,`alert_context`,`state`,`created_at`),
  CONSTRAINT `fk_alerts_ack_user` FOREIGN KEY (`company_id`, `acknowledged_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `fk_alerts_created_user` FOREIGN KEY (`company_id`, `created_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `fk_alerts_operation` FOREIGN KEY (`company_id`, `operation_id`) REFERENCES `weighing_operations` (`company_id`, `id`) ON DELETE CASCADE,
  CONSTRAINT `fk_alerts_resolved_user` FOREIGN KEY (`company_id`, `resolved_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `alerts_chk_1` CHECK (json_valid(`context_json`)),
  CONSTRAINT `chk_alerts_acknowledged` CHECK (((`state` <> _utf8mb4'ACKNOWLEDGED') or ((`acknowledged_at` is not null) and (`acknowledged_by_user_id` is not null)))),
  CONSTRAINT `chk_alerts_resolved` CHECK (((`state` <> _utf8mb4'RESOLVED') or ((`resolved_at` is not null) and (`resolution_notes` is not null))))
) ENGINE=InnoDB AUTO_INCREMENT=547 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `app_platform_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_platform_settings` (
  `platform` enum('ANDROID','IOS') NOT NULL,
  `current_version_name` varchar(30) NOT NULL DEFAULT '1.0.0',
  `current_build_number` int unsigned NOT NULL DEFAULT '1',
  `minimum_supported_build_number` int unsigned NOT NULL DEFAULT '1',
  `maintenance_mode` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance_message` varchar(500) DEFAULT NULL,
  `store_url` varchar(500) DEFAULT NULL,
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`platform`),
  CONSTRAINT `chk_app_platform_builds` CHECK (((`current_build_number` > 0) and (`minimum_supported_build_number` > 0) and (`current_build_number` >= `minimum_supported_build_number`))),
  CONSTRAINT `chk_app_platform_maintenance` CHECK ((`maintenance_mode` in (0,1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_name` varchar(100) NOT NULL,
  `entity_id` varchar(100) DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_audit_company_date` (`company_id`,`created_at`),
  KEY `idx_audit_entity` (`entity_name`,`entity_id`,`created_at`),
  KEY `fk_audit_user` (`company_id`,`user_id`),
  CONSTRAINT `fk_audit_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`company_id`, `user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `audit_logs_chk_1` CHECK (json_valid(`old_values`)),
  CONSTRAINT `audit_logs_chk_2` CHECK (json_valid(`new_values`))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `auth_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `user_device_id` bigint unsigned DEFAULT NULL,
  `refresh_token_hash` char(64) NOT NULL,
  `issued_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `last_used_at` datetime(3) DEFAULT NULL,
  `expires_at` datetime(3) NOT NULL,
  `revoked_at` datetime(3) DEFAULT NULL,
  `revoke_reason` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_auth_sessions_refresh_hash` (`refresh_token_hash`),
  KEY `idx_auth_sessions_user_expiry` (`company_id`,`user_id`,`expires_at`),
  KEY `idx_auth_sessions_device` (`company_id`,`user_device_id`),
  KEY `fk_auth_sessions_device` (`company_id`,`user_id`,`user_device_id`),
  CONSTRAINT `fk_auth_sessions_device` FOREIGN KEY (`company_id`, `user_id`, `user_device_id`) REFERENCES `user_devices` (`company_id`, `user_id`, `id`),
  CONSTRAINT `fk_auth_sessions_user` FOREIGN KEY (`company_id`, `user_id`) REFERENCES `users` (`company_id`, `id`) ON DELETE CASCADE,
  CONSTRAINT `chk_auth_sessions_dates` CHECK (((`expires_at` > `issued_at`) and ((`revoked_at` is null) or (`revoked_at` >= `issued_at`)))),
  CONSTRAINT `chk_auth_sessions_revoke_reason` CHECK (((`revoked_at` is null) or (`revoke_reason` is not null)))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `cargo_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cargo_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(140) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default_unit` enum('KG','TON','UNIT','BOX','BAG','PALLET','OTHER') NOT NULL DEFAULT 'KG',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_products_company_name` (`company_id`,`name`),
  UNIQUE KEY `uq_products_company_id` (`company_id`,`id`),
  UNIQUE KEY `uq_products_company_code` (`company_id`,`code`),
  CONSTRAINT `fk_products_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `chk_products_active` CHECK ((`active` in (0,1)))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `legal_name` varchar(180) NOT NULL,
  `trade_name` varchar(140) NOT NULL,
  `document_number` varchar(20) DEFAULT NULL,
  `slug` varchar(80) NOT NULL,
  `email` varchar(160) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `timezone_name` varchar(60) NOT NULL DEFAULT 'America/Sao_Paulo',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_companies_slug` (`slug`),
  UNIQUE KEY `uq_companies_document` (`document_number`),
  CONSTRAINT `chk_companies_active` CHECK ((`active` in (0,1)))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `company_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `legal_name` varchar(180) NOT NULL,
  `document_number` varchar(20) NOT NULL,
  `responsible_name` varchar(140) NOT NULL,
  `email` varchar(160) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `privacy_accepted` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_company_requests_status_date` (`status`,`created_at`),
  KEY `idx_company_requests_document` (`document_number`),
  CONSTRAINT `chk_company_requests_privacy` CHECK ((`privacy_accepted` in (0,1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `company_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_settings` (
  `company_id` bigint unsigned NOT NULL,
  `tolerance_percent` decimal(8,3) NOT NULL DEFAULT '1.500',
  `critical_limit_percent` decimal(8,3) NOT NULL DEFAULT '3.000',
  `tare_tolerance_percent` decimal(8,3) NOT NULL DEFAULT '5.000',
  `reading_stability_tolerance_kg` decimal(10,3) NOT NULL DEFAULT '2.000',
  `minimum_stable_readings` tinyint unsigned NOT NULL DEFAULT '3',
  `max_reading_age_seconds` int unsigned NOT NULL DEFAULT '120',
  `allow_manual_readings` tinyint(1) NOT NULL DEFAULT '1',
  `require_manual_reason` tinyint(1) NOT NULL DEFAULT '1',
  `require_rfid` tinyint(1) NOT NULL DEFAULT '0',
  `automatic_sheet_refresh` tinyint(1) NOT NULL DEFAULT '1',
  `critical_alert_notifications` tinyint(1) NOT NULL DEFAULT '1',
  `automatic_email_reports` tinyint(1) NOT NULL DEFAULT '0',
  `tracking_alerts_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `stop_speed_threshold_kmh` decimal(8,2) NOT NULL DEFAULT '1.00',
  `unplanned_stop_alert_minutes` smallint unsigned NOT NULL DEFAULT '15',
  `delivery_delay_alert_minutes` smallint unsigned NOT NULL DEFAULT '15',
  `signal_loss_alert_minutes` smallint unsigned NOT NULL DEFAULT '10',
  `route_deviation_alerts_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `route_deviation_tolerance_meters` int unsigned NOT NULL DEFAULT '500',
  `default_weight_unit` enum('KG','TON') NOT NULL DEFAULT 'KG',
  `updated_by_user_id` bigint unsigned DEFAULT NULL,
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`company_id`),
  KEY `fk_settings_user` (`company_id`,`updated_by_user_id`),
  CONSTRAINT `fk_settings_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_settings_user` FOREIGN KEY (`company_id`, `updated_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `chk_settings_flags` CHECK (((`allow_manual_readings` in (0,1)) and (`require_manual_reason` in (0,1)) and (`require_rfid` in (0,1)) and (`automatic_sheet_refresh` in (0,1)) and (`critical_alert_notifications` in (0,1)) and (`automatic_email_reports` in (0,1)))),
  CONSTRAINT `chk_settings_limits` CHECK (((`tolerance_percent` >= 0) and (`critical_limit_percent` >= `tolerance_percent`) and (`tare_tolerance_percent` >= 0) and (`reading_stability_tolerance_kg` >= 0) and (`minimum_stable_readings` > 0) and (`max_reading_age_seconds` > 0))),
  CONSTRAINT `chk_settings_tracking_v3` CHECK (((`tracking_alerts_enabled` in (0,1)) and (`route_deviation_alerts_enabled` in (0,1)) and (`stop_speed_threshold_kmh` >= 0) and (`unplanned_stop_alert_minutes` > 0) and (`delivery_delay_alert_minutes` > 0) and (`signal_loss_alert_minutes` > 0) and (`route_deviation_tolerance_meters` > 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `company_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `plan_id` bigint unsigned NOT NULL,
  `status` enum('TRIAL','ACTIVE','PAST_DUE','CANCELLED','EXPIRED') NOT NULL DEFAULT 'TRIAL',
  `starts_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `current_period_start` datetime(3) DEFAULT NULL,
  `current_period_end` datetime(3) DEFAULT NULL,
  `cancelled_at` datetime(3) DEFAULT NULL,
  `cancellation_reason` varchar(500) DEFAULT NULL,
  `limite_usuarios` int unsigned DEFAULT NULL COMMENT 'Número de usuários definido pela consultoria; NULL usa o padrão do plano',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `current_marker` tinyint GENERATED ALWAYS AS (if((`status` in (_utf8mb4'TRIAL',_utf8mb4'ACTIVE',_utf8mb4'PAST_DUE')),1,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_company_subscription_current` (`company_id`,`current_marker`),
  KEY `idx_company_subscriptions_history` (`company_id`,`starts_at`),
  KEY `fk_company_subscriptions_plan` (`plan_id`),
  CONSTRAINT `fk_company_subscriptions_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_company_subscriptions_plan` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`),
  CONSTRAINT `chk_company_subscriptions_period` CHECK (((`current_period_start` is null) or (`current_period_end` is null) or (`current_period_end` >= `current_period_start`)))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `device_calibrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_calibrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `device_id` bigint unsigned NOT NULL,
  `calibration_factor` decimal(20,8) NOT NULL,
  `reference_weight_kg` decimal(14,3) NOT NULL,
  `accuracy_class` varchar(20) DEFAULT NULL,
  `certificate_number` varchar(100) DEFAULT NULL,
  `result` enum('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  `performed_by_user_id` bigint unsigned DEFAULT NULL,
  `performed_at` datetime(3) NOT NULL,
  `expires_at` datetime(3) DEFAULT NULL,
  `notes` text,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_calibrations_company_id` (`company_id`,`id`),
  KEY `idx_calibrations_device_date` (`company_id`,`device_id`,`performed_at`),
  KEY `fk_calibrations_user` (`company_id`,`performed_by_user_id`),
  CONSTRAINT `fk_calibrations_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_calibrations_device` FOREIGN KEY (`company_id`, `device_id`) REFERENCES `devices` (`company_id`, `id`),
  CONSTRAINT `fk_calibrations_user` FOREIGN KEY (`company_id`, `performed_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `chk_calibration_values` CHECK (((`calibration_factor` > 0) and (`reference_weight_kg` > 0) and ((`expires_at` is null) or (`expires_at` >= `performed_at`))))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `operational_unit_id` bigint unsigned DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `device_type` enum('ESP32','RFID_READER','SCALE_CONTROLLER','LOAD_CELL','GPRS_MODEM','OTHER') NOT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `mac_address` varchar(30) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `firmware_version` varchar(50) DEFAULT NULL,
  `api_key_hash` varchar(255) DEFAULT NULL,
  `state` enum('ONLINE','OFFLINE','MAINTENANCE','DISABLED') NOT NULL DEFAULT 'OFFLINE',
  `last_seen_at` datetime(3) DEFAULT NULL,
  `last_calibrated_at` datetime(3) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_devices_company_id` (`company_id`,`id`),
  UNIQUE KEY `uq_devices_company_serial` (`company_id`,`serial_number`),
  UNIQUE KEY `uq_devices_company_mac` (`company_id`,`mac_address`),
  KEY `idx_devices_unit_state` (`company_id`,`operational_unit_id`,`state`),
  CONSTRAINT `fk_devices_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_devices_unit` FOREIGN KEY (`company_id`, `operational_unit_id`) REFERENCES `operational_units` (`company_id`, `id`),
  CONSTRAINT `chk_devices_active` CHECK ((`active` in (0,1))),
  CONSTRAINT `devices_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drivers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `full_name` varchar(140) NOT NULL,
  `document_number` varchar(255) DEFAULT NULL COMMENT 'CPF cifrado (AES-256-GCM, ver dados-pessoais.js)',
  `document_hash` char(64) DEFAULT NULL COMMENT 'HMAC do CPF, para checar duplicidade',
  `employee_code` varchar(40) DEFAULT NULL,
  `license_number` varchar(255) DEFAULT NULL COMMENT 'CNH cifrada',
  `license_category` varchar(10) DEFAULT NULL,
  `license_expiration_date` date DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL COMMENT 'telefone cifrado',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_drivers_company_id` (`company_id`,`id`),
  UNIQUE KEY `uq_drivers_company_employee` (`company_id`,`employee_code`),
  UNIQUE KEY `uq_drivers_company_document` (`company_id`,`document_hash`),
  CONSTRAINT `fk_drivers_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `chk_drivers_active` CHECK ((`active` in (0,1)))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `generated_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `generated_reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `report_type` enum('DAILY','WEEKLY','MONTHLY','BIMONTHLY','QUARTERLY','CUSTOM') NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `generated_by_user_id` bigint unsigned NOT NULL,
  `file_format` enum('PDF','CSV','XLSX','JSON') DEFAULT NULL,
  `file_location` text,
  `filters_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `summary_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `recommendations` text,
  `generated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reports_company_id` (`company_id`,`id`),
  KEY `idx_reports_company_period` (`company_id`,`period_start`,`period_end`),
  KEY `fk_reports_user` (`company_id`,`generated_by_user_id`),
  KEY `idx_reports_company_generated_period` (`company_id`,`generated_at`),
  CONSTRAINT `fk_reports_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_reports_user` FOREIGN KEY (`company_id`, `generated_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `chk_reports_period` CHECK ((`period_end` >= `period_start`)),
  CONSTRAINT `generated_reports_chk_1` CHECK (json_valid(`filters_json`)),
  CONSTRAINT `generated_reports_chk_2` CHECK (json_valid(`summary_json`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `legal_acceptances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legal_acceptances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `legal_document_id` bigint unsigned NOT NULL,
  `user_device_id` bigint unsigned DEFAULT NULL,
  `accepted_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `app_version_name` varchar(30) DEFAULT NULL,
  `app_build_number` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_legal_acceptance_user_document` (`company_id`,`user_id`,`legal_document_id`),
  KEY `idx_legal_acceptances_user_date` (`company_id`,`user_id`,`accepted_at`),
  KEY `fk_legal_acceptances_document` (`company_id`,`legal_document_id`),
  KEY `fk_legal_acceptances_device` (`company_id`,`user_id`,`user_device_id`),
  CONSTRAINT `fk_legal_acceptances_device` FOREIGN KEY (`company_id`, `user_id`, `user_device_id`) REFERENCES `user_devices` (`company_id`, `user_id`, `id`),
  CONSTRAINT `fk_legal_acceptances_document` FOREIGN KEY (`company_id`, `legal_document_id`) REFERENCES `legal_documents` (`company_id`, `id`),
  CONSTRAINT `fk_legal_acceptances_user` FOREIGN KEY (`company_id`, `user_id`) REFERENCES `users` (`company_id`, `id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `legal_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legal_documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `document_type` enum('TERMS_OF_USE','PRIVACY_POLICY') NOT NULL,
  `version` varchar(30) NOT NULL,
  `title` varchar(180) NOT NULL,
  `content_format` enum('MARKDOWN','HTML','PLAIN_TEXT') NOT NULL DEFAULT 'MARKDOWN',
  `content` mediumtext NOT NULL,
  `content_hash` char(64) NOT NULL,
  `mandatory` tinyint(1) NOT NULL DEFAULT '1',
  `requires_reacceptance` tinyint(1) NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `published_at` datetime(3) DEFAULT NULL,
  `effective_at` datetime(3) DEFAULT NULL,
  `created_by_user_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_legal_documents_version` (`company_id`,`document_type`,`version`),
  UNIQUE KEY `uq_legal_documents_company_id` (`company_id`,`id`),
  KEY `idx_legal_documents_active` (`company_id`,`document_type`,`active`,`effective_at`),
  KEY `fk_legal_documents_created_user` (`company_id`,`created_by_user_id`),
  CONSTRAINT `fk_legal_documents_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_legal_documents_created_user` FOREIGN KEY (`company_id`, `created_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `chk_legal_documents_dates` CHECK (((`effective_at` is null) or (`published_at` is null) or (`effective_at` >= `published_at`))),
  CONSTRAINT `chk_legal_documents_flags` CHECK (((`mandatory` in (0,1)) and (`requires_reacceptance` in (0,1)) and (`active` in (0,1))))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `operation_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_attachments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `operation_id` bigint unsigned NOT NULL,
  `attachment_type` enum('WEIGHING_TICKET','PHOTO','DOCUMENT','OTHER') NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `stored_name` varchar(255) NOT NULL,
  `mime_type` varchar(120) DEFAULT NULL,
  `size_bytes` bigint unsigned DEFAULT NULL,
  `file_location` text NOT NULL,
  `checksum_sha256` char(64) DEFAULT NULL,
  `uploaded_by_user_id` bigint unsigned NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_attachments_operation` (`company_id`,`operation_id`,`created_at`),
  KEY `fk_attachments_user` (`company_id`,`uploaded_by_user_id`),
  CONSTRAINT `fk_attachments_operation` FOREIGN KEY (`company_id`, `operation_id`) REFERENCES `weighing_operations` (`company_id`, `id`) ON DELETE CASCADE,
  CONSTRAINT `fk_attachments_user` FOREIGN KEY (`company_id`, `uploaded_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `chk_attachments_size` CHECK (((`size_bytes` is null) or (`size_bytes` >= 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `operation_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `operation_id` bigint unsigned NOT NULL,
  `event_type` enum('CREATED','READING_RECEIVED','READING_ACCEPTED','FINALIZED','CANCELLED','REOPENED','STATUS_CHANGED','NOTE_ADDED','TRANSPORT_SCHEDULED','TRACKING_STARTED','TRACKING_STOPPED','TRACKING_RESUMED','TRACKING_ARRIVED','TRACKING_SIGNAL_LOST','TRACKING_CANCELLED','DELIVERY_DELAY','ROUTE_DEVIATION') NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `device_id` bigint unsigned DEFAULT NULL,
  `event_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_operation_events_timeline` (`company_id`,`operation_id`,`created_at`),
  KEY `fk_operation_events_user` (`company_id`,`user_id`),
  KEY `fk_operation_events_device` (`company_id`,`device_id`),
  KEY `idx_events_company_created_period` (`company_id`,`created_at`),
  CONSTRAINT `fk_operation_events_device` FOREIGN KEY (`company_id`, `device_id`) REFERENCES `devices` (`company_id`, `id`),
  CONSTRAINT `fk_operation_events_operation` FOREIGN KEY (`company_id`, `operation_id`) REFERENCES `weighing_operations` (`company_id`, `id`) ON DELETE CASCADE,
  CONSTRAINT `fk_operation_events_user` FOREIGN KEY (`company_id`, `user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `operation_events_chk_1` CHECK (json_valid(`event_data`))
) ENGINE=InnoDB AUTO_INCREMENT=7062 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `operation_tracking_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_tracking_points` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `operation_id` bigint unsigned NOT NULL,
  `device_id` bigint unsigned DEFAULT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `speed_kmh` decimal(8,2) DEFAULT NULL,
  `heading_degrees` decimal(6,2) DEFAULT NULL,
  `accuracy_meters` decimal(8,2) DEFAULT NULL,
  `progress_percent` decimal(6,3) DEFAULT NULL,
  `route_deviation_meters` decimal(10,2) DEFAULT NULL,
  `estimated_arrival_at` datetime(3) DEFAULT NULL,
  `signal_strength_dbm` smallint DEFAULT NULL,
  `raw_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `recorded_at` datetime(3) NOT NULL,
  `received_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tracking_points_company_id` (`company_id`,`id`),
  KEY `idx_tracking_points_operation_time` (`company_id`,`operation_id`,`recorded_at`),
  KEY `idx_tracking_points_device_time` (`company_id`,`device_id`,`recorded_at`),
  KEY `idx_tracking_points_company_recorded_period` (`company_id`,`recorded_at`),
  CONSTRAINT `fk_tracking_points_device` FOREIGN KEY (`company_id`, `device_id`) REFERENCES `devices` (`company_id`, `id`),
  CONSTRAINT `fk_tracking_points_operation` FOREIGN KEY (`company_id`, `operation_id`) REFERENCES `weighing_operations` (`company_id`, `id`) ON DELETE CASCADE,
  CONSTRAINT `chk_tracking_points_coordinates` CHECK (((`latitude` between -(90) and 90) and (`longitude` between -(180) and 180))),
  CONSTRAINT `chk_tracking_points_route_deviation_v3` CHECK (((`route_deviation_meters` is null) or (`route_deviation_meters` >= 0))),
  CONSTRAINT `chk_tracking_points_values` CHECK ((((`speed_kmh` is null) or (`speed_kmh` >= 0)) and ((`heading_degrees` is null) or (`heading_degrees` between 0 and 360)) and ((`accuracy_meters` is null) or (`accuracy_meters` >= 0)) and ((`progress_percent` is null) or (`progress_percent` between 0 and 100)))),
  CONSTRAINT `operation_tracking_points_chk_1` CHECK (json_valid(`raw_payload`))
) ENGINE=InnoDB AUTO_INCREMENT=841 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `operation_tracking_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_tracking_status` (
  `company_id` bigint unsigned NOT NULL,
  `operation_id` bigint unsigned NOT NULL,
  `tracking_state` enum('NOT_STARTED','IN_TRANSIT','STOPPED','ARRIVED','SIGNAL_LOST','CANCELLED') NOT NULL DEFAULT 'NOT_STARTED',
  `stopped_since` datetime(3) DEFAULT NULL,
  `last_moving_at` datetime(3) DEFAULT NULL,
  `current_latitude` decimal(10,7) DEFAULT NULL,
  `current_longitude` decimal(10,7) DEFAULT NULL,
  `speed_kmh` decimal(8,2) DEFAULT NULL,
  `heading_degrees` decimal(6,2) DEFAULT NULL,
  `progress_percent` decimal(6,3) DEFAULT NULL,
  `route_deviation_meters` decimal(10,2) DEFAULT NULL,
  `estimated_arrival_at` datetime(3) DEFAULT NULL,
  `delay_minutes` int unsigned DEFAULT NULL,
  `last_position_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`company_id`,`operation_id`),
  KEY `idx_tracking_status_state` (`company_id`,`tracking_state`,`last_position_at`),
  CONSTRAINT `fk_tracking_status_operation` FOREIGN KEY (`company_id`, `operation_id`) REFERENCES `weighing_operations` (`company_id`, `id`) ON DELETE CASCADE,
  CONSTRAINT `chk_tracking_status_coordinates` CHECK ((((`current_latitude` is null) or (`current_latitude` between -(90) and 90)) and ((`current_longitude` is null) or (`current_longitude` between -(180) and 180)))),
  CONSTRAINT `chk_tracking_status_route_deviation_v3` CHECK (((`route_deviation_meters` is null) or (`route_deviation_meters` >= 0))),
  CONSTRAINT `chk_tracking_status_values` CHECK ((((`speed_kmh` is null) or (`speed_kmh` >= 0)) and ((`heading_degrees` is null) or (`heading_degrees` between 0 and 360)) and ((`progress_percent` is null) or (`progress_percent` between 0 and 100))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `operational_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operational_units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(40) NOT NULL,
  `name` varchar(140) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `address_line` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state_code` char(2) DEFAULT NULL,
  `postal_code` varchar(12) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_units_company_code` (`company_id`,`code`),
  UNIQUE KEY `uq_units_company_id` (`company_id`,`id`),
  CONSTRAINT `fk_units_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `chk_units_active` CHECK ((`active` in (0,1))),
  CONSTRAINT `chk_units_coordinates` CHECK ((((`latitude` is null) and (`longitude` is null)) or ((`latitude` is not null) and (`longitude` is not null) and (`latitude` between -(90) and 90) and (`longitude` between -(180) and 180))))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `used_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_password_reset_token_hash` (`token_hash`),
  KEY `idx_password_reset_user_expiry` (`company_id`,`user_id`,`expires_at`),
  CONSTRAINT `fk_password_reset_user` FOREIGN KEY (`company_id`, `user_id`) REFERENCES `users` (`company_id`, `id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `two_factor_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `purpose` enum('LOGIN','ENABLE','DISABLE') NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `used_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_two_factor_hash` (`token_hash`),
  KEY `idx_two_factor_user` (`company_id`,`user_id`,`purpose`,`expires_at`),
  CONSTRAINT `fk_two_factor_user` FOREIGN KEY (`company_id`, `user_id`) REFERENCES `users` (`company_id`, `id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_permissions_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `rfid_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rfid_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(100) NOT NULL,
  `vehicle_id` bigint unsigned DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `activated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `deactivated_at` datetime(3) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `active_vehicle_marker` bigint unsigned GENERATED ALWAYS AS (if((`active` = 1),`vehicle_id`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rfid_company_code` (`company_id`,`code`),
  UNIQUE KEY `uq_rfid_company_id` (`company_id`,`id`),
  UNIQUE KEY `uq_rfid_active_vehicle` (`company_id`,`active_vehicle_marker`),
  KEY `idx_rfid_vehicle` (`company_id`,`vehicle_id`),
  CONSTRAINT `fk_rfid_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_rfid_vehicle` FOREIGN KEY (`company_id`, `vehicle_id`) REFERENCES `vehicles` (`company_id`, `id`),
  CONSTRAINT `chk_rfid_active` CHECK ((`active` in (0,1))),
  CONSTRAINT `chk_rfid_dates` CHECK (((`deactivated_at` is null) or (`deactivated_at` >= `activated_at`)))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `role_id` bigint unsigned NOT NULL,
  `permission_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `fk_role_permissions_permission` (`permission_id`),
  CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `name` varchar(60) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_system_role` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_company_name` (`company_id`,`name`),
  UNIQUE KEY `uq_roles_company_id` (`company_id`,`id`),
  CONSTRAINT `fk_roles_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chk_roles_flags` CHECK (((`is_system_role` in (0,1)) and (`active` in (0,1))))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `route_waypoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route_waypoints` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `route_id` bigint unsigned NOT NULL,
  `sequence_number` smallint unsigned NOT NULL,
  `waypoint_type` enum('ORIGIN','WAYPOINT','DESTINATION') NOT NULL,
  `label` varchar(160) DEFAULT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_route_waypoints_sequence` (`company_id`,`route_id`,`sequence_number`),
  UNIQUE KEY `uq_route_waypoints_company_id` (`company_id`,`id`),
  KEY `idx_route_waypoints_route` (`company_id`,`route_id`,`sequence_number`),
  CONSTRAINT `fk_route_waypoints_route` FOREIGN KEY (`company_id`, `route_id`) REFERENCES `routes` (`company_id`, `id`) ON DELETE CASCADE,
  CONSTRAINT `chk_route_waypoints_coordinates` CHECK (((`latitude` between -(90) and 90) and (`longitude` between -(180) and 180)))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `origin` varchar(160) NOT NULL,
  `destination` varchar(160) NOT NULL,
  `distance_km` decimal(10,2) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_routes_company_path` (`company_id`,`origin`,`destination`),
  UNIQUE KEY `uq_routes_company_id` (`company_id`,`id`),
  UNIQUE KEY `uq_routes_company_code` (`company_id`,`code`),
  CONSTRAINT `fk_routes_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `chk_routes_active` CHECK ((`active` in (0,1))),
  CONSTRAINT `chk_routes_distance` CHECK (((`distance_km` is null) or (`distance_km` >= 0)))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_migrations` (
  `version` int unsigned NOT NULL,
  `name` varchar(160) NOT NULL,
  `applied_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `subscription_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `monthly_price_brl` decimal(10,2) DEFAULT NULL,
  `features_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_subscription_plans_code` (`code`),
  CONSTRAINT `chk_subscription_plans_active` CHECK ((`active` in (0,1))),
  CONSTRAINT `chk_subscription_plans_price` CHECK (((`monthly_price_brl` is null) or (`monthly_price_brl` >= 0))),
  CONSTRAINT `subscription_plans_chk_1` CHECK (json_valid(`features_json`))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `user_app_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_app_preferences` (
  `company_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `theme` enum('SYSTEM','DARK','LIGHT') NOT NULL DEFAULT 'DARK',
  `language_code` varchar(10) NOT NULL DEFAULT 'pt-BR',
  `push_notifications_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `sound_alerts_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `automatic_sync_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dashboard_alert_limit` tinyint unsigned NOT NULL DEFAULT '3',
  `alerts_page_size` smallint unsigned NOT NULL DEFAULT '20',
  `default_period_days` smallint unsigned NOT NULL DEFAULT '30',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`company_id`,`user_id`),
  CONSTRAINT `fk_app_preferences_user` FOREIGN KEY (`company_id`, `user_id`) REFERENCES `users` (`company_id`, `id`) ON DELETE CASCADE,
  CONSTRAINT `chk_app_preferences_flags` CHECK (((`push_notifications_enabled` in (0,1)) and (`sound_alerts_enabled` in (0,1)) and (`automatic_sync_enabled` in (0,1)))),
  CONSTRAINT `chk_app_preferences_limits` CHECK (((`dashboard_alert_limit` between 1 and 10) and (`alerts_page_size` between 5 and 100) and (`default_period_days` between 1 and 366)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `user_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_devices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `device_uuid` varchar(160) NOT NULL,
  `platform` enum('ANDROID','IOS','WEB') NOT NULL,
  `device_name` varchar(160) DEFAULT NULL,
  `app_version_name` varchar(30) DEFAULT NULL,
  `app_build_number` int unsigned DEFAULT NULL,
  `os_version` varchar(60) DEFAULT NULL,
  `push_token` varchar(512) DEFAULT NULL,
  `biometric_login_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `notifications_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `last_seen_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_devices_user_uuid` (`company_id`,`user_id`,`device_uuid`),
  UNIQUE KEY `uq_user_devices_company_id` (`company_id`,`id`),
  UNIQUE KEY `uq_user_devices_company_user_id` (`company_id`,`user_id`,`id`),
  KEY `idx_user_devices_user_active` (`company_id`,`user_id`,`active`),
  KEY `idx_user_devices_push_token` (`push_token`(191)),
  CONSTRAINT `fk_user_devices_user` FOREIGN KEY (`company_id`, `user_id`) REFERENCES `users` (`company_id`, `id`) ON DELETE CASCADE,
  CONSTRAINT `chk_user_devices_flags` CHECK (((`biometric_login_enabled` in (0,1)) and (`notifications_enabled` in (0,1)) and (`active` in (0,1))))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `full_name` varchar(140) NOT NULL,
  `email` varchar(160) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `must_change_password` tinyint(1) NOT NULL DEFAULT '0',
  `receive_critical_alerts` tinyint(1) NOT NULL DEFAULT '1',
  `receive_automatic_reports` tinyint(1) NOT NULL DEFAULT '0',
  `failed_login_attempts` smallint unsigned NOT NULL DEFAULT '0',
  `failed_2fa_attempts` int unsigned NOT NULL DEFAULT '0',
  `locked_until` datetime(3) DEFAULT NULL,
  `locked_until_2fa` datetime(3) DEFAULT NULL,
  `last_login_at` datetime(3) DEFAULT NULL,
  `totp_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `totp_secret_enc` varchar(255) DEFAULT NULL,
  `totp_last_step` bigint unsigned DEFAULT NULL,
  `totp_enabled_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_company_email` (`company_id`,`email`),
  UNIQUE KEY `uq_users_company_id` (`company_id`,`id`),
  KEY `idx_users_role` (`company_id`,`role_id`),
  CONSTRAINT `fk_users_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`company_id`, `role_id`) REFERENCES `roles` (`company_id`, `id`),
  CONSTRAINT `chk_users_flags` CHECK (((`active` in (0,1)) and (`must_change_password` in (0,1)) and (`receive_critical_alerts` in (0,1)) and (`receive_automatic_reports` in (0,1))))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `plate` varchar(10) NOT NULL,
  `fleet_code` varchar(40) DEFAULT NULL,
  `vehicle_type` enum('TRUCK','TRACTOR','SEMI_TRAILER','TRAILER','OTHER') NOT NULL DEFAULT 'TRUCK',
  `manufacturer` varchar(80) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `manufacture_year` smallint unsigned DEFAULT NULL,
  `axle_count` tinyint unsigned DEFAULT NULL,
  `registered_tare_kg` decimal(14,3) DEFAULT NULL,
  `gross_weight_limit_kg` decimal(14,3) DEFAULT NULL,
  `payload_limit_kg` decimal(14,3) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vehicles_company_plate` (`company_id`,`plate`),
  UNIQUE KEY `uq_vehicles_company_id` (`company_id`,`id`),
  UNIQUE KEY `uq_vehicles_company_fleet` (`company_id`,`fleet_code`),
  CONSTRAINT `fk_vehicles_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `chk_vehicles_active` CHECK ((`active` in (0,1))),
  CONSTRAINT `chk_vehicles_weights` CHECK ((((`registered_tare_kg` is null) or (`registered_tare_kg` >= 0)) and ((`gross_weight_limit_kg` is null) or (`gross_weight_limit_kg` >= 0)) and ((`payload_limit_kg` is null) or (`payload_limit_kg` >= 0)) and ((`registered_tare_kg` is null) or (`gross_weight_limit_kg` is null) or (`gross_weight_limit_kg` >= `registered_tare_kg`))))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `vw_active_operation_tracking`;
/*!50001 DROP VIEW IF EXISTS `vw_active_operation_tracking`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_active_operation_tracking` AS SELECT 
 1 AS `company_id`,
 1 AS `operation_id`,
 1 AS `operation_code`,
 1 AS `weighing_state`,
 1 AS `weighing_status`,
 1 AS `planned_departure_at`,
 1 AS `departed_at`,
 1 AS `planned_arrival_at`,
 1 AS `arrived_at`,
 1 AS `vehicle_plate`,
 1 AS `driver_name`,
 1 AS `origin`,
 1 AS `destination`,
 1 AS `distance_km`,
 1 AS `tracking_state`,
 1 AS `stopped_since`,
 1 AS `last_moving_at`,
 1 AS `current_latitude`,
 1 AS `current_longitude`,
 1 AS `speed_kmh`,
 1 AS `heading_degrees`,
 1 AS `progress_percent`,
 1 AS `route_deviation_meters`,
 1 AS `estimated_arrival_at`,
 1 AS `delay_minutes`,
 1 AS `last_position_at`*/;
SET character_set_client = @saved_cs_client;


DROP TABLE IF EXISTS `vw_company_current_subscription`;
/*!50001 DROP VIEW IF EXISTS `vw_company_current_subscription`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_company_current_subscription` AS SELECT 
 1 AS `company_id`,
 1 AS `subscription_id`,
 1 AS `status`,
 1 AS `starts_at`,
 1 AS `current_period_start`,
 1 AS `current_period_end`,
 1 AS `plan_id`,
 1 AS `plan_code`,
 1 AS `plan_name`,
 1 AS `monthly_price_brl`,
 1 AS `features_json`*/;
SET character_set_client = @saved_cs_client;


DROP TABLE IF EXISTS `vw_dashboard_daily`;
/*!50001 DROP VIEW IF EXISTS `vw_dashboard_daily`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_dashboard_daily` AS SELECT 
 1 AS `company_id`,
 1 AS `reference_date`,
 1 AS `total_operations`,
 1 AS `completed_operations`,
 1 AS `normal_operations`,
 1 AS `attention_operations`,
 1 AS `critical_operations`,
 1 AS `total_cargo_weight_kg`,
 1 AS `average_absolute_difference_percent`*/;
SET character_set_client = @saved_cs_client;


DROP TABLE IF EXISTS `vw_latest_device_calibration`;
/*!50001 DROP VIEW IF EXISTS `vw_latest_device_calibration`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_latest_device_calibration` AS SELECT 
 1 AS `id`,
 1 AS `company_id`,
 1 AS `device_id`,
 1 AS `calibration_factor`,
 1 AS `reference_weight_kg`,
 1 AS `accuracy_class`,
 1 AS `certificate_number`,
 1 AS `result`,
 1 AS `performed_by_user_id`,
 1 AS `performed_at`,
 1 AS `expires_at`,
 1 AS `notes`,
 1 AS `created_at`*/;
SET character_set_client = @saved_cs_client;


DROP TABLE IF EXISTS `vw_mobile_active_operations`;
/*!50001 DROP VIEW IF EXISTS `vw_mobile_active_operations`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_mobile_active_operations` AS SELECT 
 1 AS `company_id`,
 1 AS `operation_id`,
 1 AS `operation_code`,
 1 AS `weighing_state`,
 1 AS `weighing_status`,
 1 AS `started_at`,
 1 AS `completed_at`,
 1 AS `planned_departure_at`,
 1 AS `departed_at`,
 1 AS `planned_arrival_at`,
 1 AS `arrived_at`,
 1 AS `vehicle_plate`,
 1 AS `driver_name`,
 1 AS `cargo_product_name`,
 1 AS `origin`,
 1 AS `destination`,
 1 AS `tracking_state`,
 1 AS `progress_percent`,
 1 AS `estimated_arrival_at`,
 1 AS `delay_minutes`,
 1 AS `last_position_at`*/;
SET character_set_client = @saved_cs_client;


DROP TABLE IF EXISTS `vw_mobile_completed_operations`;
/*!50001 DROP VIEW IF EXISTS `vw_mobile_completed_operations`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_mobile_completed_operations` AS SELECT 
 1 AS `company_id`,
 1 AS `operation_id`,
 1 AS `operation_code`,
 1 AS `weighing_status`,
 1 AS `completed_at`,
 1 AS `departed_at`,
 1 AS `arrived_at`,
 1 AS `vehicle_plate`,
 1 AS `driver_name`,
 1 AS `cargo_product_name`,
 1 AS `origin`,
 1 AS `destination`,
 1 AS `tracking_state`*/;
SET character_set_client = @saved_cs_client;


DROP TABLE IF EXISTS `vw_open_alerts`;
/*!50001 DROP VIEW IF EXISTS `vw_open_alerts`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_open_alerts` AS SELECT 
 1 AS `id`,
 1 AS `company_id`,
 1 AS `operation_id`,
 1 AS `operation_code`,
 1 AS `vehicle_id`,
 1 AS `alert_context`,
 1 AS `alert_type`,
 1 AS `severity`,
 1 AS `state`,
 1 AS `title`,
 1 AS `message`,
 1 AS `difference_kg`,
 1 AS `difference_percent`,
 1 AS `detected_at`,
 1 AS `vehicle_plate`*/;
SET character_set_client = @saved_cs_client;


DROP TABLE IF EXISTS `vw_pending_legal_documents`;
/*!50001 DROP VIEW IF EXISTS `vw_pending_legal_documents`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_pending_legal_documents` AS SELECT 
 1 AS `company_id`,
 1 AS `user_id`,
 1 AS `legal_document_id`,
 1 AS `document_type`,
 1 AS `version`,
 1 AS `title`,
 1 AS `content_format`,
 1 AS `content`,
 1 AS `content_hash`,
 1 AS `effective_at`*/;
SET character_set_client = @saved_cs_client;


DROP TABLE IF EXISTS `vw_weighing_operation_details`;
/*!50001 DROP VIEW IF EXISTS `vw_weighing_operation_details`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_weighing_operation_details` AS SELECT 
 1 AS `id`,
 1 AS `company_id`,
 1 AS `company_name`,
 1 AS `operation_code`,
 1 AS `movement_type`,
 1 AS `weighing_method`,
 1 AS `state`,
 1 AS `status`,
 1 AS `status_reason`,
 1 AS `started_at`,
 1 AS `completed_at`,
 1 AS `operational_unit_name`,
 1 AS `weighing_station_name`,
 1 AS `vehicle_plate`,
 1 AS `fleet_code`,
 1 AS `driver_name`,
 1 AS `rfid_code`,
 1 AS `cargo_product_name`,
 1 AS `origin`,
 1 AS `destination`,
 1 AS `responsible_user_name`,
 1 AS `created_by_user_name`,
 1 AS `empty_truck_weight_kg`,
 1 AS `separated_cargo_weight_kg`,
 1 AS `expected_gross_weight_kg`,
 1 AS `loaded_truck_weight_kg`,
 1 AS `actual_cargo_weight_kg`,
 1 AS `difference_kg`,
 1 AS `difference_percent`,
 1 AS `tare_difference_percent`,
 1 AS `gross_limit_snapshot_kg`,
 1 AS `payload_limit_snapshot_kg`,
 1 AS `observations`*/;
SET character_set_client = @saved_cs_client;


DROP TABLE IF EXISTS `weighing_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weighing_operations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `operational_unit_id` bigint unsigned NOT NULL,
  `weighing_station_id` bigint unsigned DEFAULT NULL,
  `operation_code` varchar(40) NOT NULL,
  `movement_type` enum('ENTRY','EXIT','TRANSFER','WEIGHING_ONLY') NOT NULL DEFAULT 'WEIGHING_ONLY',
  `weighing_method` enum('THREE_STAGE','GROSS_TARE') NOT NULL DEFAULT 'THREE_STAGE',
  `state` enum('DRAFT','IN_PROGRESS','COMPLETED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  `status` enum('ANALYSIS','NORMAL','ATTENTION','CRITICAL') NOT NULL DEFAULT 'ANALYSIS',
  `vehicle_id` bigint unsigned NOT NULL,
  `driver_id` bigint unsigned DEFAULT NULL,
  `rfid_tag_id` bigint unsigned DEFAULT NULL,
  `tracking_enabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Rastreio ativado com o código RFID fornecido pela empresa parceira',
  `tracking_activated_at` datetime(3) DEFAULT NULL,
  `cargo_product_id` bigint unsigned DEFAULT NULL,
  `route_id` bigint unsigned DEFAULT NULL,
  `responsible_user_id` bigint unsigned NOT NULL,
  `created_by_user_id` bigint unsigned NOT NULL,
  `declared_quantity` decimal(14,3) DEFAULT NULL,
  `declared_quantity_unit` enum('KG','TON','UNIT','BOX','BAG','PALLET','OTHER') DEFAULT NULL,
  `declared_cargo_weight_kg` decimal(14,3) DEFAULT NULL,
  `empty_truck_weight_kg` decimal(14,3) DEFAULT NULL,
  `separated_cargo_weight_kg` decimal(14,3) DEFAULT NULL,
  `expected_gross_weight_kg` decimal(14,3) DEFAULT NULL,
  `loaded_truck_weight_kg` decimal(14,3) DEFAULT NULL,
  `actual_cargo_weight_kg` decimal(14,3) DEFAULT NULL,
  `difference_kg` decimal(14,3) DEFAULT NULL,
  `difference_percent` decimal(10,4) DEFAULT NULL,
  `tare_difference_percent` decimal(10,4) DEFAULT NULL,
  `registered_tare_snapshot_kg` decimal(14,3) DEFAULT NULL,
  `gross_limit_snapshot_kg` decimal(14,3) DEFAULT NULL,
  `payload_limit_snapshot_kg` decimal(14,3) DEFAULT NULL,
  `tolerance_percent_snapshot` decimal(8,3) NOT NULL,
  `critical_limit_snapshot` decimal(8,3) NOT NULL,
  `tare_tolerance_snapshot` decimal(8,3) NOT NULL,
  `invoice_number` varchar(80) DEFAULT NULL,
  `mdfe_number` varchar(80) DEFAULT NULL,
  `ciot_number` varchar(80) DEFAULT NULL,
  `status_reason` varchar(500) DEFAULT NULL,
  `observations` text,
  `calculation_version` int unsigned NOT NULL DEFAULT '0',
  `row_version` int unsigned NOT NULL DEFAULT '1',
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `completed_at` datetime(3) DEFAULT NULL,
  `planned_departure_at` datetime(3) DEFAULT NULL,
  `departed_at` datetime(3) DEFAULT NULL,
  `planned_arrival_at` datetime(3) DEFAULT NULL,
  `arrived_at` datetime(3) DEFAULT NULL,
  `cancelled_at` datetime(3) DEFAULT NULL,
  `cancelled_by_user_id` bigint unsigned DEFAULT NULL,
  `cancellation_reason` varchar(500) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_operations_company_code` (`company_id`,`operation_code`),
  UNIQUE KEY `uq_operations_company_id` (`company_id`,`id`),
  KEY `idx_operations_state_date` (`company_id`,`state`,`started_at`),
  KEY `idx_operations_status_date` (`company_id`,`status`,`completed_at`),
  KEY `idx_operations_vehicle_date` (`company_id`,`vehicle_id`,`started_at`),
  KEY `idx_operations_driver_date` (`company_id`,`driver_id`,`started_at`),
  KEY `idx_operations_product_date` (`company_id`,`cargo_product_id`,`started_at`),
  KEY `idx_operations_station_date` (`company_id`,`weighing_station_id`,`started_at`),
  KEY `fk_operations_station` (`company_id`,`operational_unit_id`,`weighing_station_id`),
  KEY `fk_operations_rfid` (`company_id`,`rfid_tag_id`),
  KEY `fk_operations_route` (`company_id`,`route_id`),
  KEY `fk_operations_responsible_user` (`company_id`,`responsible_user_id`),
  KEY `fk_operations_created_by_user` (`company_id`,`created_by_user_id`),
  KEY `fk_operations_cancelled_by_user` (`company_id`,`cancelled_by_user_id`),
  KEY `idx_operations_company_started_period` (`company_id`,`started_at`),
  KEY `idx_operations_company_completed_period` (`company_id`,`completed_at`),
  KEY `idx_operations_company_planned_arrival` (`company_id`,`planned_arrival_at`),
  KEY `idx_operations_company_departed` (`company_id`,`departed_at`),
  KEY `idx_operations_company_arrived` (`company_id`,`arrived_at`),
  CONSTRAINT `fk_operations_cancelled_by_user` FOREIGN KEY (`company_id`, `cancelled_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `fk_operations_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_operations_created_by_user` FOREIGN KEY (`company_id`, `created_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `fk_operations_driver` FOREIGN KEY (`company_id`, `driver_id`) REFERENCES `drivers` (`company_id`, `id`),
  CONSTRAINT `fk_operations_product` FOREIGN KEY (`company_id`, `cargo_product_id`) REFERENCES `cargo_products` (`company_id`, `id`),
  CONSTRAINT `fk_operations_responsible_user` FOREIGN KEY (`company_id`, `responsible_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `fk_operations_rfid` FOREIGN KEY (`company_id`, `rfid_tag_id`) REFERENCES `rfid_tags` (`company_id`, `id`),
  CONSTRAINT `fk_operations_route` FOREIGN KEY (`company_id`, `route_id`) REFERENCES `routes` (`company_id`, `id`),
  CONSTRAINT `fk_operations_station` FOREIGN KEY (`company_id`, `operational_unit_id`, `weighing_station_id`) REFERENCES `weighing_stations` (`company_id`, `operational_unit_id`, `id`),
  CONSTRAINT `fk_operations_unit` FOREIGN KEY (`company_id`, `operational_unit_id`) REFERENCES `operational_units` (`company_id`, `id`),
  CONSTRAINT `fk_operations_vehicle` FOREIGN KEY (`company_id`, `vehicle_id`) REFERENCES `vehicles` (`company_id`, `id`),
  CONSTRAINT `chk_operations_cancelled` CHECK (((`state` <> _utf8mb4'CANCELLED') or ((`cancelled_at` is not null) and (`cancellation_reason` is not null)))),
  CONSTRAINT `chk_operations_completed` CHECK (((`state` <> _utf8mb4'COMPLETED') or ((`empty_truck_weight_kg` is not null) and (`loaded_truck_weight_kg` is not null) and (`actual_cargo_weight_kg` is not null) and (`completed_at` is not null) and ((`weighing_method` <> _utf8mb4'THREE_STAGE') or (`separated_cargo_weight_kg` is not null))))),
  CONSTRAINT `chk_operations_nonnegative` CHECK ((((`declared_quantity` is null) or (`declared_quantity` >= 0)) and ((`declared_cargo_weight_kg` is null) or (`declared_cargo_weight_kg` >= 0)) and ((`empty_truck_weight_kg` is null) or (`empty_truck_weight_kg` >= 0)) and ((`separated_cargo_weight_kg` is null) or (`separated_cargo_weight_kg` >= 0)) and ((`expected_gross_weight_kg` is null) or (`expected_gross_weight_kg` >= 0)) and ((`loaded_truck_weight_kg` is null) or (`loaded_truck_weight_kg` >= 0)) and ((`actual_cargo_weight_kg` is null) or (`actual_cargo_weight_kg` >= 0)))),
  CONSTRAINT `chk_operations_snapshot_limits` CHECK (((`tolerance_percent_snapshot` >= 0) and (`critical_limit_snapshot` >= `tolerance_percent_snapshot`) and (`tare_tolerance_snapshot` >= 0))),
  CONSTRAINT `chk_operations_transport_actual` CHECK (((`departed_at` is null) or (`arrived_at` is null) or (`arrived_at` >= `departed_at`))),
  CONSTRAINT `chk_operations_transport_schedule` CHECK (((`planned_departure_at` is null) or (`planned_arrival_at` is null) or (`planned_arrival_at` >= `planned_departure_at`)))
) ENGINE=InnoDB AUTO_INCREMENT=1097 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `weighing_readings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weighing_readings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `operation_id` bigint unsigned NOT NULL,
  `stage` enum('EMPTY_TRUCK','SEPARATED_CARGO','LOADED_TRUCK') NOT NULL,
  `sequence_number` int unsigned NOT NULL,
  `weight_kg` decimal(14,3) NOT NULL,
  `source` enum('DEVICE','MANUAL','IMPORT') NOT NULL DEFAULT 'DEVICE',
  `device_id` bigint unsigned DEFAULT NULL,
  `is_stable` tinyint(1) NOT NULL DEFAULT '0',
  `is_accepted` tinyint(1) NOT NULL DEFAULT '0',
  `checksum_valid` tinyint(1) DEFAULT NULL,
  `signal_strength_dbm` smallint DEFAULT NULL,
  `manual_reason` varchar(500) DEFAULT NULL,
  `measured_at` datetime(3) NOT NULL,
  `received_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `accepted_at` datetime(3) DEFAULT NULL,
  `accepted_by_user_id` bigint unsigned DEFAULT NULL,
  `created_by_user_id` bigint unsigned DEFAULT NULL,
  `raw_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `accepted_marker` tinyint GENERATED ALWAYS AS (if((`is_accepted` = 1),1,NULL)) STORED,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_readings_operation_sequence` (`operation_id`,`stage`,`sequence_number`),
  UNIQUE KEY `uq_readings_company_id` (`company_id`,`id`),
  UNIQUE KEY `uq_readings_accepted_stage` (`operation_id`,`stage`,`accepted_marker`),
  KEY `idx_readings_operation_stage_date` (`company_id`,`operation_id`,`stage`,`measured_at`),
  KEY `idx_readings_device_date` (`company_id`,`device_id`,`measured_at`),
  KEY `fk_readings_accepted_user` (`company_id`,`accepted_by_user_id`),
  KEY `fk_readings_created_user` (`company_id`,`created_by_user_id`),
  CONSTRAINT `fk_readings_accepted_user` FOREIGN KEY (`company_id`, `accepted_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `fk_readings_created_user` FOREIGN KEY (`company_id`, `created_by_user_id`) REFERENCES `users` (`company_id`, `id`),
  CONSTRAINT `fk_readings_device` FOREIGN KEY (`company_id`, `device_id`) REFERENCES `devices` (`company_id`, `id`),
  CONSTRAINT `fk_readings_operation` FOREIGN KEY (`company_id`, `operation_id`) REFERENCES `weighing_operations` (`company_id`, `id`) ON DELETE CASCADE,
  CONSTRAINT `chk_readings_acceptance` CHECK (((`is_accepted` = 0) or ((`accepted_at` is not null) and (`accepted_by_user_id` is not null)))),
  CONSTRAINT `chk_readings_flags` CHECK (((`is_stable` in (0,1)) and (`is_accepted` in (0,1)) and ((`checksum_valid` is null) or (`checksum_valid` in (0,1))))),
  CONSTRAINT `chk_readings_manual` CHECK (((`source` <> _utf8mb4'MANUAL') or (`created_by_user_id` is not null))),
  CONSTRAINT `chk_readings_weight` CHECK ((`weight_kg` >= 0)),
  CONSTRAINT `weighing_readings_chk_1` CHECK (json_valid(`raw_payload`))
) ENGINE=InnoDB AUTO_INCREMENT=2455 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `weighing_stations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weighing_stations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `operational_unit_id` bigint unsigned NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(120) NOT NULL,
  `scale_device_id` bigint unsigned DEFAULT NULL,
  `rfid_reader_device_id` bigint unsigned DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stations_company_code` (`company_id`,`code`),
  UNIQUE KEY `uq_stations_company_unit_id` (`company_id`,`operational_unit_id`,`id`),
  UNIQUE KEY `uq_stations_company_id` (`company_id`,`id`),
  KEY `fk_stations_scale_device` (`company_id`,`scale_device_id`),
  KEY `fk_stations_rfid_device` (`company_id`,`rfid_reader_device_id`),
  CONSTRAINT `fk_stations_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_stations_rfid_device` FOREIGN KEY (`company_id`, `rfid_reader_device_id`) REFERENCES `devices` (`company_id`, `id`),
  CONSTRAINT `fk_stations_scale_device` FOREIGN KEY (`company_id`, `scale_device_id`) REFERENCES `devices` (`company_id`, `id`),
  CONSTRAINT `fk_stations_unit` FOREIGN KEY (`company_id`, `operational_unit_id`) REFERENCES `operational_units` (`company_id`, `id`),
  CONSTRAINT `chk_stations_active` CHECK ((`active` in (0,1)))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


/*!50003 DROP PROCEDURE IF EXISTS `sp_accept_legal_document` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_accept_legal_document`(
    IN p_company_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED,
    IN p_legal_document_id BIGINT UNSIGNED,
    IN p_user_device_id BIGINT UNSIGNED,
    IN p_ip_address VARCHAR(45),
    IN p_user_agent VARCHAR(500),
    IN p_app_version_name VARCHAR(30),
    IN p_app_build_number INT UNSIGNED
)
BEGIN
    DECLARE v_document_exists INT DEFAULT 0;
    DECLARE v_user_exists INT DEFAULT 0;

    SELECT COUNT(*)
      INTO v_user_exists
      FROM users
     WHERE company_id = p_company_id
       AND id = p_user_id
       AND active = 1;

    IF v_user_exists = 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Usuário inexistente ou inativo.';
    END IF;

    SELECT COUNT(*)
      INTO v_document_exists
      FROM legal_documents
     WHERE company_id = p_company_id
       AND id = p_legal_document_id
       AND active = 1
       AND (effective_at IS NULL OR effective_at <= CURRENT_TIMESTAMP(3));

    IF v_document_exists = 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Documento legal inexistente, inativo ou ainda não vigente.';
    END IF;

    INSERT INTO legal_acceptances (
        company_id,
        user_id,
        legal_document_id,
        user_device_id,
        accepted_at,
        ip_address,
        user_agent,
        app_version_name,
        app_build_number
    ) VALUES (
        p_company_id,
        p_user_id,
        p_legal_document_id,
        p_user_device_id,
        CURRENT_TIMESTAMP(3),
        p_ip_address,
        p_user_agent,
        p_app_version_name,
        p_app_build_number
    )
    ON DUPLICATE KEY UPDATE
        user_device_id = VALUES(user_device_id),
        accepted_at = VALUES(accepted_at),
        ip_address = VALUES(ip_address),
        user_agent = VALUES(user_agent),
        app_version_name = VALUES(app_version_name),
        app_build_number = VALUES(app_build_number);

    INSERT INTO audit_logs (
        company_id,
        user_id,
        action,
        entity_name,
        entity_id,
        new_values,
        ip_address,
        user_agent
    ) VALUES (
        p_company_id,
        p_user_id,
        'ACCEPT_LEGAL_DOCUMENT',
        'legal_documents',
        CAST(p_legal_document_id AS CHAR),
        JSON_OBJECT('accepted_at', CURRENT_TIMESTAMP(3)),
        p_ip_address,
        p_user_agent
    );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_accept_weighing_reading` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_accept_weighing_reading`(
    IN p_company_id BIGINT UNSIGNED,
    IN p_reading_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_operation_id BIGINT UNSIGNED;
    DECLARE v_stage VARCHAR(30);
    DECLARE v_weight DECIMAL(14,3);
    DECLARE v_source VARCHAR(20);
    DECLARE v_is_stable TINYINT;
    DECLARE v_operation_state VARCHAR(30);
    DECLARE v_require_stable TINYINT DEFAULT 1;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SELECT r.operation_id,
           r.stage,
           r.weight_kg,
           r.source,
           r.is_stable,
           o.state
      INTO v_operation_id,
           v_stage,
           v_weight,
           v_source,
           v_is_stable,
           v_operation_state
      FROM weighing_readings r
      JOIN weighing_operations o
        ON o.company_id = r.company_id
       AND o.id = r.operation_id
     WHERE r.company_id = p_company_id
       AND r.id = p_reading_id
     FOR UPDATE;

    IF v_operation_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Leitura não encontrada.';
    END IF;

    IF v_operation_state IN ('COMPLETED', 'CANCELLED') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Não é possível aceitar leitura em operação concluída ou cancelada.';
    END IF;

    IF v_source = 'DEVICE' AND v_is_stable = 0 AND v_require_stable = 1 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A leitura automática precisa estar estável antes de ser aceita.';
    END IF;

    UPDATE weighing_readings
       SET is_accepted = 0,
           accepted_at = NULL,
           accepted_by_user_id = NULL
     WHERE company_id = p_company_id
       AND operation_id = v_operation_id
       AND stage = v_stage
       AND is_accepted = 1;

    UPDATE weighing_readings
       SET is_accepted = 1,
           accepted_at = CURRENT_TIMESTAMP(3),
           accepted_by_user_id = p_user_id
     WHERE company_id = p_company_id
       AND id = p_reading_id;

    IF v_stage = 'EMPTY_TRUCK' THEN
        UPDATE weighing_operations
           SET empty_truck_weight_kg = v_weight,
               state = 'IN_PROGRESS'
         WHERE company_id = p_company_id
           AND id = v_operation_id;
    ELSEIF v_stage = 'SEPARATED_CARGO' THEN
        UPDATE weighing_operations
           SET separated_cargo_weight_kg = v_weight,
               state = 'IN_PROGRESS'
         WHERE company_id = p_company_id
           AND id = v_operation_id;
    ELSEIF v_stage = 'LOADED_TRUCK' THEN
        UPDATE weighing_operations
           SET loaded_truck_weight_kg = v_weight,
               state = 'IN_PROGRESS'
         WHERE company_id = p_company_id
           AND id = v_operation_id;
    END IF;

    INSERT INTO operation_events (
        company_id,
        operation_id,
        event_type,
        user_id,
        event_data
    ) VALUES (
        p_company_id,
        v_operation_id,
        'READING_ACCEPTED',
        p_user_id,
        JSON_OBJECT(
            'reading_id', p_reading_id,
            'stage', v_stage,
            'weight_kg', v_weight,
            'source', v_source
        )
    );

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_cancel_transport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_cancel_transport`(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED,
    IN p_reason VARCHAR(500)
)
BEGIN
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_tracking_state VARCHAR(30);

    IF p_reason IS NULL OR TRIM(p_reason) = '' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O motivo do cancelamento do transporte é obrigatório.';
    END IF;

    SELECT COUNT(*)
      INTO v_exists
      FROM weighing_operations
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    IF v_exists = 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação não encontrada.';
    END IF;

    SELECT MAX(tracking_state)
      INTO v_tracking_state
      FROM operation_tracking_status
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id;

    IF v_tracking_state = 'ARRIVED' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O transporte já foi concluído e não pode ser cancelado.';
    END IF;

    INSERT INTO operation_tracking_status (
        company_id, operation_id, tracking_state, stopped_since
    ) VALUES (
        p_company_id, p_operation_id, 'CANCELLED', NULL
    )
    ON DUPLICATE KEY UPDATE
        tracking_state = 'CANCELLED',
        stopped_since = NULL;

    UPDATE alerts
       SET state = 'RESOLVED',
           resolved_at = CURRENT_TIMESTAMP(3),
           resolution_notes = CONCAT('Transporte cancelado: ', p_reason)
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND alert_context = 'TRACKING'
       AND state IN ('OPEN', 'ACKNOWLEDGED');

    INSERT INTO operation_events (
        company_id, operation_id, event_type, user_id, event_data
    ) VALUES (
        p_company_id, p_operation_id, 'TRACKING_CANCELLED', p_user_id,
        JSON_OBJECT('reason', p_reason)
    );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_cancel_weighing_operation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_cancel_weighing_operation`(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED,
    IN p_reason VARCHAR(500)
)
BEGIN
    IF p_reason IS NULL OR TRIM(p_reason) = '' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O motivo do cancelamento é obrigatório.';
    END IF;

    UPDATE weighing_operations
       SET state = 'CANCELLED',
           cancelled_at = CURRENT_TIMESTAMP(3),
           cancelled_by_user_id = p_user_id,
           cancellation_reason = p_reason
     WHERE company_id = p_company_id
       AND id = p_operation_id
       AND state <> 'COMPLETED';

    IF ROW_COUNT() = 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação não encontrada ou já concluída.';
    END IF;

    INSERT INTO operation_events (
        company_id, operation_id, event_type, user_id, event_data
    ) VALUES (
        p_company_id,
        p_operation_id,
        'CANCELLED',
        p_user_id,
        JSON_OBJECT('reason', p_reason)
    );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_evaluate_tracking_alerts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_evaluate_tracking_alerts`(
    IN p_company_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_signal_loss_minutes INT UNSIGNED;
    DECLARE v_delay_minutes INT UNSIGNED;
    DECLARE v_tracking_alerts TINYINT;

    SET v_signal_loss_minutes = COALESCE((
        SELECT signal_loss_alert_minutes
          FROM company_settings
         WHERE company_id = p_company_id
         LIMIT 1
    ), 10);

    SET v_delay_minutes = COALESCE((
        SELECT delivery_delay_alert_minutes
          FROM company_settings
         WHERE company_id = p_company_id
         LIMIT 1
    ), 15);

    SET v_tracking_alerts = COALESCE((
        SELECT tracking_alerts_enabled
          FROM company_settings
         WHERE company_id = p_company_id
         LIMIT 1
    ), 1);

    IF v_tracking_alerts = 1 THEN
        
        INSERT INTO alerts (
            company_id, operation_id, alert_context, calculation_version,
            alert_type, severity, state, source, deduplication_key,
            title, message, context_json, detected_at
        )
        SELECT
            ots.company_id,
            ots.operation_id,
            'TRACKING',
            NULL,
            'TRACKING_SIGNAL_LOST',
            'ATTENTION',
            'OPEN',
            'SYSTEM',
            CONCAT('TRACKING_SIGNAL_LOST:', ots.operation_id),
            'Sinal de rastreamento perdido',
            CONCAT(
                'Nenhuma posição recebida há aproximadamente ',
                TIMESTAMPDIFF(
                    MINUTE, COALESCE(ots.last_position_at, o.departed_at), CURRENT_TIMESTAMP(3)
                ),
                ' minuto(s).'
            ),
            JSON_OBJECT(
                'last_position_at', ots.last_position_at,
                'departed_at', o.departed_at,
                'minutes_without_signal', TIMESTAMPDIFF(
                    MINUTE, COALESCE(ots.last_position_at, o.departed_at), CURRENT_TIMESTAMP(3)
                )
            ),
            CURRENT_TIMESTAMP(3)
        FROM operation_tracking_status ots
        JOIN weighing_operations o
          ON o.company_id = ots.company_id
         AND o.id = ots.operation_id
        WHERE ots.company_id = p_company_id
          AND ots.tracking_state IN ('IN_TRANSIT', 'STOPPED')
          AND COALESCE(ots.last_position_at, o.departed_at) IS NOT NULL
          AND TIMESTAMPDIFF(
              MINUTE, COALESCE(ots.last_position_at, o.departed_at), CURRENT_TIMESTAMP(3)
          ) >= v_signal_loss_minutes
        ON DUPLICATE KEY UPDATE
            state = 'OPEN',
            acknowledged_by_user_id = NULL,
            acknowledged_at = NULL,
            resolved_by_user_id = NULL,
            resolved_at = NULL,
            resolution_notes = NULL,
            message = VALUES(message),
            context_json = VALUES(context_json),
            detected_at = VALUES(detected_at);

        INSERT INTO operation_events (
            company_id, operation_id, event_type, event_data
        )
        SELECT
            ots.company_id,
            ots.operation_id,
            'TRACKING_SIGNAL_LOST',
            JSON_OBJECT(
                'last_position_at', ots.last_position_at,
                'departed_at', o.departed_at
            )
        FROM operation_tracking_status ots
        JOIN weighing_operations o
          ON o.company_id = ots.company_id
         AND o.id = ots.operation_id
        WHERE ots.company_id = p_company_id
          AND ots.tracking_state IN ('IN_TRANSIT', 'STOPPED')
          AND COALESCE(ots.last_position_at, o.departed_at) IS NOT NULL
          AND TIMESTAMPDIFF(
              MINUTE, COALESCE(ots.last_position_at, o.departed_at), CURRENT_TIMESTAMP(3)
          ) >= v_signal_loss_minutes;

        UPDATE operation_tracking_status ots
        JOIN weighing_operations o
          ON o.company_id = ots.company_id
         AND o.id = ots.operation_id
           SET ots.tracking_state = 'SIGNAL_LOST'
         WHERE ots.company_id = p_company_id
           AND ots.tracking_state IN ('IN_TRANSIT', 'STOPPED')
           AND COALESCE(ots.last_position_at, o.departed_at) IS NOT NULL
           AND TIMESTAMPDIFF(
               MINUTE, COALESCE(ots.last_position_at, o.departed_at), CURRENT_TIMESTAMP(3)
           ) >= v_signal_loss_minutes;

        
        INSERT INTO alerts (
            company_id, operation_id, alert_context, calculation_version,
            alert_type, severity, state, source, deduplication_key,
            title, message, context_json, detected_at
        )
        SELECT
            o.company_id,
            o.id,
            'TRACKING',
            NULL,
            'DELIVERY_DELAY',
            'ATTENTION',
            'OPEN',
            'SYSTEM',
            CONCAT('DELIVERY_DELAY:', o.id),
            'Atraso na entrega',
            CONCAT(
                'O horário planejado de chegada foi excedido em aproximadamente ',
                TIMESTAMPDIFF(MINUTE, o.planned_arrival_at, CURRENT_TIMESTAMP(3)),
                ' minuto(s).'
            ),
            JSON_OBJECT(
                'planned_arrival_at', o.planned_arrival_at,
                'delay_minutes', TIMESTAMPDIFF(MINUTE, o.planned_arrival_at, CURRENT_TIMESTAMP(3)),
                'source', 'CURRENT_TIME'
            ),
            CURRENT_TIMESTAMP(3)
        FROM weighing_operations o
        LEFT JOIN operation_tracking_status ots
          ON ots.company_id = o.company_id
         AND ots.operation_id = o.id
        WHERE o.company_id = p_company_id
          AND o.state = 'COMPLETED'
          AND o.planned_arrival_at IS NOT NULL
          AND o.arrived_at IS NULL
          AND COALESCE(ots.tracking_state, 'NOT_STARTED') NOT IN ('ARRIVED', 'CANCELLED')
          AND TIMESTAMPDIFF(MINUTE, o.planned_arrival_at, CURRENT_TIMESTAMP(3)) >= v_delay_minutes
        ON DUPLICATE KEY UPDATE
            state = 'OPEN',
            message = VALUES(message),
            context_json = VALUES(context_json),
            detected_at = VALUES(detected_at);

        UPDATE operation_tracking_status ots
        JOIN weighing_operations o
          ON o.company_id = ots.company_id
         AND o.id = ots.operation_id
           SET ots.delay_minutes = GREATEST(
               0,
               TIMESTAMPDIFF(MINUTE, o.planned_arrival_at, CURRENT_TIMESTAMP(3))
           )
         WHERE ots.company_id = p_company_id
           AND o.planned_arrival_at IS NOT NULL
           AND o.arrived_at IS NULL
           AND ots.tracking_state NOT IN ('ARRIVED', 'CANCELLED');
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_finalize_weighing_operation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_finalize_weighing_operation`(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_method VARCHAR(30);
    DECLARE v_state VARCHAR(30);
    DECLARE v_empty DECIMAL(14,3);
    DECLARE v_separated DECIMAL(14,3);
    DECLARE v_declared DECIMAL(14,3);
    DECLARE v_loaded DECIMAL(14,3);
    DECLARE v_expected DECIMAL(14,3);
    DECLARE v_actual_cargo DECIMAL(14,3);
    DECLARE v_difference DECIMAL(14,3);
    DECLARE v_difference_percent DECIMAL(10,4);
    DECLARE v_tare_difference_percent DECIMAL(10,4);
    DECLARE v_registered_tare DECIMAL(14,3);
    DECLARE v_gross_limit DECIMAL(14,3);
    DECLARE v_payload_limit DECIMAL(14,3);
    DECLARE v_tolerance DECIMAL(8,3);
    DECLARE v_critical DECIMAL(8,3);
    DECLARE v_tare_tolerance DECIMAL(8,3);
    DECLARE v_new_status VARCHAR(20) DEFAULT 'NORMAL';
    DECLARE v_status_reason VARCHAR(500) DEFAULT 'Pesagem dentro dos limites configurados.';
    DECLARE v_new_version INT UNSIGNED;
    DECLARE v_manual_count INT DEFAULT 0;
    DECLARE v_unstable_count INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SELECT weighing_method,
           state,
           empty_truck_weight_kg,
           separated_cargo_weight_kg,
           declared_cargo_weight_kg,
           loaded_truck_weight_kg,
           registered_tare_snapshot_kg,
           gross_limit_snapshot_kg,
           payload_limit_snapshot_kg,
           tolerance_percent_snapshot,
           critical_limit_snapshot,
           tare_tolerance_snapshot,
           calculation_version + 1
      INTO v_method,
           v_state,
           v_empty,
           v_separated,
           v_declared,
           v_loaded,
           v_registered_tare,
           v_gross_limit,
           v_payload_limit,
           v_tolerance,
           v_critical,
           v_tare_tolerance,
           v_new_version
      FROM weighing_operations
     WHERE company_id = p_company_id
       AND id = p_operation_id
     FOR UPDATE;

    IF v_method IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação de pesagem não encontrada.';
    END IF;

    IF v_state = 'CANCELLED' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Uma operação cancelada não pode ser finalizada.';
    END IF;

    IF v_empty IS NULL OR v_loaded IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'As leituras do caminhão vazio e carregado são obrigatórias.';
    END IF;

    IF v_method = 'THREE_STAGE' AND v_separated IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A pesagem em três etapas exige o peso da carga separada.';
    END IF;

    SET v_actual_cargo = v_loaded - v_empty;

    IF v_actual_cargo < 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O peso carregado não pode ser menor que o peso vazio.';
    END IF;

    IF v_method = 'THREE_STAGE' THEN
        SET v_expected = v_empty + v_separated;
    ELSEIF v_declared IS NOT NULL THEN
        SET v_expected = v_empty + v_declared;
    ELSE
        SET v_expected = v_loaded;
    END IF;

    SET v_difference = v_loaded - v_expected;
    SET v_difference_percent =
        CASE
            WHEN v_expected > 0 THEN ROUND((v_difference / v_expected) * 100, 4)
            ELSE 0
        END;

    SET v_tare_difference_percent =
        CASE
            WHEN v_registered_tare IS NOT NULL AND v_registered_tare > 0
                THEN ROUND((ABS(v_empty - v_registered_tare) / v_registered_tare) * 100, 4)
            ELSE NULL
        END;

    IF ABS(v_difference_percent) > v_critical THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'Divergência de peso acima do limite crítico.';
    ELSEIF ABS(v_difference_percent) > v_tolerance THEN
        SET v_new_status = 'ATTENTION';
        SET v_status_reason = 'Divergência de peso acima da tolerância operacional.';
    END IF;

    IF v_gross_limit IS NOT NULL AND v_gross_limit > 0 AND v_loaded > v_gross_limit THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'Peso bruto acima do limite cadastrado para o veículo.';
    END IF;

    IF v_payload_limit IS NOT NULL AND v_payload_limit > 0 AND v_actual_cargo > v_payload_limit THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'Carga líquida acima da capacidade cadastrada para o veículo.';
    END IF;

    IF v_tare_difference_percent IS NOT NULL
       AND v_tare_difference_percent > v_tare_tolerance
       AND v_new_status = 'NORMAL' THEN
        SET v_new_status = 'ATTENTION';
        SET v_status_reason = 'Peso vazio divergente da tara cadastrada.';
    END IF;

    SELECT COUNT(*)
      INTO v_manual_count
      FROM weighing_readings
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND is_accepted = 1
       AND source = 'MANUAL';

    SELECT COUNT(*)
      INTO v_unstable_count
      FROM weighing_readings
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND is_accepted = 1
       AND is_stable = 0;

    IF v_manual_count > 0 AND v_new_status = 'NORMAL' THEN
        SET v_new_status = 'ATTENTION';
        SET v_status_reason = 'A operação contém ao menos uma leitura manual.';
    END IF;

    IF v_unstable_count > 0 THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'A operação contém leitura aceita sem estabilidade.';
    END IF;

    UPDATE alerts
       SET state = 'RESOLVED',
           resolved_by_user_id = p_user_id,
           resolved_at = CURRENT_TIMESTAMP(3),
           resolution_notes = 'Alerta substituído por um novo cálculo da operação.'
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND source = 'SYSTEM'
       AND alert_context = 'WEIGHING'
       AND state IN ('OPEN', 'ACKNOWLEDGED');

    UPDATE weighing_operations
       SET expected_gross_weight_kg = v_expected,
           actual_cargo_weight_kg = v_actual_cargo,
           difference_kg = v_difference,
           difference_percent = v_difference_percent,
           tare_difference_percent = v_tare_difference_percent,
           status = v_new_status,
           status_reason = v_status_reason,
           calculation_version = v_new_version,
           state = 'COMPLETED',
           completed_at = CURRENT_TIMESTAMP(3)
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    IF v_gross_limit IS NOT NULL AND v_gross_limit > 0 AND v_loaded > v_gross_limit THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'OVER_GROSS_LIMIT', 'CRITICAL',
            'Peso bruto acima do limite',
            CONCAT(
                'Peso medido: ', FORMAT(v_loaded, 3),
                ' kg. Limite do veículo: ', FORMAT(v_gross_limit, 3), ' kg.'
            ),
            v_loaded - v_gross_limit,
            ROUND(((v_loaded - v_gross_limit) / v_gross_limit) * 100, 4)
        );
    END IF;

    IF v_payload_limit IS NOT NULL AND v_payload_limit > 0 AND v_actual_cargo > v_payload_limit THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'OVER_PAYLOAD_LIMIT', 'CRITICAL',
            'Carga acima da capacidade',
            CONCAT(
                'Carga calculada: ', FORMAT(v_actual_cargo, 3),
                ' kg. Capacidade cadastrada: ', FORMAT(v_payload_limit, 3), ' kg.'
            ),
            v_actual_cargo - v_payload_limit,
            ROUND(((v_actual_cargo - v_payload_limit) / v_payload_limit) * 100, 4)
        );
    END IF;

    IF ABS(v_difference_percent) > v_tolerance THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id,
            p_operation_id,
            v_new_version,
            IF(v_difference < 0, 'POSSIBLE_MISSING_CARGO', 'POSSIBLE_EXTRA_CARGO'),
            IF(ABS(v_difference_percent) > v_critical, 'CRITICAL', 'ATTENTION'),
            IF(v_difference < 0, 'Possível falta de carga', 'Possível excesso de carga'),
            CONCAT(
                'Diferença detectada: ', FORMAT(v_difference, 3),
                ' kg (', FORMAT(v_difference_percent, 4), '%).'
            ),
            v_difference,
            v_difference_percent
        );
    END IF;

    IF v_tare_difference_percent IS NOT NULL
       AND v_tare_difference_percent > v_tare_tolerance THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'TARE_DIVERGENCE', 'ATTENTION',
            'Divergência na tara do veículo',
            CONCAT(
                'Peso vazio medido: ', FORMAT(v_empty, 3),
                ' kg. Tara cadastrada: ', FORMAT(v_registered_tare, 3),
                ' kg. Divergência: ', FORMAT(v_tare_difference_percent, 4), '%.'
            ),
            v_empty - v_registered_tare,
            v_tare_difference_percent
        );
    END IF;

    IF v_manual_count > 0 THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'MANUAL_READING', 'ATTENTION',
            'Leitura manual utilizada',
            CONCAT('A operação possui ', v_manual_count, ' leitura(s) manual(is) aceita(s).')
        );
    END IF;

    IF v_unstable_count > 0 THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'UNSTABLE_READING', 'CRITICAL',
            'Leitura instável aceita',
            CONCAT('A operação possui ', v_unstable_count, ' leitura(s) aceita(s) sem estabilidade.')
        );
    END IF;

    INSERT INTO operation_events (
        company_id,
        operation_id,
        event_type,
        user_id,
        event_data
    ) VALUES (
        p_company_id,
        p_operation_id,
        'FINALIZED',
        p_user_id,
        JSON_OBJECT(
            'calculation_version', v_new_version,
            'status', v_new_status,
            'expected_gross_weight_kg', v_expected,
            'loaded_truck_weight_kg', v_loaded,
            'actual_cargo_weight_kg', v_actual_cargo,
            'difference_kg', v_difference,
            'difference_percent', v_difference_percent
        )
    );

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_manutencao_diaria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_manutencao_diaria`()
BEGIN
    DELETE FROM auth_sessions
     WHERE expires_at < DATE_SUB(NOW(3), INTERVAL 7 DAY)
        OR (revoked_at IS NOT NULL AND revoked_at < DATE_SUB(NOW(3), INTERVAL 7 DAY));

    DELETE FROM password_reset_tokens
     WHERE (used_at IS NOT NULL AND used_at < DATE_SUB(NOW(3), INTERVAL 7 DAY))
        OR expires_at < DATE_SUB(NOW(3), INTERVAL 1 DAY);

    DELETE FROM two_factor_codes
     WHERE expires_at < DATE_SUB(NOW(3), INTERVAL 1 DAY)
        OR (used_at IS NOT NULL AND used_at < DATE_SUB(NOW(3), INTERVAL 1 DAY));

    DELETE FROM generated_reports
     WHERE generated_at < DATE_SUB(NOW(3), INTERVAL 180 DAY);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_mark_transport_arrived` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_mark_transport_arrived`(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_now DATETIME(3);
    DECLARE v_tracking_state VARCHAR(30);
    SET v_now = CURRENT_TIMESTAMP(3);

    IF NOT EXISTS (
        SELECT 1 FROM weighing_operations
         WHERE company_id = p_company_id
           AND id = p_operation_id
           AND state = 'COMPLETED'
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação não encontrada ou pesagem ainda não concluída.';
    END IF;

    SELECT MAX(tracking_state)
      INTO v_tracking_state
      FROM operation_tracking_status
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id;

    IF v_tracking_state = 'CANCELLED' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O transporte está cancelado.';
    END IF;

    UPDATE weighing_operations
       SET arrived_at = COALESCE(arrived_at, v_now)
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    INSERT INTO operation_tracking_status (
        company_id, operation_id, tracking_state,
        stopped_since, progress_percent, delay_minutes, last_position_at
    ) VALUES (
        p_company_id, p_operation_id, 'ARRIVED', NULL, 100.000, 0, v_now
    )
    ON DUPLICATE KEY UPDATE
        tracking_state = 'ARRIVED',
        stopped_since = NULL,
        progress_percent = 100.000,
        delay_minutes = 0,
        last_position_at = GREATEST(COALESCE(last_position_at, v_now), v_now);

    UPDATE alerts
       SET state = 'RESOLVED',
           resolved_at = v_now,
           resolution_notes = 'Transporte concluído/veículo chegou ao destino.'
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND alert_context = 'TRACKING'
       AND state IN ('OPEN', 'ACKNOWLEDGED');

    INSERT INTO operation_events (
        company_id, operation_id, event_type, user_id, event_data
    ) VALUES (
        p_company_id, p_operation_id, 'TRACKING_ARRIVED', p_user_id,
        JSON_OBJECT('arrived_at', v_now, 'source', 'MANUAL_OR_API')
    );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purge_weighing_operation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purge_weighing_operation`(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    DELETE FROM weighing_operations
     WHERE company_id = p_company_id AND id = p_operation_id;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_set_transport_schedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_set_transport_schedule`(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED,
    IN p_planned_departure_at DATETIME(3),
    IN p_planned_arrival_at DATETIME(3)
)
BEGIN
    IF p_planned_departure_at IS NOT NULL
       AND p_planned_arrival_at IS NOT NULL
       AND p_planned_arrival_at < p_planned_departure_at THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A chegada planejada não pode ser anterior à saída planejada.';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM weighing_operations
         WHERE company_id = p_company_id AND id = p_operation_id
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação não encontrada.';
    END IF;

    UPDATE weighing_operations
       SET planned_departure_at = p_planned_departure_at,
           planned_arrival_at = p_planned_arrival_at
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    INSERT INTO operation_events (
        company_id, operation_id, event_type, user_id, event_data
    ) VALUES (
        p_company_id, p_operation_id, 'TRANSPORT_SCHEDULED', p_user_id,
        JSON_OBJECT(
            'planned_departure_at', p_planned_departure_at,
            'planned_arrival_at', p_planned_arrival_at
        )
    );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_start_transport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_start_transport`(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_weighing_state VARCHAR(30);
    DECLARE v_tracking_state VARCHAR(30);
    DECLARE v_now DATETIME(3);

    SET v_now = CURRENT_TIMESTAMP(3);

    SELECT MAX(state)
      INTO v_weighing_state
      FROM weighing_operations
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    IF v_weighing_state IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação não encontrada.';
    END IF;

    IF v_weighing_state <> 'COMPLETED' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A pesagem deve estar concluída antes de iniciar o transporte.';
    END IF;

    SELECT MAX(tracking_state)
      INTO v_tracking_state
      FROM operation_tracking_status
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id;

    IF v_tracking_state IN ('ARRIVED', 'CANCELLED') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O transporte já foi encerrado.';
    END IF;

    UPDATE weighing_operations
       SET departed_at = COALESCE(departed_at, v_now)
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    INSERT INTO operation_tracking_status (
        company_id, operation_id, tracking_state, last_moving_at
    ) VALUES (
        p_company_id, p_operation_id, 'IN_TRANSIT', v_now
    )
    ON DUPLICATE KEY UPDATE
        tracking_state = 'IN_TRANSIT',
        stopped_since = NULL,
        last_moving_at = v_now;

    INSERT INTO operation_events (
        company_id, operation_id, event_type, user_id, event_data
    ) VALUES (
        p_company_id, p_operation_id, 'TRACKING_STARTED', p_user_id,
        JSON_OBJECT('departed_at', v_now, 'source', 'MANUAL_OR_API')
    );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;


USE `loadsense`;


/*!50001 DROP VIEW IF EXISTS `vw_active_operation_tracking`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_active_operation_tracking` AS select `ots`.`company_id` AS `company_id`,`ots`.`operation_id` AS `operation_id`,`o`.`operation_code` AS `operation_code`,`o`.`state` AS `weighing_state`,`o`.`status` AS `weighing_status`,`o`.`planned_departure_at` AS `planned_departure_at`,`o`.`departed_at` AS `departed_at`,`o`.`planned_arrival_at` AS `planned_arrival_at`,`o`.`arrived_at` AS `arrived_at`,`v`.`plate` AS `vehicle_plate`,`d`.`full_name` AS `driver_name`,`rt`.`origin` AS `origin`,`rt`.`destination` AS `destination`,`rt`.`distance_km` AS `distance_km`,`ots`.`tracking_state` AS `tracking_state`,`ots`.`stopped_since` AS `stopped_since`,`ots`.`last_moving_at` AS `last_moving_at`,`ots`.`current_latitude` AS `current_latitude`,`ots`.`current_longitude` AS `current_longitude`,`ots`.`speed_kmh` AS `speed_kmh`,`ots`.`heading_degrees` AS `heading_degrees`,`ots`.`progress_percent` AS `progress_percent`,`ots`.`route_deviation_meters` AS `route_deviation_meters`,`ots`.`estimated_arrival_at` AS `estimated_arrival_at`,`ots`.`delay_minutes` AS `delay_minutes`,`ots`.`last_position_at` AS `last_position_at` from ((((`operation_tracking_status` `ots` join `weighing_operations` `o` on(((`o`.`company_id` = `ots`.`company_id`) and (`o`.`id` = `ots`.`operation_id`)))) join `vehicles` `v` on(((`v`.`company_id` = `o`.`company_id`) and (`v`.`id` = `o`.`vehicle_id`)))) left join `drivers` `d` on(((`d`.`company_id` = `o`.`company_id`) and (`d`.`id` = `o`.`driver_id`)))) left join `routes` `rt` on(((`rt`.`company_id` = `o`.`company_id`) and (`rt`.`id` = `o`.`route_id`)))) where (`ots`.`tracking_state` in ('NOT_STARTED','IN_TRANSIT','STOPPED','SIGNAL_LOST')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;


/*!50001 DROP VIEW IF EXISTS `vw_company_current_subscription`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_company_current_subscription` AS select `cs`.`company_id` AS `company_id`,`cs`.`id` AS `subscription_id`,`cs`.`status` AS `status`,`cs`.`starts_at` AS `starts_at`,`cs`.`current_period_start` AS `current_period_start`,`cs`.`current_period_end` AS `current_period_end`,`p`.`id` AS `plan_id`,`p`.`code` AS `plan_code`,`p`.`name` AS `plan_name`,`p`.`monthly_price_brl` AS `monthly_price_brl`,`p`.`features_json` AS `features_json` from (`company_subscriptions` `cs` join `subscription_plans` `p` on((`p`.`id` = `cs`.`plan_id`))) where (`cs`.`status` in ('TRIAL','ACTIVE','PAST_DUE')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;


/*!50001 DROP VIEW IF EXISTS `vw_dashboard_daily`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_dashboard_daily` AS select `weighing_operations`.`company_id` AS `company_id`,cast(coalesce(`weighing_operations`.`completed_at`,`weighing_operations`.`started_at`) as date) AS `reference_date`,count(0) AS `total_operations`,sum((`weighing_operations`.`state` = 'COMPLETED')) AS `completed_operations`,sum((`weighing_operations`.`status` = 'NORMAL')) AS `normal_operations`,sum((`weighing_operations`.`status` = 'ATTENTION')) AS `attention_operations`,sum((`weighing_operations`.`status` = 'CRITICAL')) AS `critical_operations`,round(sum(coalesce(`weighing_operations`.`actual_cargo_weight_kg`,0)),3) AS `total_cargo_weight_kg`,round(avg(abs(`weighing_operations`.`difference_percent`)),4) AS `average_absolute_difference_percent` from `weighing_operations` group by `weighing_operations`.`company_id`,cast(coalesce(`weighing_operations`.`completed_at`,`weighing_operations`.`started_at`) as date) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;


/*!50001 DROP VIEW IF EXISTS `vw_latest_device_calibration`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_latest_device_calibration` AS select `dc`.`id` AS `id`,`dc`.`company_id` AS `company_id`,`dc`.`device_id` AS `device_id`,`dc`.`calibration_factor` AS `calibration_factor`,`dc`.`reference_weight_kg` AS `reference_weight_kg`,`dc`.`accuracy_class` AS `accuracy_class`,`dc`.`certificate_number` AS `certificate_number`,`dc`.`result` AS `result`,`dc`.`performed_by_user_id` AS `performed_by_user_id`,`dc`.`performed_at` AS `performed_at`,`dc`.`expires_at` AS `expires_at`,`dc`.`notes` AS `notes`,`dc`.`created_at` AS `created_at` from (`device_calibrations` `dc` join (select `device_calibrations`.`company_id` AS `company_id`,`device_calibrations`.`device_id` AS `device_id`,max(`device_calibrations`.`performed_at`) AS `max_performed_at` from `device_calibrations` group by `device_calibrations`.`company_id`,`device_calibrations`.`device_id`) `latest` on(((`latest`.`company_id` = `dc`.`company_id`) and (`latest`.`device_id` = `dc`.`device_id`) and (`latest`.`max_performed_at` = `dc`.`performed_at`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;


/*!50001 DROP VIEW IF EXISTS `vw_mobile_active_operations`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_mobile_active_operations` AS select `o`.`company_id` AS `company_id`,`o`.`id` AS `operation_id`,`o`.`operation_code` AS `operation_code`,`o`.`state` AS `weighing_state`,`o`.`status` AS `weighing_status`,`o`.`started_at` AS `started_at`,`o`.`completed_at` AS `completed_at`,`o`.`planned_departure_at` AS `planned_departure_at`,`o`.`departed_at` AS `departed_at`,`o`.`planned_arrival_at` AS `planned_arrival_at`,`o`.`arrived_at` AS `arrived_at`,`v`.`plate` AS `vehicle_plate`,`d`.`full_name` AS `driver_name`,`cp`.`name` AS `cargo_product_name`,`rt`.`origin` AS `origin`,`rt`.`destination` AS `destination`,coalesce(`ots`.`tracking_state`,'NOT_STARTED') AS `tracking_state`,`ots`.`progress_percent` AS `progress_percent`,`ots`.`estimated_arrival_at` AS `estimated_arrival_at`,`ots`.`delay_minutes` AS `delay_minutes`,`ots`.`last_position_at` AS `last_position_at` from (((((`weighing_operations` `o` join `vehicles` `v` on(((`v`.`company_id` = `o`.`company_id`) and (`v`.`id` = `o`.`vehicle_id`)))) left join `drivers` `d` on(((`d`.`company_id` = `o`.`company_id`) and (`d`.`id` = `o`.`driver_id`)))) left join `cargo_products` `cp` on(((`cp`.`company_id` = `o`.`company_id`) and (`cp`.`id` = `o`.`cargo_product_id`)))) left join `routes` `rt` on(((`rt`.`company_id` = `o`.`company_id`) and (`rt`.`id` = `o`.`route_id`)))) left join `operation_tracking_status` `ots` on(((`ots`.`company_id` = `o`.`company_id`) and (`ots`.`operation_id` = `o`.`id`)))) where ((`o`.`state` in ('DRAFT','IN_PROGRESS')) or ((`o`.`state` = 'COMPLETED') and (`o`.`route_id` is not null) and (coalesce(`ots`.`tracking_state`,'NOT_STARTED') in ('NOT_STARTED','IN_TRANSIT','STOPPED','SIGNAL_LOST')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;


/*!50001 DROP VIEW IF EXISTS `vw_mobile_completed_operations`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_mobile_completed_operations` AS select `o`.`company_id` AS `company_id`,`o`.`id` AS `operation_id`,`o`.`operation_code` AS `operation_code`,`o`.`status` AS `weighing_status`,`o`.`completed_at` AS `completed_at`,`o`.`departed_at` AS `departed_at`,`o`.`arrived_at` AS `arrived_at`,`v`.`plate` AS `vehicle_plate`,`d`.`full_name` AS `driver_name`,`cp`.`name` AS `cargo_product_name`,`rt`.`origin` AS `origin`,`rt`.`destination` AS `destination`,coalesce(`ots`.`tracking_state`,'ARRIVED') AS `tracking_state` from (((((`weighing_operations` `o` join `vehicles` `v` on(((`v`.`company_id` = `o`.`company_id`) and (`v`.`id` = `o`.`vehicle_id`)))) left join `drivers` `d` on(((`d`.`company_id` = `o`.`company_id`) and (`d`.`id` = `o`.`driver_id`)))) left join `cargo_products` `cp` on(((`cp`.`company_id` = `o`.`company_id`) and (`cp`.`id` = `o`.`cargo_product_id`)))) left join `routes` `rt` on(((`rt`.`company_id` = `o`.`company_id`) and (`rt`.`id` = `o`.`route_id`)))) left join `operation_tracking_status` `ots` on(((`ots`.`company_id` = `o`.`company_id`) and (`ots`.`operation_id` = `o`.`id`)))) where ((`o`.`state` = 'COMPLETED') and ((`o`.`route_id` is null) or (`ots`.`tracking_state` = 'ARRIVED'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;


/*!50001 DROP VIEW IF EXISTS `vw_open_alerts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_open_alerts` AS select `a`.`id` AS `id`,`a`.`company_id` AS `company_id`,`a`.`operation_id` AS `operation_id`,`o`.`operation_code` AS `operation_code`,`o`.`vehicle_id` AS `vehicle_id`,`a`.`alert_context` AS `alert_context`,`a`.`alert_type` AS `alert_type`,`a`.`severity` AS `severity`,`a`.`state` AS `state`,`a`.`title` AS `title`,`a`.`message` AS `message`,`a`.`difference_kg` AS `difference_kg`,`a`.`difference_percent` AS `difference_percent`,`a`.`detected_at` AS `detected_at`,`v`.`plate` AS `vehicle_plate` from ((`alerts` `a` left join `weighing_operations` `o` on(((`o`.`company_id` = `a`.`company_id`) and (`o`.`id` = `a`.`operation_id`)))) left join `vehicles` `v` on(((`v`.`company_id` = `o`.`company_id`) and (`v`.`id` = `o`.`vehicle_id`)))) where (`a`.`state` in ('OPEN','ACKNOWLEDGED')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;


/*!50001 DROP VIEW IF EXISTS `vw_pending_legal_documents`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_pending_legal_documents` AS select `u`.`company_id` AS `company_id`,`u`.`id` AS `user_id`,`ld`.`id` AS `legal_document_id`,`ld`.`document_type` AS `document_type`,`ld`.`version` AS `version`,`ld`.`title` AS `title`,`ld`.`content_format` AS `content_format`,`ld`.`content` AS `content`,`ld`.`content_hash` AS `content_hash`,`ld`.`effective_at` AS `effective_at` from ((`users` `u` join `legal_documents` `ld` on(((`ld`.`company_id` = `u`.`company_id`) and (`ld`.`active` = 1) and (`ld`.`mandatory` = 1) and ((`ld`.`effective_at` is null) or (`ld`.`effective_at` <= now(3)))))) left join `legal_acceptances` `la` on(((`la`.`company_id` = `u`.`company_id`) and (`la`.`user_id` = `u`.`id`) and (`la`.`legal_document_id` = `ld`.`id`)))) where ((`u`.`active` = 1) and (`la`.`id` is null)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;


/*!50001 DROP VIEW IF EXISTS `vw_weighing_operation_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_weighing_operation_details` AS select `o`.`id` AS `id`,`o`.`company_id` AS `company_id`,`c`.`trade_name` AS `company_name`,`o`.`operation_code` AS `operation_code`,`o`.`movement_type` AS `movement_type`,`o`.`weighing_method` AS `weighing_method`,`o`.`state` AS `state`,`o`.`status` AS `status`,`o`.`status_reason` AS `status_reason`,`o`.`started_at` AS `started_at`,`o`.`completed_at` AS `completed_at`,`u`.`name` AS `operational_unit_name`,`ws`.`name` AS `weighing_station_name`,`v`.`plate` AS `vehicle_plate`,`v`.`fleet_code` AS `fleet_code`,`d`.`full_name` AS `driver_name`,`rfid`.`code` AS `rfid_code`,`cp`.`name` AS `cargo_product_name`,`rt`.`origin` AS `origin`,`rt`.`destination` AS `destination`,`responsible`.`full_name` AS `responsible_user_name`,`creator`.`full_name` AS `created_by_user_name`,`o`.`empty_truck_weight_kg` AS `empty_truck_weight_kg`,`o`.`separated_cargo_weight_kg` AS `separated_cargo_weight_kg`,`o`.`expected_gross_weight_kg` AS `expected_gross_weight_kg`,`o`.`loaded_truck_weight_kg` AS `loaded_truck_weight_kg`,`o`.`actual_cargo_weight_kg` AS `actual_cargo_weight_kg`,`o`.`difference_kg` AS `difference_kg`,`o`.`difference_percent` AS `difference_percent`,`o`.`tare_difference_percent` AS `tare_difference_percent`,`o`.`gross_limit_snapshot_kg` AS `gross_limit_snapshot_kg`,`o`.`payload_limit_snapshot_kg` AS `payload_limit_snapshot_kg`,`o`.`observations` AS `observations` from ((((((((((`weighing_operations` `o` join `companies` `c` on((`c`.`id` = `o`.`company_id`))) join `operational_units` `u` on(((`u`.`company_id` = `o`.`company_id`) and (`u`.`id` = `o`.`operational_unit_id`)))) left join `weighing_stations` `ws` on(((`ws`.`company_id` = `o`.`company_id`) and (`ws`.`id` = `o`.`weighing_station_id`)))) join `vehicles` `v` on(((`v`.`company_id` = `o`.`company_id`) and (`v`.`id` = `o`.`vehicle_id`)))) left join `drivers` `d` on(((`d`.`company_id` = `o`.`company_id`) and (`d`.`id` = `o`.`driver_id`)))) left join `rfid_tags` `rfid` on(((`rfid`.`company_id` = `o`.`company_id`) and (`rfid`.`id` = `o`.`rfid_tag_id`)))) left join `cargo_products` `cp` on(((`cp`.`company_id` = `o`.`company_id`) and (`cp`.`id` = `o`.`cargo_product_id`)))) left join `routes` `rt` on(((`rt`.`company_id` = `o`.`company_id`) and (`rt`.`id` = `o`.`route_id`)))) join `users` `responsible` on(((`responsible`.`company_id` = `o`.`company_id`) and (`responsible`.`id` = `o`.`responsible_user_id`)))) join `users` `creator` on(((`creator`.`company_id` = `o`.`company_id`) and (`creator`.`id` = `o`.`created_by_user_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


USE `loadsense`;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


/*!40000 ALTER TABLE `app_platform_settings` DISABLE KEYS */;
INSERT INTO `app_platform_settings` (`platform`, `current_version_name`, `current_build_number`, `minimum_supported_build_number`, `maintenance_mode`, `maintenance_message`, `store_url`, `updated_at`) VALUES ('ANDROID','1.0.0',1,1,0,NULL,NULL,'2026-10-13 17:28:42.664'),('IOS','1.0.0',1,1,0,NULL,NULL,'2026-10-13 17:28:42.664');
/*!40000 ALTER TABLE `app_platform_settings` ENABLE KEYS */;


/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` (`id`, `legal_name`, `trade_name`, `document_number`, `slug`, `email`, `phone`, `timezone_name`, `active`, `created_at`, `updated_at`) VALUES (1,'LoadSense Tecnologia e Logística LTDA','LoadSense',NULL,'loadsense-demo','contato@loadsense.local',NULL,'America/Sao_Paulo',1,'2026-10-13 17:28:42.653','2026-10-13 17:28:42.653');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;


/*!40000 ALTER TABLE `company_settings` DISABLE KEYS */;
INSERT INTO `company_settings` (`company_id`, `tolerance_percent`, `critical_limit_percent`, `tare_tolerance_percent`, `reading_stability_tolerance_kg`, `minimum_stable_readings`, `max_reading_age_seconds`, `allow_manual_readings`, `require_manual_reason`, `require_rfid`, `automatic_sheet_refresh`, `critical_alert_notifications`, `automatic_email_reports`, `tracking_alerts_enabled`, `stop_speed_threshold_kmh`, `unplanned_stop_alert_minutes`, `delivery_delay_alert_minutes`, `signal_loss_alert_minutes`, `route_deviation_alerts_enabled`, `route_deviation_tolerance_meters`, `default_weight_unit`, `updated_by_user_id`, `updated_at`) VALUES (1,1.500,3.000,5.000,2.000,3,120,1,1,0,1,1,0,1,1.00,15,15,10,1,500,'KG',NULL,'2026-10-13 17:28:42.655');
/*!40000 ALTER TABLE `company_settings` ENABLE KEYS */;


/*!40000 ALTER TABLE `operational_units` DISABLE KEYS */;
INSERT INTO `operational_units` (`id`, `company_id`, `code`, `name`, `description`, `address_line`, `city`, `state_code`, `postal_code`, `latitude`, `longitude`, `active`, `created_at`, `updated_at`) VALUES (1,1,'MATRIZ','Unidade Principal','Unidade inicial do projeto LoadSense',NULL,'Taboão da Serra','SP',NULL,NULL,NULL,1,'2026-10-13 17:28:42.654','2026-10-13 17:28:42.654');
/*!40000 ALTER TABLE `operational_units` ENABLE KEYS */;


/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `code`, `description`) VALUES (1,'DASHBOARD_VIEW','Visualizar dashboard e indicadores'),(2,'OPERATION_CREATE','Criar operações de pesagem'),(3,'OPERATION_VIEW','Visualizar operações de pesagem'),(4,'OPERATION_UPDATE','Alterar operações em andamento'),(5,'OPERATION_FINALIZE','Finalizar e recalcular operações'),(6,'OPERATION_CANCEL','Cancelar operações'),(7,'READING_CREATE','Registrar leituras de pesagem'),(8,'READING_ACCEPT','Aceitar a leitura oficial de uma etapa'),(9,'ALERT_VIEW','Visualizar alertas'),(10,'ALERT_MANAGE','Reconhecer e resolver alertas'),(11,'REPORT_GENERATE','Gerar e exportar relatórios'),(12,'VEHICLE_MANAGE','Gerenciar veículos e etiquetas RFID'),(13,'DRIVER_MANAGE','Gerenciar motoristas'),(14,'PRODUCT_MANAGE','Gerenciar produtos e tipos de carga'),(15,'DEVICE_MANAGE','Gerenciar hardware, dispositivos e calibrações'),(16,'USER_MANAGE','Gerenciar usuários, perfis e permissões'),(17,'SETTINGS_MANAGE','Alterar configurações da empresa'),(18,'AUDIT_VIEW','Consultar registros de auditoria'),(19,'TRACKING_VIEW','Visualizar monitoramento e trajeto das operações'),(20,'TRACKING_MANAGE','Gerenciar horários, viagem e estados de monitoramento'),(23,'SUBSCRIPTION_VIEW','Visualizar plano e assinatura da empresa'),(24,'SUBSCRIPTION_MANAGE','Gerenciar plano e assinatura da empresa');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;


/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES (1,1),(2,1),(3,1),(1,2),(2,2),(3,2),(1,3),(2,3),(3,3),(1,4),(2,4),(3,4),(1,5),(2,5),(1,6),(2,6),(1,7),(2,7),(3,7),(1,8),(2,8),(3,8),(1,9),(2,9),(3,9),(1,10),(2,10),(1,11),(2,11),(1,12),(2,12),(1,13),(2,13),(1,14),(2,14),(1,15),(2,15),(1,16),(1,17),(1,18),(2,18),(1,19),(2,19),(3,19),(1,20),(2,20),(1,23),(2,23),(1,24);
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;


/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `company_id`, `name`, `description`, `is_system_role`, `active`, `created_at`) VALUES (1,1,'ADMINISTRATOR','Acesso total ao sistema',1,1,'2026-10-13 17:28:42.656'),(2,1,'SUPERVISOR','Supervisão, alertas e relatórios',1,1,'2026-10-13 17:28:42.657'),(3,1,'OPERATOR','Cadastro e execução das pesagens',1,1,'2026-10-13 17:28:42.657');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;


/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` (`version`, `name`, `applied_at`) VALUES (3,'LoadSense V3 - transporte, tracking e planos','2026-10-13 17:28:42.740');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;


/*!40000 ALTER TABLE `subscription_plans` DISABLE KEYS */;
INSERT INTO `subscription_plans` (`id`, `code`, `name`, `description`, `monthly_price_brl`, `features_json`, `sort_order`, `active`, `created_at`, `updated_at`) VALUES (1,'ESSENCIAL','Essencial','Para começar a controlar a operação.',149.90,'{"veiculos":3,"usuarios":"definidos pela consultoria","historico_dias":90,"recursos":[],"ciclos":{"MENSAL":149.90,"TRIMESTRAL":427.90,"ANUAL":1529.90}}',10,1,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3)),(2,'PROFISSIONAL','Profissional','Para parar de digitar e não perder histórico.',349.90,'{"veiculos":10,"usuarios":"definidos pela consultoria","historico_dias":null,"recursos":["importar_planilha","exportar_planilha"],"ciclos":{"MENSAL":349.90,"TRIMESTRAL":997.90,"ANUAL":3569.90}}',20,1,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3)),(3,'AVANCADO','Avançado','Para quem responde a auditoria e fiscalização.',749.90,'{"veiculos":25,"usuarios":"definidos pela consultoria","historico_dias":null,"recursos":["importar_planilha","exportar_planilha","auditoria"],"ciclos":{"MENSAL":749.90,"TRIMESTRAL":2139.90,"ANUAL":7649.90}}',30,1,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3)),(4,'ENTERPRISE','Enterprise','Para operações maiores e com necessidades específicas. Sob consulta.',NULL,'{"veiculos":"acima de 25","usuarios":"definidos pela consultoria","historico_dias":null,"recursos":["importar_planilha","exportar_planilha","auditoria"],"ciclos":null,"sob_consulta":true}',40,1,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3));
/*!40000 ALTER TABLE `subscription_plans` ENABLE KEYS */;


/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `company_id`, `role_id`, `full_name`, `email`, `password_hash`, `phone`, `active`, `must_change_password`, `receive_critical_alerts`, `receive_automatic_reports`, `failed_login_attempts`, `locked_until`, `last_login_at`, `totp_enabled`, `totp_secret_enc`, `totp_last_step`, `totp_enabled_at`, `created_at`, `updated_at`) VALUES (1,1,1,'Administrador LoadSense','admin@loadsense.local','$2b$12$tdEbXrApK6z6ob/JmfgkOeSdOdYa170QDeSWYS6A9JZsb0wNQTCKK',NULL,1,0,1,0,0,NULL,'2026-11-13 22:13:25.819',0,NULL,NULL,NULL,'2026-10-13 17:28:43.001','2026-11-13 22:13:25.819'),(2,1,2,'Marina Supervisora','supervisor@loadsense.local','$2b$12$tdEbXrApK6z6ob/JmfgkOeSdOdYa170QDeSWYS6A9JZsb0wNQTCKK',NULL,1,0,1,0,0,NULL,NULL,0,NULL,NULL,NULL,'2026-10-13 17:28:53.610','2026-11-13 22:12:15.507'),(3,1,3,'Carlos Operador','operador@loadsense.local','$2b$12$tdEbXrApK6z6ob/JmfgkOeSdOdYa170QDeSWYS6A9JZsb0wNQTCKK',NULL,1,0,1,0,0,NULL,NULL,0,NULL,NULL,NULL,'2026-10-13 17:28:53.611','2026-11-13 22:12:15.507');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;



/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_tracking_point_after_insert` AFTER INSERT ON `operation_tracking_points` FOR EACH ROW BEGIN
    DECLARE v_prev_state VARCHAR(30);
    DECLARE v_prev_stopped_since DATETIME(3);
    DECLARE v_prev_last_moving_at DATETIME(3);
    DECLARE v_prev_last_position_at DATETIME(3);
    DECLARE v_tracking_state VARCHAR(30);
    DECLARE v_stopped_since DATETIME(3);
    DECLARE v_last_moving_at DATETIME(3);
    DECLARE v_stop_threshold DECIMAL(8,2);
    DECLARE v_stop_minutes INT UNSIGNED;
    DECLARE v_delay_threshold INT UNSIGNED;
    DECLARE v_route_tolerance INT UNSIGNED;
    DECLARE v_tracking_alerts TINYINT;
    DECLARE v_route_alerts TINYINT;
    DECLARE v_planned_arrival DATETIME(3);
    DECLARE v_departed_at DATETIME(3);
    DECLARE v_delay_minutes INT;
    DECLARE v_stop_duration INT;
    DECLARE v_stop_key VARCHAR(190);

    SELECT
        MAX(tracking_state),
        MAX(stopped_since),
        MAX(last_moving_at),
        MAX(last_position_at)
      INTO
        v_prev_state,
        v_prev_stopped_since,
        v_prev_last_moving_at,
        v_prev_last_position_at
      FROM operation_tracking_status
     WHERE company_id = NEW.company_id
       AND operation_id = NEW.operation_id;

    
    IF v_prev_last_position_at IS NULL OR NEW.recorded_at >= v_prev_last_position_at THEN
        SET v_stop_threshold = COALESCE((
            SELECT stop_speed_threshold_kmh
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 1.00);

        SET v_stop_minutes = COALESCE((
            SELECT unplanned_stop_alert_minutes
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 15);

        SET v_delay_threshold = COALESCE((
            SELECT delivery_delay_alert_minutes
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 15);

        SET v_route_tolerance = COALESCE((
            SELECT route_deviation_tolerance_meters
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 500);

        SET v_tracking_alerts = COALESCE((
            SELECT tracking_alerts_enabled
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 1);

        SET v_route_alerts = COALESCE((
            SELECT route_deviation_alerts_enabled
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 1);

        SELECT planned_arrival_at, departed_at
          INTO v_planned_arrival, v_departed_at
          FROM weighing_operations
         WHERE company_id = NEW.company_id
           AND id = NEW.operation_id
         LIMIT 1;

        SET v_tracking_state = CASE
            WHEN NEW.progress_percent IS NOT NULL AND NEW.progress_percent >= 100
                THEN 'ARRIVED'
            WHEN NEW.speed_kmh IS NOT NULL AND NEW.speed_kmh > v_stop_threshold
                THEN 'IN_TRANSIT'
            WHEN v_departed_at IS NULL AND COALESCE(NEW.progress_percent, 0) <= 0
                THEN 'NOT_STARTED'
            ELSE 'STOPPED'
        END;

        SET v_stopped_since = CASE
            WHEN v_tracking_state = 'STOPPED' AND v_prev_state = 'STOPPED'
                THEN COALESCE(v_prev_stopped_since, NEW.recorded_at)
            WHEN v_tracking_state = 'STOPPED'
                THEN NEW.recorded_at
            ELSE NULL
        END;

        SET v_last_moving_at = CASE
            WHEN v_tracking_state IN ('IN_TRANSIT', 'ARRIVED')
                THEN NEW.recorded_at
            ELSE v_prev_last_moving_at
        END;

        SET v_delay_minutes = CASE
            WHEN v_planned_arrival IS NOT NULL
             AND NEW.estimated_arrival_at IS NOT NULL
             AND NEW.estimated_arrival_at > v_planned_arrival
                THEN TIMESTAMPDIFF(MINUTE, v_planned_arrival, NEW.estimated_arrival_at)
            ELSE 0
        END;

        INSERT INTO operation_tracking_status (
            company_id,
            operation_id,
            tracking_state,
            stopped_since,
            last_moving_at,
            current_latitude,
            current_longitude,
            speed_kmh,
            heading_degrees,
            progress_percent,
            route_deviation_meters,
            estimated_arrival_at,
            delay_minutes,
            last_position_at
        ) VALUES (
            NEW.company_id,
            NEW.operation_id,
            v_tracking_state,
            v_stopped_since,
            v_last_moving_at,
            NEW.latitude,
            NEW.longitude,
            NEW.speed_kmh,
            NEW.heading_degrees,
            NEW.progress_percent,
            NEW.route_deviation_meters,
            NEW.estimated_arrival_at,
            GREATEST(v_delay_minutes, 0),
            NEW.recorded_at
        )
        ON DUPLICATE KEY UPDATE
            tracking_state = v_tracking_state,
            stopped_since = v_stopped_since,
            last_moving_at = v_last_moving_at,
            current_latitude = NEW.latitude,
            current_longitude = NEW.longitude,
            speed_kmh = NEW.speed_kmh,
            heading_degrees = NEW.heading_degrees,
            progress_percent = NEW.progress_percent,
            route_deviation_meters = NEW.route_deviation_meters,
            estimated_arrival_at = NEW.estimated_arrival_at,
            delay_minutes = GREATEST(v_delay_minutes, 0),
            last_position_at = NEW.recorded_at;

        
        IF v_tracking_state = 'IN_TRANSIT' AND v_departed_at IS NULL THEN
            UPDATE weighing_operations
               SET departed_at = COALESCE(departed_at, NEW.recorded_at)
             WHERE company_id = NEW.company_id
               AND id = NEW.operation_id;
            SET v_departed_at = NEW.recorded_at;
        END IF;

        
        IF v_tracking_state = 'ARRIVED' THEN
            UPDATE weighing_operations
               SET arrived_at = COALESCE(arrived_at, NEW.recorded_at)
             WHERE company_id = NEW.company_id
               AND id = NEW.operation_id;
        END IF;

        
        IF v_tracking_state = 'IN_TRANSIT'
           AND (v_prev_state IS NULL OR v_prev_state IN ('NOT_STARTED', 'SIGNAL_LOST')) THEN
            INSERT INTO operation_events (
                company_id, operation_id, event_type, device_id, event_data
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING_STARTED', NEW.device_id,
                JSON_OBJECT('recorded_at', NEW.recorded_at)
            );
        ELSEIF v_tracking_state = 'IN_TRANSIT' AND v_prev_state = 'STOPPED' THEN
            INSERT INTO operation_events (
                company_id, operation_id, event_type, device_id, event_data
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING_RESUMED', NEW.device_id,
                JSON_OBJECT('recorded_at', NEW.recorded_at)
            );
        ELSEIF v_tracking_state = 'STOPPED' AND COALESCE(v_prev_state, '') <> 'STOPPED' THEN
            INSERT INTO operation_events (
                company_id, operation_id, event_type, device_id, event_data
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING_STOPPED', NEW.device_id,
                JSON_OBJECT('recorded_at', NEW.recorded_at)
            );
        ELSEIF v_tracking_state = 'ARRIVED' AND COALESCE(v_prev_state, '') <> 'ARRIVED' THEN
            INSERT INTO operation_events (
                company_id, operation_id, event_type, device_id, event_data
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING_ARRIVED', NEW.device_id,
                JSON_OBJECT('recorded_at', NEW.recorded_at)
            );
        END IF;

        
        IF v_prev_state = 'SIGNAL_LOST' THEN
            UPDATE alerts
               SET state = 'RESOLVED',
                   resolved_at = CURRENT_TIMESTAMP(3),
                   resolution_notes = 'Sinal de rastreamento restabelecido automaticamente.'
             WHERE company_id = NEW.company_id
               AND operation_id = NEW.operation_id
               AND deduplication_key = CONCAT('TRACKING_SIGNAL_LOST:', NEW.operation_id)
               AND state IN ('OPEN', 'ACKNOWLEDGED');
        END IF;

        
        IF v_tracking_alerts = 1
           AND v_tracking_state = 'STOPPED'
           AND v_stopped_since IS NOT NULL
           AND v_departed_at IS NOT NULL THEN
            SET v_stop_duration = TIMESTAMPDIFF(MINUTE, v_stopped_since, NEW.recorded_at);
            IF v_stop_duration >= v_stop_minutes THEN
                SET v_stop_key = CONCAT(
                    'UNPLANNED_STOP:', NEW.operation_id, ':',
                    DATE_FORMAT(v_stopped_since, '%Y%m%d%H%i%s%f')
                );

                INSERT INTO alerts (
                    company_id, operation_id, alert_context, calculation_version,
                    alert_type, severity, state, source, deduplication_key,
                    title, message, context_json, detected_at
                ) VALUES (
                    NEW.company_id, NEW.operation_id, 'TRACKING', NULL,
                    'UNPLANNED_STOP', 'ATTENTION', 'OPEN', 'SYSTEM', v_stop_key,
                    'Parada não programada',
                    CONCAT('Veículo parado há aproximadamente ', v_stop_duration, ' minuto(s).'),
                    JSON_OBJECT(
                        'stopped_since', v_stopped_since,
                        'duration_minutes', v_stop_duration,
                        'latitude', NEW.latitude,
                        'longitude', NEW.longitude
                    ),
                    NEW.recorded_at
                )
                ON DUPLICATE KEY UPDATE
                    state = 'OPEN',
                    acknowledged_by_user_id = NULL,
                    acknowledged_at = NULL,
                    resolved_by_user_id = NULL,
                    resolved_at = NULL,
                    resolution_notes = NULL,
                    message = VALUES(message),
                    context_json = VALUES(context_json),
                    detected_at = VALUES(detected_at);
            END IF;
        END IF;

        
        IF v_prev_state = 'STOPPED'
           AND v_tracking_state = 'IN_TRANSIT'
           AND v_prev_stopped_since IS NOT NULL THEN
            SET v_stop_key = CONCAT(
                'UNPLANNED_STOP:', NEW.operation_id, ':',
                DATE_FORMAT(v_prev_stopped_since, '%Y%m%d%H%i%s%f')
            );
            UPDATE alerts
               SET state = 'RESOLVED',
                   resolved_at = CURRENT_TIMESTAMP(3),
                   resolution_notes = 'Veículo voltou a se movimentar.'
             WHERE company_id = NEW.company_id
               AND deduplication_key = v_stop_key
               AND state IN ('OPEN', 'ACKNOWLEDGED');
        END IF;

        
        IF v_tracking_alerts = 1
           AND v_planned_arrival IS NOT NULL
           AND v_delay_minutes >= v_delay_threshold
           AND v_tracking_state <> 'ARRIVED' THEN
            INSERT INTO alerts (
                company_id, operation_id, alert_context, calculation_version,
                alert_type, severity, state, source, deduplication_key,
                title, message, context_json, detected_at
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING', NULL,
                'DELIVERY_DELAY', 'ATTENTION', 'OPEN', 'SYSTEM',
                CONCAT('DELIVERY_DELAY:', NEW.operation_id),
                'Atraso na entrega',
                CONCAT('ETA atual indica atraso de aproximadamente ', v_delay_minutes, ' minuto(s).'),
                JSON_OBJECT(
                    'planned_arrival_at', v_planned_arrival,
                    'estimated_arrival_at', NEW.estimated_arrival_at,
                    'delay_minutes', v_delay_minutes
                ),
                NEW.recorded_at
            )
            ON DUPLICATE KEY UPDATE
                state = 'OPEN',
                acknowledged_by_user_id = NULL,
                acknowledged_at = NULL,
                resolved_by_user_id = NULL,
                resolved_at = NULL,
                resolution_notes = NULL,
                message = VALUES(message),
                context_json = VALUES(context_json),
                detected_at = VALUES(detected_at);
        ELSEIF v_tracking_state <> 'ARRIVED' THEN
            UPDATE alerts
               SET state = 'RESOLVED',
                   resolved_at = CURRENT_TIMESTAMP(3),
                   resolution_notes = 'ETA voltou a ficar dentro da tolerância planejada.'
             WHERE company_id = NEW.company_id
               AND operation_id = NEW.operation_id
               AND deduplication_key = CONCAT('DELIVERY_DELAY:', NEW.operation_id)
               AND state IN ('OPEN', 'ACKNOWLEDGED');
        END IF;

        
        IF v_tracking_alerts = 1
           AND v_route_alerts = 1
           AND NEW.route_deviation_meters IS NOT NULL
           AND NEW.route_deviation_meters > v_route_tolerance
           AND v_tracking_state <> 'ARRIVED' THEN
            INSERT INTO alerts (
                company_id, operation_id, alert_context, calculation_version,
                alert_type, severity, state, source, deduplication_key,
                title, message, context_json, detected_at
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING', NULL,
                'ROUTE_DEVIATION', 'ATTENTION', 'OPEN', 'SYSTEM',
                CONCAT('ROUTE_DEVIATION:', NEW.operation_id),
                'Desvio de rota detectado',
                CONCAT(
                    'Veículo está aproximadamente ', FORMAT(NEW.route_deviation_meters, 0),
                    ' m fora da rota de referência.'
                ),
                JSON_OBJECT(
                    'route_deviation_meters', NEW.route_deviation_meters,
                    'tolerance_meters', v_route_tolerance,
                    'latitude', NEW.latitude,
                    'longitude', NEW.longitude
                ),
                NEW.recorded_at
            )
            ON DUPLICATE KEY UPDATE
                state = 'OPEN',
                acknowledged_by_user_id = NULL,
                acknowledged_at = NULL,
                resolved_by_user_id = NULL,
                resolved_at = NULL,
                resolution_notes = NULL,
                message = VALUES(message),
                context_json = VALUES(context_json),
                detected_at = VALUES(detected_at);
        ELSEIF NEW.route_deviation_meters IS NOT NULL
           AND NEW.route_deviation_meters <= v_route_tolerance THEN
            UPDATE alerts
               SET state = 'RESOLVED',
                   resolved_at = CURRENT_TIMESTAMP(3),
                   resolution_notes = 'Veículo retornou à faixa de tolerância da rota.'
             WHERE company_id = NEW.company_id
               AND operation_id = NEW.operation_id
               AND deduplication_key = CONCAT('ROUTE_DEVIATION:', NEW.operation_id)
               AND state IN ('OPEN', 'ACKNOWLEDGED');
        END IF;

        
        IF v_tracking_state = 'ARRIVED' THEN
            UPDATE alerts
               SET state = 'RESOLVED',
                   resolved_at = CURRENT_TIMESTAMP(3),
                   resolution_notes = 'Transporte concluído/veículo chegou ao destino.'
             WHERE company_id = NEW.company_id
               AND operation_id = NEW.operation_id
               AND alert_context = 'TRACKING'
               AND alert_type IN (
                   'UNPLANNED_STOP', 'DELIVERY_DELAY', 'ROUTE_DEVIATION', 'TRACKING_SIGNAL_LOST'
               )
               AND state IN ('OPEN', 'ACKNOWLEDGED');
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_operations_before_insert` BEFORE INSERT ON `weighing_operations` FOR EACH ROW BEGIN
    DECLARE v_tolerance DECIMAL(8,3);
    DECLARE v_critical DECIMAL(8,3);
    DECLARE v_tare_tolerance DECIMAL(8,3);
    DECLARE v_registered_tare DECIMAL(14,3);
    DECLARE v_gross_limit DECIMAL(14,3);
    DECLARE v_payload_limit DECIMAL(14,3);
    DECLARE v_require_rfid TINYINT;
    DECLARE v_rfid_vehicle_id BIGINT UNSIGNED;

    IF NEW.operation_code IS NULL OR TRIM(NEW.operation_code) = '' THEN
        SET NEW.operation_code = CONCAT('PES-', UUID_SHORT());
    END IF;

    SELECT tolerance_percent,
           critical_limit_percent,
           tare_tolerance_percent,
           require_rfid
      INTO v_tolerance,
           v_critical,
           v_tare_tolerance,
           v_require_rfid
      FROM company_settings
     WHERE company_id = NEW.company_id;

    SELECT registered_tare_kg,
           gross_weight_limit_kg,
           payload_limit_kg
      INTO v_registered_tare,
           v_gross_limit,
           v_payload_limit
      FROM vehicles
     WHERE company_id = NEW.company_id
       AND id = NEW.vehicle_id;

    SET NEW.tolerance_percent_snapshot = v_tolerance;
    SET NEW.critical_limit_snapshot = v_critical;
    SET NEW.tare_tolerance_snapshot = v_tare_tolerance;
    SET NEW.registered_tare_snapshot_kg = v_registered_tare;
    SET NEW.gross_limit_snapshot_kg = v_gross_limit;
    SET NEW.payload_limit_snapshot_kg = v_payload_limit;

    IF v_require_rfid = 1 AND NEW.rfid_tag_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A empresa exige uma etiqueta RFID na operação.';
    END IF;

    IF NEW.rfid_tag_id IS NOT NULL THEN
        SELECT MAX(vehicle_id)
          INTO v_rfid_vehicle_id
          FROM rfid_tags
         WHERE company_id = NEW.company_id
           AND id = NEW.rfid_tag_id
           AND active = 1;

        IF v_rfid_vehicle_id IS NULL OR v_rfid_vehicle_id <> NEW.vehicle_id THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'A etiqueta RFID não está ativa para o veículo informado.';
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_operation_created_event` AFTER INSERT ON `weighing_operations` FOR EACH ROW BEGIN
    INSERT INTO operation_events (
        company_id,
        operation_id,
        event_type,
        user_id,
        event_data
    ) VALUES (
        NEW.company_id,
        NEW.id,
        'CREATED',
        NEW.created_by_user_id,
        JSON_OBJECT(
            'operation_code', NEW.operation_code,
            'movement_type', NEW.movement_type,
            'weighing_method', NEW.weighing_method
        )
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_operations_before_update` BEFORE UPDATE ON `weighing_operations` FOR EACH ROW BEGIN
    DECLARE v_rfid_vehicle_id BIGINT UNSIGNED;
    DECLARE v_registered_tare DECIMAL(14,3);
    DECLARE v_gross_limit DECIMAL(14,3);
    DECLARE v_payload_limit DECIMAL(14,3);

    IF NEW.company_id <> OLD.company_id THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A empresa de uma operação não pode ser alterada.';
    END IF;

    SET NEW.row_version = OLD.row_version + 1;

    IF NEW.vehicle_id <> OLD.vehicle_id THEN
        SELECT registered_tare_kg,
               gross_weight_limit_kg,
               payload_limit_kg
          INTO v_registered_tare,
               v_gross_limit,
               v_payload_limit
          FROM vehicles
         WHERE company_id = NEW.company_id
           AND id = NEW.vehicle_id;

        SET NEW.registered_tare_snapshot_kg = v_registered_tare;
        SET NEW.gross_limit_snapshot_kg = v_gross_limit;
        SET NEW.payload_limit_snapshot_kg = v_payload_limit;
    END IF;

    IF (
        NOT (NEW.rfid_tag_id <=> OLD.rfid_tag_id)
        OR NEW.vehicle_id <> OLD.vehicle_id
    ) AND NEW.rfid_tag_id IS NOT NULL THEN
        SELECT MAX(vehicle_id)
          INTO v_rfid_vehicle_id
          FROM rfid_tags
         WHERE company_id = NEW.company_id
           AND id = NEW.rfid_tag_id
           AND active = 1;

        IF v_rfid_vehicle_id IS NULL OR v_rfid_vehicle_id <> NEW.vehicle_id THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'A etiqueta RFID não está ativa para o veículo informado.';
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_readings_before_insert` BEFORE INSERT ON `weighing_readings` FOR EACH ROW BEGIN
    DECLARE v_allow_manual TINYINT;
    DECLARE v_require_reason TINYINT;
    DECLARE v_operation_state VARCHAR(30);

    SELECT allow_manual_readings, require_manual_reason
      INTO v_allow_manual, v_require_reason
      FROM company_settings
     WHERE company_id = NEW.company_id;

    SELECT state
      INTO v_operation_state
      FROM weighing_operations
     WHERE company_id = NEW.company_id
       AND id = NEW.operation_id;

    IF v_operation_state IN ('COMPLETED', 'CANCELLED') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Não é possível registrar leitura em operação concluída ou cancelada.';
    END IF;

    IF NEW.source = 'DEVICE' AND NEW.device_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Uma leitura automática deve informar o dispositivo de origem.';
    END IF;

    IF NEW.source = 'MANUAL' THEN
        IF v_allow_manual = 0 THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Leituras manuais estão desabilitadas para esta empresa.';
        END IF;

        IF NEW.created_by_user_id IS NULL THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Uma leitura manual deve informar o usuário responsável.';
        END IF;

        IF v_require_reason = 1
           AND (NEW.manual_reason IS NULL OR TRIM(NEW.manual_reason) = '') THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'O motivo da leitura manual é obrigatório.';
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_readings_before_update` BEFORE UPDATE ON `weighing_readings` FOR EACH ROW BEGIN
    DECLARE v_allow_manual TINYINT;
    DECLARE v_require_reason TINYINT;

    SELECT allow_manual_readings, require_manual_reason
      INTO v_allow_manual, v_require_reason
      FROM company_settings
     WHERE company_id = NEW.company_id;

    IF NEW.source = 'DEVICE' AND NEW.device_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Uma leitura automática deve informar o dispositivo de origem.';
    END IF;

    IF NEW.source = 'MANUAL' THEN
        IF v_allow_manual = 0 THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Leituras manuais estão desabilitadas para esta empresa.';
        END IF;

        IF NEW.created_by_user_id IS NULL THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Uma leitura manual deve informar o usuário responsável.';
        END IF;

        IF v_require_reason = 1
           AND (NEW.manual_reason IS NULL OR TRIM(NEW.manual_reason) = '') THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'O motivo da leitura manual é obrigatório.';
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

