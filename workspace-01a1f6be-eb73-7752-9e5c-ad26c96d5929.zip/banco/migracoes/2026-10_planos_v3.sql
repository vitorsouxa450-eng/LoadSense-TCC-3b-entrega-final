
ALTER TABLE company_subscriptions
  ADD COLUMN limite_usuarios int unsigned DEFAULT NULL
  COMMENT 'Número de usuários definido pela consultoria; NULL usa o padrão do plano'
  AFTER cancellation_reason;

START TRANSACTION;

UPDATE subscription_plans
   SET code = 'ESSENCIAL', name = 'Essencial', description = 'Para começar a controlar a operação.',
       monthly_price_brl = 149.90, sort_order = 10, active = 1,
       features_json = '{"veiculos":3,"usuarios":"definidos pela consultoria","historico_dias":90,"recursos":[],"ciclos":{"MENSAL":149.90,"TRIMESTRAL":427.90,"ANUAL":1529.90}}'
 WHERE code = 'BASIC';

UPDATE subscription_plans
   SET code = 'PROFISSIONAL', name = 'Profissional', description = 'Para parar de digitar e não perder histórico.',
       monthly_price_brl = 349.90, sort_order = 20, active = 1,
       features_json = '{"veiculos":10,"usuarios":"definidos pela consultoria","historico_dias":null,"recursos":["importar_planilha","exportar_planilha"],"ciclos":{"MENSAL":349.90,"TRIMESTRAL":997.90,"ANUAL":3569.90}}'
 WHERE code = 'BASIC_PLUS';

UPDATE subscription_plans
   SET code = 'AVANCADO', name = 'Avançado', description = 'Para quem responde a auditoria e fiscalização.',
       monthly_price_brl = 749.90, sort_order = 30, active = 1,
       features_json = '{"veiculos":25,"usuarios":"definidos pela consultoria","historico_dias":null,"recursos":["importar_planilha","exportar_planilha","auditoria"],"ciclos":{"MENSAL":749.90,"TRIMESTRAL":2139.90,"ANUAL":7649.90}}'
 WHERE code = 'PREMIUM';

UPDATE subscription_plans
   SET name = 'Enterprise', description = 'Para operações maiores e com necessidades específicas. Sob consulta.', monthly_price_brl = NULL, sort_order = 40, active = 1,
       features_json = '{"veiculos":"acima de 25","usuarios":"definidos pela consultoria","historico_dias":null,"recursos":["importar_planilha","exportar_planilha","auditoria"],"ciclos":null,"sob_consulta":true}'
 WHERE code = 'ENTERPRISE';

INSERT INTO subscription_plans (code, name, description, monthly_price_brl, features_json, sort_order, active)
SELECT 'ENTERPRISE', 'Enterprise', 'Para operações maiores e com necessidades específicas. Sob consulta.', NULL,
       '{"veiculos":"acima de 25","usuarios":"definidos pela consultoria","historico_dias":null,"recursos":["importar_planilha","exportar_planilha","auditoria"],"ciclos":null,"sob_consulta":true}', 40, 1
  FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM subscription_plans WHERE code = 'ENTERPRISE');

COMMIT;
