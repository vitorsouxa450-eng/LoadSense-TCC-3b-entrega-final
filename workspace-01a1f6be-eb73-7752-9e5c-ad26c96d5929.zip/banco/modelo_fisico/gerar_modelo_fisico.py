import pathlib
import re
from docx import Document
from docx.enum.section import WD_ORIENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, Cm

RAIZ = pathlib.Path(__file__).resolve().parent.parent.parent  # pasta do workspace
SQL = (RAIZ / "banco" / "LoadSense_Banco_MySQL_Workbench.sql").read_text(encoding="utf-8", errors="replace")
SAIDA = RAIZ / "Modelo_fisico_banco_LoadSense.docx"

MARCADORES = re.compile(
    r"\s(NOT NULL|NULL|DEFAULT|AUTO_INCREMENT|ON UPDATE|COMMENT|CHARACTER SET|COLLATE|GENERATED|VIRTUAL|STORED)\b",
    re.I,
)


def ler_tabelas():
    tabelas = {}
    for m in re.finditer(r"CREATE TABLE `(\w+)` \((.*?)\n\)\s*ENGINE", SQL, re.S):
        nome, corpo = m.group(1), m.group(2)
        colunas, pk, uks, fks, idx = [], [], [], [], []
        for bruto in corpo.split("\n"):
            linha = bruto.strip().rstrip(",")
            if not linha:
                continue
            up = linha.upper()
            if linha.startswith("`"):
                mc = re.match(r"`(\w+)` (.*)", linha)
                if mc:
                    colunas.append((mc.group(1), mc.group(2)))
            elif up.startswith("PRIMARY KEY"):
                pk = re.findall(r"`(\w+)`", linha)
            elif up.startswith("UNIQUE KEY"):
                mu = re.match(r"UNIQUE KEY `(\w+)`", linha)
                uks.append((mu.group(1), re.findall(r"`(\w+)`", re.search(r"\((.*?)\)", linha).group(1))))
            elif up.startswith("KEY") or up.startswith("INDEX"):
                mi = re.match(r"KEY `(\w+)` \((.*?)\)", linha)
                if mi:
                    idx.append((mi.group(1), re.findall(r"`(\w+)`", mi.group(2))))
            elif up.startswith("CONSTRAINT") and "FOREIGN KEY" in up:
                mf = re.search(r"FOREIGN KEY \((.*?)\) REFERENCES `(\w+)` \((.*?)\)", linha)
                if mf:
                    fks.append((re.findall(r"`(\w+)`", mf.group(1)), mf.group(2), re.findall(r"`(\w+)`", mf.group(3))))
        tabelas[nome] = {"cols": colunas, "pk": pk, "uk": uks, "fk": fks, "idx": idx}
    return tabelas


def separar(definicao):
    base = " " + definicao
    m = MARCADORES.search(base)
    if not m:
        return definicao.strip(), ""
    return base[: m.start()].strip(), base[m.start():].strip()


def atributos(resto):
    nulo = "Não" if re.search(r"NOT NULL", resto, re.I) else "Sim"
    padrao = ""
    md = re.search(r"DEFAULT ('(?:[^']*)'|\S+)", resto, re.I)
    if md:
        padrao = md.group(1).strip("'")
    extras = []
    if re.search(r"AUTO_INCREMENT", resto, re.I):
        extras.append("auto incremento")
    mu = re.search(r"ON UPDATE (\w+)", resto, re.I)
    if mu:
        extras.append(f"atualiza ao alterar ({mu.group(1)})")
    return nulo, padrao, "; ".join(extras)


def chave_coluna(nome, t):
    partes = []
    if nome in t["pk"]:
        partes.append("PK")
    for cols, pai, _ in t["fk"]:
        if nome in cols:
            partes.append(f"FK → {pai}" + (" (composta)" if len(cols) > 1 else ""))
    for _, cols in t["uk"]:
        if nome in cols and len(cols) == 1:
            partes.append("UK")
    return ", ".join(dict.fromkeys(partes))


def sombrear(celula, cor):
    tc = celula._tc.get_or_add_tcPr()
    sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear")
    sh.set(qn("w:color"), "auto")
    sh.set(qn("w:fill"), cor)
    tc.append(sh)


def repetir_cabecalho(linha):
    trPr = linha._tr.get_or_add_trPr()
    el = OxmlElement("w:tblHeader")
    el.set(qn("w:val"), "true")
    trPr.append(el)


def tabela(doc, cabecalho, linhas, larguras):
    tb = doc.add_table(rows=1, cols=len(cabecalho))
    tb.style = "Table Grid"
    tb.autofit = False
    for i, texto in enumerate(cabecalho):
        c = tb.rows[0].cells[i]
        c.width = larguras[i]
        r = c.paragraphs[0].add_run(texto)
        r.bold = True
        r.font.size = Pt(8)
        sombrear(c, "D9E2F3")
    repetir_cabecalho(tb.rows[0])
    for linha in linhas:
        cells = tb.add_row().cells
        for i, texto in enumerate(linha):
            cells[i].width = larguras[i]
            r = cells[i].paragraphs[0].add_run(str(texto))
            r.font.size = Pt(8)
    return tb


def main():
    tabelas = ler_tabelas()
    doc = Document()
    sec = doc.sections[0]
    sec.orientation = WD_ORIENT.LANDSCAPE
    sec.page_width, sec.page_height = sec.page_height, sec.page_width
    for lado in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, lado, Cm(1.8))
    doc.styles["Normal"].font.name = "Arial"
    doc.styles["Normal"].font.size = Pt(10)

    doc.add_heading("Modelo físico do banco de dados LoadSense", level=1)
    doc.add_heading("Resumo das tabelas", level=2)
    linhas = [
        (nome, len(t["cols"]), ", ".join(t["pk"]), len(t["fk"]), len(t["uk"]), len(t["idx"]))
        for nome, t in tabelas.items()
    ]
    tabela(
        doc,
        ["Tabela", "Colunas", "Chave primária", "Chaves estrangeiras", "Chaves únicas", "Índices"],
        linhas,
        [Cm(6.5), Cm(2), Cm(5), Cm(3.5), Cm(3), Cm(2.5)],
    )

    doc.add_page_break()
    doc.add_heading("Dicionário de dados por tabela", level=2)
    for nome, t in tabelas.items():
        doc.add_heading(nome, level=3)
        linhas = []
        for col, definicao in t["cols"]:
            tipo, resto = separar(definicao)
            nulo, padrao, extras = atributos(resto)
            linhas.append((col, tipo, nulo, padrao, chave_coluna(col, t), extras))
        tabela(
            doc,
            ["Coluna", "Tipo MySQL", "Nulo", "Padrão", "Chave", "Observação"],
            linhas,
            [Cm(5.5), Cm(4.5), Cm(1.5), Cm(3.5), Cm(5.5), Cm(6)],
        )
        chaves = []
        for uname, cols in t["uk"]:
            if len(cols) > 1:
                chaves.append((uname, "Chave única composta", ", ".join(cols), "-"))
        for cols, pai, refs in t["fk"]:
            if len(cols) > 1:
                chaves.append(("-", "Chave estrangeira composta", ", ".join(cols), f"{pai} ({', '.join(refs)})"))
        for iname, cols in t["idx"]:
            chaves.append((iname, "Índice", ", ".join(cols), "-"))
        if chaves:
            rotulo = doc.add_paragraph()
            rotulo.paragraph_format.space_before = Pt(8)
            rotulo.paragraph_format.keep_with_next = True
            r = rotulo.add_run(f"Chaves compostas e índices de {nome}")
            r.bold = True
            r.font.size = Pt(9)
            tabela(
                doc,
                ["Nome", "Tipo", "Colunas", "Referência"],
                chaves,
                [Cm(7), Cm(5.5), Cm(9), Cm(7.5)],
            )

    doc.save(SAIDA)
    print("gerado:", SAIDA)


if __name__ == "__main__":
    main()
