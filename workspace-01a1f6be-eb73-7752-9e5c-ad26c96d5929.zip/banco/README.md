# Banco de dados — LoadSense

Banco MySQL 8.0 (testado com o MySQL 8.0.40). Nome do banco: `loadsense`.

## Conteúdo

| Caminho | O que é |
| --- | --- |
| `LoadSense_Banco_MySQL_Workbench.sql` | Schema completo: tabelas, views, procedures, triggers e dados-base. **Fonte de verdade do schema.** |
| `db/07_migracao_totp.sql` | Migração para bancos antigos: colunas do segundo fator (TOTP) em `users`. Executar uma única vez. |
| `db/08_migracao_dados_pessoais.sql` | Migração manual do CPF/CNH/telefone cifrados (LGPD). A API também faz isso sozinha ao iniciar; o script serve para quem prefere rodar à mão. |
| `db/01_demo_seed.sql` | Dados de demonstração (empresa `loadsense-demo`, usuários, veículos, motoristas, rotas, posto). |
| `db/04_diagnostico.sql` | 25 verificações de integridade (órfãos, constraints, índices). |
| `db/05_limpeza_orfaos.sql` | Remove órfãos de execuções antigas de teste (com contagem antes/depois). |
| `db/06_ajustes_sugeridos.sql` | Ajustes propostos na revisão do backend (ver relatório). |

## Banco de demonstração (um comando)

Recria o banco `loadsense` do zero, com schema, dados de demonstração e 30 dias de operações:

```bash
node banco/ferramentas/criar-banco-demonstracao.mjs --sim
```

O `--sim` é obrigatório porque o comando apaga o banco atual. Os passos abaixo fazem o mesmo à mão.

## Banco de entrega (sem dados de demonstração)

```bash
node banco/ferramentas/criar-banco-entrega.mjs --sim
```

Recria o banco `loadsense` só com o schema, uma balança (`BAL-01`) em cada empresa e as contas de acesso (`contas-entrega.mjs`): `admin@` e `admin.essencial@`, `admin.profissional@`, `admin.avancado@`, senha `LoadSense@2026`. Não há veículos, motoristas, rotas, operações nem alertas: eles são cadastrados pelo sistema. Testado no MySQL 8.0.40.

## Ordem para preparar o banco

```bash
# 1) criar o banco e importar o schema (o arquivo cria o banco loadsense e os dados-base)
mysql -u root -p --default-character-set=utf8mb4 < LoadSense_Banco_MySQL_Workbench.sql

# 2) dados de demonstração
mysql -u root -p --default-character-set=utf8mb4 loadsense < db/01_demo_seed.sql

# 3) histórico de pesagens e rastreamento para os gráficos (usa a API/procedures)
cd ../api && LS_DB_USER=root LS_DB_PASSWORD=... node server/scripts/seed-demo.mjs --dias 30
```

Sem o passo 3 o painel mostra poucos dados. Para regenerar só os dados de demonstração:
`node server/scripts/seed-demo.mjs --limpar` seguido de novo seed.

## Verificar

```bash
mysql -u root -p --default-character-set=utf8mb4 loadsense < db/04_diagnostico.sql
```

Esperado: todas as verificações em `0`, exceto a `11b`, que é informativa (alertas resolvidos automaticamente
pelo trigger de rastreamento não têm usuário responsável — comportamento esperado, ver relatório).

## Acesso padrão

| Usuário | Papel | Senha |
| --- | --- | --- |
| admin@loadsense.local | Administrador | LoadSense@2026 |
