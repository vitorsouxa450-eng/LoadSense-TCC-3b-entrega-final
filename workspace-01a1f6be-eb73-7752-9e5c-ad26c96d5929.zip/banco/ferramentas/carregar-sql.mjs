import { readFileSync } from "node:fs";
import { createRequire } from "node:module";

const require = createRequire(new URL("../../api/package.json", import.meta.url));
const mysql = require("mysql2/promise");

const args = process.argv.slice(2);
const posDb = args.indexOf("--db");
const arquivo = args.find((a, i) => !a.startsWith("--") && i !== (posDb >= 0 ? posDb + 1 : -1));
if (!arquivo) {
  console.error("Uso: node carregar-sql.mjs arquivo.sql [--db nome]");
  process.exit(2);
}
const banco = posDb >= 0 ? args[posDb + 1] : null;

function dividir(texto) {
  const comandos = [];
  let delimitador = ";";
  let buffer = "";
  for (const linha of texto.split(/\r?\n/)) {
    const m = /^\s*DELIMITER\s+(\S+)\s*$/i.exec(linha);
    if (m && buffer.trim() === "") {
      delimitador = m[1];
      continue;
    }
    if (buffer.trim() === "" && /^\s*(--|#|$)/.test(linha)) continue;
    buffer += linha + "\n";
    const t = buffer.trimEnd();
    if (t.endsWith(delimitador)) {
      const corpo = t.slice(0, t.length - delimitador.length).trim();
      if (corpo) comandos.push(corpo);
      buffer = "";
    }
  }
  if (buffer.trim()) comandos.push(buffer.trim());
  return comandos;
}

const conexao = await mysql.createConnection({
  host: process.env.LS_DB_HOST ?? "127.0.0.1",
  port: Number(process.env.LS_DB_PORT ?? 3306),
  user: process.env.LS_DB_USER ?? "root",
  password: process.env.LS_DB_PASSWORD ?? "",
  charset: "utf8mb4",
  multipleStatements: false,
  ...(banco ? { database: banco } : {}),
});

const comandos = dividir(readFileSync(arquivo, "utf8"));
let n = 0;
for (const c of comandos) {
  try {
    await conexao.query(c);
    n += 1;
  } catch (erro) {
    console.error(`Falha no comando ${n + 1}: ${erro.message}\n${c.slice(0, 200)}`);
    await conexao.end();
    process.exit(1);
  }
}
await conexao.end();
console.log(`${n} comandos executados de ${arquivo}`);
