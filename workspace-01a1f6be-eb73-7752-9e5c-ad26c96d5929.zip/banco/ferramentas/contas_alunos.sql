USE loadsense;

INSERT INTO users (company_id, role_id, full_name, email, password_hash, must_change_password, active)
SELECT company_id, role_id, CONCAT('Aluno Teste ', n), CONCAT('teste', n, '@loadsense.local'), password_hash, 0, 1
FROM users, (SELECT 1 n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5) k
WHERE email = 'admin@loadsense.local';

SELECT id, email, role_id, must_change_password, active FROM users ORDER BY id;
