SET NAMES utf8mb4;

INSERT INTO route_waypoints (company_id, route_id, sequence_number, waypoint_type, label, latitude, longitude)
SELECT r.company_id, r.id, 1, 'ORIGIN', r.origin,
       CASE
         WHEN r.origin LIKE 'Taboão%' THEN -23.5861
         WHEN r.origin LIKE 'Santos%' THEN -23.9608
         ELSE -23.5505
       END,
       CASE
         WHEN r.origin LIKE 'Taboão%' THEN -46.8200
         WHEN r.origin LIKE 'Santos%' THEN -46.3336
         ELSE -46.6333
       END
  FROM routes r
 WHERE NOT EXISTS (SELECT 1 FROM route_waypoints w WHERE w.route_id = r.id);

INSERT INTO route_waypoints (company_id, route_id, sequence_number, waypoint_type, label, latitude, longitude)
SELECT r.company_id, r.id, 2, 'DESTINATION', r.destination,
       CASE
         WHEN r.destination LIKE 'Campinas%' THEN -22.9099
         WHEN r.destination LIKE 'Sorocaba%' THEN -23.5015
         WHEN r.destination LIKE 'São José dos Campos%' THEN -23.1896
         WHEN r.destination LIKE 'Santos%' THEN -23.9608
         WHEN r.destination LIKE 'Taboão%' THEN -23.5861
         ELSE -23.5505
       END,
       CASE
         WHEN r.destination LIKE 'Campinas%' THEN -47.0626
         WHEN r.destination LIKE 'Sorocaba%' THEN -47.4526
         WHEN r.destination LIKE 'São José dos Campos%' THEN -45.8841
         WHEN r.destination LIKE 'Santos%' THEN -46.3336
         WHEN r.destination LIKE 'Taboão%' THEN -46.8200
         ELSE -46.6333
       END
  FROM routes r
 WHERE r.id IN (SELECT w.route_id FROM route_waypoints w WHERE w.sequence_number = 1)
   AND NOT EXISTS (SELECT 1 FROM route_waypoints w WHERE w.route_id = r.id AND w.sequence_number = 2);
