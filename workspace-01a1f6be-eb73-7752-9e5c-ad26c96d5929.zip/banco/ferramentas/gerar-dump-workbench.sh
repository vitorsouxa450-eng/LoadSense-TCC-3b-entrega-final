#!/usr/bin/env bash
# Regenera banco/LoadSense_Banco_MySQL_Workbench.sql a partir do MySQL 8.0 em execução.
# O arquivo tem estrutura (tabelas, views, procedures), triggers e os dados da empresa que o seed
# espera encontrar (empresa, unidade, perfis, permissões, planos, usuários). Histórico e cadastros de
# demonstração (operações, pesagens, alertas, rastreio, veículos, motoristas, rotas) ficam de fora:
# quem cria tudo isso é banco/ferramentas/criar-banco-demonstracao.mjs --sim (via 01_demo_seed.sql).
# Uso (na raiz do projeto, com o MySQL 8.0 no ar e o banco "loadsense" carregado):
#   bash banco/ferramentas/gerar-dump-workbench.sh
set -euo pipefail

RAIZ="$(cd "$(dirname "$0")/../.." && pwd)"
DB="/var/tmp/ls-mysql"
MYSQLDUMP="$DB/base/bin/mysqldump"
LIBS="$DB/libs/usr/lib/x86_64-linux-gnu"
export LD_LIBRARY_PATH="$LIBS:${LD_LIBRARY_PATH:-}"
SAIDA="$RAIZ/banco/LoadSense_Banco_MySQL_Workbench.sql"

# Tabelas que NÃO entram nos dados do dump: histórico (operações, pesagens, alertas, rastreio, auditoria)
# e cadastros de demonstração que o 01_demo_seed.sql já cria (veículos, motoristas, rotas, dispositivos...).
EXCLUIDAS=" alerts audit_logs auth_sessions generated_reports operation_attachments operation_events \
operation_tracking_points operation_tracking_status password_reset_tokens weighing_operations weighing_readings \
user_devices legal_acceptances company_requests cargo_products company_subscriptions device_calibrations \
devices drivers legal_documents rfid_tags route_waypoints routes user_app_preferences vehicles weighing_stations "

TODAS=$("$DB/base/bin/mysql" -h127.0.0.1 -uroot -N -e \
  "SELECT table_name FROM information_schema.tables WHERE table_schema='loadsense' AND table_type='BASE TABLE' ORDER BY table_name" loadsense)
BASE=()
for t in $TODAS; do
  case "$EXCLUIDAS" in *" $t "*) ;; *) BASE+=("$t") ;; esac
done

CABECALHO="$RAIZ/banco/.dump-cabecalho.tmp"
cat > "$CABECALHO" <<'EOF'
-- ============================================================================
-- LoadSense — banco de dados (MySQL 8.0 / MySQL Workbench)
-- ----------------------------------------------------------------------------
-- Contém: estrutura (tabelas, views e procedures), triggers e os dados da empresa
-- (empresa, unidade, perfis, permissões, planos e usuários).
-- Não contém cadastros de demonstração (veículos, motoristas, rotas, dispositivos),
-- operações, pesagens, alertas nem rastreio: quem cria isso é
-- banco/ferramentas/criar-banco-demonstracao.mjs --sim.
--
-- Como usar no MySQL Workbench:
--   1) Server > Data Import > Import from Self-Contained File, escolha este
--      arquivo e clique em "Start Import", ou
--   2) File > Open SQL Script, abra este arquivo e clique no raio (Execute).
--   O script cria o banco "loadsense" (apaga o existente, se houver).
--
-- Login de demonstração (senha igual para todos): LoadSense@2026
--   admin@loadsense.local · supervisor@loadsense.local · operador@loadsense.local
-- ============================================================================

EOF

COMUM=(-h127.0.0.1 -uroot --no-tablespaces --set-gtid-purged=OFF --default-character-set=utf8mb4)

{
  cat "$CABECALHO"
  "$MYSQLDUMP" "${COMUM[@]}" --databases loadsense --no-data --skip-triggers --routines --events \
    --add-drop-database --add-drop-table
  echo
  echo "USE \`loadsense\`;"
  echo
  "$MYSQLDUMP" "${COMUM[@]}" --no-create-info --skip-triggers --complete-insert --skip-add-locks loadsense "${BASE[@]}"
  echo
  # triggers de todas as tabelas (inclusive as transacionais), depois dos dados
  "$MYSQLDUMP" "${COMUM[@]}" --no-create-info --no-data --triggers loadsense $TODAS
} > "$SAIDA.novo"

rm -f "$CABECALHO"
mv "$SAIDA.novo" "$SAIDA"
echo "Dump gerado: $SAIDA ($(wc -c < "$SAIDA") bytes)"
echo "Tabelas com dados-base: ${#BASE[@]}"
