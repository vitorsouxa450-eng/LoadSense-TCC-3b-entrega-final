#!/usr/bin/env bash
# Backup do banco LoadSense com mysqldump (compactado). Guarda os últimos 14 dias.
#
# Uso:
#   LS_DB_USER=root LS_DB_PASSWORD=... bash banco/ferramentas/backup.sh
# Variáveis (opcionais): LS_DB_HOST (127.0.0.1), LS_DB_PORT (3306), LS_DB_NAME (loadsense),
#                        LS_BACKUP_DIR (~/backups/loadsense), LS_BACKUP_DIAS (14)
#
# Agendamento sugerido (diário, 02:30) no Linux:  30 2 * * * cd /caminho/do/projeto && bash banco/ferramentas/backup.sh
set -euo pipefail

HOST="${LS_DB_HOST:-127.0.0.1}"
PORTA="${LS_DB_PORT:-3306}"
BANCO="${LS_DB_NAME:-loadsense}"
USUARIO="${LS_DB_USER:?Defina LS_DB_USER}"
DESTINO="${LS_BACKUP_DIR:-$HOME/backups/loadsense}"
DIAS="${LS_BACKUP_DIAS:-14}"

mkdir -p "$DESTINO"
ARQUIVO="$DESTINO/${BANCO}-$(date +%Y%m%d-%H%M%S).sql.gz"

# a senha vai por variável de ambiente (MYSQL_PWD), não aparece na lista de processos
MYSQL_PWD="${LS_DB_PASSWORD:-}" mysqldump \
  --host="$HOST" --port="$PORTA" --user="$USUARIO" \
  --single-transaction --routines --triggers --events --default-character-set=utf8mb4 \
  "$BANCO" | gzip -9 > "$ARQUIVO"

# confere que o arquivo não está vazio antes de apagar os antigos
if [ ! -s "$ARQUIVO" ]; then
  echo "Backup falhou: arquivo vazio ($ARQUIVO)" >&2
  exit 1
fi

find "$DESTINO" -name "${BANCO}-*.sql.gz" -mtime +"$DIAS" -delete
echo "Backup gerado: $ARQUIVO ($(du -h "$ARQUIVO" | cut -f1))"
