import re, sys

src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding="utf-8").read()

# colunas por tabela (ordem do CREATE TABLE) e colunas geradas
cols, geradas = {}, {}
for m in re.finditer(r"CREATE TABLE `(\w+)` \((.*?)\n\) ENGINE", s, re.S):
    t, corpo = m.group(1), m.group(2)
    lista = []
    for linha in corpo.split("\n"):
        linha = linha.strip()
        mm = re.match(r"`(\w+)` ", linha)
        if mm:
            lista.append(mm.group(1))
            if "GENERATED ALWAYS" in linha:
                geradas.setdefault(t, set()).add(mm.group(1))
    cols[t] = lista


def parse_tuples(texto):
    """Separa as tuplas (...) de um VALUES, respeitando strings SQL."""
    tuplas, i, n = [], 0, len(texto)
    while i < n:
        if texto[i] != "(":
            i += 1
            continue
        depth, j, emstr, campos, atual = 0, i, False, [], ""
        while j < n:
            c = texto[j]
            if emstr:
                atual += c
                if c == "\\" and j + 1 < n:
                    atual += texto[j + 1]
                    j += 2
                    continue
                if c == "'":
                    if j + 1 < n and texto[j + 1] == "'":
                        atual += "'"
                        j += 2
                        continue
                    emstr = False
            elif c == "'":
                emstr = True
                atual += c
            elif c == "(":
                depth += 1
                if depth > 1:
                    atual += c
            elif c == ")":
                depth -= 1
                if depth == 0:
                    campos.append(atual.strip())
                    break
                atual += c
            elif c == "," and depth == 1:
                campos.append(atual.strip())
                atual = ""
            else:
                atual += c
            j += 1
        tuplas.append(campos)
        i = j + 1
    return tuplas


out, pos, feitos = [], 0, 0
for m in re.finditer(r"INSERT INTO `(\w+)` VALUES\s", s):
    t = m.group(1)
    if t not in geradas:
        continue
    fim = s.index(";\n", m.end())
    tuplas = parse_tuples(s[m.end():fim])
    idx = {cols[t].index(g) for g in geradas[t]}
    manter = [c for c in cols[t] if c not in geradas[t]]
    novas = []
    for tp in tuplas:
        assert len(tp) == len(cols[t]), (t, len(tp), len(cols[t]))
        novas.append("(" + ",".join(v for k, v in enumerate(tp) if k not in idx) + ")")
    out.append(s[pos:m.start()])
    out.append("INSERT INTO `%s` (%s) VALUES\n%s" % (t, ",".join("`%s`" % c for c in manter), ",\n".join(novas)))
    pos = fim
    feitos += 1
out.append(s[pos:])
open(dst, "w", encoding="utf-8").write("".join(out))
print("inserts ajustados:", feitos, "| geradas:", {k: sorted(v) for k, v in geradas.items()})
