import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import fs from "node:fs";

const RAIZ = join(dirname(fileURLToPath(import.meta.url)), "..", "..");
const require = createRequire(join(RAIZ, "api", "package.json"));
const mysql = require("mysql2/promise");
const modelo = JSON.parse(fs.readFileSync(join(RAIZ, "api", "server", "dados", "modelo-empresa.json"), "utf8"));

const conexao = await mysql.createConnection({
  host: process.env.LS_DB_HOST ?? "127.0.0.1",
  port: Number(process.env.LS_DB_PORT ?? 3306),
  user: process.env.LS_DB_USER ?? "root",
  password: process.env.LS_DB_PASSWORD ?? "",
  database: process.env.LS_DB_NAME ?? "loadsense",
  charset: "utf8mb4",
});

const PLANOS_ADMIN = [
  {
    codigo: "ESSENCIAL",
    empresa: "LoadSense Essencial",
    slug: "loadsense-essencial",
    nome: "Administrador Plano Essencial",
    email: "admin.essencial@loadsense.local",
  },
  {
    codigo: "PROFISSIONAL",
    empresa: "LoadSense Profissional",
    slug: "loadsense-profissional",
    nome: "Administrador Plano Profissional",
    email: "admin.profissional@loadsense.local",
  },
  {
    codigo: "AVANCADO",
    empresa: "LoadSense Avançado",
    slug: "loadsense-avancado",
    nome: "Administrador Plano Avançado",
    email: "admin.avancado@loadsense.local",
  },
];

const [[adminBase]] = await conexao.query(
  "SELECT company_id, password_hash FROM users WHERE email = 'admin@loadsense.local'",
);
if (!adminBase) {
  console.error(
    "Conta admin@loadsense.local não encontrada. Carregue o schema antes (banco/LoadSense_Banco_MySQL_Workbench.sql).",
  );
  process.exit(1);
}
const senhaHash = adminBase.password_hash;

const [[assinaturaAtiva]] = await conexao.query(
  "SELECT id FROM company_subscriptions WHERE company_id = ? AND status = 'ACTIVE' LIMIT 1",
  [adminBase.company_id],
);
if (!assinaturaAtiva) {
  await conexao.query(
    `INSERT INTO company_subscriptions (company_id, plan_id, status, starts_at, current_period_start, current_period_end)
     SELECT ?, id, 'ACTIVE', CURRENT_TIMESTAMP(3), CURRENT_TIMESTAMP(3), DATE_ADD(CURRENT_TIMESTAMP(3), INTERVAL 365 DAY)
       FROM subscription_plans WHERE code = 'ENTERPRISE'`,
    [adminBase.company_id],
  );
  console.log("  + assinatura Enterprise na empresa principal");
}

const [[temBalanca]] = await conexao.query("SELECT id FROM weighing_stations WHERE company_id = ? LIMIT 1", [
  adminBase.company_id,
]);
if (!temBalanca) {
  const [[unidade]] = await conexao.query("SELECT id FROM operational_units WHERE company_id = ? ORDER BY id LIMIT 1", [
    adminBase.company_id,
  ]);
  let unidadeId = unidade?.id;
  if (!unidadeId) {
    const [u] = await conexao.query(
      "INSERT INTO operational_units (company_id, code, name, description, active) VALUES (?, 'MATRIZ', 'LoadSense', 'Unidade principal', 1)",
      [adminBase.company_id],
    );
    unidadeId = u.insertId;
  }
  await conexao.query(
    "INSERT INTO weighing_stations (company_id, operational_unit_id, code, name, description, active) VALUES (?, ?, 'BAL-01', 'Balança 01', 'Balança principal', 1)",
    [adminBase.company_id, unidadeId],
  );
  console.log("  + balança BAL-01 na empresa principal");
}

await conexao.query("UPDATE users SET must_change_password = 0, active = 1 WHERE email = 'admin@loadsense.local'");

const SUPERVISOR_OPERADOR = [
  { papel: "SUPERVISOR", nome: "Marina Supervisora", email: "supervisor@loadsense.local" },
  { papel: "OPERATOR", nome: "Carlos Operador", email: "operador@loadsense.local" },
];
for (const c of SUPERVISOR_OPERADOR) {
  const [[existe]] = await conexao.query("SELECT id FROM users WHERE email = ?", [c.email]);
  if (existe) {
    console.log(`  = ${c.email} (já existe)`);
    continue;
  }
  const [[papel]] = await conexao.query("SELECT id FROM roles WHERE company_id = ? AND name = ? LIMIT 1", [
    adminBase.company_id,
    c.papel,
  ]);
  if (!papel) {
    console.error(`Papel ${c.papel} não encontrado na empresa principal.`);
    process.exit(1);
  }
  await conexao.query(
    "INSERT INTO users (company_id, role_id, full_name, email, password_hash, must_change_password, active) VALUES (?, ?, ?, ?, ?, 0, 1)",
    [adminBase.company_id, papel.id, c.nome, c.email, senhaHash],
  );
  console.log(`  + ${c.email} (papel ${c.papel})`);
}

async function criarEmpresaDoPlano(c) {
  const [[existe]] = await conexao.query("SELECT id FROM users WHERE email = ?", [c.email]);
  if (existe) return console.log(`  = ${c.email} (já existe)`);

  const cx = conexao;
  await cx.beginTransaction();
  try {
    const [empresa] = await cx.query(
      "INSERT INTO companies (legal_name, trade_name, slug, email) VALUES (?, ?, ?, ?)",
      [c.empresa, c.empresa, c.slug, c.email],
    );
    const companyId = empresa.insertId;

    const config = { ...modelo.configuracoes, company_id: companyId };
    const colunas = Object.keys(config);
    await cx.query(
      `INSERT INTO company_settings (${colunas.join(", ")}) VALUES (${colunas.map(() => "?").join(", ")})`,
      colunas.map((k) => config[k]),
    );

    let roleAdmin = null;
    for (const papel of modelo.papeis) {
      const [r] = await cx.query(
        "INSERT INTO roles (company_id, name, description, is_system_role, active) VALUES (?, ?, ?, 1, 1)",
        [companyId, papel.nome, papel.descricao],
      );
      if (papel.nome === "ADMINISTRATOR") roleAdmin = r.insertId;
      for (const codigo of papel.permissoes) {
        await cx.query(
          "INSERT INTO role_permissions (role_id, permission_id) SELECT ?, id FROM permissions WHERE code = ?",
          [r.insertId, codigo],
        );
      }
    }

    const [unidade] = await cx.query(
      "INSERT INTO operational_units (company_id, code, name, description, active) VALUES (?, 'MATRIZ', ?, 'Unidade principal', 1)",
      [companyId, c.empresa],
    );
    await cx.query(
      "INSERT INTO weighing_stations (company_id, operational_unit_id, code, name, description, active) VALUES (?, ?, 'BAL-01', 'Balança 01', 'Balança principal', 1)",
      [companyId, unidade.insertId],
    );

    const [usuario] = await cx.query(
      "INSERT INTO users (company_id, role_id, full_name, email, password_hash, must_change_password, active) VALUES (?, ?, ?, ?, ?, 0, 1)",
      [companyId, roleAdmin, c.nome, c.email, senhaHash],
    );
    await cx.query("INSERT INTO user_app_preferences (company_id, user_id) VALUES (?, ?)", [
      companyId,
      usuario.insertId,
    ]);

    await cx.query(
      `INSERT INTO company_subscriptions (company_id, plan_id, status, starts_at, current_period_start, current_period_end)
       SELECT ?, id, 'ACTIVE', CURRENT_TIMESTAMP(3), CURRENT_TIMESTAMP(3), DATE_ADD(CURRENT_TIMESTAMP(3), INTERVAL 365 DAY)
         FROM subscription_plans WHERE code = ?`,
      [companyId, c.codigo],
    );

    await cx.commit();
    console.log(`  + ${c.email} (plano ${c.codigo})`);
  } catch (erro) {
    await cx.rollback();
    throw erro;
  }
}

for (const c of PLANOS_ADMIN) await criarEmpresaDoPlano(c);

await conexao.query(
  `INSERT IGNORE INTO user_app_preferences (company_id, user_id)
   SELECT u.company_id, u.id FROM users u`,
);

const [contas] = await conexao.query(
  `SELECT u.email, u.full_name, sp.code AS plano, cs.status
     FROM users u
     LEFT JOIN company_subscriptions cs ON cs.company_id = u.company_id AND cs.status = 'ACTIVE'
     LEFT JOIN subscription_plans sp ON sp.id = cs.plan_id
    WHERE u.email IN ('admin@loadsense.local','supervisor@loadsense.local','operador@loadsense.local',
                                            'admin.essencial@loadsense.local','admin.profissional@loadsense.local','admin.avancado@loadsense.local')
    ORDER BY u.id`,
);
console.log("\nContas disponíveis (senha de todas: LoadSense@2026):");
for (const c of contas)
  console.log(`  ${c.email.padEnd(34)} ${String(c.plano ?? "sem plano").padEnd(14)} ${c.full_name}`);

await conexao.end();
