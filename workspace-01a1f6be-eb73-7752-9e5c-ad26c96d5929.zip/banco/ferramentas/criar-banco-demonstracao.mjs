import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const RAIZ = join(dirname(fileURLToPath(import.meta.url)), "..", "..");
const require = createRequire(join(RAIZ, "api", "package.json"));
const mysql = require("mysql2/promise");

if (!process.argv.includes("--sim")) {
  console.error("Esta ação apaga o banco `loadsense` atual. Para confirmar, rode com --sim.");
  process.exit(2);
}

const conexao = await mysql.createConnection({
  host: process.env.LS_DB_HOST ?? "127.0.0.1",
  port: Number(process.env.LS_DB_PORT ?? 3306),
  user: process.env.LS_DB_USER ?? "root",
  password: process.env.LS_DB_PASSWORD ?? "",
});
await conexao.query("DROP DATABASE IF EXISTS loadsense");
await conexao.end();
console.log("1/4 banco anterior removido");

const carregar = (arquivo, ...extra) => {
  const r = spawnSync(process.execPath, [join(RAIZ, "banco", "ferramentas", "carregar-sql.mjs"), arquivo, ...extra], {
    cwd: join(RAIZ, "api"),
    stdio: "inherit",
  });
  if (r.status !== 0) process.exit(r.status ?? 1);
};
carregar(join(RAIZ, "banco", "LoadSense_Banco_MySQL_Workbench.sql"));
console.log("2/4 schema carregado");
carregar(join(RAIZ, "banco", "db", "01_demo_seed.sql"), "--db", "loadsense");
console.log("3/4 dados-base carregados");

const semeadura = spawnSync(
  process.execPath,
  [join(RAIZ, "api", "server", "scripts", "seed-demo.mjs"), "--dias", "90"],
  {
    cwd: join(RAIZ, "api"),
    stdio: "inherit",
  },
);
if (semeadura.status !== 0) process.exit(semeadura.status ?? 1);
console.log("4/4 histórico de demonstração gerado");
carregar(join(RAIZ, "banco", "ferramentas", "completar-rotas-demo.sql"), "--db", "loadsense");
console.log("pontos de origem e destino das rotas de demonstração");
const contas = spawnSync(process.execPath, [join(RAIZ, "banco", "ferramentas", "contas-entrega.mjs")], {
  cwd: join(RAIZ, "api"),
  stdio: "inherit",
  env: { ...process.env, LS_DB_NAME: "loadsense" },
});
if (contas.status !== 0) process.exit(contas.status ?? 1);
console.log("contas de acesso criadas (admin, supervisor, operador e administradores de plano)");
console.log("Pronto. Entre com admin@loadsense.local / LoadSense@2026");
