import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const RAIZ = join(dirname(fileURLToPath(import.meta.url)), "..", "..");
const require = createRequire(join(RAIZ, "api", "package.json"));
const mysql = require("mysql2/promise");

if (!process.argv.includes("--sim")) {
  console.error("Esta ação apaga o banco `loadsense` atual. Para confirmar, rode com --sim.");
  process.exit(2);
}

const conexao = await mysql.createConnection({
  host: process.env.LS_DB_HOST ?? "127.0.0.1",
  port: Number(process.env.LS_DB_PORT ?? 3306),
  user: process.env.LS_DB_USER ?? "root",
  password: process.env.LS_DB_PASSWORD ?? "",
});
await conexao.query("DROP DATABASE IF EXISTS loadsense");
await conexao.end();
console.log("1/3 banco anterior removido");

const carregar = (arquivo, ...extra) => {
  const r = spawnSync(process.execPath, [join(RAIZ, "banco", "ferramentas", "carregar-sql.mjs"), arquivo, ...extra], {
    cwd: join(RAIZ, "api"),
    stdio: "inherit",
  });
  if (r.status !== 0) process.exit(r.status ?? 1);
};
carregar(join(RAIZ, "banco", "LoadSense_Banco_MySQL_Workbench.sql"));
console.log("2/3 schema carregado");

const contas = spawnSync(process.execPath, [join(RAIZ, "banco", "ferramentas", "contas-entrega.mjs")], {
  cwd: join(RAIZ, "api"),
  stdio: "inherit",
  env: { ...process.env, LS_DB_NAME: "loadsense" },
});
if (contas.status !== 0) process.exit(contas.status ?? 1);
console.log("3/4 contas criadas");
carregar(join(RAIZ, "banco", "db", "02_entrega_balanca.sql"), "--db", "loadsense");
console.log("4/4 balança criada");
console.log(
  "Pronto. Entre com admin@loadsense.local / LoadSense@2026 (ou admin.essencial / .profissional / .avancado)",
);
