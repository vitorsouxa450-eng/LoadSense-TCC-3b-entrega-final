#!/usr/bin/env bash
# Prepara o ambiente de testes local sem instalar nada no sistema:
#   - MySQL 8.0 (MySQL Community Server 8.0.33), baixado do site oficial em /var/tmp/ls-mysql
#     (porta 3306, usuário root sem senha, como o projeto espera por padrão)
#   - bibliotecas do MySQL (libaio, libnuma) extraídas de pacotes Debian
#   - bibliotecas do Chromium extraídas de pacotes Debian
#   - navegador do Playwright (cache em ~/.cache/ms-playwright)
# O schema e os dados de demonstração são carregados por banco/ferramentas/criar-banco-demonstracao.mjs --sim.
# Uso (na raiz do projeto):  bash banco/ferramentas/preparar-ambiente-teste.sh
# Requer: apt-get download (sem root), curl, tar com xz, Node.js e npm já instalados.
set -euo pipefail

RAIZ="$(cd "$(dirname "$0")/../.." && pwd)"
MYSQL_VERSAO="8.0.33"
MYSQL_URL="https://cdn.mysql.com/Downloads/MySQL-8.0/mysql-${MYSQL_VERSAO}-linux-glibc2.28-x86_64.tar.xz"
DB="/var/tmp/ls-mysql"
BASE="$DB/base"
LIBS="$DB/libs/usr/lib/x86_64-linux-gnu"
CHROME="/var/tmp/ls-chrome"
export LD_LIBRARY_PATH="$LIBS:$CHROME/root/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"

baixar_debs() { # $1 = pasta, demais = pacotes
  local pasta="$1"; shift
  mkdir -p "$pasta"
  (cd "$pasta" && apt-get download "$@" >/dev/null 2>&1) || true
}

echo "== MySQL $MYSQL_VERSAO"
if [ ! -x "$BASE/bin/mysqld" ]; then
  mkdir -p "$DB"
  curl -sSL -o "$DB/mysql.tar.xz" "$MYSQL_URL"
  tar -xJf "$DB/mysql.tar.xz" -C "$DB"
  rm -rf "$BASE"
  mv "$DB/mysql-${MYSQL_VERSAO}-linux-glibc2.28-x86_64" "$BASE"
  rm -f "$DB/mysql.tar.xz"
fi
if [ ! -e "$LIBS/libaio.so.1" ] || [ ! -e "$LIBS/libnuma.so.1" ]; then
  baixar_debs "$DB/debs" libaio1t64 libnuma1
  for f in "$DB"/debs/*.deb; do dpkg-deb -x "$f" "$DB/libs"; done
  ln -sf libaio.so.1t64 "$LIBS/libaio.so.1"
fi
if [ ! -d "$DB/data/mysql" ]; then
  mkdir -p "$DB/data" "$DB/run"
  "$BASE/bin/mysqld" --no-defaults --initialize-insecure --basedir="$BASE" \
    --datadir="$DB/data" --user="$(whoami)" >"$DB/install.log" 2>&1
fi
MYSQLADMIN="$BASE/bin/mysqladmin -h127.0.0.1 -uroot"
if ! $MYSQLADMIN ping >/dev/null 2>&1; then
  nohup "$BASE/bin/mysqld" --no-defaults --basedir="$BASE" --datadir="$DB/data" \
    --socket="$DB/run/mysqld.sock" --port=3306 --bind-address=127.0.0.1 --user="$(whoami)" \
    --mysqlx=OFF --collation-server=utf8mb4_0900_ai_ci --character-set-server=utf8mb4 \
    --max-allowed-packet=256M --log-error="$DB/mysqld.err" \
    >/dev/null 2>&1 </dev/null &
  for _ in $(seq 1 60); do $MYSQLADMIN ping >/dev/null 2>&1 && break; sleep 1; done
fi
$MYSQLADMIN ping >/dev/null 2>&1 || { echo "MySQL não respondeu; veja $DB/mysqld.err" >&2; exit 1; }

echo "== Bibliotecas do Chromium"
if [ ! -d "$CHROME/root/usr/lib/x86_64-linux-gnu" ]; then
  baixar_debs "$CHROME/pkg" libnspr4 libnss3 libasound2t64 libatk1.0-0t64 libatk-bridge2.0-0t64 \
    libcups2t64 libxkbcommon0 libxcomposite1 libxdamage1 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 \
    libxfixes3 libdrm2 libatspi2.0-0t64 libxshmfence1 libxext6 libx11-6 libxcb1 libpangocairo-1.0-0 \
    libcairo-gobject2 libgdk-pixbuf-2.0-0 libexpat1 libfontconfig1 libfreetype6 libharfbuzz0b libthai0 \
    libdatrie1 libgraphite2-3 libbrotli1 libpng16-16t64 libglib2.0-0t64 libdbus-1-3 libxau6 libxdmcp6 \
    libpixman-1-0 libxrender1 libsqlite3-0
  for f in "$CHROME"/pkg/*.deb; do dpkg-deb -x "$f" "$CHROME/root"; done
fi

echo "== Navegador do Playwright"
if [ ! -d "$RAIZ/app/node_modules/playwright-core" ]; then
  (cd "$RAIZ/app" && npm install --no-audit --no-fund >/dev/null)
fi
if [ ! -d "$HOME/.cache/ms-playwright/chromium_headless_shell-1248" ]; then
  (cd "$RAIZ/app" && node node_modules/playwright-core/cli.js install chromium-headless-shell >/dev/null)
fi

echo "Pronto. MySQL em 127.0.0.1:3306 (root, sem senha); bibliotecas do navegador em:"
echo "  LD_LIBRARY_PATH=$CHROME/root/usr/lib/x86_64-linux-gnu"
