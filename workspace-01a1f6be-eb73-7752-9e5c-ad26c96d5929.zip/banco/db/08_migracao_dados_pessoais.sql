ALTER TABLE drivers
  ADD COLUMN document_hash CHAR(64) DEFAULT NULL AFTER document_number,
  MODIFY COLUMN document_number VARCHAR(255) DEFAULT NULL,
  MODIFY COLUMN license_number VARCHAR(255) DEFAULT NULL,
  MODIFY COLUMN phone VARCHAR(255) DEFAULT NULL,
  DROP INDEX uq_drivers_company_document,
  ADD UNIQUE KEY uq_drivers_company_document (company_id, document_hash);
