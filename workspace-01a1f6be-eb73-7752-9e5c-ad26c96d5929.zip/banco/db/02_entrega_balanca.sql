SET @company_id := (SELECT id FROM companies WHERE slug = 'loadsense' OR trade_name = 'LoadSense' ORDER BY id LIMIT 1);
SET @unit_id    := (SELECT id FROM operational_units WHERE company_id = @company_id AND code = 'MATRIZ' LIMIT 1);

INSERT INTO devices (company_id, operational_unit_id, name, device_type, serial_number, firmware_version, state)
SELECT @company_id, @unit_id, 'Balança 01 - ESP32', 'ESP32', 'LS-ESP32-0001', '1.0', 'OFFLINE'
WHERE NOT EXISTS (SELECT 1 FROM devices WHERE company_id = @company_id AND serial_number = 'LS-ESP32-0001');

INSERT INTO devices (company_id, operational_unit_id, name, device_type, serial_number, firmware_version, state)
SELECT @company_id, @unit_id, 'Célula de carga 01', 'LOAD_CELL', 'LS-CEL-0001', '1.0.1', 'OFFLINE'
WHERE NOT EXISTS (SELECT 1 FROM devices WHERE company_id = @company_id AND serial_number = 'LS-CEL-0001');

INSERT INTO devices (company_id, operational_unit_id, name, device_type, serial_number, firmware_version, state)
SELECT @company_id, @unit_id, 'Leitor RFID 01', 'RFID_READER', 'LS-RFID-0001', '1.2.0', 'OFFLINE'
WHERE NOT EXISTS (SELECT 1 FROM devices WHERE company_id = @company_id AND serial_number = 'LS-RFID-0001');

SET @cell_id := (SELECT id FROM devices WHERE company_id = @company_id AND serial_number = 'LS-CEL-0001' LIMIT 1);
SET @rfid_id := (SELECT id FROM devices WHERE company_id = @company_id AND serial_number = 'LS-RFID-0001' LIMIT 1);

INSERT INTO weighing_stations (company_id, operational_unit_id, code, name, scale_device_id, rfid_reader_device_id, description)
SELECT @company_id, @unit_id, 'BAL-01', 'Balança Rodoviária 01', @cell_id, @rfid_id, 'Balança com leitor RFID.'
WHERE NOT EXISTS (SELECT 1 FROM weighing_stations WHERE company_id = @company_id AND code = 'BAL-01');
