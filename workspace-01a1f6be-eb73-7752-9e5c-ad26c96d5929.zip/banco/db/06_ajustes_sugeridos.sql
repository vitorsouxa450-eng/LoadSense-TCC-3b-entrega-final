USE loadsense;

CREATE OR REPLACE VIEW vw_open_alerts AS
SELECT
    a.id,
    a.company_id,
    a.operation_id,                  
    o.operation_code,                
    o.vehicle_id,                    
    a.alert_context,
    a.alert_type,
    a.severity,
    a.state,
    a.title,
    a.message,
    a.difference_kg,
    a.difference_percent,
    a.detected_at,
    v.plate AS vehicle_plate
FROM alerts a
LEFT JOIN weighing_operations o
       ON o.company_id = a.company_id
      AND o.id = a.operation_id
LEFT JOIN vehicles v
       ON v.company_id = o.company_id
      AND v.id = o.vehicle_id
WHERE a.state IN ('OPEN', 'ACKNOWLEDGED');


DELIMITER $$
DROP PROCEDURE IF EXISTS sp_purge_weighing_operation$$
CREATE PROCEDURE sp_purge_weighing_operation (
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    DELETE FROM weighing_operations
     WHERE company_id = p_company_id AND id = p_operation_id;

    COMMIT;
END$$
DELIMITER ;



DELIMITER $$
DROP PROCEDURE IF EXISTS sp_manutencao_diaria$$
CREATE PROCEDURE sp_manutencao_diaria()
BEGIN
    DELETE FROM auth_sessions
     WHERE expires_at < DATE_SUB(NOW(3), INTERVAL 7 DAY)
        OR (revoked_at IS NOT NULL AND revoked_at < DATE_SUB(NOW(3), INTERVAL 7 DAY));

    DELETE FROM password_reset_tokens
     WHERE (used_at IS NOT NULL AND used_at < DATE_SUB(NOW(3), INTERVAL 7 DAY))
        OR expires_at < DATE_SUB(NOW(3), INTERVAL 1 DAY);

    DELETE FROM generated_reports
     WHERE generated_at < DATE_SUB(NOW(3), INTERVAL 180 DAY);
END$$
DELIMITER ;


