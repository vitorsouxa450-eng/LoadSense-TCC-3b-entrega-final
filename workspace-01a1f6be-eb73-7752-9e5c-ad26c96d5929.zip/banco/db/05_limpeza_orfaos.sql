USE loadsense;

SELECT 'ANTES' AS fase,
       (SELECT COUNT(*) FROM weighing_readings r
         WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = r.operation_id)) AS leituras_orfas,
       (SELECT COUNT(*) FROM alerts a
         WHERE a.operation_id IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = a.operation_id)) AS alertas_orfaos,
       (SELECT COUNT(*) FROM operation_events e
         WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = e.operation_id)) AS eventos_orfaos,
       (SELECT COUNT(*) FROM operation_tracking_points p
         WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = p.operation_id)) AS pontos_orfaos,
       (SELECT COUNT(*) FROM operation_tracking_status s
         WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = s.operation_id)) AS status_orfaos,
       (SELECT COUNT(*) FROM operation_attachments at
         WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = at.operation_id)) AS anexos_orfaos;

DELETE r FROM weighing_readings r
 LEFT JOIN weighing_operations o ON o.id = r.operation_id
 WHERE o.id IS NULL;

DELETE a FROM alerts a
 LEFT JOIN weighing_operations o ON o.id = a.operation_id
 WHERE a.operation_id IS NOT NULL AND o.id IS NULL;

DELETE e FROM operation_events e
 LEFT JOIN weighing_operations o ON o.id = e.operation_id
 WHERE o.id IS NULL;

DELETE p FROM operation_tracking_points p
 LEFT JOIN weighing_operations o ON o.id = p.operation_id
 WHERE o.id IS NULL;

DELETE s FROM operation_tracking_status s
 LEFT JOIN weighing_operations o ON o.id = s.operation_id
 WHERE o.id IS NULL;

DELETE at FROM operation_attachments at
 LEFT JOIN weighing_operations o ON o.id = at.operation_id
 WHERE o.id IS NULL;

SELECT 'DEPOIS' AS fase,
       (SELECT COUNT(*) FROM weighing_readings r
         WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = r.operation_id)) AS leituras_orfas,
       (SELECT COUNT(*) FROM alerts a
         WHERE a.operation_id IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = a.operation_id)) AS alertas_orfaos,
       (SELECT COUNT(*) FROM operation_events e
         WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = e.operation_id)) AS eventos_orfaos,
       (SELECT COUNT(*) FROM operation_tracking_points p
         WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = p.operation_id)) AS pontos_orfaos,
       (SELECT COUNT(*) FROM operation_tracking_status s
         WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = s.operation_id)) AS status_orfaos,
       (SELECT COUNT(*) FROM operation_attachments at
         WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = at.operation_id)) AS anexos_orfaos;
