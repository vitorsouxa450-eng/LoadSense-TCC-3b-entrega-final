USE loadsense;

SELECT '1. leituras aceitas sem carimbo de aceite' AS verificacao, COUNT(*) AS violacoes,
       'is_accepted=1 mas accepted_at/accepted_by_user_id vazios' AS detalhe
  FROM weighing_readings WHERE is_accepted = 1 AND (accepted_at IS NULL OR accepted_by_user_id IS NULL)
UNION ALL
SELECT '2. leituras aceitas instáveis (regra do banco)', COUNT(*),
       'sp_accept bloqueia is_stable=0 para DEVICE; aqui não deveria existir nenhuma'
  FROM weighing_readings r JOIN weighing_operations o ON o.id = r.operation_id
 WHERE r.is_accepted = 1 AND r.source = 'DEVICE' AND r.is_stable = 0
UNION ALL
SELECT '3. mais de uma leitura aceita por etapa', COUNT(*),
       'uq_readings_accepted_stage garante isso — qualquer valor > 0 indica índice ausente'
  FROM (SELECT operation_id, stage FROM weighing_readings WHERE is_accepted = 1
         GROUP BY operation_id, stage HAVING COUNT(*) > 1) t
UNION ALL
SELECT '4. operações concluídas sem peso carregado', COUNT(*),
       'state=COMPLETED exige loaded_truck_weight_kg ou actual_cargo_weight_kg'
  FROM weighing_operations WHERE state = 'COMPLETED' AND loaded_truck_weight_kg IS NULL AND actual_cargo_weight_kg IS NULL
UNION ALL
SELECT '5. operações concluídas sem cargo aferido', COUNT(*),
       'sp_finalize deveria sempre gravar actual_cargo_weight_kg'
  FROM weighing_operations WHERE state = 'COMPLETED' AND actual_cargo_weight_kg IS NULL
UNION ALL
SELECT '6. operações canceladas sem motivo', COUNT(*),
       'sp_cancel_weighing_operation exige p_reason'
  FROM weighing_operations WHERE state = 'CANCELLED' AND (cancellation_reason IS NULL OR TRIM(cancellation_reason) = '')
UNION ALL
SELECT '7. operações canceladas sem cancelled_at', COUNT(*), 'coluna deveria ser preenchida junto com o estado'
  FROM weighing_operations WHERE state = 'CANCELLED' AND cancelled_at IS NULL
UNION ALL
SELECT '8. diferença de peso divergente do status gravado', COUNT(*),
       '|difference_percent| acima da tolerância deveria resultar em ATTENTION/CRITICAL'
  FROM weighing_operations
 WHERE difference_percent IS NOT NULL AND state = 'COMPLETED'
   AND ABS(difference_percent) > tolerance_percent_snapshot AND status = 'NORMAL'
UNION ALL
SELECT '9. status CRITICAL sem nenhum alerta de pesagem', COUNT(*),
       'sp_finalize cria alerta para toda operação crítica (qualquer situação)'
  FROM weighing_operations o
 WHERE o.status = 'CRITICAL' AND o.state = 'COMPLETED'
   AND NOT EXISTS (SELECT 1 FROM alerts a WHERE a.operation_id = o.id AND a.alert_context = 'WEIGHING')
UNION ALL
SELECT '10. alertas de rastreio duplicados (mesma operação/tipo abertos)', COUNT(*),
       'operation_id nulo em UNIQUE permite repetição — conferir se é intencional'
  FROM (SELECT operation_id, alert_type FROM alerts
         WHERE alert_context = 'TRACKING' AND state IN ('OPEN','ACKNOWLEDGED') AND operation_id IS NOT NULL
         GROUP BY operation_id, alert_type HAVING COUNT(*) > 1) t
UNION ALL
SELECT '11. alertas resolvidos sem data de resolução', COUNT(*), 'resolved_at é obrigatório em qualquer resolução'
  FROM alerts WHERE state = 'RESOLVED' AND resolved_at IS NULL
UNION ALL
SELECT '11b. alertas resolvidos automaticamente (sem usuário) - informativo; decisão: resolução do sistema', COUNT(*),
       'trigger de rastreio resolve sozinho e não grava resolved_by_user_id; decidir se é o comportamento desejado'
  FROM alerts WHERE state = 'RESOLVED' AND resolved_at IS NOT NULL AND resolved_by_user_id IS NULL
UNION ALL
SELECT '12. alertas reconhecidos sem carimbo', COUNT(*), 'acknowledged_at obrigatório ao reconhecer'
  FROM alerts WHERE state = 'ACKNOWLEDGED' AND (acknowledged_at IS NULL OR acknowledged_by_user_id IS NULL)
UNION ALL
SELECT '13. rastreio sem status correspondente', COUNT(*),
       'toda operação com pontos de rastreio deveria ter linha em operation_tracking_status'
  FROM (SELECT DISTINCT p.operation_id FROM operation_tracking_points p
         WHERE NOT EXISTS (SELECT 1 FROM operation_tracking_status s WHERE s.operation_id = p.operation_id)) t
UNION ALL
SELECT '14. pontos de rastreio com coordenadas fora do Brasil', COUNT(*),
       'valida latitude/longitude recebidas do ESP32/GPRS'
  FROM operation_tracking_points WHERE latitude NOT BETWEEN -34 AND 6 OR longitude NOT BETWEEN -74 AND -34
UNION ALL
SELECT '15. leituras com peso negativo ou zero', COUNT(*), 'peso aferido deve ser positivo'
  FROM weighing_readings WHERE weight_kg <= 0
UNION ALL
SELECT '16. leituras com sequência duplicada por etapa', COUNT(*), 'uq_readings_operation_sequence garante isso'
  FROM (SELECT operation_id, stage, sequence_number FROM weighing_readings
         GROUP BY operation_id, stage, sequence_number HAVING COUNT(*) > 1) t
UNION ALL
SELECT '17. viagens concluídas sem horário de chegada', COUNT(*), 'ARRIVED deve gravar weighing_operations.arrived_at'
  FROM operation_tracking_status s JOIN weighing_operations o ON o.id = s.operation_id
 WHERE s.tracking_state = 'ARRIVED' AND o.arrived_at IS NULL
UNION ALL
SELECT '18. viagens em rota sem horário de partida', COUNT(*), 'IN_TRANSIT/STOPPED exigem weighing_operations.departed_at'
  FROM operation_tracking_status s JOIN weighing_operations o ON o.id = s.operation_id
 WHERE s.tracking_state IN ('IN_TRANSIT','STOPPED') AND o.departed_at IS NULL
UNION ALL
SELECT '19. transporte iniciado antes da pesagem concluída', COUNT(*),
       'sp_start_transport exige state=COMPLETED em weighing_operations'
  FROM operation_tracking_status s JOIN weighing_operations o ON o.id = s.operation_id
 WHERE s.tracking_state IN ('IN_TRANSIT','STOPPED','ARRIVED') AND o.state <> 'COMPLETED'
UNION ALL
SELECT '20. usuários ativos sem sessão válida', COUNT(*),
       'informativo: sessões expiradas continuam na tabela até serem limpas'
  FROM auth_sessions WHERE revoked_at IS NULL AND expires_at < NOW(3)
UNION ALL
SELECT '21. leituras órfãs (operação inexistente)', COUNT(*), 'integridade referencial'
  FROM weighing_readings r WHERE NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = r.operation_id)
UNION ALL
SELECT '22. alertas de operação inexistente', COUNT(*), 'alerts.operation_id nulo é permitido; valores preenchidos devem existir'
  FROM alerts a WHERE a.operation_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM weighing_operations o WHERE o.id = a.operation_id)
UNION ALL
SELECT '23. operações fora da unidade operacional da empresa', COUNT(*),
       'FK composta (company_id, operational_unit_id) cobre isso'
  FROM weighing_operations o JOIN operational_units u ON u.id = o.operational_unit_id
 WHERE u.company_id <> o.company_id
UNION ALL
SELECT '24. veículos com tara maior que o limite de peso bruto', COUNT(*),
       'dado de cadastro incoerente (evita operação impossível)'
  FROM vehicles WHERE registered_tare_kg >= gross_weight_limit_kg
UNION ALL
SELECT '25. eventos gravados fora da ordem cronológica da operação', COUNT(*),
       'evento anterior ao created_at da própria operação'
  FROM operation_events e JOIN weighing_operations o ON o.id = e.operation_id
 WHERE e.created_at < o.created_at;
