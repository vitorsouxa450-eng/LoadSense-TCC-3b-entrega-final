
DROP PROCEDURE IF EXISTS ls_adicionar_coluna_se_faltar;

DELIMITER $$
CREATE PROCEDURE ls_adicionar_coluna_se_faltar(IN p_coluna VARCHAR(64), IN p_definicao TEXT)
BEGIN
  DECLARE v_existe INT DEFAULT 0;
  SELECT COUNT(*) INTO v_existe
    FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = p_coluna;
  IF v_existe = 0 THEN
    SET @ls_sql = CONCAT('ALTER TABLE users ADD COLUMN ', p_coluna, ' ', p_definicao);
    PREPARE ls_stmt FROM @ls_sql;
    EXECUTE ls_stmt;
    DEALLOCATE PREPARE ls_stmt;
  END IF;
END$$
DELIMITER ;

CALL ls_adicionar_coluna_se_faltar('totp_enabled',    'TINYINT(1) NOT NULL DEFAULT 0 AFTER last_login_at');
CALL ls_adicionar_coluna_se_faltar('totp_secret_enc', 'VARCHAR(255) DEFAULT NULL AFTER totp_enabled');
CALL ls_adicionar_coluna_se_faltar('totp_last_step',  'BIGINT UNSIGNED DEFAULT NULL AFTER totp_secret_enc');
CALL ls_adicionar_coluna_se_faltar('totp_enabled_at', 'DATETIME(3) DEFAULT NULL AFTER totp_last_step');

DROP PROCEDURE IF EXISTS ls_adicionar_coluna_se_faltar;
