USE loadsense;
SET NAMES utf8mb4;

SET @company_id := (SELECT id FROM companies WHERE slug = 'loadsense-demo' LIMIT 1);
SET @unit_id    := (SELECT id FROM operational_units WHERE company_id = @company_id AND code = 'MATRIZ' LIMIT 1);
SET @admin_role := (SELECT id FROM roles WHERE company_id = @company_id AND name = 'ADMINISTRATOR' LIMIT 1);
SET @super_role := (SELECT id FROM roles WHERE company_id = @company_id AND name = 'SUPERVISOR' LIMIT 1);
SET @oper_role  := (SELECT id FROM roles WHERE company_id = @company_id AND name = 'OPERATOR' LIMIT 1);

SET @pwd := '$2b$12$5aZyYIc63Y/mTa9kjRvCjuP02tHJ5DbV7VCb3OX4VzwtqVwLSIkSq';

INSERT INTO users (company_id, role_id, full_name, email, password_hash, active)
SELECT @company_id, @super_role, 'Marina Supervisora', 'supervisor@loadsense.local', @pwd, 1
WHERE NOT EXISTS (SELECT 1 FROM users WHERE company_id = @company_id AND email = 'supervisor@loadsense.local');

INSERT INTO users (company_id, role_id, full_name, email, password_hash, active)
SELECT @company_id, @oper_role, 'Carlos Operador', 'operador@loadsense.local', @pwd, 1
WHERE NOT EXISTS (SELECT 1 FROM users WHERE company_id = @company_id AND email = 'operador@loadsense.local');

SET @admin_id := (SELECT id FROM users WHERE company_id = @company_id AND email = 'admin@loadsense.local' LIMIT 1);
SET @super_id := (SELECT id FROM users WHERE company_id = @company_id AND email = 'supervisor@loadsense.local' LIMIT 1);
SET @oper_id  := (SELECT id FROM users WHERE company_id = @company_id AND email = 'operador@loadsense.local' LIMIT 1);

INSERT INTO user_app_preferences (company_id, user_id, theme, push_notifications_enabled)
SELECT @company_id, u.id, 'DARK', 1
  FROM users u
 WHERE u.company_id = @company_id
   AND NOT EXISTS (
       SELECT 1 FROM user_app_preferences p
        WHERE p.company_id = u.company_id AND p.user_id = u.id
   );

INSERT INTO devices (company_id, operational_unit_id, name, device_type, serial_number, firmware_version, state, last_seen_at)
SELECT @company_id, @unit_id, 'Balança 01 - ESP32', 'ESP32', 'LS-ESP32-0001', '1.4.2', 'ONLINE', NOW(3)
WHERE NOT EXISTS (SELECT 1 FROM devices WHERE company_id = @company_id AND serial_number = 'LS-ESP32-0001');

INSERT INTO devices (company_id, operational_unit_id, name, device_type, serial_number, firmware_version, state)
SELECT @company_id, @unit_id, 'Célula de carga 01', 'LOAD_CELL', 'LS-CEL-0001', '1.0.1', 'ONLINE'
WHERE NOT EXISTS (SELECT 1 FROM devices WHERE company_id = @company_id AND serial_number = 'LS-CEL-0001');

INSERT INTO devices (company_id, operational_unit_id, name, device_type, serial_number, firmware_version, state)
SELECT @company_id, @unit_id, 'Leitor RFID 01', 'RFID_READER', 'LS-RFID-0001', '1.2.0', 'ONLINE'
WHERE NOT EXISTS (SELECT 1 FROM devices WHERE company_id = @company_id AND serial_number = 'LS-RFID-0001');

INSERT INTO devices (company_id, operational_unit_id, name, device_type, serial_number, firmware_version, state)
SELECT @company_id, @unit_id, 'Modem GPRS 01', 'GPRS_MODEM', 'LS-GPRS-0001', '2.0.0', 'ONLINE'
WHERE NOT EXISTS (SELECT 1 FROM devices WHERE company_id = @company_id AND serial_number = 'LS-GPRS-0001');

SET @esp32_id := (SELECT id FROM devices WHERE company_id = @company_id AND serial_number = 'LS-ESP32-0001' LIMIT 1);
SET @cell_id  := (SELECT id FROM devices WHERE company_id = @company_id AND serial_number = 'LS-CEL-0001' LIMIT 1);
SET @rfid_id  := (SELECT id FROM devices WHERE company_id = @company_id AND serial_number = 'LS-RFID-0001' LIMIT 1);

INSERT INTO device_calibrations (company_id, device_id, calibration_factor, reference_weight_kg, accuracy_class, certificate_number, result, performed_by_user_id, performed_at, expires_at, notes)
SELECT @company_id, @cell_id, 1.000000, 1000.000, 'III', 'CAL-2026-0001', 'APPROVED', @admin_id, DATE_SUB(NOW(3), INTERVAL 20 DAY), DATE_ADD(NOW(3), INTERVAL 160 DAY), 'Calibração de referência (massa padrão 1.000 kg).'
WHERE NOT EXISTS (SELECT 1 FROM device_calibrations WHERE company_id = @company_id AND device_id = @cell_id);

INSERT INTO weighing_stations (company_id, operational_unit_id, code, name, scale_device_id, rfid_reader_device_id, description)
SELECT @company_id, @unit_id, 'BAL-01', 'Balança Rodoviária 01', @cell_id, @rfid_id, 'Balança de 80 t com leitor RFID.'
WHERE NOT EXISTS (SELECT 1 FROM weighing_stations WHERE company_id = @company_id AND code = 'BAL-01');

SET @station_id := (SELECT id FROM weighing_stations WHERE company_id = @company_id AND code = 'BAL-01' LIMIT 1);

INSERT INTO vehicles (company_id, plate, fleet_code, vehicle_type, manufacturer, model, manufacture_year, axle_count, registered_tare_kg, gross_weight_limit_kg, payload_limit_kg)
SELECT @company_id, t.plate, t.fleet, 'TRUCK', t.maker, t.model, t.year, t.axles, t.tare, t.gross, t.payload
  FROM (
        SELECT 'ABC1A23' AS plate, 'F-101' AS fleet, 'Volvo' AS maker, 'VM 270' AS model, 2019 AS year, 2 AS axles,  8500.000 AS tare, 23000.000 AS gross, 14500.000 AS payload
  UNION SELECT 'XYZ9Z99', 'F-102', 'Scania', 'P 310', 2020, 3,  9200.000, 26000.000, 16800.000
  UNION SELECT 'JKL4B56', 'F-103', 'Mercedes-Benz', 'Accelo 1016', 2018, 2,  6200.000, 16000.000,  9800.000
  UNION SELECT 'MNO7C89', 'F-104', 'Volkswagen', 'Constellation 24.280', 2021, 3, 10400.000, 29000.000, 18600.000
  UNION SELECT 'PQR2D34', 'F-105', 'Ford', 'Cargo 1719', 2017, 2,  7100.000, 17500.000, 10400.000
  UNION SELECT 'STU5E67', 'F-106', 'Iveco', 'Tector 240E28', 2022, 3,  9800.000, 23500.000, 13700.000
       ) AS t
 WHERE NOT EXISTS (SELECT 1 FROM vehicles v WHERE v.company_id = @company_id AND v.plate = t.plate);

INSERT INTO rfid_tags (company_id, code, vehicle_id, active, notes)
SELECT @company_id, CONCAT('RFID-', v.plate), v.id, 1, CONCAT('Etiqueta do veículo ', v.plate)
  FROM vehicles v
 WHERE v.company_id = @company_id
   AND NOT EXISTS (SELECT 1 FROM rfid_tags r WHERE r.company_id = v.company_id AND r.vehicle_id = v.id AND r.active = 1);

INSERT INTO drivers (company_id, full_name, document_number, employee_code, license_number, license_category, license_expiration_date, phone)
SELECT @company_id, t.name, t.doc, t.code, t.lic, t.cat, DATE_ADD(CURDATE(), INTERVAL t.days DAY), t.phone
  FROM (
        SELECT 'João Batista Lima' AS name, '12345678901' AS doc, 'M-001' AS code, 'SP1234567' AS lic, 'E' AS cat, 400 AS days, '(11) 98888-1001' AS phone
  UNION SELECT 'Ricardo Alves Prado', '23456789012', 'M-002', 'SP2345678', 'E', 700, '(11) 98888-1002'
  UNION SELECT 'Fernanda Souza Reis', '34567890123', 'M-003', 'SP3456789', 'D', 120, '(11) 98888-1003'
  UNION SELECT 'Marcos Vinícius Teles', '45678901234', 'M-004', 'SP4567890', 'E', 900, '(11) 98888-1004'
  UNION SELECT 'Antônio Carlos Ferreira', '56789012345', 'M-005', 'SP5678901', 'D', 250, '(11) 98888-1005'
       ) AS t
 WHERE NOT EXISTS (SELECT 1 FROM drivers d WHERE d.company_id = @company_id AND d.document_number = t.doc);

INSERT INTO cargo_products (company_id, code, name, description, default_unit)
SELECT @company_id, t.code, t.name, t.descr, 'KG'
  FROM (
        SELECT 'SOJA' AS code, 'Soja em grãos' AS name, 'Carga a granel' AS descr
  UNION SELECT 'MILHO', 'Milho em grãos', 'Carga a granel'
  UNION SELECT 'FERT', 'Fertilizante ensacado', 'Carga paletizada'
  UNION SELECT 'ACUCAR', 'Açúcar refinado', 'Carga ensacada'
  UNION SELECT 'CIMENTO', 'Cimento CP-II', 'Carga ensacada'
       ) AS t
 WHERE NOT EXISTS (SELECT 1 FROM cargo_products cp WHERE cp.company_id = @company_id AND cp.code = t.code);

INSERT INTO routes (company_id, code, origin, destination, distance_km, description)
SELECT @company_id, t.code, t.orig, t.dest, t.km, t.descr
  FROM (
        SELECT 'R-01' AS code, 'Taboão da Serra - SP' AS orig, 'Santos - SP' AS dest,  99.80 AS km, 'Baixada Santista' AS descr
  UNION SELECT 'R-02', 'Taboão da Serra - SP', 'Campinas - SP', 98.00, 'Interior'
  UNION SELECT 'R-03', 'Taboão da Serra - SP', 'Sorocaba - SP', 62.00, 'Interior'
  UNION SELECT 'R-04', 'Taboão da Serra - SP', 'São José dos Campos - SP', 112.00, 'Vale do Paraíba'
       ) AS t
 WHERE NOT EXISTS (SELECT 1 FROM routes r WHERE r.company_id = @company_id AND r.code = t.code);

SET @r1 := (SELECT id FROM routes WHERE company_id = @company_id AND code = 'R-01' LIMIT 1);

INSERT INTO route_waypoints (company_id, route_id, sequence_number, waypoint_type, label, latitude, longitude)
SELECT @company_id, @r1, t.seq, t.wtype, t.label, t.lat, t.lng
  FROM (
        SELECT 1 AS seq, 'ORIGIN' AS wtype, 'Taboão da Serra - SP' AS label, -23.5861000 AS lat, -46.8200000 AS lng
  UNION SELECT 2, 'WAYPOINT', 'Rodoanel Mário Covas', -23.6100000, -46.7100000
  UNION SELECT 3, 'WAYPOINT', 'Serra do Mar - Rod. Anchieta', -23.7600000, -46.5200000
  UNION SELECT 4, 'DESTINATION', 'Porto de Santos - SP', -23.9608000, -46.3336000
       ) AS t
 WHERE NOT EXISTS (SELECT 1 FROM route_waypoints w WHERE w.company_id = @company_id AND w.route_id = @r1 AND w.sequence_number = t.seq);

SET @plan_plus := (SELECT id FROM subscription_plans WHERE code = 'ENTERPRISE' LIMIT 1);

INSERT INTO company_subscriptions (company_id, plan_id, status, starts_at, current_period_start, current_period_end)
SELECT @company_id, @plan_plus, 'ACTIVE', NOW(3), DATE_FORMAT(NOW(3), '%Y-%m-01 00:00:00'), DATE_ADD(DATE_FORMAT(NOW(3), '%Y-%m-01 00:00:00'), INTERVAL 1 MONTH)
WHERE NOT EXISTS (SELECT 1 FROM company_subscriptions WHERE company_id = @company_id);

INSERT INTO legal_documents (company_id, document_type, version, title, content_format, content, content_hash, mandatory, active, published_at, effective_at, created_by_user_id)
SELECT @company_id, 'TERMS_OF_USE', '1.0', 'Termos de Uso LoadSense', 'MARKDOWN',
       '# Termos de Uso\n\nAo utilizar o LoadSense você concorda com o registro de dados operacionais de pesagem para fins de auditoria e segurança.',
       SHA2('LoadSense-Termos-1.0', 256), 1, 1, NOW(3), NOW(3), @admin_id
WHERE NOT EXISTS (SELECT 1 FROM legal_documents WHERE company_id = @company_id AND document_type = 'TERMS_OF_USE' AND version = '1.0');

INSERT INTO legal_documents (company_id, document_type, version, title, content_format, content, content_hash, mandatory, active, published_at, effective_at, created_by_user_id)
SELECT @company_id, 'PRIVACY_POLICY', '1.0', 'Política de Privacidade LoadSense', 'MARKDOWN',
       '# Política de Privacidade\n\nOs dados de pesagens, trajetos e identificação de veículos são tratados conforme a LGPD.',
       SHA2('LoadSense-Privacidade-1.0', 256), 1, 1, NOW(3), NOW(3), @admin_id
WHERE NOT EXISTS (SELECT 1 FROM legal_documents WHERE company_id = @company_id AND document_type = 'PRIVACY_POLICY' AND version = '1.0');

SELECT 'usuarios' AS entidade, COUNT(*) AS total FROM users WHERE company_id = @company_id
UNION ALL SELECT 'veiculos', COUNT(*) FROM vehicles WHERE company_id = @company_id
UNION ALL SELECT 'etiquetas rfid', COUNT(*) FROM rfid_tags WHERE company_id = @company_id
UNION ALL SELECT 'motoristas', COUNT(*) FROM drivers WHERE company_id = @company_id
UNION ALL SELECT 'produtos', COUNT(*) FROM cargo_products WHERE company_id = @company_id
UNION ALL SELECT 'rotas', COUNT(*) FROM routes WHERE company_id = @company_id
UNION ALL SELECT 'waypoints', COUNT(*) FROM route_waypoints WHERE company_id = @company_id
UNION ALL SELECT 'dispositivos', COUNT(*) FROM devices WHERE company_id = @company_id
UNION ALL SELECT 'postos de pesagem', COUNT(*) FROM weighing_stations WHERE company_id = @company_id
UNION ALL SELECT 'documentos legais', COUNT(*) FROM legal_documents WHERE company_id = @company_id
UNION ALL SELECT 'assinaturas', COUNT(*) FROM company_subscriptions WHERE company_id = @company_id;
