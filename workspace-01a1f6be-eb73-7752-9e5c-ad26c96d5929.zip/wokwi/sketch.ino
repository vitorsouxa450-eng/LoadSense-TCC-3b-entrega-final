#include <Wire.h>

#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASS ""
#define SERVIDOR_URL "http://host.wokwi.internal:5174"
#define DEVICE_KEY "CHAVE-DE-TESTE-WOKWI"
#define FIRMWARE_VERSAO "1.1"


class HX711 {
 public:
  void begin(uint8_t dt, uint8_t sck) { (void)dt; (void)sck; pinMode(34, INPUT); }
  void set_scale(float f) { (void)f; }
  void tare(uint8_t n = 10) { (void)n; }
  bool is_ready() { return true; }
  bool wait_ready_timeout(unsigned long ms) { (void)ms; return true; }
  long get_value(uint8_t n = 1) { (void)n; return lerGramas(); }
  float get_units(uint8_t n = 1) { (void)n; return (float)lerGramas(); }

 private:
  long lerGramas() {
    long soma = 0;
    for (int i = 0; i < 16; i++) soma += analogRead(34);
    float media = soma / 16.0;
    return lround(media / 4095.0 * 10000.0);
  }
};
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <LiquidCrystal_I2C.h>

const int PIN_DT        = 16;
const int PIN_SCK       = 4;
const int PIN_BUZZER    = 25;
const int PIN_LED_AZUL  = 26;
const int PIN_LED_VERDE = 27;

const float TOL_KG = 0.3;

LiquidCrystal_I2C lcd(0x27, 16, 2);
HX711 scale;

float fatorCal = 1.0;
int ultimoCodigoTotal = 201;

enum Estado { ST_INICIANDO, ST_AGUARDANDO, ST_MEDIR_VAZIO, ST_MEDIR_CARGA, ST_MEDIR_TOTAL, ST_OK, ST_DIVERGENTE };
Estado estado = ST_INICIANDO;

float medVazio = 0, medCarga = 0, medTotal = 0;
float ultimaMedida = -99999;
bool aguardandoMudanca = false;

const int N_AMP = 8;
const float LIMIAR_ESTAVEL_G = 5.0;
float janela[N_AMP];
int idxJ = 0, cntJ = 0;

void limparJanela() { idxJ = 0; cntJ = 0; }

bool estavel(float g) {
  janela[idxJ] = g;
  idxJ = (idxJ + 1) % N_AMP;
  if (cntJ < N_AMP) cntJ++;
  if (cntJ < N_AMP) return false;
  float mn = janela[0], mx = janela[0];
  for (int i = 1; i < N_AMP; i++) {
    if (janela[i] < mn) mn = janela[i];
    if (janela[i] > mx) mx = janela[i];
  }
  return (mx - mn) <= LIMIAR_ESTAVEL_G;
}

void lcd2(uint8_t l, const String& s) {
  String t = s;
  while (t.length() < 16) t += ' ';
  lcd.setCursor(0, l);
  lcd.print(t.substring(0, 16));
}

void mostrarPeso(float kg) {
  char b[17];
  snprintf(b, sizeof b, "Peso: %6.3fkg", kg);
  lcd2(1, b);
}

void beep(int ms) {
  digitalWrite(PIN_BUZZER, HIGH);
  delay(ms);
  digitalWrite(PIN_BUZZER, LOW);
}
void somOK() { beep(100); delay(80); beep(100); }
void somAlerta() { for (int i = 0; i < 3; i++) { beep(250); delay(150); } }

void atualizarLeds() {
  bool pisca = (millis() / 400) % 2;
  if (estado == ST_DIVERGENTE) {
    digitalWrite(PIN_LED_AZUL, pisca);
    digitalWrite(PIN_LED_VERDE, pisca);
  } else {
    digitalWrite(PIN_LED_AZUL, HIGH);
    digitalWrite(PIN_LED_VERDE, WiFi.status() == WL_CONNECTED ? HIGH : LOW);
  }
}

String textoErro(int codigo) {
  if (codigo == 409) return "Escolha operacao";
  if (codigo == 401) return "Chave invalida";
  if (codigo == -1) return "Sem Wi-Fi";
  if (codigo == 0) return "Servidor offline";
  return "Erro HTTP " + String(codigo);
}

void mostrarEnvio(const char* rotulo, int codigo, float kg) {
  if (codigo == 201) {
    lcd2(0, String(rotulo) + " enviado");
    lcd2(1, String(kg, 3) + " kg");
  } else {
    lcd2(0, String(rotulo) + " NAO enviado");
    lcd2(1, textoErro(codigo));
  }
}

int postDispositivo(const char* caminho, const String& corpo, String& resposta) {
  if (WiFi.status() != WL_CONNECTED) return -1;

  String url = String(SERVIDOR_URL) + caminho;
  HTTPClient http;
  http.setTimeout(3000);
  bool iniciado;
  if (url.startsWith("https://")) {
    WiFiClientSecure seguro;
    seguro.setInsecure();
    iniciado = http.begin(seguro, url);
    if (!iniciado) return 0;
    http.addHeader("Content-Type", "application/json");
    http.addHeader("X-Device-Key", DEVICE_KEY);
    int codigo = http.POST(corpo);
    resposta = http.getString();
    http.end();
    return codigo < 0 ? 0 : codigo;
  }
  WiFiClient simples;
  iniciado = http.begin(simples, url);
  if (!iniciado) return 0;
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_KEY);
  int codigo = http.POST(corpo);
  resposta = http.getString();
  http.end();
  return codigo < 0 ? 0 : codigo;
}

int enviarLeituraUma(const char* etapa, float kg) {
  String corpo = String("{\"etapa\":\"") + etapa + "\",\"pesoKg\":" + String(kg, 3) +
                 ",\"estavel\":true,\"sinalDbm\":" + String(WiFi.RSSI()) +
                 ",\"firmware\":\"" + FIRMWARE_VERSAO + "\"}";
  String resposta;
  int codigo = postDispositivo("/api/dispositivos/leituras", corpo, resposta);
  Serial.print("Envio ");
  Serial.print(etapa);
  Serial.print(": HTTP ");
  Serial.println(codigo);
  if (codigo != 201) Serial.println(resposta);
  return codigo;
}

int enviarLeitura(const char* etapa, float kg) {
  int codigo = -1;
  for (int tentativa = 1; tentativa <= 3; tentativa++) {
    codigo = enviarLeituraUma(etapa, kg);
    if (!(codigo == 0 || codigo >= 500)) break;
    if (tentativa < 3) {
      Serial.println("Nova tentativa em 1 s...");
      delay(1000);
    }
  }
  return codigo;
}

void enviarSinal() {
  String corpo = String("{\"firmware\":\"") + FIRMWARE_VERSAO + "\",\"sinalDbm\":" + String(WiFi.RSSI()) + "}";
  String resposta;
  int codigo = postDispositivo("/api/dispositivos/sinal", corpo, resposta);
  if (codigo != 200) {
    Serial.print("Sinal de vida: HTTP ");
    Serial.println(codigo);
  }
}

void processarSerial() {
  if (!Serial.available()) return;
  String cmd = Serial.readStringUntil('\n');
  cmd.trim();
  cmd.toLowerCase();

  if (cmd == "t") {
    scale.tare(20);
    Serial.println("Tara concluida.");
  } else if (cmd.startsWith("c ")) {
    float g = cmd.substring(2).toFloat();
    if (g > 0) {
      scale.set_scale(1.0);
      double leitura = scale.get_value(20);
      fatorCal = leitura / g;
      scale.set_scale(fatorCal);
      Serial.print("Fator de calibracao: ");
      Serial.println(fatorCal, 6);
      estado = ST_AGUARDANDO;
      medVazio = medCarga = medTotal = 0;
      ultimaMedida = scale.get_units(3);
      aguardandoMudanca = true;
      limparJanela();
      lcd2(0, "Calibrado!");
      lcd2(1, "Retire o peso");
      delay(2000);
    }
  } else if (cmd == "r") {
    estado = ST_AGUARDANDO;
    medVazio = medCarga = medTotal = 0;
    ultimaMedida = -99999;
    aguardandoMudanca = false;
    limparJanela();
    Serial.println("Operacao reiniciada.");
  } else if (cmd == "ajuda") {
    Serial.println("t = tara | c <gramas> = calibrar | r = reiniciar");
  }
}

void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_LED_AZUL, OUTPUT);
  pinMode(PIN_LED_VERDE, OUTPUT);
  digitalWrite(PIN_LED_AZUL, HIGH);

  lcd.init();
  lcd.backlight();
  lcd2(0, "LoadSense");
  lcd2(1, "Iniciando...");

  scale.begin(PIN_DT, PIN_SCK);
  scale.set_scale(1.0);

  if (scale.wait_ready_timeout(3000)) {
    scale.tare(20);
    Serial.println("HX711 OK. Tara inicial concluida.");
  } else {
    lcd2(0, "ERRO HX711!");
    lcd2(1, "Verifique fios");
    Serial.println("ERRO: HX711 nao respondeu.");
    while (true) delay(1000);
  }

  lcd2(0, "Conectando WiFi");
  lcd2(1, "Aguarde...");
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  unsigned long t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) delay(250);

  if (WiFi.status() == WL_CONNECTED) {
    lcd2(0, "Conectado!");
    lcd2(1, "WiFi OK");
    Serial.println("Wi-Fi conectado.");
    somOK();
  } else {
    lcd2(0, "WiFi ERRO");
    lcd2(1, "Sem envio");
    Serial.println("Wi-Fi falhou. As leituras nao serao enviadas.");
  }

  delay(1500);
  estado = ST_AGUARDANDO;
  Serial.println("=== LoadSense pronto ===");
}

const unsigned long INTERVALO_SINAL_MS = 60000;
unsigned long ultimoSinal = 0;
bool sinalEnviadoAlguma = false;
unsigned long tRepouso = 0;

void loop() {
  processarSerial();
  atualizarLeds();

  if (WiFi.status() == WL_CONNECTED && (!sinalEnviadoAlguma || millis() - ultimoSinal >= INTERVALO_SINAL_MS)) {
    enviarSinal();
    ultimoSinal = millis();
    sinalEnviadoAlguma = true;
  }

  if (!scale.is_ready()) {
    lcd2(0, "HX711 sem sinal");
    lcd2(1, "Verifique fios");
    delay(500);
    return;
  }

  float pesoG = scale.get_units(3);
  float pesoKg = pesoG / 1000.0;
  if (fabs(pesoG) < 0.5) { pesoG = 0; pesoKg = 0; }

  bool e = estavel(pesoG);

  if (aguardandoMudanca) {
    if (fabs(pesoG - ultimaMedida) > 200) {
      aguardandoMudanca = false;
      limparJanela();
    } else {
      lcd2(0, "Altere o peso...");
      mostrarPeso(pesoKg);
      delay(250);
      return;
    }
  }

  if ((estado == ST_OK || estado == ST_DIVERGENTE) && pesoG < 50) {
    if (tRepouso == 0) tRepouso = millis();
    if (millis() - tRepouso > 3000) {
      estado = ST_AGUARDANDO;
      tRepouso = 0;
      medVazio = medCarga = medTotal = 0;
      limparJanela();
    }
  } else {
    tRepouso = 0;
  }

  switch (estado) {
    case ST_AGUARDANDO:
      lcd2(0, "Aguardando...");
      mostrarPeso(pesoKg);
      if (e && pesoG > 50) {
        estado = ST_MEDIR_VAZIO;
        limparJanela();
      }
      break;

    case ST_MEDIR_VAZIO:
      lcd2(0, "1/3 Caminhao vaz");
      mostrarPeso(pesoKg);
      if (e && pesoG > 50) {
        medVazio = pesoKg;
        ultimaMedida = pesoG;
        mostrarEnvio("Vazio", enviarLeitura("EMPTY_TRUCK", medVazio), medVazio);
        somOK();
        delay(2000);
        aguardandoMudanca = true;
        estado = ST_MEDIR_CARGA;
      }
      break;

    case ST_MEDIR_CARGA:
      lcd2(0, "2/3 Medir carga");
      mostrarPeso(pesoKg);
      if (e && pesoG > 50) {
        medCarga = pesoKg;
        ultimaMedida = pesoG;
        mostrarEnvio("Carga", enviarLeitura("SEPARATED_CARGO", medCarga), medCarga);
        somOK();
        delay(2000);
        aguardandoMudanca = true;
        estado = ST_MEDIR_TOTAL;
      }
      break;

    case ST_MEDIR_TOTAL:
      lcd2(0, "3/3 Carregado");
      mostrarPeso(pesoKg);
      if (e && pesoG > 50) {
        medTotal = pesoKg;
        ultimaMedida = pesoG;
        float esperado = medVazio + medCarga;
        float dif = medTotal - esperado;
        ultimoCodigoTotal = enviarLeitura("LOADED_TRUCK", medTotal);

        if (fabs(dif) <= TOL_KG) {
          estado = ST_OK;
          lcd2(0, "PESO CONFERE!");
          lcd2(1, String(medTotal, 3) + " kg");
          somOK();
        } else {
          estado = ST_DIVERGENTE;
          lcd2(0, "DIVERGENCIA!");
          lcd2(1, "Dif:" + String(dif, 2) + "kg");
          somAlerta();
        }
        if (ultimoCodigoTotal != 201) Serial.println("Aviso: total nao enviado. Codigo: " + String(ultimoCodigoTotal));
      }
      break;

    case ST_OK:
      lcd2(0, "PESO CONFERE!");
      if (ultimoCodigoTotal == 201) mostrarPeso(medTotal); else lcd2(1, textoErro(ultimoCodigoTotal));
      break;

    case ST_DIVERGENTE:
      lcd2(0, "DIVERGENCIA!");
      if (ultimoCodigoTotal == 201) mostrarPeso(medTotal); else lcd2(1, textoErro(ultimoCodigoTotal));
      break;

    default:
      break;
  }
  delay(250);
}
