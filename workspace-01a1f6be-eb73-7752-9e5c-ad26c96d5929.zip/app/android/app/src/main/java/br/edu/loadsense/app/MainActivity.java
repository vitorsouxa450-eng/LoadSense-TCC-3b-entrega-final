package br.edu.loadsense.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
