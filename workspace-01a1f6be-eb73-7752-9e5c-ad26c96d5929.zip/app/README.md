# Aplicativo LoadSense

Aplicativo web mobile-first (largura de 420 px, pt-BR), identidade `#C2410C` / `#121212`.
Consome a API (`../api`). Sem servidor, mostra dados de exemplo no navegador.

## Rodar

```bash
npm install
npm run dev          # http://localhost:5173 (proxy /api → 5174)
```

Para o modo servidor, suba a API antes (`cd ../api && node server/index.js`).
Sem API, o app entra sozinho com **dados de exemplo** (simulados no navegador). A entrega do projeto usa sempre a API e o banco.

## Versão sem banco (arquivada): `app.html`

```bash
npm run build
python3 scripts/build-standalone.py     # gera app/app.html (≈620 KB, sem recursos externos)
```

`app.html` abre direto no navegador e usa dados de exemplo embutidos (não lê o banco). Está arquivado e **não é a entrega** deste projeto; só gere de novo se for usar essa versão.

## Telas

Splash, termos, login, recuperação de senha (e-mail → código → nova senha), cadastro, dashboard,
planilha, nova pesagem (3 etapas), operação, monitoramento, alertas, histórico, relatórios,
configurações, perfil, planos, status e sobre.

## Estrutura

```
app/
├── src/
│   ├── pages/         telas (LoginPage, RecuperacaoPages, DashboardPage, …)
│   ├── components/    cabeçalho, navegação, cartões, mapa
│   ├── store/         estado global; alterna entre modo servidor e dados de exemplo
│   └── lib/api.ts     cliente HTTP (compartilhado com o site)
├── scripts/           testes de fluxo, capturas de tela, build do app.html
├── public/            ícones e manifesto
└── app.html           aplicativo em arquivo único (gerado)
```

## Testes

A verificação do app é feita pelo typecheck (`npm run typecheck`). Os roteiros de navegador ficaram fora da entrega.
