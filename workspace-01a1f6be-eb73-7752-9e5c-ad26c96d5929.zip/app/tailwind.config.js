export default {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx}", "../shared/src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
          elev: "hsl(var(--card-elev))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        success: {
          DEFAULT: "hsl(var(--success))",
          foreground: "hsl(var(--success-foreground))",
        },
        warning: {
          DEFAULT: "hsl(var(--warning))",
          foreground: "hsl(var(--warning-foreground))",
        },
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
        "2xl": "1rem",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "-apple-system", "sans-serif"],
        brand: ["Montserrat", "system-ui", "-apple-system", "sans-serif"],
      },
      keyframes: {
        "ls-fade-in": {
          from: { opacity: "0" },
          to: { opacity: "1" },
        },
        "ls-slide-up": {
          from: { opacity: "0", transform: "translateY(8px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        "ls-tela": {
          from: { opacity: "0", transform: "translateX(14px)" },
          to: { opacity: "1", transform: "translateX(0)" },
        },
        "ls-sheet-up": {
          from: { opacity: "0", transform: "translateY(32px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        "ls-toast-in": {
          from: { opacity: "0", transform: "translateY(12px) scale(0.98)" },
          to: { opacity: "1", transform: "translateY(0) scale(1)" },
        },
        "ls-loading": {
          "0%": { transform: "translateX(-100%)" },
          "100%": { transform: "translateX(200%)" },
        },
      },
      transitionTimingFunction: {
        "ls-suave": "cubic-bezier(0.22, 1, 0.36, 1)",
      },
      animation: {
        "ls-fade-in": "ls-fade-in 280ms cubic-bezier(0.22, 1, 0.36, 1) both",
        "ls-slide-up": "ls-slide-up 320ms cubic-bezier(0.22, 1, 0.36, 1) both",
        "ls-tela": "ls-tela 340ms cubic-bezier(0.22, 1, 0.36, 1) both",
        "ls-sheet-up": "ls-sheet-up 380ms cubic-bezier(0.22, 1, 0.36, 1) both",
        "ls-toast-in": "ls-toast-in 300ms cubic-bezier(0.22, 1, 0.36, 1) both",
        "ls-loading": "ls-loading 1.4s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
