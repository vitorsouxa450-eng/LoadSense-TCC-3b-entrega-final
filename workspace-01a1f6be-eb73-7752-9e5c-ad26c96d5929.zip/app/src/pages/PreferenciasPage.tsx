import { AppHeader } from "@/components/AppHeader";
import { AppShell } from "@/components/AppShell";
import { useToast } from "@/components/Toast";
import { Section, Toggle } from "@/components/ui";
import { useStore } from "@/store/store";
import { useTheme } from "@/lib/theme";
import { pedirPermissaoAviso, permissaoAviso, type PermissaoAviso } from "@shared/lib/avisos";
import { useState } from "react";
import { cn } from "@/lib/utils";

const IDIOMAS = ["PT-BR", "EN", "ES"] as const;

export function PreferenciasPage() {
  const { preferences, atualizarPreferencias, modo } = useStore();
  const { theme, setTheme } = useTheme();
  const { notificar } = useToast();
  const [permissao, setPermissao] = useState<PermissaoAviso>(permissaoAviso());

  async function alternarNotificacoes(valor: boolean) {
    atualizarPreferencias({ notificacoes: valor });
    if (valor) setPermissao(await pedirPermissaoAviso());
  }

  const itens: Array<{ chave: keyof typeof preferences; rotulo: string; descricao: string }> = [
    { chave: "notificacoes", rotulo: "Avisos de alerta", descricao: "Toast e notificação do sistema com o app aberto" },
    { chave: "sons", rotulo: "Sons de alerta", descricao: "Reproduzir som ao receber alerta" },
    { chave: "apenasCriticos", rotulo: "Apenas alertas críticos", descricao: "Filtrar notificações e listas" },
    {
      chave: "autoSync",
      rotulo: "Sincronização automática",
      descricao: modo === "servidor" ? "Atualizar dados a cada 30 s" : "Atualizar dados a cada 5 s (demonstração)",
    },
  ];

  return (
    <AppShell activeNav="Configurações" headerSlot={<AppHeader back title="Preferências" />}>
      <ul className="mx-5 mt-4 mb-3 divide-y divide-border/60 rounded-2xl border border-border/60 bg-card">
        {itens.map((item) => (
          <li key={item.chave} className="flex items-center gap-3 px-4 py-3">
            <div className="flex-1">
              <div className="text-[12px] font-semibold">{item.rotulo}</div>
              <div className="text-[10px] text-muted-foreground">{item.descricao}</div>
            </div>
            <Toggle
              rotulo={item.rotulo}
              on={Boolean(preferences[item.chave])}
              onChange={(valor) =>
                item.chave === "notificacoes"
                  ? void alternarNotificacoes(valor)
                  : atualizarPreferencias({ [item.chave]: valor })
              }
            />
          </li>
        ))}
      </ul>

      {preferences.notificacoes && (
        <p className="mx-5 -mt-1 mb-3 text-[11px] text-muted-foreground">
          {permissao === "granted" && "Permissão do navegador concedida: você verá avisos do sistema."}
          {permissao === "denied" &&
            "Permissão bloqueada no navegador. Libere as notificações nas configurações do site para receber avisos do sistema; os avisos na tela continuam."}
          {permissao === "default" && (
            <>
              Permita as notificações do navegador para receber avisos do sistema.{" "}
              <button
                type="button"
                className="font-semibold text-primary"
                onClick={async () => setPermissao(await pedirPermissaoAviso())}
              >
                Permitir
              </button>
            </>
          )}
          {permissao === "indisponivel" &&
            "Este navegador não oferece notificações do sistema; os avisos aparecem na tela."}
        </p>
      )}

      <Section title="Aparência">
        <div className="flex items-center gap-3">
          <div className="flex-1">
            <div className="text-[12px] font-semibold">Tema da interface</div>
            <div className="text-[10px] text-muted-foreground">
              Padrão LoadSense: escuro (#121212) com destaque laranja (#C2410C)
            </div>
          </div>
          <Toggle rotulo="Tema escuro" on={theme === "dark"} onChange={(valor) => setTheme(valor ? "dark" : "light")} />
        </div>
      </Section>

      <Section title="Idioma" className="mb-5">
        <div className="grid grid-cols-3 gap-2">
          {IDIOMAS.map((idioma) => (
            <button
              key={idioma}
              type="button"
              onClick={() => {
                atualizarPreferencias({ idioma });
                notificar({ titulo: `Idioma: ${idioma}`, descricao: "Preferência salva localmente.", tom: "info" });
              }}
              className={cn(
                "rounded-xl border py-2 text-[12px] font-semibold",
                preferences.idioma === idioma
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border/60 bg-card-elev text-muted-foreground",
              )}
            >
              {idioma}
            </button>
          ))}
        </div>
      </Section>
    </AppShell>
  );
}
