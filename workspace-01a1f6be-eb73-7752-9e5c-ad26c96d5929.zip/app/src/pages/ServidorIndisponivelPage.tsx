import { useEffect } from "react";
import { detectarServidor } from "@shared/lib/api";

export function ServidorIndisponivelPage() {
  useEffect(() => {
    const temporizador = setInterval(async () => {
      const { disponivel } = await detectarServidor();
      if (disponivel) window.location.reload();
    }, 5000);
    return () => clearInterval(temporizador);
  }, []);
  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-6">
      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 text-center shadow-sm">
        <h1 className="text-lg font-semibold">Sem servidor disponível</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          O LoadSense precisa do servidor (API e banco de dados) para mostrar as informações. Por isso, nenhum dado de
          exemplo é exibido.
        </p>
        <ol className="mt-4 space-y-2 text-left text-sm">
          <li>
            1. Confira se a janela da API está aberta e mostrando <strong>ouvindo em http://0.0.0.0:5174</strong>.
          </li>
          <li>2. Se a API mostrar erro de banco de dados, confirme que o MySQL está no ar (porta 3307).</li>
          <li>
            3. Clique em <strong>Tentar novamente</strong>. A tela também verifica sozinha a cada 5 segundos.
          </li>
        </ol>
        <button
          type="button"
          onClick={() => window.location.reload()}
          className="mt-6 w-full rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground"
        >
          Tentar novamente
        </button>
      </div>
    </div>
  );
}
