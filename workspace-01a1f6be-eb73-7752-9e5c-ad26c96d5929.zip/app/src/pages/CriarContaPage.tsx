import { AppShell } from "@/components/AppShell";
import { AppHeader } from "@/components/AppHeader";
import { CriarContaPainel } from "@/components/CriarContaPainel";
import { useStore } from "@/store/store";

export function CriarContaPage() {
  const { modo, sessao } = useStore();
  const podeCriar = modo === "servidor" && sessao?.usuario.papel === "ADMINISTRATOR";

  return (
    <AppShell activeNav="Configurações" headerSlot={<AppHeader back title="Criar conta" />}>
      <div className="px-5 pt-4">
        <h1 className="text-xl font-bold">Criar conta</h1>
        <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">
          Crie contas para as pessoas da sua empresa e defina o cargo de cada uma. Só administradores podem criar
          contas.
        </p>
      </div>
      <div className="mx-5 mb-6 mt-4">
        {podeCriar ? (
          <CriarContaPainel />
        ) : (
          <p className="rounded-xl border border-border/60 bg-card-elev p-4 text-[12px] text-muted-foreground">
            Esta área é exclusiva para administradores da empresa. Entre com uma conta de administrador para criar
            contas.
          </p>
        )}
      </div>
    </AppShell>
  );
}
