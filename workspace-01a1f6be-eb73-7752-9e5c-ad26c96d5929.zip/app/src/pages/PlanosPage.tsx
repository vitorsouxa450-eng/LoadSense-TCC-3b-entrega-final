import { CircleCheck, MessageCircle } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { AppShell } from "@/components/AppShell";
import { useStore } from "@/store/store";
import { cn } from "@/lib/utils";

interface Plano {
  nome: string;
  limites: string;
  precoMensal: string;
  precoAnual: string;
  descricao: string;
  itens: string[];
  destaque?: boolean;
}

const PLANOS: Plano[] = [
  {
    nome: "Essencial",
    limites: "até 3 veículos",
    precoMensal: "R$ 149,90",
    precoAnual: "R$ 1.529,90 por ano",
    descricao: "Para começar a controlar a operação.",
    itens: [
      "Operações de pesagem ilimitadas",
      "Cadastros de caminhões, motoristas, produtos e rotas",
      "Painel, alertas e monitoramento",
      "Relatórios em CSV e XLSX",
      "Histórico dos últimos 90 dias",
    ],
  },
  {
    nome: "Profissional",
    limites: "até 10 veículos",
    precoMensal: "R$ 349,90",
    precoAnual: "R$ 3.569,90 por ano",
    descricao: "Para parar de digitar e não perder histórico.",
    itens: [
      "Tudo do Essencial",
      "Importação e exportação de planilha",
      "Histórico completo, sem limite de 90 dias",
      "Suporte prioritário",
    ],
    destaque: true,
  },
  {
    nome: "Avançado",
    limites: "até 25 veículos",
    precoMensal: "R$ 749,90",
    precoAnual: "R$ 7.649,90 por ano",
    descricao: "Para operações em crescimento, com mais veículos e usuários.",
    itens: ["Tudo do Profissional", "Usuários ilimitados"],
  },
  {
    nome: "Enterprise",
    limites: "acima de 25 veículos",
    precoMensal: "Sob consulta",
    precoAnual: "",
    descricao: "Para operações maiores e com necessidades específicas.",
    itens: ["Tudo do Avançado", "Implantação assistida e treinamento", "SLA e suporte dedicado"],
  },
];

const CONTATO = import.meta.env.VITE_CONTATO_COMERCIAL as string | undefined;

function linkConsultoria(plano?: string) {
  const assunto = plano ? `Contratação do plano ${plano}` : "Contratação de plano LoadSense";
  if (!CONTATO) return undefined;
  return CONTATO.includes("@") ? `mailto:${CONTATO}?subject=${encodeURIComponent(assunto)}` : CONTATO;
}

export function PlanosPage() {
  const { profile } = useStore();

  return (
    <AppShell activeNav="Configurações" headerSlot={<AppHeader back title="Planos" />}>
      <div className="px-5 pt-4">
        <h1 className="text-xl font-bold">Planos</h1>
        <p className="text-[11px] text-muted-foreground">
          Escolha o plano pelo tamanho da sua frota e pelo que a sua operação precisa. Cada plano tem um botão para
          falar com a consultoria LoadSense, que orienta a contratação.
        </p>
      </div>

      <div className="space-y-3 px-5 pb-5 pt-4">
        {PLANOS.map((plano) => {
          const atual = plano.nome.toLowerCase() === profile.plano.toLowerCase();
          const link = linkConsultoria(plano.nome);
          return (
            <div
              key={plano.nome}
              className={cn(
                "rounded-2xl border p-4",
                plano.destaque ? "border-primary/60 bg-card-elev" : "border-border/60 bg-card",
              )}
            >
              <div className="flex items-center justify-between">
                <div className="text-[13px] font-bold">{plano.nome}</div>
                {atual && (
                  <span className="rounded-full bg-success/15 px-2 py-0.5 text-[9px] font-bold uppercase text-success">
                    Plano atual
                  </span>
                )}
              </div>
              <div className="text-[10px] text-muted-foreground">{plano.limites}</div>

              <div className="mt-1 text-lg font-extrabold tabular">
                {plano.precoMensal}
                {plano.precoMensal.startsWith("R$") && (
                  <span className="text-[10px] font-normal text-muted-foreground"> /mês</span>
                )}
              </div>
              {plano.precoAnual && <div className="text-[10px] text-muted-foreground">ou {plano.precoAnual}</div>}

              <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">{plano.descricao}</p>

              <ul className="mt-3 space-y-1.5">
                {plano.itens.map((item) => (
                  <li key={item} className="flex gap-2 text-[11px]">
                    <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              {!atual && (
                <a
                  href={link}
                  target={link?.startsWith("http") ? "_blank" : undefined}
                  rel="noreferrer"
                  aria-disabled={!link}
                  className={cn(
                    "mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-[12px] font-semibold",
                    link ? "bg-primary text-primary-foreground" : "pointer-events-none bg-muted text-muted-foreground",
                  )}
                >
                  <MessageCircle className="h-3.5 w-3.5" />
                  {link ? `Falar com a consultoria sobre ${plano.nome}` : "Contato comercial indisponível"}
                </a>
              )}
            </div>
          );
        })}

        <p className="pt-1 text-center text-[10px] text-muted-foreground">
          Teste grátis de 14 dias no plano Profissional. Enterprise é sob consulta. · LoadSense Tecnologia e Logística
          LTDA
        </p>
      </div>
    </AppShell>
  );
}
