import { useEffect, useState } from "react";
import { Boxes, CircleCheck, CirclePlay, Truck, TriangleAlert, Weight } from "lucide-react";
import { Link } from "react-router-dom";
import { AppShell } from "@/components/AppShell";
import { Ring, Sparkline } from "@/components/charts";
import { Banner, Pill, ProgressBar, Section, StatCard } from "@/components/ui";
import { dashboardSummary } from "@/lib/analytics";
import { useStore } from "@/store/store";
import { GuiaPrimeirosPassos, guiaJaVisto } from "@shared/components/ajuda/GuiaPrimeirosPassos";
import { PASSOS_GUIA_APP } from "@shared/lib/ajuda";
import { cn, formatNumber, timeAgo } from "@/lib/utils";

export function DashboardPage() {
  const { operations, alerts, ativas, ultimaSync, sensors, profile } = useStore();
  const resumo = dashboardSummary(operations, alerts);
  const alertasAtivos = alerts.filter((alert) => alert.status === "ativo");
  const critico = alertasAtivos.find((alert) => alert.nivel === "critico") ?? alertasAtivos[0];
  const ultima = sensors.rfid.ultimaLeitura;
  const variacaoToneladas = variacao(resumo.serieToneladas);
  const [guiaAberto, setGuiaAberto] = useState(false);
  useEffect(() => {
    if (!guiaJaVisto("app")) setGuiaAberto(true);
  }, []);

  return (
    <AppShell activeNav="Dashboard">
      <div className="px-5 pt-4 pb-2">
        <h1 className="text-xl font-bold">Olá, {profile.nome.split(" ")[0]}</h1>
        <p className="mt-0.5 text-xs text-muted-foreground">Acompanhe o status da operação</p>
      </div>

      {}
      <section className="mx-5 mt-3 rounded-2xl border border-border/60 bg-card p-4">
        <p className="text-[11px] font-semibold tracking-widest text-muted-foreground">NÍVEL OPERACIONAL</p>
        <div className="mt-3 flex items-center gap-4">
          <Ring value={resumo.eficienciaPct} size={130} stroke={11}>
            <div className="text-center">
              <div className="text-2xl font-bold tabular">{resumo.eficienciaPct}%</div>
              <div className="text-[10px] tracking-wider text-muted-foreground">OPERAÇÃO ATIVA</div>
            </div>
          </Ring>

          <ul className="flex-1 space-y-2 text-[12px]">
            <li className="flex items-start gap-2">
              <span className="mt-1.5 h-2 w-2 rounded-full bg-success" />
              <div>
                <div className="font-semibold">Frota ativa</div>
                <div className="text-[11px] text-muted-foreground">{resumo.frotaAtiva} veículos</div>
              </div>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-1.5 h-2 w-2 rounded-full bg-primary" />
              <div>
                <div className="font-semibold">Em rota</div>
                <div className="text-[11px] text-muted-foreground">{ativas.length} entregas</div>
              </div>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-1.5 h-2 w-2 rounded-full bg-destructive" />
              <div>
                <div className="font-semibold">Alertas</div>
                <div className="text-[11px] text-muted-foreground">{resumo.alertasCriticos} críticos</div>
              </div>
            </li>
          </ul>
        </div>

        <Banner
          tom={resumo.divergenciasHoje > 0 ? "warning" : "success"}
          className="mt-3"
          icone={
            resumo.divergenciasHoje > 0 ? (
              <TriangleAlert className="h-4 w-4 text-warning" />
            ) : (
              <CircleCheck className="h-4 w-4 text-success" />
            )
          }
        >
          {resumo.divergenciasHoje > 0
            ? `${resumo.divergenciasHoje} divergência(s) de peso detectada(s) nas pesagens de hoje`
            : "Nenhuma divergência detectada hoje"}
        </Banner>
      </section>

      {}
      <section className="mx-5 mt-5">
        <Link to="/relatorios" className="mb-2 flex items-center justify-between">
          <h2 className="text-sm font-semibold">Resumo da operação</h2>
          <span className="text-[11px] text-primary">Hoje ›</span>
        </Link>
        <Link to="/relatorios" className="grid grid-cols-4 gap-2">
          {[
            { valor: String(resumo.viagensHoje), rotulo: "Viagens" },
            { valor: String(resumo.cargas), rotulo: "Cargas" },
            { valor: formatNumber(resumo.toneladasHoje, 1), rotulo: "Toneladas" },
            { valor: String(resumo.alertasAtivos), rotulo: "Alertas" },
          ].map((item) => (
            <div key={item.rotulo} className="rounded-xl border border-border/60 bg-card p-2.5">
              <div className="text-sm font-bold tabular">{item.valor}</div>
              <div className="mt-0.5 text-[10px] text-muted-foreground">{item.rotulo}</div>
            </div>
          ))}
        </Link>
      </section>

      {}
      <Section
        title="Monitoramento em tempo real"
        className="mt-5"
        action={
          <Link to="/monitoramento" className="text-[11px] text-primary">
            Ver tudo ›
          </Link>
        }
      >
        <Sparkline data={resumo.serieToneladas} height={110} />
        <div className="mt-2 flex items-center justify-between text-[10px] text-muted-foreground">
          <span>Toneladas transportadas · últimos 10 dias</span>
          <span>{timeAgo(ultimaSync)}</span>
        </div>
        <div className="mt-3 flex items-center justify-between rounded-xl bg-card-elev px-3 py-2">
          <div className="flex items-center gap-2">
            <CirclePlay className="h-3.5 w-3.5 text-success" />
            <span className="text-[11px]">Leituras RFID ativas</span>
          </div>
          <span className="text-[11px] font-semibold text-muted-foreground">
            {ultima ? `última leitura ${timeAgo(ultima)}` : "sem leituras de RFID"}
          </span>
        </div>
      </Section>

      {}
      <section className="mx-5 mt-5 grid grid-cols-2 gap-2">
        {[
          {
            valor: resumo.viagensHoje,
            rotulo: "Viagens",
            detalhe: `${resumo.emRota} em andamento · ${resumo.concluidasHoje} concluídas`,
            icone: <Truck className="h-4 w-4" />,
          },
          {
            valor: resumo.cargas,
            rotulo: "Cargas",
            detalhe: "Todas registradas no RFID",
            icone: <Boxes className="h-4 w-4" />,
          },
          {
            valor: `${formatNumber(resumo.toneladasHoje, 1)} t`,
            rotulo: "Toneladas",
            detalhe: `Média ${formatNumber(resumo.mediaPorViagemT, 1)} t / viagem`,
            icone: <Weight className="h-4 w-4" />,
          },
          {
            valor: resumo.alertasAtivos,
            rotulo: "Alertas",
            detalhe: `${resumo.alertasCriticos} crítico(s) · ${resumo.alertasAtencao} atenção`,
            icone: <TriangleAlert className="h-4 w-4" />,
          },
        ].map((item) => (
          <StatCard
            key={item.rotulo}
            valor={item.valor}
            rotulo={item.rotulo}
            detalhe={item.detalhe}
            icone={item.icone}
          />
        ))}
      </section>

      {}
      <Section title="Tendência de carga" className="mt-4">
        <div className="flex items-end justify-between">
          <div>
            <div className="text-lg font-bold tabular">{formatNumber(resumo.toneladasHoje, 1)} t</div>
            <div className="text-[10px] text-muted-foreground">movimentadas hoje</div>
          </div>
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-semibold",
              variacaoToneladas >= 0 ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive",
            )}
          >
            {variacaoToneladas >= 0 ? "+" : ""}
            {formatNumber(variacaoToneladas, Math.abs(variacaoToneladas) >= 50 ? 0 : 1)}% vs. média do período
          </span>
        </div>
        <Sparkline data={resumo.serieViagens} height={80} className="mt-2" />
        <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
          <span>Viagens iniciadas por dia</span>
          <span>últimos 10 dias</span>
        </div>
      </Section>

      {}
      <section className="mx-5 mt-5 mb-5">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-sm font-semibold">Operações em andamento</h2>
          <Link to="/operacoes" className="text-[11px] text-primary">
            Ver tudo ›
          </Link>
        </div>
        <ul className="space-y-2">
          {ativas.slice(0, 4).map((op) => (
            <li key={op.id}>
              <Link
                to={`/operacoes/${op.id}`}
                className="flex items-center gap-3 rounded-2xl border border-border/60 bg-card p-3"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[13px] font-semibold">{op.placa}</span>
                    <Pill tom={op.status === "Parado" ? "warning" : "primary"}>{op.status}</Pill>
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    {op.destino} · {formatNumber(op.pesoCargaKg / 1000, 1)} t
                  </div>
                  <ProgressBar className="mt-2" valor={(op.kmPercorrido / op.distanciaKm) * 100} />
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {}
      <section className="mx-5 mb-5">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-sm font-semibold">Alertas ativos</h2>
          <Link to="/alertas" className="text-[11px] text-primary">
            Ver tudo ›
          </Link>
        </div>
        {critico ? (
          <Link
            to={`/alertas/${critico.id}`}
            className="flex items-center gap-3 rounded-xl border border-destructive/40 bg-destructive/10 p-3"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-destructive/20">
              <TriangleAlert className="h-4 w-4 text-destructive" />
            </div>
            <div className="flex-1">
              <div className="text-[13px] font-semibold">{critico.tipo}</div>
              <div className="text-[11px] text-muted-foreground">
                {critico.placa} · {timeAgo(new Date(critico.criadoEm).getTime())}
              </div>
            </div>
          </Link>
        ) : (
          <Banner tom="success" icone={<CircleCheck className="h-4 w-4 text-success" />}>
            Nenhum alerta ativo no momento
          </Banner>
        )}
      </section>
      <GuiaPrimeirosPassos
        plataforma="app"
        passos={PASSOS_GUIA_APP}
        aberto={guiaAberto}
        onFechar={() => setGuiaAberto(false)}
      />
    </AppShell>
  );
}

function variacao(serie: number[]) {
  if (serie.length < 2) return 0;
  const anterior = serie[serie.length - 2] || 0;
  const atual = serie[serie.length - 1] || 0;
  if (!anterior) return atual ? 100 : 0;
  return ((atual - anterior) / anterior) * 100;
}
