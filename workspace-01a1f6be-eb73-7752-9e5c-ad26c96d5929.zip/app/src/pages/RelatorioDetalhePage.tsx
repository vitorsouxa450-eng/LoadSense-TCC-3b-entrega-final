import { CircleCheck, Download, OctagonAlert, TrendingUp } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { AppHeader } from "@/components/AppHeader";
import { AppShell } from "@/components/AppShell";
import { BarChart, Donut, Ring, Sparkline } from "@/components/charts";
import { useToast } from "@/components/Toast";
import { Banner, EmptyState, InfoList, Section } from "@/components/ui";
import { dailySeries, principaisDivergencias, resumirPeriodo } from "@/lib/analytics";
import { useStore } from "@/store/store";
import { api } from "@shared/lib/api";
import { formatDate, formatNumber, formatSigned, formatTons } from "@/lib/utils";

export function RelatorioDetalhePage() {
  const { modo } = useStore();
  if (modo === "servidor") {
    return (
      <div className="px-5 py-10 text-center">
        <p className="text-[14px] font-semibold">Relatório não encontrado</p>
        <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
          Este relatório não está disponível. Volte à lista de relatórios e escolha outro.
        </p>
      </div>
    );
  }
  return <RelatorioDemonstracao />;
}

function RelatorioDemonstracao() {
  const { id } = useParams<{ id: string }>();
  const { notificar } = useToast();
  const { reports, operations, alerts } = useStore();

  const relatorio = reports.find((item) => item.id === id) ?? reports[0];
  const desde = +new Date(relatorio.inicio);
  const ate = +new Date(relatorio.fim);

  const { kpis, tipos } = resumirPeriodo(operations, alerts, desde, ate);
  const divergencias = principaisDivergencias(
    operations.filter((op) => +new Date(op.saida) >= desde),
    5,
  );
  const serieToneladas = dailySeries(operations, relatorio.tipo === "semanal" ? 7 : 14, "toneladas");
  const serieEficiencia = serieToneladas.map((valor, index, lista) => {
    const anterior = lista[index - 1] ?? valor;
    return Math.round(60 + (valor / Math.max(1, Math.max(...lista))) * 40 + (valor >= anterior ? 4 : -4));
  });

  if (!relatorio) {
    return (
      <AppShell activeNav="Relatórios" headerSlot={<AppHeader back title="Detalhes do Relatório" />}>
        <div className="px-5 pt-4">
          <EmptyState titulo="Relatório não encontrado" />
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell activeNav="Relatórios" headerSlot={<AppHeader back title="Detalhes do Relatório" />}>
      <div className="px-5 pt-4">
        <h1 className="text-base font-bold">{relatorio.titulo}</h1>
        <p className="text-[11px] text-muted-foreground">
          Período: {formatDate(relatorio.inicio)} a {formatDate(relatorio.fim)}
        </p>
      </div>

      <Section title="Resumo do período" className="mt-3">
        <p className="text-[12px] leading-relaxed text-muted-foreground">
          A operação manteve eficiência de {formatNumber(kpis.eficienciaPct, 1)}% no período, com {kpis.viagens} viagens
          registradas e {formatTons(kpis.volumeT)} transportados. Foram identificadas {divergencias.length}{" "}
          divergência(s) de pesagem, tratadas pela torre de controle.
        </p>
      </Section>

      <div className="mt-3 grid grid-cols-2 gap-2.5 px-5">
        {[
          { valor: String(kpis.viagens), rotulo: "Operações concluídas" },
          { valor: String(kpis.alertas), rotulo: "Alertas registrados" },
          { valor: `${formatNumber(kpis.eficienciaPct, 1)}%`, rotulo: "Eficiência operacional" },
          { valor: formatTons(kpis.volumeT), rotulo: "Volume total" },
        ].map((item) => (
          <div key={item.rotulo} className="rounded-xl border border-border/60 bg-card p-3">
            <div className="text-lg font-bold tabular">{item.valor}</div>
            <div className="mt-0.5 text-[10px] text-muted-foreground">{item.rotulo}</div>
          </div>
        ))}
      </div>

      <Section title="Eficiência operacional">
        <div className="flex items-center gap-4">
          <Ring value={kpis.eficienciaPct} size={104} stroke={10}>
            <div className="text-center">
              <div className="text-lg font-bold tabular">{formatNumber(kpis.eficienciaPct, 1)}%</div>
              <div className="text-[9px] text-muted-foreground">NO PERÍODO</div>
            </div>
          </Ring>
          <div className="flex-1">
            <Sparkline data={serieEficiencia} height={80} />
            <p className="mt-1 text-[10px] text-muted-foreground">
              Índice diário de eficiência calculado a partir de atrasos e divergências.
            </p>
          </div>
        </div>
      </Section>

      <Section title="Volume transportado por dia">
        <BarChart data={serieToneladas} height={110} />
        <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
          <span>Toneladas</span>
          <span>total {formatTons(kpis.volumeT)}</span>
        </div>
      </Section>

      <Section title="Distribuição por tipo de carga">
        <div className="flex items-center gap-4">
          <Donut fatias={tipos.map((fatia) => ({ label: fatia.label, valor: fatia.pct, cor: fatia.cor }))} size={104} />
          <ul className="flex-1 space-y-1.5 text-[11px]">
            {tipos.map((fatia) => (
              <li key={fatia.label} className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-sm" style={{ background: fatia.cor }} />
                  {fatia.label}
                </span>
                <span className="text-muted-foreground tabular">{fatia.pct}%</span>
              </li>
            ))}
          </ul>
        </div>
      </Section>

      <Section title="Principais divergências">
        {divergencias.length === 0 ? (
          <Banner tom="success" icone={<CircleCheck className="h-4 w-4" />}>
            Nenhuma divergência registrada no período
          </Banner>
        ) : (
          <ul className="space-y-2 text-[12px]">
            {divergencias.map((linha) => (
              <li key={linha.operacaoId} className="flex items-center gap-2">
                <OctagonAlert className="h-4 w-4 text-destructive" />
                <Link to={`/operacoes/${linha.operacaoId}`} className="flex-1 font-semibold text-primary">
                  {linha.placa}
                </Link>
                <span className="font-semibold text-destructive tabular">{formatSigned(linha.diferencaKg)}</span>
                <span className="text-[10px] text-muted-foreground">
                  {new Date(linha.data).toLocaleDateString("pt-BR")}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section title="Indicadores consolidados">
        <InfoList
          items={[
            ["Viagens realizadas", String(kpis.viagens)],
            ["Cargas transportadas", String(kpis.cargas)],
            ["Volume transportado", formatTons(kpis.volumeT)],
            ["Média por viagem", formatTons(kpis.mediaPorViagemT)],
            ["Taxa de divergência", `${formatNumber(kpis.taxaDivergenciaPct, 1)}%`],
            ["Alertas registrados", String(kpis.alertas)],
            ["Trecho de referência", "612 km (SP → Uberlândia)"],
          ]}
        />
        <Banner tom="success" className="mt-3" icone={<CircleCheck className="h-4 w-4" />}>
          Relatório validado pela torre de controle
        </Banner>
      </Section>

      <div className="px-5 pb-5 pt-4">
        <button
          type="button"
          onClick={() =>
            api
              .exportarRelatorio(Number(relatorio.id))
              .catch((e: Error) => notificar({ titulo: "Falha ao exportar", descricao: e.message, tom: "alert" }))
          }
          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3 text-[13px] font-semibold text-primary-foreground"
        >
          <Download className="h-4 w-4" />
          Exportar CSV
        </button>
        <p className="mt-2 flex items-center justify-center gap-1 text-[10px] text-muted-foreground">
          <TrendingUp className="h-3 w-3" />
          Tendência de queda nas divergências nas últimas semanas
        </p>
      </div>
    </AppShell>
  );
}
