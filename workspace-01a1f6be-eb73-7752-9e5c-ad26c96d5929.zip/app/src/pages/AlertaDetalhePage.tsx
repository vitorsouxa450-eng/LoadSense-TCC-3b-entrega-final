import { useState } from "react";
import { CircleCheck, OctagonAlert, TriangleAlert } from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { AppHeader } from "@/components/AppHeader";
import { AppShell } from "@/components/AppShell";
import { useToast } from "@/components/Toast";
import { EmptyState, InfoList, Pill } from "@/components/ui";
import { useStore } from "@/store/store";
import { cn, formatDate, formatKg, formatSigned, formatTime } from "@/lib/utils";
import { DetalheResolucao, FormResolucaoAlerta } from "@/components/FormResolucaoAlerta";
import { rotuloMotivo, type ResolucaoAlerta } from "@shared/lib/alertas";

export function AlertaDetalhePage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { alerts, operations, resolverAlerta, reabrirAlerta } = useStore();
  const [resolvendo, setResolvendo] = useState(false);
  const { notificar } = useToast();

  const alert = alerts.find((item) => item.id === id);
  const operacao = operations.find((op) => op.id === alert?.operacaoId);

  if (!alert) {
    return (
      <AppShell activeNav="Configurações" headerSlot={<AppHeader back title="Detalhes do Alerta" />}>
        <div className="px-5 pt-4">
          <EmptyState titulo="Alerta não encontrado" descricao="Ele pode ter sido removido." />
          <Link to="/alertas" className="mt-3 block text-center text-[12px] text-primary">
            Voltar para alertas
          </Link>
        </div>
      </AppShell>
    );
  }

  const critico = alert.nivel === "critico";
  const resolvido = alert.status === "resolvido";
  const Icone = critico ? OctagonAlert : TriangleAlert;

  const itens: Array<[string, React.ReactNode]> = [
    ["Tipo", alert.tipo],
    ["Placa do caminhão", alert.placa],
    ["Motorista", alert.motorista],
    ["Operação", alert.operacaoId],
    ["Data", `${formatDate(alert.criadoEm)} ${formatTime(alert.criadoEm)}`],
    ["Nível de risco", critico ? "Crítico" : "Atenção"],
    ["Status", resolvido ? "Resolvido" : "Ativo"],
  ];

  if (alert.pesoEsperadoKg !== undefined) itens.push(["Peso esperado", formatKg(alert.pesoEsperadoKg)]);
  if (alert.pesoRealKg !== undefined) itens.push(["Peso real", formatKg(alert.pesoRealKg)]);
  if (alert.diferencaKg !== undefined) itens.push(["Diferença", formatSigned(alert.diferencaKg)]);
  if (alert.duracaoMin !== undefined) itens.push(["Duração da parada", `${alert.duracaoMin} min`]);

  return (
    <AppShell activeNav="Configurações" headerSlot={<AppHeader back title="Detalhes do Alerta" />}>
      <section
        className={cn(
          "mx-5 mt-4 flex items-center gap-3 rounded-2xl border p-4",
          critico ? "border-destructive/40 bg-destructive/10" : "border-warning/40 bg-warning/10",
        )}
      >
        <div
          className={cn(
            "flex h-10 w-10 items-center justify-center rounded-full",
            critico ? "bg-destructive/20" : "bg-warning/20",
          )}
        >
          <Icone className={cn("h-5 w-5", critico ? "text-destructive" : "text-warning")} />
        </div>
        <div className="flex-1">
          <div className="text-[13px] font-bold">{alert.tipo}</div>
          <div className={cn("text-[11px]", critico ? "text-destructive" : "text-warning")}>
            {critico ? "Crítico" : "Atenção"} · {alert.placa}
          </div>
        </div>
        <Pill tom={resolvido ? "success" : critico ? "destructive" : "warning"}>
          {resolvido ? "Resolvido" : "Ativo"}
        </Pill>
      </section>

      <section className="mx-5 mt-4 rounded-2xl border border-border/60 bg-card p-4">
        <h3 className="mb-2 text-[13px] font-semibold">Descrição</h3>
        <p className="text-[12px] leading-relaxed text-muted-foreground">{alert.descricao}</p>
        {alert.extra && <p className="mt-2 text-[11px] font-semibold">{alert.extra}</p>}
      </section>

      <section className="mx-5 mt-3 rounded-2xl border border-border/60 bg-card p-4">
        <h3 className="mb-1 text-[13px] font-semibold">Dados da ocorrência</h3>
        <InfoList items={itens} />
      </section>

      {alert.resolvidoEm && (
        <section className="mx-5 mt-3 rounded-2xl border border-success/30 bg-success/10 p-4">
          <div className="text-[12px] font-semibold text-success">Resolvido</div>
          <div className="text-[11px] text-success">
            {formatDate(alert.resolvidoEm)} às {formatTime(alert.resolvidoEm)}
          </div>
          <DetalheResolucao
            motivo={rotuloMotivo(alert.motivoResolucao) || null}
            acao={alert.extra}
            por={alert.resolvidoPor}
            quando={`${formatDate(alert.resolvidoEm)} às ${formatTime(alert.resolvidoEm)}`}
          />
        </section>
      )}

      <div className="mb-5 mt-4 space-y-2 px-5">
        {!resolvido && resolvendo ? (
          <FormResolucaoAlerta
            ocupado={false}
            onCancelar={() => setResolvendo(false)}
            onConfirmar={(resolucao: ResolucaoAlerta) => {
              resolverAlerta(alert.id, resolucao);
              setResolvendo(false);
              notificar({ titulo: "Alerta marcado como resolvido", descricao: alert.tipo, tom: "success" });
            }}
          />
        ) : !resolvido ? (
          <button
            type="button"
            onClick={() => setResolvendo(true)}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3 text-[13px] font-semibold text-primary-foreground"
          >
            <CircleCheck className="h-4 w-4" />
            Resolver alerta
          </button>
        ) : (
          <button
            type="button"
            onClick={() => {
              reabrirAlerta(alert.id);
              notificar({ titulo: "Alerta reaberto", descricao: alert.tipo, tom: "info" });
            }}
            className="w-full rounded-2xl border border-border/60 bg-card py-3 text-[13px] font-semibold"
          >
            Reabrir alerta
          </button>
        )}

        {operacao && (
          <button
            type="button"
            onClick={() => navigate(`/operacoes/${operacao.id}`)}
            className="w-full rounded-2xl border border-border/60 bg-card py-3 text-[13px] font-semibold"
          >
            Ver operação {operacao.id}
          </button>
        )}
      </div>
    </AppShell>
  );
}
