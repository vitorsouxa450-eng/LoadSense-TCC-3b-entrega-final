import { CircleCheck, Cpu, Database, RefreshCw, ScanLine, Scale, Server, Signal } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { AppShell } from "@/components/AppShell";
import { useToast } from "@/components/Toast";
import { useStore } from "@/store/store";
import { cn, timeAgo } from "@/lib/utils";

type Tom = "ok" | "aviso" | "erro" | "neutro";

interface Item {
  id: string;
  icone: keyof typeof ICONES;
  nome: string;
  status: string;
  detalhe: string;
  tom: Tom;
}

const ICONES = {
  balanca: Scale,
  cpu: Cpu,
  scan: ScanLine,
  refresh: RefreshCw,
  server: Server,
  signal: Signal,
  database: Database,
} as const;

const DIA = 86_400_000;

const TOM_CLASSE: Record<Tom, string> = {
  ok: "bg-success/15 text-success",
  aviso: "bg-warning/20 text-warning",
  erro: "bg-destructive/15 text-destructive",
  neutro: "bg-border/50 text-muted-foreground",
};

const data = (ms: number) => new Date(ms).toLocaleDateString("pt-BR");

function calibracao(validaAte: number | null, agora: number): { texto: string; tom: Tom } {
  if (validaAte === null) return { texto: "Validade da calibração não informada", tom: "aviso" };
  const dias = Math.ceil((validaAte - agora) / DIA);
  if (dias < 0) return { texto: `Calibração vencida em ${data(validaAte)}`, tom: "erro" };
  if (dias <= 15) return { texto: `Calibração vence em ${dias} dia(s), em ${data(validaAte)}`, tom: "aviso" };
  return { texto: `Calibrada, válida até ${data(validaAte)}`, tom: "ok" };
}

export function StatusPage() {
  const { sensors, ultimaSync, sincronizarAgora, modo } = useStore();
  const { notificar } = useToast();
  const agora = Date.now();
  const servidor = modo === "servidor";

  const b = sensors.balanca;
  const cal = calibracao(b.validaAte, agora);
  const balancaItem: Item =
    b.estado === "AUSENTE"
      ? {
          id: "balanca",
          icone: "balanca",
          nome: "Balança",
          status: "Não cadastrada",
          detalhe: "Nenhum controlador de balança vinculado",
          tom: "aviso",
        }
      : b.estado === "ONLINE"
        ? b.ultimoSinal === null
          ? {
              id: "balanca",
              icone: "balanca",
              nome: b.nome,
              status: "Sem sinal",
              detalhe: "Ainda não enviou leituras",
              tom: "aviso",
            }
          : { id: "balanca", icone: "balanca", nome: b.nome, status: "Conectada", detalhe: cal.texto, tom: cal.tom }
        : b.estado === "MAINTENANCE"
          ? {
              id: "balanca",
              icone: "balanca",
              nome: b.nome,
              status: "Em manutenção",
              detalhe: "Pesagens podem estar indisponíveis",
              tom: "aviso",
            }
          : b.estado === "DISABLED"
            ? {
                id: "balanca",
                icone: "balanca",
                nome: b.nome,
                status: "Desativada",
                detalhe: "Balança desligada no cadastro",
                tom: "neutro",
              }
            : {
                id: "balanca",
                icone: "balanca",
                nome: b.nome,
                status: "Offline",
                detalhe: "Sem comunicação com a balança",
                tom: "erro",
              };

  const items: Item[] = [
    balancaItem,
    {
      id: "esp32",
      icone: "cpu",
      nome: "ESP32",
      status: sensors.esp32.ok ? "Conectado" : "Offline",
      detalhe: `Série ${sensors.esp32.serie} · firmware ${sensors.esp32.firmware}`,
      tom: sensors.esp32.ok ? "ok" : "erro",
    },
    {
      id: "rfid",
      icone: "scan",
      nome: "Leitor RFID",
      status: !sensors.rfid.cadastrado ? "Não cadastrado" : sensors.rfid.ok ? "Ativo" : "Inativo",
      detalhe: !sensors.rfid.cadastrado
        ? "Nenhum leitor vinculado"
        : sensors.rfid.ultimaLeitura
          ? `Tag ${sensors.rfid.tag} · última leitura ${timeAgo(sensors.rfid.ultimaLeitura)}`
          : "Nenhuma leitura registrada",
      tom: !sensors.rfid.cadastrado ? "aviso" : sensors.rfid.ok ? "ok" : "erro",
    },
    {
      id: "sync",
      icone: "refresh",
      nome: "Última sincronização",
      status: timeAgo(ultimaSync),
      detalhe: servidor ? "Atualização automática a cada 30 s" : "Atualização automática a cada 5 s",
      tom: "neutro",
    },
    {
      id: "servidor",
      icone: "server",
      nome: "Servidor",
      status: sensors.servidor.ok ? "Online" : "Instável",
      detalhe: sensors.servidor.ok ? `Resposta ${sensors.servidor.latenciaMs} ms` : "Sem resposta da API",
      tom: sensors.servidor.ok ? "ok" : "erro",
    },
    {
      id: "gprs",
      icone: "signal",
      nome: "Modem GPRS",
      status: !sensors.gprs.cadastrado ? "Não cadastrado" : sensors.gprs.ok ? "Conectado" : "Sem sinal",
      detalhe: !sensors.gprs.cadastrado
        ? "Nenhum modem vinculado"
        : `${sensors.gprs.tecnologia}${sensors.gprs.sinalPct !== null ? ` · ${sensors.gprs.sinalPct}%` : " · força do sinal não informada"}`,
      tom: !sensors.gprs.cadastrado ? "aviso" : sensors.gprs.ok ? "ok" : "erro",
    },
    {
      id: "banco",
      icone: "database",
      nome: "Banco de dados",
      status: sensors.banco.ok ? "Conectado" : "Instável",
      detalhe:
        sensors.banco.ok && sensors.banco.latenciaMs !== null
          ? `Latência ${sensors.banco.latenciaMs} ms`
          : "Sem resposta do banco",
      tom: sensors.banco.ok ? "ok" : "erro",
    },
  ];

  const temErro = items.some((item) => item.tom === "erro");
  const temAviso = items.some((item) => item.tom === "aviso");
  const resumo = temErro
    ? { titulo: "Atenção: há falhas no sistema", classe: "border-destructive/30 bg-destructive/10 text-destructive" }
    : temAviso
      ? { titulo: "Atenção: revise os itens destacados", classe: "border-warning/40 bg-warning/10 text-warning" }
      : { titulo: "Todos os serviços operacionais", classe: "border-success/30 bg-success/10 text-success" };

  return (
    <AppShell activeNav="Configurações" headerSlot={<AppHeader back title="Status do sistema" />}>
      <div className={cn("mx-5 mt-4 rounded-2xl border p-4 text-center", resumo.classe)}>
        <div className="text-[11px] font-semibold uppercase tracking-widest">Sistema</div>
        <div className="mt-1 text-xl font-bold text-foreground">{resumo.titulo}</div>
        <div className="mt-1 text-[10px] text-muted-foreground">
          Balança · ESP32 · RFID · GPRS · servidor · banco de dados
        </div>
      </div>

      <ul className="mx-5 mb-3 mt-4 divide-y divide-border/60 rounded-2xl border border-border/60 bg-card">
        {items.map((item) => {
          const Icone = ICONES[item.icone];
          return (
            <li key={item.id} className="flex items-center gap-3 px-4 py-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 text-primary">
                <Icone className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-[12px] font-semibold">{item.nome}</div>
                <div className="text-[10px] text-muted-foreground">{item.detalhe}</div>
              </div>
              <span className={cn("shrink-0 rounded-md px-2 py-1 text-[10px] font-bold", TOM_CLASSE[item.tom])}>
                {item.status}
              </span>
            </li>
          );
        })}
      </ul>

      <div className="px-5 pb-5">
        <button
          type="button"
          onClick={() => {
            sincronizarAgora();
            notificar({
              titulo: "Sincronização concluída",
              descricao: "Status atualizado.",
              tom: "success",
            });
          }}
          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3 text-[13px] font-semibold text-primary-foreground"
        >
          <CircleCheck className="h-4 w-4" />
          Sincronizar agora
        </button>
      </div>
    </AppShell>
  );
}
