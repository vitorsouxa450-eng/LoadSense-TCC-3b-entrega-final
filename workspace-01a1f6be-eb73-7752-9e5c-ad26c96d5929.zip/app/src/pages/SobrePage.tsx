import { AppHeader } from "@/components/AppHeader";
import { AppShell } from "@/components/AppShell";
import { Logo } from "@/components/Logo";
import { InfoList, Section } from "@/components/ui";
import { useStore } from "@/store/store";

const INTEGRANTES = [
  "Levi Nathanael Mendes Sousa",
  "Pedro Henrique Coneglian de Arruda",
  "Vitor Silva Souza",
  "Vítor Oliveira Rangel",
];

export function SobrePage() {
  const { profile } = useStore();

  return (
    <AppShell activeNav="Configurações" headerSlot={<AppHeader back title="Sobre LoadSense" />}>
      <div className="flex flex-col items-center px-5 pt-6 text-center">
        <Logo size="lg" />
        <p className="mt-3 max-w-[300px] text-[12px] leading-relaxed text-muted-foreground">
          O LoadSense é um sistema integrado de monitoramento de cargas, pesagens e frota, conectando hardware (ESP32 +
          células de carga + RFID), site e aplicativo em tempo real.
        </p>
      </div>

      <Section title="Missão">
        <p className="text-[12px] leading-relaxed text-muted-foreground">
          Tornar o controle logístico mais inteligente, seguro e transparente, evitando divergências de carga e
          otimizando as operações de transporte rodoviário.
        </p>
      </Section>

      <Section title="Projeto">
        <InfoList
          items={[
            ["Versão do app", "1.0.0"],
            ["Escola", "ETEC de Taboão da Serra"],
            ["Instituição", "Centro Paula Souza"],
            ["Curso", "Desenvolvimento de Sistemas"],
            ["Tipo", "Trabalho de Conclusão de Curso (2026)"],
            ["Orientadora", "Prof.ª Nathane de Castro"],
            ["Empresa (razão social)", "LoadSense Tecnologia e Logística LTDA"],
            ["Responsável na demo", profile.nome],
          ]}
        />
      </Section>

      <Section title="Integrantes" className="mb-3">
        <ul className="space-y-1.5 text-[12px]">
          {INTEGRANTES.map((integrante) => (
            <li key={integrante} className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" />
              {integrante}
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Tecnologias">
        <ul className="space-y-1.5 text-[11px] text-muted-foreground">
          <li>· Hardware: ESP32, células de carga, leitor RFID RC522, módulo GPRS/4G</li>
          <li>· Aplicação: React + TypeScript + Vite + Tailwind CSS</li>
          <li>· Interface: identidade visual LoadSense (laranja #C2410C / preto #121212)</li>
          <li>· Comunicação: MQTT/HTTP entre embarcado, servidor e painel da torre de controle</li>
        </ul>
      </Section>

      <p className="pb-6 pt-4 text-center text-[10px] text-muted-foreground">
        LoadSense v1.0.0 · TCC 2026 · ETEC de Taboão da Serra
      </p>
    </AppShell>
  );
}
