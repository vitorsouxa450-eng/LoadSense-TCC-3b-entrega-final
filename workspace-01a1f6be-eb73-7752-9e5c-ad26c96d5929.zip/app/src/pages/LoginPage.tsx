import { useState, type ReactNode } from "react";
import { Database, Loader2, Lock, Mail, Server } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { sessaoAtual } from "@shared/lib/api";
import { AuthShell } from "@/components/AppShell";
import { Logo } from "@/components/Logo";
import { useToast } from "@/components/Toast";
import { useStore } from "@/store/store";

function Campo({ icone, children }: { icone: ReactNode; children: ReactNode }) {
  return (
    <div className="flex items-center gap-2 rounded-xl border border-border/60 bg-card-elev px-3 py-3">
      <span className="text-muted-foreground">{icone}</span>
      {children}
    </div>
  );
}

const ENTRADA = "flex-1 bg-transparent text-[13px] outline-none placeholder:text-muted-foreground";

export function LoginPage() {
  const navigate = useNavigate();
  const { notificar } = useToast();
  const {
    entrar,
    profile,
    servidorOnline,
    conectando,
    erroLogin,
    desafioDoisFatores,
    codigoTesteDoisFatores,
    confirmarCodigoDoisFatores,
    cancelarDoisFatores,
  } = useStore();
  const [codigoDoisFatores, setCodigoDoisFatores] = useState("");
  const [email, setEmail] = useState(servidorOnline ? "" : profile.email);
  const [senha, setSenha] = useState("");
  const [erroLocal, setErroLocal] = useState<string | null>(null);

  const destinoPosLogin = () => (sessaoAtual()?.usuario.trocarSenha ? "/trocar-senha" : "/dashboard");

  async function aoEntrar(event: React.FormEvent) {
    event.preventDefault();
    if (servidorOnline) {
      const ok = await entrar(email.trim(), senha);
      if (ok) {
        notificar({ titulo: "Acesso autorizado", descricao: "Sessão aberta no servidor LoadSense", tom: "success" });
        navigate(destinoPosLogin());
      }
      return;
    }
    const entrouLocal = await entrar(email.trim(), senha);
    if (!entrouLocal && erroExibido) return;
    notificar({ titulo: "Acesso autorizado", descricao: `Bem-vindo, ${profile.nome}`, tom: "success" });
    navigate("/dashboard");
  }

  async function aoConfirmarCodigo(event: React.FormEvent) {
    event.preventDefault();
    if (!/^\d{6}$/.test(codigoDoisFatores.replace(/\s/g, ""))) {
      setErroLocal("Digite os 6 números do código enviado para o seu e-mail.");
      return;
    }
    setErroLocal(null);
    const ok = await confirmarCodigoDoisFatores(codigoDoisFatores);
    if (ok) {
      notificar({ titulo: "Acesso autorizado", descricao: "Verificação em duas etapas concluída", tom: "success" });
      navigate(destinoPosLogin());
    }
  }

  const erroExibido = erroLocal ?? erroLogin;

  return (
    <AuthShell>
      <div className="flex flex-1 flex-col justify-center">
        <div className="mb-6 flex flex-col items-center">
          <Logo size="lg" />
          <p className="mt-3 text-[12px] text-muted-foreground">Monitoramento inteligente de cargas</p>
        </div>

        {desafioDoisFatores && servidorOnline ? (
          <form onSubmit={aoConfirmarCodigo} className="space-y-3">
            <p className="text-[13px] text-foreground">
              {codigoTesteDoisFatores ? (
                <>
                  Este servidor não envia e-mails. Por isso o código de 6 números aparece aqui, nesta máquina:{" "}
                  <strong className="tracking-widest">{codigoTesteDoisFatores}</strong>. Ele vale por 10 minutos e só
                  pode ser usado uma vez.
                </>
              ) : (
                <>
                  Enviamos um código de 6 números para o e-mail da sua conta. Ele vale por 10 minutos e só pode ser
                  usado uma vez.
                </>
              )}
            </p>
            <Campo icone={<Lock className="h-4 w-4" />}>
              <input
                value={codigoDoisFatores}
                onChange={(e) => setCodigoDoisFatores(e.target.value)}
                placeholder="Código de 6 números"
                inputMode="numeric"
                autoComplete="one-time-code"
                maxLength={7}
                autoFocus
                className={ENTRADA}
              />
            </Campo>
            {erroExibido && <Erro texto={erroExibido} />}
            <button type="submit" disabled={conectando} className={BOTAO}>
              {conectando && <Loader2 className="h-4 w-4 animate-spin" />}
              Confirmar
            </button>
            <button
              type="button"
              onClick={() => {
                cancelarDoisFatores();
                setCodigoDoisFatores("");
                setSenha("");
                setErroLocal(null);
              }}
              className="w-full py-2 text-center text-[12px] text-muted-foreground"
            >
              Voltar
            </button>
          </form>
        ) : (
          <form onSubmit={aoEntrar} className="space-y-3">
            <Campo icone={<Mail className="h-4 w-4" />}>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="E-mail"
                autoComplete="username"
                className={ENTRADA}
              />
            </Campo>
            <Campo icone={<Lock className="h-4 w-4" />}>
              <input
                type="password"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                placeholder="Senha"
                autoComplete="current-password"
                className={ENTRADA}
              />
            </Campo>
            {erroExibido && <Erro texto={erroExibido} />}
            <button type="submit" disabled={conectando} className={BOTAO}>
              {conectando && <Loader2 className="h-4 w-4 animate-spin" />}
              Entrar
            </button>
            {servidorOnline && (
              <Link
                to="/esqueci-senha"
                className="block w-full py-2 text-center text-[12px] font-semibold text-primary"
              >
                Esqueci minha senha
              </Link>
            )}
          </form>
        )}
      </div>

      <div className="pb-6">
        <div className="flex items-center justify-center gap-2 rounded-xl border border-border/60 bg-card/60 px-3 py-2 text-[10px] text-muted-foreground">
          {servidorOnline ? (
            <>
              <Database className="h-3 w-3 text-success" />
              Conectado ao servidor — contas e dados no banco de dados
            </>
          ) : (
            <>
              <Server className="h-3 w-3 text-warning" />
              Entre com qualquer e-mail e senha
            </>
          )}
        </div>
      </div>
    </AuthShell>
  );
}

const BOTAO =
  "flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-[13px] font-semibold text-primary-foreground disabled:opacity-60";

function Erro({ texto }: { texto: string }) {
  return (
    <p className="rounded-xl border border-destructive/40 bg-destructive/10 px-3 py-2 text-[11px] text-destructive">
      {texto}
    </p>
  );
}
