import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Activity, AlertTriangle, ChevronDown, KeyRound, Package, Pencil, Radio, Scale, Users } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { AppShell } from "@/components/AppShell";
import { EmptyState, Pill, SearchField, SegmentedTabs } from "@/components/ui";
import { api, type AtividadeApi, type HistoricoApi, type OperacaoApi } from "@shared/lib/api";
import { cn, formatShortDate } from "@/lib/utils";

const TIPOS = [
  { id: "", rotulo: "Todas" },
  { id: "pesagem", rotulo: "Pesagens" },
  { id: "criacao", rotulo: "Operações criadas" },
  { id: "evento", rotulo: "Eventos" },
  { id: "rastreio", rotulo: "Rastreio" },
  { id: "alerta", rotulo: "Alertas" },
  { id: "edicao", rotulo: "Edições" },
  { id: "cadastro", rotulo: "Cadastros" },
  { id: "acesso", rotulo: "Acessos" },
] as const;

const ICONE_TIPO: Record<string, typeof Scale> = {
  pesagem: Scale,
  criacao: Package,
  evento: Activity,
  rastreio: Radio,
  alerta: AlertTriangle,
  edicao: Pencil,
  cadastro: Users,
  acesso: KeyRound,
};

const TOM_TIPO: Record<string, "primary" | "success" | "warning"> = {
  pesagem: "primary",
  criacao: "success",
  evento: "primary",
  rastreio: "primary",
  alerta: "warning",
  edicao: "warning",
  cadastro: "primary",
  acesso: "primary",
};

const CAMPOS_EDICAO: [string, string][] = [
  ["motorista", "Motorista"],
  ["produto", "Produto"],
  ["observacoes", "Observações"],
  ["documentoFiscal", "Nota fiscal"],
  ["mdfe", "MDF-e"],
  ["ciot", "CIOT"],
];

const CAMPO =
  "w-full rounded-xl border border-border/60 bg-card-elev px-3 py-2 text-[12px] outline-none focus:border-primary/60";

function ComparacaoEdicao({ atividade }: { atividade: AtividadeApi }) {
  if (!atividade.temAntes || !atividade.antes) {
    return (
      <p className="rounded-xl border border-primary/30 bg-primary/10 px-3 py-2 text-[11px] text-primary">
        Versão anterior não registrada nesta edição (feita antes da atualização do histórico). Edições a partir de agora
        guardam antes e depois.
      </p>
    );
  }
  return (
    <div className="overflow-x-auto rounded-xl border border-border/60">
      <table className="w-full text-left text-[11px]">
        <thead className="bg-card-elev text-[10px] uppercase text-muted-foreground">
          <tr>
            <th className="px-2 py-1.5 font-semibold">Campo</th>
            <th className="px-2 py-1.5 font-semibold">Antes</th>
            <th className="px-2 py-1.5 font-semibold">Agora</th>
          </tr>
        </thead>
        <tbody>
          {CAMPOS_EDICAO.map(([chave, rotulo]) => {
            const antes = atividade.antes?.[chave] ?? "—";
            const depois = atividade.depois?.[chave] ?? "—";
            const mudou = antes !== depois;
            return (
              <tr key={chave} className="border-t border-border/60">
                <td className="px-2 py-1.5 font-medium">{rotulo}</td>
                <td className={cn("px-2 py-1.5 text-muted-foreground", mudou && "line-through")}>{antes}</td>
                <td className={cn("px-2 py-1.5", mudou && "font-semibold text-warning")}>{depois}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function ItemAtividade({ a }: { a: AtividadeApi }) {
  const [aberta, setAberta] = useState(false);
  const Icone = ICONE_TIPO[a.tipo] ?? Activity;
  const rotuloTipo = TIPOS.find((t) => t.id === a.tipo)?.rotulo ?? a.tipo;

  return (
    <li className="rounded-2xl border border-border/60 bg-card p-3">
      <div className="flex items-start gap-3">
        <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
          <Icone className="h-4 w-4" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[12px] font-semibold">{a.rotulo}</span>
            <Pill tom={TOM_TIPO[a.tipo] ?? "primary"}>{rotuloTipo}</Pill>
          </div>
          <div className="mt-0.5 text-[10px] text-muted-foreground">
            {formatShortDate(a.data)} · {a.usuario ?? "sistema"}
            {a.codigo && (
              <>
                {" · "}
                {a.operacaoId ? (
                  <Link to={`/operacoes/${a.operacaoId}`} className="font-semibold text-primary">
                    {a.codigo}
                  </Link>
                ) : (
                  a.codigo
                )}
              </>
            )}
            {a.placa && <> · {a.placa}</>}
          </div>
          {a.detalhe && <div className="mt-1 text-[11px] text-muted-foreground">{a.detalhe}</div>}

          {a.tipo === "edicao" && (
            <button
              type="button"
              onClick={() => setAberta((v) => !v)}
              className="mt-2 text-[11px] font-semibold text-primary"
            >
              {aberta ? "Ocultar antes e depois" : "Ver antes e depois"}
            </button>
          )}
          {a.tipo === "edicao" && aberta && (
            <div className="mt-2">
              <ComparacaoEdicao atividade={a} />
            </div>
          )}
        </div>
      </div>
    </li>
  );
}

function AbaAtividades() {
  const [tipo, setTipo] = useState("");
  const [busca, setBusca] = useState("");
  const [operacaoId, setOperacaoId] = useState("");
  const [de, setDe] = useState("");
  const [ate, setAte] = useState("");
  const [filtrosAbertos, setFiltrosAbertos] = useState(false);
  const [pagina, setPagina] = useState(1);
  const [historico, setHistorico] = useState<HistoricoApi | null>(null);
  const [operacoes, setOperacoes] = useState<OperacaoApi[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    api
      .operacoes("&limite=500")
      .then((r) => setOperacoes(r.operacoes))
      .catch(() => setOperacoes([]));
  }, []);

  useEffect(() => {
    setPagina(1);
  }, [tipo, busca, operacaoId, de, ate]);

  const consulta = useMemo(() => {
    const p = new URLSearchParams();
    if (tipo) p.set("tipo", tipo);
    if (busca.trim()) p.set("busca", busca.trim());
    if (operacaoId) p.set("operacaoId", operacaoId);
    if (de) p.set("de", de);
    if (ate) p.set("ate", ate);
    p.set("limite", "100");
    p.set("pagina", String(pagina));
    return p.toString();
  }, [tipo, busca, operacaoId, de, ate, pagina]);

  useEffect(() => {
    let ativo = true;
    const espera = setTimeout(() => {
      setCarregando(true);
      setErro(null);
      api
        .historico(consulta)
        .then(
          (r) =>
            ativo &&
            setHistorico((anterior) =>
              r.pagina > 1 && anterior ? { ...r, atividades: [...anterior.atividades, ...r.atividades] } : r,
            ),
        )
        .catch((e) => ativo && setErro(e instanceof Error ? e.message : "Falha ao consultar o histórico."))
        .finally(() => ativo && setCarregando(false));
    }, 250);
    return () => {
      ativo = false;
      clearTimeout(espera);
    };
  }, [consulta]);

  const total = historico ? Object.values(historico.contagem).reduce((soma, n) => soma + n, 0) : 0;
  const filtrosAtivos = Boolean(operacaoId || de || ate);

  return (
    <div className="px-5 pb-6 pt-4">
      <SearchField value={busca} onChange={setBusca} placeholder="Placa, código, usuário, texto" />

      <div className="mt-3 flex items-center justify-between">
        <button
          type="button"
          onClick={() => setFiltrosAbertos((v) => !v)}
          className="flex items-center gap-1 text-[12px] font-semibold text-primary"
        >
          Filtros {filtrosAtivos && "•"}
          <ChevronDown className={cn("h-4 w-4 transition-transform", filtrosAbertos && "rotate-180")} />
        </button>
        {(tipo || busca || filtrosAtivos) && (
          <button
            type="button"
            onClick={() => {
              setTipo("");
              setBusca("");
              setOperacaoId("");
              setDe("");
              setAte("");
            }}
            className="text-[11px] font-semibold text-muted-foreground"
          >
            Limpar
          </button>
        )}
      </div>

      {filtrosAbertos && (
        <div className="mt-3 space-y-3 rounded-2xl border border-border/60 bg-card p-3">
          <label className="block text-[11px] font-medium">
            Operação
            <select value={operacaoId} onChange={(e) => setOperacaoId(e.target.value)} className={cn(CAMPO, "mt-1")}>
              <option value="">Todas as operações</option>
              {operacoes.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.codigo} · {o.veiculo?.placa ?? "sem placa"}
                </option>
              ))}
            </select>
          </label>
          <div className="grid grid-cols-2 gap-2">
            <label className="block text-[11px] font-medium">
              De
              <input type="date" value={de} onChange={(e) => setDe(e.target.value)} className={cn(CAMPO, "mt-1")} />
            </label>
            <label className="block text-[11px] font-medium">
              Até
              <input type="date" value={ate} onChange={(e) => setAte(e.target.value)} className={cn(CAMPO, "mt-1")} />
            </label>
          </div>
        </div>
      )}

      <div className="mt-3 flex flex-wrap gap-1.5" role="group" aria-label="Filtrar atividades por tipo">
        {TIPOS.map((t) => {
          const n = t.id === "" ? total : (historico?.contagem[t.id] ?? 0);
          const ativo = tipo === t.id;
          return (
            <button
              key={t.id || "todas"}
              type="button"
              onClick={() => setTipo(t.id)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-[11px] font-semibold",
                ativo ? "border-primary bg-primary/15 text-primary" : "border-border text-muted-foreground",
              )}
            >
              {t.rotulo} <span className="tabular-nums">({n})</span>
            </button>
          );
        })}
      </div>

      {erro && <p className="mt-3 rounded-xl bg-destructive/10 px-3 py-2 text-[11px] text-destructive">{erro}</p>}

      {carregando && !historico ? (
        <p className="mt-6 text-center text-[12px] text-muted-foreground">Carregando histórico…</p>
      ) : !historico || historico.atividades.length === 0 ? (
        <div className="mt-4">
          <EmptyState titulo="Nenhuma atividade encontrada" descricao="Ajuste os filtros para ver outros registros." />
        </div>
      ) : (
        <ul className="mt-3 space-y-2">
          {historico.atividades.map((a) => (
            <ItemAtividade key={a.id} a={a} />
          ))}
        </ul>
      )}

      {historico && historico.atividades.length > 0 && (
        <p className="mt-3 text-center text-[11px] text-muted-foreground">
          Mostrando {historico.atividades.length} de {historico.total} atividades
        </p>
      )}
      {historico?.temMais && (
        <button
          type="button"
          disabled={carregando}
          onClick={() => setPagina((p) => p + 1)}
          className="mt-3 w-full rounded-xl border border-border py-2.5 text-[12px] font-semibold text-primary disabled:opacity-50"
        >
          {carregando ? "Carregando…" : "Carregar mais"}
        </button>
      )}
    </div>
  );
}

function AbaOperacoes() {
  const [operacoes, setOperacoes] = useState<OperacaoApi[] | null>(null);
  const [status, setStatus] = useState("");
  const [busca, setBusca] = useState("");
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    let ativo = true;
    const espera = setTimeout(() => {
      const partes = ["&limite=200"];
      if (status) partes.push(`&status=${status}`);
      if (busca.trim()) partes.push(`&busca=${encodeURIComponent(busca.trim())}`);
      setErro(null);
      api
        .operacoes(partes.join(""))
        .then((r) => ativo && setOperacoes(r.operacoes))
        .catch((e) => ativo && setErro(e instanceof Error ? e.message : "Falha ao consultar as operações."));
    }, 250);
    return () => {
      ativo = false;
      clearTimeout(espera);
    };
  }, [status, busca]);

  return (
    <div className="px-5 pb-6 pt-4">
      <SearchField value={busca} onChange={setBusca} placeholder="Operação, placa, motorista..." />
      <select value={status} onChange={(e) => setStatus(e.target.value)} className={cn(CAMPO, "mt-3")}>
        <option value="">Todos os status</option>
        <option value="NORMAL">Normal</option>
        <option value="ATTENTION">Atenção</option>
        <option value="CRITICAL">Crítico</option>
        <option value="ANALYSIS">Análise</option>
      </select>

      {erro && <p className="mt-3 rounded-xl bg-destructive/10 px-3 py-2 text-[11px] text-destructive">{erro}</p>}

      {operacoes === null && !erro ? (
        <p className="mt-6 text-center text-[12px] text-muted-foreground">Carregando operações…</p>
      ) : operacoes && operacoes.length === 0 ? (
        <div className="mt-4">
          <EmptyState titulo="Nenhuma operação encontrada" descricao="Ajuste a busca ou o status." />
        </div>
      ) : (
        <ul className="mt-3 space-y-2">
          {operacoes?.map((o) => (
            <li key={o.id}>
              <Link
                to={`/operacoes/${o.id}`}
                className="flex items-center justify-between rounded-2xl border border-border/60 bg-card p-3"
              >
                <div className="min-w-0">
                  <div className="text-[12px] font-bold">
                    {o.codigo} · {o.veiculo?.placa ?? "sem placa"}
                  </div>
                  <div className="truncate text-[10px] text-muted-foreground">
                    {o.motorista ?? "—"} · {o.produto ?? "—"}
                  </div>
                </div>
                <span className="ml-3 shrink-0 text-[11px] font-semibold text-primary">Abrir →</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function HistoricoPage() {
  const [aba, setAba] = useState<"atividades" | "operacoes">("atividades");

  return (
    <AppShell activeNav="Relatórios" headerSlot={<AppHeader back title="Histórico" />}>
      <div className="px-5 pt-4">
        <SegmentedTabs
          value={aba}
          onChange={setAba}
          tabs={[
            { value: "atividades", label: "Atividades" },
            { value: "operacoes", label: "Operações" },
          ]}
        />
      </div>
      {aba === "atividades" ? <AbaAtividades /> : <AbaOperacoes />}
    </AppShell>
  );
}
