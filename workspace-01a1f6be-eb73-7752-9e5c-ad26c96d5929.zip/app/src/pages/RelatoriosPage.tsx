import { useEffect, useMemo, useState } from "react";
import { CalendarDays, ChevronRight, Download, FileText } from "lucide-react";
import { Link } from "react-router-dom";
import { AppShell } from "@/components/AppShell";
import { BarChart, Donut, Sparkline } from "@/components/charts";
import { useToast } from "@/components/Toast";
import { Banner, SegmentedTabs, Section } from "@/components/ui";
import { dailySeries, resumirPeriodo, principaisDivergencias } from "@/lib/analytics";
import { useStore } from "@/store/store";
import { api, type RelatorioApi } from "@shared/lib/api";
import { apiDemo } from "@shared/lib/demo";
import { cn, formatNumber, formatSigned, formatTons } from "@/lib/utils";

type Periodo = "7d" | "30d" | "90d";

const DIAS: Record<Periodo, number> = { "7d": 7, "30d": 30, "90d": 90 };
const DIA = 24 * 3600_000;

const NOME_TIPO: Record<string, string> = {
  MONTHLY: "mensal",
  WEEKLY: "semanal",
  DAILY: "diário",
  CUSTOM: "personalizado",
};

function dataCurta(valor: string | null | undefined): string {
  if (!valor) return "—";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(valor);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : valor;
}

export function RelatoriosPage() {
  const { operations, alerts, reports, modo } = useStore();
  const [salvos, setSalvos] = useState<RelatorioApi[]>([]);

  useEffect(() => {
    if (modo !== "servidor") {
      apiDemo
        .relatorios()
        .then((r) => setSalvos(r.relatorios))
        .catch(() => setSalvos([]));
      return;
    }
    api
      .relatorios()
      .then((r) => setSalvos(r.relatorios))
      .catch(() => setSalvos([]));
  }, [modo]);
  const { notificar } = useToast();
  const [periodo, setPeriodo] = useState<Periodo>("30d");

  const { desde, ate, dias } = useMemo(() => {
    const agora = Date.now();
    const janela = DIAS[periodo];
    return { desde: agora - janela * DIA, ate: agora + DIA, dias: janela };
  }, [periodo]);

  const { kpis, tipos, divergencias } = useMemo(
    () => resumirPeriodo(operations, alerts, desde, ate),
    [operations, alerts, desde, ate],
  );

  const serieToneladas = useMemo(() => dailySeries(operations, Math.min(14, dias), "toneladas"), [operations, dias]);
  const serieViagens = dailySeries(operations, Math.min(14, dias), "viagens");

  const exportar = () => {
    const linhas = [
      ["Indicador", "Valor"],
      ["Período", `${dias} dias`],
      ["Viagens realizadas", String(kpis.viagens)],
      ["Cargas transportadas", String(kpis.cargas)],
      ["Volume transportado (t)", formatNumber(kpis.volumeT, 1)],
      ["Média por viagem (t)", formatNumber(kpis.mediaPorViagemT, 1)],
      ["Taxa de divergência (%)", formatNumber(kpis.taxaDivergenciaPct, 1)],
      ["Eficiência (%)", formatNumber(kpis.eficienciaPct, 1)],
      ["Alertas registrados", String(kpis.alertas)],
      [],
      ["Divergências", "Placa", "Diferença", "Data"],
      ...principaisDivergencias(operations, 10).map((linha) => [
        linha.operacaoId,
        linha.placa,
        formatSigned(linha.diferencaKg),
        new Date(linha.data).toLocaleDateString("pt-BR"),
      ]),
    ];

    const csv = linhas.map((linha) => linha.map((valor) => `"${valor ?? ""}"`).join(";")).join("\n");
    try {
      const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `loadsense-relatorio-${periodo}.csv`;
      link.click();
      URL.revokeObjectURL(url);
      notificar({ titulo: "Relatório exportado", descricao: `Arquivo CSV gerado (${periodo}).`, tom: "success" });
    } catch {
      notificar({
        titulo: "Exportação indisponível neste ambiente",
        descricao: "Baixe o projeto e rode localmente para gerar o arquivo.",
        tom: "alert",
      });
    }
  };

  return (
    <AppShell activeNav="Relatórios">
      <div className="px-5 pt-4">
        <h1 className="text-xl font-bold">Relatórios</h1>
        <p className="text-[11px] text-muted-foreground">Visão consolidada do período selecionado</p>
      </div>

      <Link
        to="/historico"
        className="mx-5 mt-3 flex items-center justify-between rounded-2xl border border-border/60 bg-card p-3"
      >
        <span>
          <span className="block text-[12px] font-semibold">Histórico de operações</span>
          <span className="block text-[10px] text-muted-foreground">
            Pesagens anteriores e busca por produto, motorista ou destino
          </span>
        </span>
        <ChevronRight className="h-4 w-4 text-muted-foreground" />
      </Link>

      <div className="mt-3 px-5">
        <SegmentedTabs
          tabs={[
            { value: "7d", label: "7 dias" },
            { value: "30d", label: "30 dias" },
            { value: "90d", label: "90 dias" },
          ]}
          value={periodo}
          onChange={setPeriodo}
        />
      </div>

      <div className="mx-5 mt-3 flex items-center gap-2 rounded-xl border border-border/60 bg-card-elev px-3 py-2.5">
        <CalendarDays className="h-4 w-4 text-primary" />
        <span className="flex-1 text-[12px]">
          Dados filtrados de {new Date(desde).toLocaleDateString("pt-BR")} a {new Date().toLocaleDateString("pt-BR")}
        </span>
      </div>

      {salvos.length > 0 && (
        <Section
          title="Relatórios salvos no servidor"
          className="mt-3 p-3"
          action={<Download className="h-4 w-4 text-muted-foreground" />}
        >
          <ul className="divide-y divide-border/60">
            {salvos.map((r) => {
              const resumo = (typeof r.resumo === "object" && r.resumo ? r.resumo : {}) as {
                titulo?: string;
                periodo?: string;
              };
              return (
                <li key={r.id} className="flex items-center gap-3 py-2.5">
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12px] font-semibold">
                      {resumo.titulo ?? `Relatório ${NOME_TIPO[r.tipo] ?? r.tipo}`}
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      {resumo.periodo ?? `${dataCurta(r.inicio)} a ${dataCurta(r.fim)}`} · nº {r.id}
                    </div>
                  </div>
                  <button
                    onClick={() =>
                      api
                        .exportarRelatorio(r.id)
                        .catch((e: Error) =>
                          notificar({ titulo: "Falha ao exportar", descricao: e.message, tom: "alert" }),
                        )
                    }
                    className="rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-medium hover:bg-card-elev"
                  >
                    CSV
                  </button>
                </li>
              );
            })}
          </ul>
        </Section>
      )}

      {}
      {modo !== "servidor" && (
        <Section
          title="Relatórios gerados"
          className="mt-3 p-3"
          action={<Download className="h-4 w-4 text-muted-foreground" />}
        >
          <ul className="divide-y divide-border/60">
            {reports.map((relatorio) => (
              <li key={relatorio.id}>
                <Link to={`/relatorios/${relatorio.id}`} className="flex items-center gap-3 py-2.5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 text-primary">
                    <FileText className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12px] font-semibold">{relatorio.titulo}</div>
                    <div className="text-[10px] text-muted-foreground">{relatorio.periodo}</div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </Link>
              </li>
            ))}
          </ul>
        </Section>
      )}
      {modo === "servidor" && salvos.length === 0 && (
        <p className="mx-5 mt-3 text-[12px] leading-relaxed text-muted-foreground">
          Nenhum relatório salvo ainda. Use “Exportar relatório (CSV)” para baixar o período escolhido.
        </p>
      )}

      <div className="mt-3 grid grid-cols-2 gap-2.5 px-5">
        {[
          { valor: String(kpis.viagens), rotulo: "Viagens realizadas" },
          { valor: String(kpis.pesagens), rotulo: "Pesagens aferidas" },
          { valor: formatTons(kpis.volumeT), rotulo: "Volume transportado" },
          { valor: `${formatNumber(kpis.taxaDivergenciaPct, 1)}%`, rotulo: "Taxa de divergência" },
        ].map((item) => (
          <div key={item.rotulo} className="rounded-xl border border-border/60 bg-card p-3">
            <div className="text-lg font-bold tabular">{item.valor}</div>
            <div className="mt-0.5 text-[10px] text-muted-foreground">{item.rotulo}</div>
          </div>
        ))}
      </div>

      <Section title="Desempenho operacional">
        <BarChart data={serieToneladas} height={120} />
        <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
          <span>Toneladas por dia</span>
          <span>pico {formatNumber(Math.max(...serieToneladas), 1)} t</span>
        </div>
      </Section>

      <Section title="Distribuição por tipo de carga">
        <div className="flex items-center gap-4">
          <Donut fatias={tipos.map((fatia) => ({ label: fatia.label, valor: fatia.pct, cor: fatia.cor }))} />
          <ul className="flex-1 space-y-1.5 text-[11px]">
            {tipos.map((fatia) => (
              <li key={fatia.label} className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-sm" style={{ background: fatia.cor }} />
                  {fatia.label}
                </span>
                <span className="text-muted-foreground tabular">{formatNumber(fatia.valorT, 1)} t</span>
              </li>
            ))}
          </ul>
        </div>
      </Section>

      <Section title="Principais divergências">
        {divergencias.length === 0 ? (
          <Banner tom="success">Nenhuma divergência de peso registrada no período</Banner>
        ) : (
          <ul className="space-y-2 text-[12px]">
            {divergencias.map((linha) => (
              <li key={linha.operacaoId} className="flex items-center gap-2">
                <Link to={`/operacoes/${linha.operacaoId}`} className="flex-1 font-semibold text-primary">
                  {linha.placa}
                </Link>
                <span className="font-semibold text-destructive tabular">{formatSigned(linha.diferencaKg)}</span>
                <span className="text-[10px] text-muted-foreground">
                  {new Date(linha.data).toLocaleDateString("pt-BR")}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section title="Viagens iniciadas" className="mb-3">
        <Sparkline data={serieViagens} height={90} />
      </Section>

      <div className="px-5 pb-5">
        <button
          type="button"
          onClick={exportar}
          className={cn(
            "flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3 text-[13px] font-semibold text-primary-foreground",
          )}
        >
          <Download className="h-4 w-4" />
          Exportar relatório (CSV)
        </button>
      </div>
    </AppShell>
  );
}
