import { useState } from "react";
import { ArrowLeft, CheckCircle2, KeyRound, Loader2, Lock, Mail } from "lucide-react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { AuthShell } from "@/components/AppShell";
import { Logo } from "@/components/Logo";
import { api, ErroApi } from "@shared/lib/api";
import { useStore } from "@/store/store";

export const senhaForte = (s: string) => s.length >= 8 && /[A-Z]/.test(s) && /[0-9]/.test(s) && /[^A-Za-z0-9]/.test(s);

const mensagem = (erro: unknown) =>
  erro instanceof ErroApi ? erro.message : "Não foi possível falar com o servidor. Verifique a conexão.";

const campo = "flex items-center gap-2 rounded-xl border border-border/60 bg-card-elev px-3 py-3";
const entrada = "flex-1 bg-transparent text-[13px] outline-none placeholder:text-muted-foreground";
const botao =
  "flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-[13px] font-semibold text-primary-foreground disabled:opacity-70";

function Erro({ texto }: { texto: string | null }) {
  if (!texto) return null;
  return (
    <p className="rounded-xl border border-destructive/40 bg-destructive/10 px-3 py-2 text-[11px] text-destructive">
      {texto}
    </p>
  );
}

function Cabecalho({ titulo, texto }: { titulo: string; texto: string }) {
  return (
    <div className="mb-8 flex flex-col items-center">
      <Logo size="lg" />
      <h1 className="mt-6 text-[18px] font-semibold">{titulo}</h1>
      <p className="mt-1 max-w-xs text-center text-[12px] text-muted-foreground">{texto}</p>
    </div>
  );
}

export function EsqueciSenhaPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  async function aoEnviar(event: React.FormEvent) {
    event.preventDefault();
    setEnviando(true);
    setErro(null);
    try {
      const resposta = await api.recuperarSenha(email.trim());
      navigate("/verificar-codigo", { state: { email: email.trim(), codigoDemo: resposta.codigoDemo ?? null } });
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <AuthShell>
      <div className="flex flex-1 flex-col justify-center">
        <Cabecalho
          titulo="Recuperar senha"
          texto="Informe seu e-mail corporativo e enviaremos um código de verificação."
        />
        <form onSubmit={aoEnviar} className="space-y-3">
          <div className={campo}>
            <Mail className="h-4 w-4 text-muted-foreground" />
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="E-mail"
              autoComplete="username"
              className={entrada}
            />
          </div>
          <Erro texto={erro} />
          <button type="submit" disabled={enviando} className={botao}>
            {enviando && <Loader2 className="h-4 w-4 animate-spin" />}
            Enviar código
          </button>
          <p className="pt-1 text-center text-[12px] text-muted-foreground">
            <Link to="/login" className="font-semibold text-primary">
              <ArrowLeft className="mr-1 inline h-3 w-3" />
              Voltar para o login
            </Link>
          </p>
        </form>
      </div>
    </AuthShell>
  );
}

export function VerificarCodigoPage() {
  const navigate = useNavigate();
  const estado = (useLocation().state ?? {}) as { email?: string; codigoDemo?: string | null };
  const [codigo, setCodigo] = useState("");
  const [validando, setValidando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  if (!estado.email) return <Navigate to="/esqueci-senha" replace />;

  async function aoEnviar(event: React.FormEvent) {
    event.preventDefault();
    setValidando(true);
    setErro(null);
    try {
      await api.verificarCodigoRecuperacao(estado.email!, codigo);
      navigate("/nova-senha", { state: { email: estado.email, codigo } });
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setValidando(false);
    }
  }

  return (
    <AuthShell>
      <div className="flex flex-1 flex-col justify-center">
        <Cabecalho
          titulo="Código de verificação"
          texto={
            estado.codigoDemo
              ? "Digite os 6 dígitos mostrados abaixo."
              : `Digite os 6 dígitos enviados para ${estado.email}.`
          }
        />
        {estado.codigoDemo && (
          <p className="mb-3 rounded-xl border border-warning/40 bg-warning/10 px-3 py-2 text-center text-[11px] text-warning">
            Este servidor não envia e-mails. O código aparece aqui, nesta máquina:{" "}
            <strong className="tracking-widest">{estado.codigoDemo}</strong>
          </p>
        )}
        <form onSubmit={aoEnviar} className="space-y-3">
          <div className={campo}>
            <KeyRound className="h-4 w-4 text-muted-foreground" />
            <input
              inputMode="numeric"
              pattern="[0-9]{6}"
              maxLength={6}
              required
              value={codigo}
              onChange={(e) => setCodigo(e.target.value.replace(/\D/g, ""))}
              placeholder="000000"
              autoComplete="one-time-code"
              className={`${entrada} text-center text-[18px] tracking-[0.5em]`}
            />
          </div>
          <Erro texto={erro} />
          <button type="submit" disabled={validando || codigo.length !== 6} className={botao}>
            {validando && <Loader2 className="h-4 w-4 animate-spin" />}
            Validar código
          </button>
          <p className="pt-1 text-center text-[12px] text-muted-foreground">
            <Link to="/esqueci-senha" className="font-semibold text-primary">
              Alterar e-mail
            </Link>
          </p>
        </form>
      </div>
    </AuthShell>
  );
}

export function NovaSenhaPage() {
  const navigate = useNavigate();
  const estado = (useLocation().state ?? {}) as { email?: string; codigo?: string };
  const [senha, setSenha] = useState("");
  const [confirmacao, setConfirmacao] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  if (!estado.email || !estado.codigo) return <Navigate to="/esqueci-senha" replace />;

  const regras = [
    { ok: senha.length >= 8, texto: "Mínimo de 8 caracteres" },
    { ok: /[A-Z]/.test(senha), texto: "Uma letra maiúscula" },
    { ok: /[0-9]/.test(senha), texto: "Um número" },
    { ok: /[^A-Za-z0-9]/.test(senha), texto: "Um caractere especial" },
  ];

  async function aoEnviar(event: React.FormEvent) {
    event.preventDefault();
    if (!senhaForte(senha)) return setErro("A senha não atende a todas as regras.");
    if (senha !== confirmacao) return setErro("As senhas não coincidem.");
    setSalvando(true);
    setErro(null);
    try {
      await api.novaSenha(estado.email!, estado.codigo!, senha);
      navigate("/senha-alterada");
    } catch (e) {
      setErro(mensagem(e));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <AuthShell>
      <div className="flex flex-1 flex-col justify-center">
        <Cabecalho titulo="Criar nova senha" texto="Escolha uma senha forte para proteger sua conta." />
        <form onSubmit={aoEnviar} className="space-y-3">
          <div className={campo}>
            <Lock className="h-4 w-4 text-muted-foreground" />
            <input
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              placeholder="Nova senha"
              autoComplete="new-password"
              className={entrada}
            />
          </div>
          <div className={campo}>
            <Lock className="h-4 w-4 text-muted-foreground" />
            <input
              type="password"
              value={confirmacao}
              onChange={(e) => setConfirmacao(e.target.value)}
              placeholder="Confirmar senha"
              autoComplete="new-password"
              className={entrada}
            />
          </div>
          <ul className="space-y-1 px-1 text-[11px]">
            {regras.map((r) => (
              <li key={r.texto} className={r.ok ? "text-success" : "text-muted-foreground"}>
                {r.ok ? "✓" : "•"} {r.texto}
              </li>
            ))}
          </ul>
          <Erro texto={erro} />
          <button type="submit" disabled={salvando} className={botao}>
            {salvando && <Loader2 className="h-4 w-4 animate-spin" />}
            Salvar nova senha
          </button>
          <p className="pt-1 text-center text-[12px] text-muted-foreground">
            <Link to="/login" className="font-semibold text-primary">
              Voltar para o login
            </Link>
          </p>
        </form>
      </div>
    </AuthShell>
  );
}

export function SenhaAlteradaPage() {
  return (
    <AuthShell>
      <div className="flex flex-1 flex-col items-center justify-center text-center">
        <CheckCircle2 className="mb-4 h-12 w-12 text-success" />
        <h1 className="text-[18px] font-semibold">Senha alterada com sucesso</h1>
        <p className="mt-2 max-w-xs text-[12px] text-muted-foreground">
          Sua senha foi atualizada. Use as novas credenciais para acessar a central LoadSense.
        </p>
        <Link
          to="/login"
          className="mt-8 flex w-full max-w-xs items-center justify-center rounded-xl bg-primary py-3 text-[13px] font-semibold text-primary-foreground"
        >
          Ir para o login
        </Link>
      </div>
    </AuthShell>
  );
}

export function TrocarSenhaPage() {
  const navigate = useNavigate();
  const { precisaTrocarSenha, alterarSenha, sair } = useStore();
  const [senhaAtual, setSenhaAtual] = useState("");
  const [novaSenha, setNovaSenha] = useState("");
  const [confirmacao, setConfirmacao] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  if (!precisaTrocarSenha) return <Navigate to="/dashboard" replace />;

  async function aoEnviar(event: React.FormEvent) {
    event.preventDefault();
    setErro(null);
    if (!senhaForte(novaSenha)) {
      setErro("A nova senha precisa de 8 caracteres, com letra maiúscula, número e símbolo.");
      return;
    }
    if (novaSenha !== confirmacao) {
      setErro("A confirmação não confere com a nova senha.");
      return;
    }
    if (novaSenha === senhaAtual) {
      setErro("Escolha uma senha diferente da atual.");
      return;
    }
    setEnviando(true);
    const falha = await alterarSenha(senhaAtual, novaSenha);
    setEnviando(false);
    if (falha) return setErro(falha);
    navigate("/dashboard", { replace: true });
  }

  return (
    <AuthShell>
      <div className="flex flex-1 flex-col justify-center">
        <Cabecalho
          titulo="Crie uma nova senha"
          texto="Por segurança, o administrador pediu a troca da senha antes de continuar."
        />
        <form onSubmit={aoEnviar} className="space-y-3">
          <div className={campo}>
            <Lock className="h-4 w-4 text-muted-foreground" />
            <input
              type="password"
              required
              value={senhaAtual}
              onChange={(e) => setSenhaAtual(e.target.value)}
              placeholder="Senha atual"
              autoComplete="current-password"
              className={entrada}
            />
          </div>
          <div className={campo}>
            <KeyRound className="h-4 w-4 text-muted-foreground" />
            <input
              type="password"
              required
              value={novaSenha}
              onChange={(e) => setNovaSenha(e.target.value)}
              placeholder="Nova senha"
              autoComplete="new-password"
              className={entrada}
            />
          </div>
          <div className={campo}>
            <KeyRound className="h-4 w-4 text-muted-foreground" />
            <input
              type="password"
              required
              value={confirmacao}
              onChange={(e) => setConfirmacao(e.target.value)}
              placeholder="Confirme a nova senha"
              autoComplete="new-password"
              className={entrada}
            />
          </div>
          <Erro texto={erro} />
          <button type="submit" disabled={enviando} className={botao}>
            {enviando && <Loader2 className="h-4 w-4 animate-spin" />}
            Salvar nova senha
          </button>
          <p className="pt-1 text-center text-[12px] text-muted-foreground">
            <button type="button" onClick={() => void sair()} className="font-semibold text-primary">
              Sair
            </button>
          </p>
        </form>
      </div>
    </AuthShell>
  );
}
