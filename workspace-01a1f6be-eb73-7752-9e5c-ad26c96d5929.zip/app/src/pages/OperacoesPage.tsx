import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Plus, Radio, Truck } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { NovaOperacaoDialog } from "@/components/NovaOperacaoDialog";
import { EmptyState, Pill, ProgressBar, SearchField } from "@/components/ui";
import { api, type OperacaoApi } from "@shared/lib/api";
import { snapshotDemo } from "@shared/lib/demo";
import { useStore } from "@/store/store";
import { cn, formatNumber, formatShortDate } from "@/lib/utils";

const STATUS: Record<string, { rotulo: string; tom: "primary" | "success" | "warning" | "destructive" }> = {
  NORMAL: { rotulo: "Normal", tom: "success" },
  ATTENTION: { rotulo: "Atenção", tom: "warning" },
  CRITICAL: { rotulo: "Crítico", tom: "destructive" },
  ANALYSIS: { rotulo: "Análise", tom: "primary" },
};

const ESTADO: Record<
  string,
  { rotulo: string; tom: "primary" | "success" | "muted" | "destructive"; progresso: number }
> = {
  DRAFT: { rotulo: "Rascunho", tom: "muted", progresso: 0 },
  IN_PROGRESS: { rotulo: "Em andamento", tom: "primary", progresso: 50 },
  COMPLETED: { rotulo: "Concluída", tom: "success", progresso: 100 },
  CANCELLED: { rotulo: "Cancelada", tom: "destructive", progresso: 0 },
};

const FILTROS_ESTADO = [
  { id: "todas", rotulo: "Todas" },
  { id: "IN_PROGRESS", rotulo: "Em andamento" },
  { id: "COMPLETED", rotulo: "Concluídas" },
  { id: "DRAFT", rotulo: "Rascunho" },
  { id: "CANCELLED", rotulo: "Canceladas" },
] as const;

const FILTROS_STATUS = [
  { id: "todos", rotulo: "Qualquer status" },
  { id: "NORMAL", rotulo: "Normal" },
  { id: "ATTENTION", rotulo: "Atenção" },
  { id: "CRITICAL", rotulo: "Crítico" },
  { id: "ANALYSIS", rotulo: "Análise" },
] as const;

const kgTexto = (valor: number | null | undefined) => (valor == null ? "—" : `${formatNumber(valor)} kg`);

function CartaoOperacao({ o }: { o: OperacaoApi }) {
  const estado = ESTADO[o.estado] ?? { rotulo: o.estado, tom: "muted" as const, progresso: 0 };
  const status = STATUS[o.status];
  const desvio = o.pesos.desvioKg ?? 0;
  const origem = o.rota?.origem;
  const destino = o.rota?.destino;

  return (
    <Link
      to={`/operacoes/${o.id}`}
      className="block rounded-2xl border border-border/60 bg-card p-4 transition-colors hover:border-primary/50"
    >
      <div className="flex items-start gap-3">
        <div
          className={cn(
            "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
            o.estado === "COMPLETED" ? "bg-success/15 text-success" : "bg-primary/15 text-primary",
          )}
        >
          <Truck className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[13px] font-bold">{o.veiculo?.placa ?? "Sem veículo"}</span>
            <Pill tom={estado.tom}>{estado.rotulo}</Pill>
            {status && <Pill tom={status.tom}>{status.rotulo}</Pill>}
            {o.rastreioAtivado && (
              <span className="flex items-center gap-1 text-[10px] font-semibold text-primary">
                <Radio className="h-3 w-3" /> Rastreio
              </span>
            )}
          </div>
          <div className="mt-0.5 truncate text-[11px] text-muted-foreground">
            {o.codigo} · {o.motorista ?? "sem motorista"} · {o.produto ?? "sem produto"}
          </div>
          {(origem || destino) && (
            <div className="truncate text-[11px] text-muted-foreground">
              {origem ?? "—"} → {destino ?? "—"}
            </div>
          )}
        </div>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        {(
          [
            ["Declarada", kgTexto(o.pesos.cargaDeclaradaKg)],
            ["Aferida", kgTexto(o.pesos.cargaAferidaKg)],
            ["Bruto", kgTexto(o.pesos.brutoAferidoKg)],
          ] as const
        ).map(([rotulo, valor]) => (
          <div key={rotulo} className="rounded-lg bg-card-elev py-1.5">
            <div className="text-[9px] uppercase text-muted-foreground">{rotulo}</div>
            <div className="text-[11px] font-semibold tabular-nums">{valor}</div>
          </div>
        ))}
      </div>

      <div className="mt-3">
        <ProgressBar valor={estado.progresso} tom={o.estado === "COMPLETED" ? "success" : "primary"} />
      </div>

      <div className="mt-2 flex items-center justify-between text-[10px] text-muted-foreground">
        <span>Início {o.datas.iniciadaEm ? formatShortDate(o.datas.iniciadaEm) : "—"}</span>
        {desvio > 0 ? (
          <span className="font-bold text-destructive tabular-nums">Divergência +{formatNumber(desvio)} kg</span>
        ) : (
          <span>Sem divergência de peso</span>
        )}
      </div>
    </Link>
  );
}

export function OperacoesPage() {
  const { modo } = useStore();
  const [operacoes, setOperacoes] = useState<OperacaoApi[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const [busca, setBusca] = useState("");
  const [estado, setEstado] = useState<(typeof FILTROS_ESTADO)[number]["id"]>("todas");
  const [status, setStatus] = useState<(typeof FILTROS_STATUS)[number]["id"]>("todos");
  const [novaAberta, setNovaAberta] = useState(false);

  useEffect(() => {
    let ativo = true;
    setCarregando(true);
    setErro(null);
    const origem =
      modo === "demo" ? Promise.resolve({ operacoes: snapshotDemo().operacoes }) : api.operacoes("&limite=500");
    origem
      .then((r) => ativo && setOperacoes(r.operacoes))
      .catch((e: Error) => ativo && setErro(e.message || "Não foi possível carregar as operações."))
      .finally(() => ativo && setCarregando(false));
    return () => {
      ativo = false;
    };
  }, [modo]);

  const filtradas = useMemo(() => {
    const termo = busca.trim().toLowerCase();
    return operacoes.filter((o) => {
      if (estado !== "todas" && o.estado !== estado) return false;
      if (status !== "todos" && o.status !== status) return false;
      if (!termo) return true;
      return [o.codigo, o.veiculo?.placa, o.motorista, o.produto, o.rota?.origem, o.rota?.destino]
        .filter(Boolean)
        .some((campo) => String(campo).toLowerCase().includes(termo));
    });
  }, [operacoes, busca, estado, status]);

  return (
    <AppShell activeNav="Operações">
      <div className="px-5 pb-6 pt-4">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold">Operações</h1>
            <p className="text-[11px] text-muted-foreground">
              {operacoes.length} operação(ões) · toque em uma para ver os detalhes
            </p>
          </div>
          <button
            type="button"
            onClick={() => setNovaAberta(true)}
            className="flex shrink-0 items-center gap-1 rounded-lg bg-primary px-3 py-2 text-[12px] font-semibold text-primary-foreground"
          >
            <Plus className="h-4 w-4" /> Nova
          </button>
        </div>

        <SearchField value={busca} onChange={setBusca} placeholder="Buscar por placa, código, motorista ou produto" />

        <div className="mt-3 flex flex-wrap items-center gap-1.5" role="group" aria-label="Filtrar por situação">
          <span className="mr-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Situação</span>
          {FILTROS_ESTADO.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setEstado(f.id)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-[11px] font-semibold",
                estado === f.id
                  ? "border-primary bg-primary/15 text-primary"
                  : "border-border/60 text-muted-foreground",
              )}
            >
              {f.rotulo}
            </button>
          ))}
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-1.5" role="group" aria-label="Filtrar por status">
          <span className="mr-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Status</span>
          {FILTROS_STATUS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setStatus(f.id)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-[11px] font-semibold",
                status === f.id
                  ? "border-primary bg-primary/15 text-primary"
                  : "border-border/60 text-muted-foreground",
              )}
            >
              {f.rotulo}
            </button>
          ))}
        </div>

        <div className="mt-4 space-y-3">
          {carregando && <p className="py-8 text-center text-[12px] text-muted-foreground">Carregando operações…</p>}
          {erro && (
            <p className="rounded-xl border border-destructive/40 px-3 py-2 text-[12px] text-destructive">{erro}</p>
          )}
          {!carregando && !erro && filtradas.length === 0 && (
            <EmptyState titulo="Nenhuma operação encontrada" descricao="Ajuste a busca ou os filtros." />
          )}
          {filtradas.map((o) => (
            <CartaoOperacao key={o.id} o={o} />
          ))}
        </div>
      </div>
      {novaAberta && <NovaOperacaoDialog onFechar={() => setNovaAberta(false)} />}
    </AppShell>
  );
}
