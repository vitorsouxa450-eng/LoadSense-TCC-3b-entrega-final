import { useCallback, useEffect, useMemo, useState } from "react";
import { api, type OperacaoDetalheApi } from "@shared/lib/api";
import { useSincronia } from "@shared/lib/sincronia";
import { MonitoramentoDaOperacao } from "@shared/components/prototipo/MonitoramentoOperacoes";
import {
  CalendarClock,
  CircleCheck,
  Crosshair,
  Flag,
  MapPin,
  Scale,
  ScanLine,
  Thermometer,
  Truck,
  User,
} from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { AppHeader } from "@/components/AppHeader";
import { AppShell } from "@/components/AppShell";
import { AlertCard } from "@/components/AlertCard";
import { useToast } from "@/components/Toast";
import { Banner, EmptyState, InfoList, ProgressBar, SegmentedTabs } from "@/components/ui";
import { kmRestantes, pesoRealKg, progressPct, statusPrevisao, trajetoDaOperacao } from "@/lib/analytics";
import { useStore } from "@/store/store";
import { cn, formatDate, formatKg, formatSigned, formatTime, timeAgo } from "@/lib/utils";

type Aba = "resumo" | "pesagens" | "trajeto" | "alertas";

export function OperacaoDetalhePage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { notificar } = useToast();
  const {
    operations,
    alerts,
    registrarPesagem,
    registrarPesagemCompleta,
    iniciarTransporte,
    registrarChegada,
    ativarRastreio,
    sincronizarAgora,
    ultimaSync,
    modo,
  } = useStore();
  const [detalheServidor, setDetalheServidor] = useState<OperacaoDetalheApi | null>(null);
  const [vazioKg, setVazioKg] = useState("");
  const [carregadoKg, setCarregadoKg] = useState("");
  const [motivoPesagem, setMotivoPesagem] = useState("Pesagem registrada pelo app");
  const [enviandoPesagem, setEnviandoPesagem] = useState(false);
  const [erroPesagem, setErroPesagem] = useState<string | null>(null);
  const [aba, setAba] = useState<Aba>("resumo");
  const [pesoAferido, setPesoAferido] = useState("");
  const [enviandoTransporte, setEnviandoTransporte] = useState(false);
  const [erroTransporte, setErroTransporte] = useState<string | null>(null);
  const [codigoRastreio, setCodigoRastreio] = useState("");
  const [enviandoRastreio, setEnviandoRastreio] = useState(false);
  const [erroRastreio, setErroRastreio] = useState<string | null>(null);

  const idServidor = Number(id);
  const ehServidor = modo === "servidor" && Number.isInteger(idServidor) && idServidor > 0;
  const carregarDetalhe = useCallback(() => {
    if (!ehServidor) return;
    api
      .operacao(idServidor)
      .then(setDetalheServidor)
      .catch(() => undefined);
  }, [ehServidor, idServidor]);
  useEffect(() => {
    carregarDetalhe();
  }, [carregarDetalhe]);
  useSincronia(carregarDetalhe, ehServidor);

  const operacao = useMemo(
    () => operations.find((op) => op.id === id) ?? operations.find((op) => op.placa === id),
    [operations, id],
  );
  const alertas = alerts.filter((alert) => alert.operacaoId === operacao?.id);

  if (!operacao) {
    return (
      <AppShell activeNav="Operações" headerSlot={<AppHeader back title="Operação" />}>
        <div className="px-5 pt-4">
          <EmptyState
            titulo="Operação não encontrada"
            descricao="Ela pode ter sido removida ou o link está incompleto. Procure pelo código na lista de operações."
          />
          <Link to="/operacoes" className="mt-3 block text-center text-[12px] text-primary">
            Voltar para operações
          </Link>
        </div>
      </AppShell>
    );
  }

  const pct = progressPct(operacao);
  const emViagem = operacao.status === "Em trânsito" || operacao.status === "Parado";
  const prontaParaSair = operacao.status === "Carregando" && operacao.pesagens.some((p) => p.tipo === "carregado");

  async function aoAtualizarTransporte() {
    setEnviandoTransporte(true);
    setErroTransporte(null);
    try {
      if (emViagem) {
        await registrarChegada(operacao!.id);
        notificar({ titulo: "Chegada registrada", descricao: "A viagem foi encerrada no destino.", tom: "success" });
      } else {
        await iniciarTransporte(operacao!.id);
        notificar({ titulo: "Transporte iniciado", descricao: "A operação passou para em andamento.", tom: "success" });
      }
    } catch (erro) {
      setErroTransporte(erro instanceof Error ? erro.message : "Não foi possível atualizar o transporte.");
    } finally {
      setEnviandoTransporte(false);
    }
  }
  async function aoAtivarRastreio() {
    if (!codigoRastreio.trim()) return setErroRastreio("Informe o código RFID fornecido pela empresa.");
    setEnviandoRastreio(true);
    setErroRastreio(null);
    try {
      await ativarRastreio(operacao!.id, codigoRastreio.trim());
      setCodigoRastreio("");
      notificar({ titulo: "Rastreio ativado", descricao: "O monitoramento do transporte está ativo.", tom: "success" });
    } catch (erro) {
      setErroRastreio(erro instanceof Error ? erro.message : "Não foi possível ativar o rastreio.");
    } finally {
      setEnviandoRastreio(false);
    }
  }
  const previsao = statusPrevisao(operacao);
  const trajeto = trajetoDaOperacao(operacao);
  const pesagensCarregadas = operacao.pesagens;
  const pesagemPendente = operacao.status === "Carregando" && !pesagensCarregadas.some((p) => p.tipo === "carregado");

  async function aoRegistrarPesagemCompleta() {
    const v = Number(vazioKg.replace(/\./g, "").replace(",", "."));
    const c = Number(carregadoKg.replace(/\./g, "").replace(",", "."));
    if (!(v > 0)) return setErroPesagem("Informe o peso do caminhão vazio.");
    if (!(c > v)) return setErroPesagem("O caminhão carregado precisa pesar mais que o vazio.");
    if (motivoPesagem.trim().length < 5) return setErroPesagem("Informe o motivo do registro manual.");
    setEnviandoPesagem(true);
    setErroPesagem(null);
    try {
      await registrarPesagemCompleta(operacao!.id, { vazioKg: v, carregadoKg: c, motivo: motivoPesagem });
      notificar({
        titulo: "Pesagem registrada",
        descricao: "Operação encerrada com os pesos informados.",
        tom: "success",
      });
      setVazioKg("");
      setCarregadoKg("");
    } catch (erro) {
      setErroPesagem(erro instanceof Error ? erro.message : "Não foi possível registrar a pesagem.");
    } finally {
      setEnviandoPesagem(false);
    }
  }

  async function aoRegistrarPesagem() {
    const valor = Number(pesoAferido.replace(/\./g, "").replace(",", "."));
    if (!Number.isFinite(valor) || valor <= 0) {
      notificar({ titulo: "Informe o peso aferido", descricao: "Digite o valor em kg (ex.: 32920).", tom: "alert" });
      return;
    }
    try {
      const pesagem = await registrarPesagem(operacao!.id, valor, "Balança intermediária (RFID)");
      notificar({
        titulo: `Pesagem registrada · ${formatKg(pesagem.pesoKg)}`,
        descricao:
          pesagem.desvioKg === 0 ? "Peso dentro do esperado" : `Divergência de ${formatSigned(pesagem.desvioKg)}`,
        tom: Math.abs(pesagem.desvioKg) > 300 ? "alert" : "success",
      });
      setPesoAferido("");
      sincronizarAgora();
    } catch (erro) {
      notificar({
        titulo: "Pesagem não registrada",
        descricao: erro instanceof Error ? erro.message : "Falha ao falar com o servidor.",
        tom: "alert",
      });
    }
  }

  return (
    <AppShell activeNav="Operações" headerSlot={<AppHeader back title="Detalhes da operação" />}>
      {}
      <section className="mx-5 mt-4 rounded-2xl border border-border/60 bg-card p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
            <Truck className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <div className="text-[14px] font-bold">{operacao.placa}</div>
            <div className={cn("text-[11px]", previsao.tom === "warning" ? "text-warning" : "text-success")}>
              {operacao.status} · {pct}%
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-muted-foreground">ETA</div>
            <div className="text-[12px] font-bold tabular">{formatTime(operacao.previsaoChegada)}</div>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2 text-[11px]">
          {[
            { icone: <MapPin className="h-3.5 w-3.5" />, rotulo: "Origem", valor: operacao.origem },
            { icone: <Flag className="h-3.5 w-3.5" />, rotulo: "Destino", valor: operacao.destino },
            { icone: <User className="h-3.5 w-3.5" />, rotulo: "Motorista", valor: operacao.motorista },
            {
              icone: <CalendarClock className="h-3.5 w-3.5" />,
              rotulo: "Saída",
              valor: `${formatTime(operacao.saida)} · ${formatDate(operacao.saida)}`,
            },
            { icone: <Crosshair className="h-3.5 w-3.5" />, rotulo: "Distância", valor: `${operacao.distanciaKm} km` },
            { icone: <Crosshair className="h-3.5 w-3.5" />, rotulo: "Restante", valor: `${kmRestantes(operacao)} km` },
          ].map((item) => (
            <div key={item.rotulo} className="flex items-center gap-2 rounded-xl bg-card-elev px-3 py-2">
              <span className="text-muted-foreground">{item.icone}</span>
              <div className="min-w-0">
                <div className="text-[9px] uppercase tracking-wide text-muted-foreground">{item.rotulo}</div>
                <div className="truncate font-semibold">{item.valor}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-3">
          <div className="mb-1 flex justify-between text-[11px]">
            <span className="text-muted-foreground">Progresso da rota</span>
            <span className="font-semibold tabular">{pct}%</span>
          </div>
          <ProgressBar valor={pct} tom={operacao.status === "Concluída" ? "success" : "primary"} />
          <div className="mt-1 flex justify-between text-[10px] text-muted-foreground">
            <span>
              {Math.round(operacao.kmPercorrido)} km percorridos · {operacao.rfid}
            </span>
            <span>sincronizado {timeAgo(ultimaSync)}</span>
          </div>
        </div>

        <Banner
          tom={previsao.tom === "warning" ? "warning" : "success"}
          className="mt-3"
          icone={<CircleCheck className="h-4 w-4" />}
        >
          {previsao.texto}
        </Banner>
      </section>

      {pesagemPendente && (
        <section className="mx-5 mt-3 rounded-2xl border border-border/60 bg-card p-4">
          <h3 className="mb-1 text-[13px] font-semibold">Registrar pesagem</h3>
          <p className="mb-3 text-[11px] text-muted-foreground">
            Informe os pesos lidos na balança. Ao registrar, a pesagem é finalizada e a operação é encerrada.
          </p>
          <div className="grid grid-cols-2 gap-2">
            <label className="text-[11px] font-medium">
              Caminhão vazio (kg)
              <input
                inputMode="decimal"
                value={vazioKg}
                onChange={(event) => setVazioKg(event.target.value)}
                placeholder="ex.: 8200"
                className="mt-1 w-full rounded-xl border border-border/60 bg-card-elev px-3 py-2.5 text-[12px] outline-none placeholder:text-muted-foreground"
              />
            </label>
            <label className="text-[11px] font-medium">
              Caminhão carregado (kg)
              <input
                inputMode="decimal"
                value={carregadoKg}
                onChange={(event) => setCarregadoKg(event.target.value)}
                placeholder="ex.: 29336"
                className="mt-1 w-full rounded-xl border border-border/60 bg-card-elev px-3 py-2.5 text-[12px] outline-none placeholder:text-muted-foreground"
              />
            </label>
          </div>
          <label className="mt-2 block text-[11px] font-medium">
            Motivo do registro manual
            <input
              value={motivoPesagem}
              onChange={(event) => setMotivoPesagem(event.target.value)}
              maxLength={200}
              className="mt-1 w-full rounded-xl border border-border/60 bg-card-elev px-3 py-2.5 text-[12px] outline-none"
            />
          </label>
          {erroPesagem && <p className="mt-2 text-[11px] text-destructive">{erroPesagem}</p>}
          <button
            type="button"
            onClick={aoRegistrarPesagemCompleta}
            disabled={enviandoPesagem}
            className="mt-3 w-full rounded-xl bg-primary py-2.5 text-[12px] font-semibold text-primary-foreground disabled:opacity-60"
          >
            {enviandoPesagem ? "Registrando…" : "Registrar pesagem"}
          </button>
        </section>
      )}

      {!operacao.cancelada && (
        <section className="mx-5 mt-3 rounded-2xl border border-border/60 bg-card p-4">
          <h3 className="mb-1 text-[13px] font-semibold">Rastreio</h3>
          {operacao.rastreioAtivado && detalheServidor && (
            <div className="mb-3">
              <MonitoramentoDaOperacao op={detalheServidor} trajeto={detalheServidor.trajeto} />
            </div>
          )}
          {operacao.rastreioAtivado ? (
            <p className="text-[11px] text-muted-foreground">Rastreio ativado com a etiqueta RFID {operacao.rfid}.</p>
          ) : (
            <>
              <p className="mb-3 text-[11px] text-muted-foreground">
                Informe o código RFID fornecido pela empresa parceira para acompanhar o transporte.
              </p>
              {erroRastreio && <p className="mb-2 text-[11px] text-destructive">{erroRastreio}</p>}
              <div className="flex gap-2">
                <input
                  value={codigoRastreio}
                  onChange={(event) => setCodigoRastreio(event.target.value)}
                  maxLength={100}
                  placeholder="Código RFID da empresa"
                  className="flex-1 rounded-xl border border-border/60 bg-card-elev px-3 py-2.5 text-[12px] outline-none placeholder:text-muted-foreground"
                />
                <button
                  type="button"
                  disabled={enviandoRastreio}
                  onClick={aoAtivarRastreio}
                  className="rounded-xl bg-primary px-3 py-2.5 text-[12px] font-semibold text-primary-foreground disabled:opacity-60"
                >
                  {enviandoRastreio ? "Ativando…" : "Ativar"}
                </button>
              </div>
            </>
          )}
        </section>
      )}

      {!operacao.cancelada && (emViagem || prontaParaSair) && (
        <section className="mx-5 mt-3 rounded-2xl border border-border/60 bg-card p-4">
          <h3 className="mb-1 text-[13px] font-semibold">Transporte</h3>
          <p className="mb-3 text-[11px] text-muted-foreground">
            {emViagem
              ? "Em viagem. Registre a chegada quando a carga chegar ao destino."
              : "Pesagem concluída. Inicie o transporte quando o caminhão sair do pátio."}
          </p>
          {erroTransporte && <p className="mb-2 text-[11px] text-destructive">{erroTransporte}</p>}
          <button
            type="button"
            disabled={enviandoTransporte}
            onClick={aoAtualizarTransporte}
            className="w-full rounded-xl bg-primary py-2.5 text-[12px] font-semibold text-primary-foreground disabled:opacity-60"
          >
            {enviandoTransporte ? "Atualizando…" : emViagem ? "Registrar chegada" : "Iniciar transporte"}
          </button>
        </section>
      )}

      {}
      <section className="mx-5 mt-3 rounded-2xl border border-border/60 bg-card p-4">
        <h3 className="mb-2 flex items-center gap-2 text-[13px] font-semibold">
          <ScanLine className="h-4 w-4 text-primary" />
          Leituras do sistema embarcado
        </h3>
        <div className="flex gap-2">
          <input
            value={pesoAferido}
            onChange={(event) => setPesoAferido(event.target.value)}
            inputMode="numeric"
            placeholder="Peso aferido (kg)"
            className="flex-1 rounded-xl border border-border/60 bg-card-elev px-3 py-2.5 text-[12px] outline-none placeholder:text-muted-foreground"
          />
          <button
            type="button"
            onClick={aoRegistrarPesagem}
            className="rounded-xl bg-primary px-3 py-2.5 text-[12px] font-semibold text-primary-foreground"
          >
            Registrar
          </button>
        </div>
        <div className="mt-2 flex gap-2">
          <button
            type="button"
            onClick={() => {
              sincronizarAgora();
              notificar({ titulo: "Dados sincronizados", descricao: "ESP32 respondeu em 84 ms.", tom: "info" });
            }}
            className="flex-1 rounded-xl border border-border/60 bg-card-elev py-2.5 text-[12px] font-semibold"
          >
            Sincronizar agora
          </button>
        </div>
      </section>

      <div className="mt-3 px-5">
        <SegmentedTabs
          tabs={[
            { value: "resumo", label: "Resumo" },
            { value: "pesagens", label: "Pesagens" },
            { value: "trajeto", label: "Trajeto" },
            { value: "alertas", label: "Alertas" },
          ]}
          value={aba}
          onChange={setAba}
        />
      </div>

      {aba === "resumo" && (
        <section className="mx-5 mb-4 mt-4 rounded-2xl border border-border/60 bg-card p-4">
          <h3 className="mb-2 text-[13px] font-semibold">Resumo da operação</h3>
          <InfoList
            items={[
              ["Placa", operacao.placa],
              ["Motorista", operacao.motorista],
              ["Tipo de carga", operacao.tipoCarga],
              ["Origem", operacao.origem],
              ["Destino", operacao.destino],
              ["Saída", `${formatDate(operacao.saida)} ${formatTime(operacao.saida)}`],
              [
                "Previsão de chegada",
                `${formatDate(operacao.previsaoChegada)} ${formatTime(operacao.previsaoChegada)}`,
              ],
              ["Distância total", `${operacao.distanciaKm} km`],
              ["Distância restante", `${kmRestantes(operacao)} km`],
              ["Peso total carregado", formatKg(pesoRealKg(operacao))],
              ["Limite legal", formatKg(operacao.limiteKg)],
              ["Temperatura da carga", `${operacao.temperaturaC?.toFixed(1) ?? "—"} °C`],
              ["Status", `${operacao.status} · ${pct}%`],
            ]}
            destaqueUltimo
          />
          {operacao.desvioKg === 0 ? (
            <Banner tom="success" className="mt-3" icone={<CircleCheck className="h-4 w-4" />}>
              Operação dentro dos parâmetros esperados
            </Banner>
          ) : (
            <Banner tom="warning" className="mt-3" icone={<Thermometer className="h-4 w-4" />}>
              Divergência acumulada de {formatSigned(operacao.desvioKg)} nas pesagens
            </Banner>
          )}
        </section>
      )}

      {aba === "pesagens" && (
        <>
          <section className="mx-5 mt-4 rounded-2xl border border-border/60 bg-card p-4">
            <h3 className="mb-3 text-[13px] font-semibold">Pesagens realizadas</h3>
            <ol className="relative pl-6">
              <div className="absolute bottom-2 left-2 top-2 w-px bg-border" />
              {pesagensCarregadas.map((pesagem, index) => (
                <li key={pesagem.id} className="relative mb-4 last:mb-0">
                  <span
                    className={cn(
                      "absolute -left-[18px] top-1 h-3 w-3 rounded-full",
                      pesagem.desvioKg > 0 ? "bg-destructive" : index === 1 ? "bg-primary" : "bg-success",
                    )}
                  />
                  <div className="flex items-baseline justify-between">
                    <div>
                      <div className="text-[12px] font-semibold">
                        {pesagem.tipo === "vazio"
                          ? "Caminhão vazio"
                          : pesagem.tipo === "carregado"
                            ? "Caminhão carregado"
                            : "Pesagem intermediária"}
                      </div>
                      <div className="text-[10px] text-muted-foreground">
                        {pesagem.local} · {formatDate(pesagem.registradoEm)} {formatTime(pesagem.registradoEm)}
                      </div>
                    </div>
                    <div
                      className={cn(
                        "text-[13px] font-bold tabular",
                        pesagem.desvioKg > 0 ? "text-destructive" : "text-success",
                      )}
                    >
                      {formatKg(pesagem.pesoKg)}
                    </div>
                  </div>
                  <div className="text-[10px] text-muted-foreground">Tag {pesagem.rfid}</div>
                </li>
              ))}
            </ol>
          </section>

          <section className="mx-5 mb-4 mt-4 rounded-2xl border border-border/60 bg-card p-4">
            <h3 className="mb-2 flex items-center gap-2 text-[13px] font-semibold">
              <Scale className="h-4 w-4 text-primary" />
              Resumo da pesagem
            </h3>
            <InfoList
              items={[
                ["Peso do caminhão vazio", formatKg(operacao.taraKg)],
                ["Peso da carga (romaneio)", formatKg(operacao.pesoCargaKg)],
                ["Peso total esperado", formatKg(operacao.taraKg + operacao.pesoCargaKg)],
                ["Peso total aferido", formatKg(pesoRealKg(operacao))],
                ["Diferença calculada", formatSigned(operacao.desvioKg)],
              ]}
            />
            <Banner
              tom={operacao.desvioKg > 0 ? "warning" : "success"}
              className="mt-3"
              icone={<CircleCheck className="h-4 w-4" />}
            >
              {operacao.desvioKg > 0
                ? "Recomenda-se nova conferência em balança certificada"
                : "Valores dentro da margem esperada"}
            </Banner>
          </section>
        </>
      )}

      {aba === "trajeto" && (
        <section className="mx-5 mb-4 mt-4 rounded-2xl border border-border/60 bg-card p-4">
          <h3 className="mb-3 text-[13px] font-semibold">Trajeto percorrido</h3>
          <ol className="relative pl-6">
            <div className="absolute bottom-2 left-2 top-2 w-px bg-border" />
            {trajeto.map((ponto) => (
              <li key={ponto.local} className="relative mb-4 last:mb-0">
                <span
                  className={cn(
                    "absolute -left-[18px] top-1 h-3 w-3 rounded-full",
                    ponto.atual ? "bg-primary ring-4 ring-primary/20" : ponto.concluido ? "bg-success" : "bg-muted",
                  )}
                />
                <div className="flex items-baseline justify-between gap-2">
                  <div className="min-w-0">
                    <div className="truncate text-[12px] font-semibold">{ponto.local}</div>
                    <div className="text-[10px] text-muted-foreground">
                      {ponto.info} · {ponto.km} km
                    </div>
                  </div>
                  <div className="whitespace-nowrap text-[11px] font-semibold tabular">{ponto.horario}</div>
                </div>
              </li>
            ))}
          </ol>
          <ProgressBar className="mt-2" valor={pct} />
        </section>
      )}

      {aba === "alertas" && (
        <section className="mx-5 mb-4 mt-4">
          <h3 className="mb-2 px-1 text-[13px] font-semibold">Alertas registrados</h3>
          {alertas.length === 0 ? (
            <EmptyState titulo="Nenhum alerta nesta operação" descricao="Pesagens e trajeto sem ocorrências." />
          ) : (
            <ul className="space-y-2.5">
              {alertas.map((alert) => (
                <li key={alert.id}>
                  <AlertCard alert={alert} />
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      <div className="px-5 pb-5">
        <button
          type="button"
          onClick={() => navigate(`/relatorios`)}
          className="w-full rounded-2xl border border-border/60 bg-card py-3 text-[12px] font-semibold"
        >
          Ver relatórios da operação
        </button>
      </div>
    </AppShell>
  );
}
