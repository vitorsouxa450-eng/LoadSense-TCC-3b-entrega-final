import { AppShell } from "@/components/AppShell";
import { AppHeader } from "@/components/AppHeader";
import { AjudaFuncionalidades } from "@shared/components/ajuda/AjudaFuncionalidades";
import { FUNCOES_APP } from "@shared/lib/ajuda";

export function AjudaPage() {
  return (
    <AppShell activeNav="Configurações" headerSlot={<AppHeader back title="Ajuda" />}>
      <div className="px-5 pt-4">
        <h1 className="text-xl font-bold">Ajuda</h1>
        <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">
          Toque em cada função para ver para que ela serve e como usar. Para rever o passo a passo inicial, volte a
          Configurações e toque em Guia de primeiros passos.
        </p>
      </div>
      <div className="mx-5 mb-6 mt-4">
        <AjudaFuncionalidades funcoes={FUNCOES_APP} />
      </div>
    </AppShell>
  );
}
