import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { Banner } from "@/components/ui";
import { MonitoramentoOperacoes, type ViagemMonitorada } from "@shared/components/prototipo/MonitoramentoOperacoes";
import { api } from "@shared/lib/api";
import { viagensDemo } from "@shared/lib/demo";
import { useStore } from "@/store/store";

export function MonitoramentoPage() {
  const { modo } = useStore();
  const [viagens, setViagens] = useState<ViagemMonitorada[]>(() => (modo === "demo" ? viagensDemo() : []));
  const [aguardando, setAguardando] = useState<{ id: number; codigo: string; placa: string | null }[]>([]);
  const [aba, setAba] = useState<"andamento" | "concluidas">("andamento");

  useEffect(() => {
    if (modo === "demo") {
      setViagens(aba === "concluidas" ? [] : viagensDemo());
      setAguardando([]);
      return;
    }
    api
      .rastreioAtivo(aba === "concluidas")
      .then((r) => {
        setViagens(r.viagens);
        setAguardando(aba === "concluidas" ? [] : r.aguardandoAtivacao);
      })
      .catch(() => {
        setViagens([]);
        setAguardando([]);
      });
  }, [modo, aba]);

  return (
    <AppShell activeNav="Monitoramento">
      <div className="px-4 pb-6 pt-4">
        <div className="mb-3 flex gap-2" role="tablist" aria-label="Abas do monitoramento">
          {(
            [
              ["andamento", "Em andamento"],
              ["concluidas", "Concluídas"],
            ] as const
          ).map(([id, rotulo]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={aba === id}
              onClick={() => setAba(id)}
              className={`rounded-md border px-3 py-1.5 text-[13px] font-medium ${
                aba === id ? "border-slate-900 bg-slate-900 text-white" : "border-slate-300 bg-white text-slate-700"
              }`}
            >
              {rotulo}
            </button>
          ))}
        </div>
        {aguardando.length > 0 && (
          <div className="mb-3">
            <Banner tom="warning">
              {aguardando.length} operação(ões) sem rastreio ativado não aparecem aqui:{" "}
              {aguardando
                .slice(0, 3)
                .map((o) => o.codigo)
                .join(", ")}
              {aguardando.length > 3 ? ` e mais ${aguardando.length - 3}` : ""}. Ative o rastreio pelo detalhe da
              operação, com o código RFID fornecido pela empresa.
            </Banner>
          </div>
        )}
        <MonitoramentoOperacoes viagens={viagens} />
      </div>
    </AppShell>
  );
}
