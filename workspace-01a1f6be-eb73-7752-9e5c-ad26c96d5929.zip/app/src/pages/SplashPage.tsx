import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Logo } from "@/components/Logo";
import { sessionStore } from "@/lib/storage";

export function SplashPage({ onDone }: { onDone?: () => void }) {
  const navigate = useNavigate();
  const ao = useRef({ onDone, navigate });
  ao.current = { onDone, navigate };
  const continuar = () => {
    const { onDone: concluir, navigate: ir } = ao.current;
    if (concluir) concluir();
    else ir("/termos");
  };

  useEffect(() => {
    const timer = window.setTimeout(() => continuar(), 2200);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="flex min-h-screen items-stretch justify-center bg-black">
      <div className="relative flex min-h-screen w-full max-w-[420px] flex-col items-center justify-center bg-background px-8">
        <div className="flex flex-col items-center animate-ls-fade-in">
          <Logo size="lg" />
          <p className="mt-3 text-[12px] text-muted-foreground">Monitoramento inteligente de cargas</p>
        </div>

        <div className="mt-10 h-1 w-40 overflow-hidden rounded-full bg-muted">
          <div className="h-full w-1/2 rounded-full bg-primary animate-ls-loading" />
        </div>
        <p className="mt-3 text-[11px] text-muted-foreground">Carregando seus dados…</p>
        <button
          type="button"
          onClick={continuar}
          className="mt-6 rounded-full border border-border px-4 py-1.5 text-[11px] font-semibold text-muted-foreground hover:text-foreground"
        >
          Pular
        </button>

        <p className="absolute bottom-8 text-[10px] text-muted-foreground">LoadSense v1.0.0 · TCC 2026</p>
      </div>
    </div>
  );
}

export function SplashGate({ children }: { children: React.ReactNode }) {
  const [pronta, setPronta] = useState(() => sessionStore.get("ls-splash") === "1");

  if (pronta) return <>{children}</>;

  return (
    <SplashPage
      onDone={() => {
        sessionStore.set("ls-splash", "1");
        setPronta(true);
      }}
    />
  );
}
