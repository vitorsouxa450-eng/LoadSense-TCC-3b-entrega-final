import { useState } from "react";
import {
  Bell,
  Briefcase,
  ChevronRight,
  CreditCard,
  Info,
  LogOut,
  RotateCcw,
  Server,
  SlidersHorizontal,
  CircleUserRound,
  CircleHelp,
  Compass,
  UserPlus,
  ShieldCheck,
  Users,
  KeyRound,
  UserCog,
  Route,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { AppShell } from "@/components/AppShell";
import { useToast } from "@/components/Toast";
import { NavRow } from "@/components/ui";
import { useStore } from "@/store/store";
import { initials } from "@/lib/utils";
import { GuiaPrimeirosPassos } from "@shared/components/ajuda/GuiaPrimeirosPassos";
import { PASSOS_GUIA_APP } from "@shared/lib/ajuda";

export function ConfiguracoesPage() {
  const navigate = useNavigate();
  const { notificar } = useToast();
  const { profile, resetarDemo, modo, servidorOnline, latenciaApi, sessao, sair, recarregar } = useStore();
  const [confirmando, setConfirmando] = useState(false);
  const [guiaAberto, setGuiaAberto] = useState(false);

  return (
    <AppShell activeNav="Configurações">
      <div className="px-5 pt-4">
        <h1 className="text-xl font-bold">Configurações</h1>
        <p className="text-[11px] text-muted-foreground">Conta, integrações e preferências do app</p>
      </div>

      <Link to="/perfil" className="mx-5 mt-4 flex items-center gap-3 rounded-2xl border border-border/60 bg-card p-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/15 text-[13px] font-bold text-primary">
          {initials(profile.nome)}
        </div>
        <div className="flex-1">
          <div className="text-[13px] font-bold">{profile.nome}</div>
          <div className="text-[11px] text-muted-foreground">{profile.permissoes}</div>
        </div>
        <ChevronRight className="h-4 w-4 text-muted-foreground" />
      </Link>

      <h2 className="mx-5 mt-5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        Conta e plano
      </h2>
      <ul className="mx-5 mt-2 divide-y divide-border/60 overflow-hidden rounded-2xl border border-border/60 bg-card">
        <li>
          <Link to="/planos">
            <NavRow
              icone={<CreditCard className="h-4 w-4" />}
              titulo="Planos"
              descricao="Visualizar planos disponíveis"
            />
          </Link>
        </li>
        <li>
          <Link to="/preferencias">
            <NavRow
              icone={<SlidersHorizontal className="h-4 w-4" />}
              titulo="Preferências"
              descricao="Configurações do aplicativo"
            />
          </Link>
        </li>
      </ul>
      <h2 className="mx-5 mt-5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Operação</h2>
      <ul className="mx-5 mt-2 divide-y divide-border/60 overflow-hidden rounded-2xl border border-border/60 bg-card">
        <li>
          <Link to="/alertas">
            <NavRow icone={<Bell className="h-4 w-4" />} titulo="Alertas" descricao="Configurar tipos de alertas" />
          </Link>
        </li>
      </ul>
      {modo === "servidor" && (
        <>
          <h2 className="mx-5 mt-5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            Segurança
          </h2>
          <ul className="mx-5 mt-2 divide-y divide-border/60 overflow-hidden rounded-2xl border border-border/60 bg-card">
            <li>
              <Link to="/seguranca">
                <NavRow
                  icone={<ShieldCheck className="h-4 w-4" />}
                  titulo="Segurança da conta"
                  descricao="Código de dois fatores"
                />
              </Link>
            </li>
            <li>
              <Link to="/meus-dados">
                <NavRow
                  icone={<KeyRound className="h-4 w-4" />}
                  titulo="Meus dados (LGPD)"
                  descricao="Acessar, corrigir ou excluir seus dados"
                />
              </Link>
            </li>
          </ul>
        </>
      )}
      {modo === "servidor" && (sessao?.usuario.papel === "ADMINISTRATOR" || sessao?.usuario.papel === "SUPERVISOR") && (
        <>
          <h2 className="mx-5 mt-5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            Operações
          </h2>
          <ul className="mx-5 mt-2 divide-y divide-border/60 overflow-hidden rounded-2xl border border-border/60 bg-card">
            <li>
              <Link to="/rotas-cadastro">
                <NavRow
                  icone={<Route className="h-4 w-4" />}
                  titulo="Rotas"
                  descricao="Cadastrar rotas com opções de trajeto"
                />
              </Link>
            </li>
          </ul>
        </>
      )}
      {modo === "servidor" && sessao?.usuario.papel === "ADMINISTRATOR" && (
        <>
          <h2 className="mx-5 mt-5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Equipe</h2>
          <ul className="mx-5 mt-2 divide-y divide-border/60 overflow-hidden rounded-2xl border border-border/60 bg-card">
            <li>
              <Link to="/criar-conta">
                <NavRow
                  icone={<UserPlus className="h-4 w-4" />}
                  titulo="Criar conta"
                  descricao="Novas contas da empresa, com cargo e senha provisória"
                />
              </Link>
            </li>
            <li>
              <Link to="/equipe">
                <NavRow
                  icone={<Users className="h-4 w-4" />}
                  titulo="Equipe e permissões"
                  descricao="Contas da empresa e troca de senha"
                />
              </Link>
            </li>
            <li>
              <Link to="/cargos">
                <NavRow
                  icone={<Briefcase className="h-4 w-4" />}
                  titulo="Cargos"
                  descricao="Quem tem cada cargo e quantas pessoas"
                />
              </Link>
            </li>
            <li>
              <Link to="/permissoes-cargos">
                <NavRow
                  icone={<UserCog className="h-4 w-4" />}
                  titulo="Permissões por cargo"
                  descricao="O que supervisores e operadores podem fazer"
                />
              </Link>
            </li>
          </ul>
        </>
      )}

      <h2 className="mx-5 mt-5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Ajuda</h2>
      <ul className="mx-5 mt-2 divide-y divide-border/60 overflow-hidden rounded-2xl border border-border/60 bg-card">
        <li>
          <NavRow
            icone={<Compass className="h-4 w-4" />}
            titulo="Guia de primeiros passos"
            descricao="Rever o passo a passo do sistema"
            onClick={() => setGuiaAberto(true)}
          />
        </li>
        <li>
          <Link to="/ajuda">
            <NavRow
              icone={<CircleHelp className="h-4 w-4" />}
              titulo="Ajuda: o que cada função faz"
              descricao="Explicação de cada tela, passo a passo"
            />
          </Link>
        </li>
      </ul>
      <h2 className="mx-5 mt-5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Sistema</h2>
      <ul className="mx-5 mt-2 divide-y divide-border/60 overflow-hidden rounded-2xl border border-border/60 bg-card">
        <li>
          <Link to="/status">
            <NavRow
              icone={<Server className="h-4 w-4" />}
              titulo="Status do sistema"
              descricao="Integrações e sensores (ESP32, RFID, GPRS)"
            />
          </Link>
        </li>
        <li>
          <Link to="/sobre">
            <NavRow icone={<Info className="h-4 w-4" />} titulo="Sobre LoadSense" descricao="Versão 1.0.0 · TCC 2026" />
          </Link>
        </li>
      </ul>

      <div className="mx-5 mt-3 rounded-2xl border border-border/60 bg-card p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 text-primary">
            <Server className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <div className="text-[12px] font-semibold">
              {modo === "servidor" ? "Conectado ao banco de dados" : "Dados de exemplo"}
            </div>
            <div className="text-[10px] text-muted-foreground">
              {modo === "servidor"
                ? `${sessao?.empresa.nome ?? "empresa"} · ${sessao?.usuario.papel ?? ""} · ${latenciaApi} ms de latência`
                : servidorOnline
                  ? "Servidor disponível — entre com seu e-mail para usar os dados reais"
                  : "API offline: os dados são gerados localmente pelo app"}
            </div>
          </div>
        </div>
        {modo === "servidor" && (
          <button
            type="button"
            onClick={async () => {
              await recarregar();
              notificar({
                titulo: "Dados atualizados",
                descricao: "Operações e alertas recarregados do banco.",
                tom: "success",
              });
            }}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-border/60 py-2.5 text-[12px] font-semibold"
          >
            <RotateCcw className="h-4 w-4" />
            Sincronizar agora
          </button>
        )}
      </div>

      {modo !== "servidor" && (
        <div className="mx-5 mt-3 rounded-2xl border border-border/60 bg-card p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 text-primary">
              <CircleUserRound className="h-4 w-4" />
            </div>
            <div className="flex-1">
              <div className="text-[12px] font-semibold">Dados de exemplo</div>
              <div className="text-[10px] text-muted-foreground">
                Apaga as alterações feitas neste aparelho e volta aos dados de exemplo
              </div>
            </div>
          </div>
          {confirmando && (
            <p className="mt-3 text-[11px] text-destructive">
              Isso apaga as alterações feitas neste aparelho. O servidor não é alterado.
            </p>
          )}
          {confirmando ? (
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  resetarDemo();
                  setConfirmando(false);
                  notificar({
                    titulo: "Dados de exemplo restaurados",
                    descricao: "Dados originais recarregados.",
                    tom: "success",
                  });
                }}
                className="flex-1 rounded-xl bg-primary py-2.5 text-[12px] font-semibold text-primary-foreground"
              >
                Confirmar
              </button>
              <button
                type="button"
                onClick={() => setConfirmando(false)}
                className="flex-1 rounded-xl border border-border/60 py-2.5 text-[12px] font-semibold"
              >
                Cancelar
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmando(true)}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-border/60 py-2.5 text-[12px] font-semibold"
            >
              <RotateCcw className="h-4 w-4" />
              Restaurar dados iniciais
            </button>
          )}
        </div>
      )}

      <div className="mb-5 mt-4 px-5">
        <button
          type="button"
          onClick={async () => {
            if (modo === "servidor") await sair();
            notificar({ titulo: "Sessão encerrada", descricao: "Você saiu da conta com segurança.", tom: "info" });
            navigate("/login");
          }}
          className="flex w-full items-center justify-center gap-2 rounded-2xl border border-destructive/40 bg-destructive/10 py-3 text-[13px] font-semibold text-destructive"
        >
          <LogOut className="h-4 w-4" />
          Sair da conta
        </button>
      </div>
      <GuiaPrimeirosPassos
        plataforma="app"
        passos={PASSOS_GUIA_APP}
        aberto={guiaAberto}
        onFechar={() => setGuiaAberto(false)}
      />
    </AppShell>
  );
}
