import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthShell } from "@/components/AppShell";
import { Logo } from "@/components/Logo";
import { CheckSquare } from "@/components/ui";

const SECOES: Array<[string, string]> = [
  [
    "1. Objeto.",
    " O LoadSense é uma plataforma de monitoramento de cargas e pesagem de veículos, destinada ao acompanhamento operacional de transportes.",
  ],
  [
    "2. Uso da conta.",
    " O usuário é responsável pela veracidade dos dados informados e pelo sigilo de suas credenciais de acesso.",
  ],
  [
    "3. Dados coletados.",
    " Coletamos dados de localização dos veículos, pesagens, rotas e alertas gerados durante as operações, com a finalidade exclusiva de monitoramento logístico.",
  ],
  [
    "4. Privacidade.",
    " Os dados são tratados conforme a LGPD (Lei nº 13.709/2018). Você pode acessar, corrigir, exportar e pedir a exclusão dos seus dados em Configurações > Meus dados (LGPD). Dados não são compartilhados com terceiros fora das hipóteses da Política de Privacidade.",
  ],
  [
    "5. Alertas.",
    " Os alertas de sobrecarga, parada não programada e divergência de peso são indicativos e não substituem a conferência oficial em balança certificada.",
  ],
  [
    "6. Disponibilidade.",
    " O serviço pode passar por manutenções programadas, comunicadas na tela de Status do Sistema.",
  ],
  [
    "7. Arrependimento e garantia.",
    " Em contratações à distância, você pode desistir em até 7 dias corridos, com reembolso integral (art. 49 do CDC). Defeitos no serviço podem ser reclamados nos prazos legais (art. 18 e art. 26 do CDC).",
  ],
  ["8. Contato.", " Dúvidas e solicitações: Vitor.o.rangel01@gmail.com. Respondemos em até 15 dias corridos."],
  [
    "9. Aceite.",
    " Ao continuar, o usuário declara ter lido e concordado integralmente com estes Termos de Uso e com a Política de Privacidade.",
  ],
];

export function TermsPage() {
  const navigate = useNavigate();
  const [aceito, setAceito] = useState(false);

  return (
    <AuthShell>
      <div className="mb-5 flex justify-center">
        <Logo />
      </div>

      <h1 className="text-lg font-bold">Termos de Uso</h1>
      <p className="mt-1 text-[11px] text-muted-foreground">Leia e aceite para continuar</p>

      <div className="ls-scroll mt-4 flex-1 space-y-3 overflow-y-auto rounded-2xl border border-border/60 bg-card p-4 text-[11px] leading-relaxed text-muted-foreground">
        {SECOES.map(([titulo, texto]) => (
          <p key={titulo}>
            <span className="font-semibold text-foreground">{titulo}</span>
            {texto}
          </p>
        ))}
      </div>

      <button
        type="button"
        onClick={() => setAceito((valor) => !valor)}
        className="mt-4 flex items-center gap-3 text-left"
      >
        <CheckSquare marcado={aceito} />
        <span className="text-[11px]">Li e aceito os Termos de Uso e a Política de Privacidade</span>
      </button>

      <button
        type="button"
        disabled={!aceito}
        onClick={() => navigate("/login")}
        className="mt-4 w-full rounded-xl bg-primary py-3 text-[13px] font-semibold text-primary-foreground disabled:opacity-40"
      >
        Aceitar e continuar
      </button>

      <button
        type="button"
        onClick={() => navigate("/splash")}
        className="w-full py-2 text-center text-[12px] text-muted-foreground"
      >
        Recusar
      </button>
    </AuthShell>
  );
}
