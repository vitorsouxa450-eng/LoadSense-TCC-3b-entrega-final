import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { CircleCheck, Filter } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { AlertCard } from "@/components/AlertCard";
import { useToast } from "@/components/Toast";
import { Banner, EmptyState, Pill, SegmentedTabs, Toggle } from "@/components/ui";
import { useStore } from "@/store/store";
import { api, type AlertaApi } from "@shared/lib/api";
import { cn, formatShortDate, formatTime } from "@/lib/utils";
import { FormResolucaoAlerta, DetalheResolucao } from "@/components/FormResolucaoAlerta";
import { rotuloMotivo, type ResolucaoAlerta } from "@shared/lib/alertas";

type Aba = "ativos" | "resolvidos" | "todos";

function AlertasDemo() {
  const { alerts, resolverTodosAlertas, preferences, atualizarPreferencias } = useStore();
  const { notificar } = useToast();
  const [aba, setAba] = useState<Aba>("ativos");

  const base =
    aba === "ativos"
      ? alerts.filter((alert) => alert.status === "ativo")
      : aba === "resolvidos"
        ? alerts.filter((alert) => alert.status === "resolvido")
        : alerts;

  const lista = preferences.apenasCriticos ? base.filter((alert) => alert.nivel === "critico") : base;
  const criticos = lista.filter((alert) => alert.nivel === "critico" && alert.status === "ativo").length;

  return (
    <AppShell activeNav="Configurações" headerSlot={<HeaderAlertas />}>
      <div className="flex items-start justify-between px-5 pt-4">
        <div>
          <h1 className="text-xl font-bold">Alertas</h1>
          <p className="text-[11px] text-muted-foreground">
            {alerts.filter((alert) => alert.status === "ativo").length} ativos · {criticos} críticos
          </p>
        </div>
        {alerts.some((alert) => alert.status === "ativo") && (
          <button
            type="button"
            onClick={() => {
              resolverTodosAlertas();
              notificar({
                titulo: "Alertas resolvidos",
                descricao: "Todas as ocorrências foram encerradas.",
                tom: "success",
              });
            }}
            className="flex items-center gap-1 rounded-xl border border-success/40 bg-success/10 px-3 py-2 text-[12px] font-semibold text-success"
          >
            <CircleCheck className="h-4 w-4" />
            Resolver todos
          </button>
        )}
      </div>

      <div className="mt-3 px-5">
        <SegmentedTabs
          tabs={[
            { value: "ativos", label: "Ativos" },
            { value: "resolvidos", label: "Resolvidos" },
            { value: "todos", label: "Todos" },
          ]}
          value={aba}
          onChange={setAba}
        />
      </div>

      <div className="mx-5 mt-3 flex items-center gap-3 rounded-2xl border border-border/60 bg-card px-4 py-3">
        <Filter className="h-4 w-4 text-muted-foreground" />
        <div className="flex-1">
          <div className="text-[12px] font-semibold">Apenas alertas críticos</div>
          <div className="text-[10px] text-muted-foreground">Filtra a lista exibida abaixo</div>
        </div>
        <Toggle
          rotulo="Mostrar apenas alertas críticos"
          on={preferences.apenasCriticos}
          onChange={(valor) => atualizarPreferencias({ apenasCriticos: valor })}
        />
      </div>

      {criticos > 0 && aba !== "resolvidos" && (
        <div className="px-5">
          <Banner tom="destructive" className="mt-3">
            {criticos} alerta(s) crítico(s) exigem ação imediata da torre de controle
          </Banner>
        </div>
      )}

      <ul className="mt-3 space-y-2.5 px-5 pb-5">
        {lista.map((alert) => (
          <li key={alert.id}>
            <AlertCard alert={alert} />
          </li>
        ))}
        {lista.length === 0 && (
          <li>
            <EmptyState
              titulo="Nenhum alerta nesta visão"
              descricao="As ocorrências aparecem aqui em tempo real conforme as pesagens e o rastreamento."
            />
          </li>
        )}
      </ul>
    </AppShell>
  );
}

function HeaderAlertas() {
  return (
    <header className="flex min-h-12 items-center justify-between border-b border-border/60 bg-background/95 px-5 py-2 backdrop-blur">
      <span className="text-sm font-semibold">Central de alertas</span>
      <span className="text-[11px] text-muted-foreground">Torre de controle</span>
    </header>
  );
}

const NIVEL: Record<AlertaApi["nivel"], { rotulo: string; tom: "destructive" | "warning" }> = {
  CRITICAL: { rotulo: "Crítico", tom: "destructive" },
  ATTENTION: { rotulo: "Atenção", tom: "warning" },
};

const SITUACAO: Record<AlertaApi["situacao"], { rotulo: string; tom: "primary" | "success" | "muted" }> = {
  OPEN: { rotulo: "Aberto", tom: "primary" },
  ACKNOWLEDGED: { rotulo: "Reconhecido", tom: "muted" },
  RESOLVED: { rotulo: "Resolvido", tom: "success" },
};

const mensagemErro = (e: unknown) => (e instanceof Error ? e.message : "Não foi possível concluir a ação.");

function CartaoAlertaServidor({ alerta, onAlterado }: { alerta: AlertaApi; onAlterado: () => void }) {
  const { notificar } = useToast();
  const [resolvendo, setResolvendo] = useState(false);
  const [ocupado, setOcupado] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const nivel = NIVEL[alerta.nivel] ?? NIVEL.ATTENTION;
  const situacao = SITUACAO[alerta.situacao] ?? SITUACAO.OPEN;

  async function executar(acao: () => Promise<unknown>, titulo: string) {
    setOcupado(true);
    setErro(null);
    try {
      await acao();
      setResolvendo(false);
      notificar({ titulo, tom: "success" });
      onAlterado();
    } catch (e) {
      setErro(mensagemErro(e));
    } finally {
      setOcupado(false);
    }
  }

  const botao = "rounded-xl border border-border/60 px-3 py-2 text-[12px] font-semibold disabled:opacity-50";

  return (
    <div className="rounded-2xl border border-border/60 bg-card p-4">
      <div className="mb-1 flex flex-wrap items-center gap-2">
        <Pill tom={nivel.tom}>{nivel.rotulo}</Pill>
        <Pill tom={situacao.tom}>{situacao.rotulo}</Pill>
        <span className="text-[10px] text-muted-foreground">
          {formatShortDate(alerta.criadoEm)}, {formatTime(alerta.criadoEm)}
        </span>
      </div>
      <div className="text-[13px] font-semibold">{alerta.titulo}</div>
      <p className="mt-1 text-[12px] text-muted-foreground">{alerta.mensagem}</p>
      <p className="mt-2 text-[11px]">
        Operação <span className="font-semibold text-primary">{alerta.operacaoCodigo ?? "—"}</span>
        {alerta.veiculo && <> · {alerta.veiculo}</>}
        {alerta.motorista && <> · {alerta.motorista}</>}
        {alerta.operacaoId && (
          <>
            {" · "}
            <Link to={`/operacoes/${alerta.operacaoId}`} className="font-semibold text-primary">
              Ver operação →
            </Link>
          </>
        )}
      </p>
      {alerta.situacao === "RESOLVED" && (
        <DetalheResolucao
          motivo={rotuloMotivo(alerta.motivoResolucao) || null}
          acao={alerta.notasResolucao}
          por={alerta.resolvidoPor}
          quando={
            alerta.resolvidoEm ? `${formatShortDate(alerta.resolvidoEm)}, ${formatTime(alerta.resolvidoEm)}` : null
          }
        />
      )}

      {alerta.situacao === "RESOLVED" ? (
        <div className="mt-3 flex justify-end gap-2">
          {alerta.operacaoId && (
            <Link to={`/operacoes/${alerta.operacaoId}`} className="self-center text-[12px] font-semibold text-primary">
              Ver operação
            </Link>
          )}
          <button
            type="button"
            disabled={ocupado}
            className={botao}
            onClick={() => executar(() => api.reabrirAlerta(alerta.id), "Alerta reaberto")}
          >
            Reabrir
          </button>
        </div>
      ) : resolvendo ? (
        <FormResolucaoAlerta
          ocupado={ocupado}
          onCancelar={() => {
            setResolvendo(false);
            setErro(null);
          }}
          onConfirmar={(resolucao: ResolucaoAlerta) =>
            executar(() => api.resolverAlerta(alerta.id, resolucao), "Alerta resolvido")
          }
        />
      ) : (
        <div className="mt-3 flex flex-wrap justify-end gap-2">
          {alerta.situacao === "OPEN" && (
            <button
              type="button"
              disabled={ocupado}
              className={botao}
              onClick={() => executar(() => api.reconhecerAlerta(alerta.id), "Alerta reconhecido")}
            >
              Reconhecer
            </button>
          )}
          <button
            type="button"
            disabled={ocupado}
            className="rounded-xl bg-primary px-3 py-2 text-[12px] font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-50"
            onClick={() => setResolvendo(true)}
          >
            Resolver
          </button>
        </div>
      )}
      {erro && <p className="mt-2 text-[11px] text-destructive">{erro}</p>}
    </div>
  );
}

function AlertasServidor() {
  const { recarregarDados } = useStore();
  const [alertas, setAlertas] = useState<AlertaApi[] | null>(null);
  const [erro, setErro] = useState<string | null>(null);
  const [filtro, setFiltro] = useState<"ABERTOS" | "RESOLVIDOS" | "TODOS">("ABERTOS");
  const [versao, setVersao] = useState(0);

  useEffect(() => {
    let ativo = true;
    api
      .alertas("&limite=200")
      .then((r) => ativo && setAlertas(r.alertas))
      .catch((e) => ativo && setErro(mensagemErro(e)));
    return () => {
      ativo = false;
    };
  }, [versao]);

  const visiveis = (alertas ?? []).filter((a) => {
    if (filtro === "TODOS") return true;
    if (filtro === "RESOLVIDOS") return a.situacao === "RESOLVED";
    return a.situacao !== "RESOLVED";
  });
  const abertos = (alertas ?? []).filter((a) => a.situacao !== "RESOLVED").length;

  function alterado() {
    setVersao((v) => v + 1);
    recarregarDados().catch(() => undefined);
  }

  return (
    <AppShell activeNav="Configurações" headerSlot={<HeaderAlertas />}>
      <div className="px-5 pt-4">
        <h1 className="text-xl font-bold">Alertas</h1>
        <p className="text-[11px] text-muted-foreground">
          Alertas automáticos gerados pelo banco de dados (pesagem e rastreamento)
          {alertas && ` · ${abertos} em aberto`}
        </p>
      </div>

      <div className="mt-3 flex gap-2 px-5">
        {(["ABERTOS", "RESOLVIDOS", "TODOS"] as const).map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => setFiltro(f)}
            className={cn(
              "rounded-lg px-3 py-1.5 text-[12px] font-semibold",
              filtro === f ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground",
            )}
          >
            {f === "ABERTOS" ? "Em aberto" : f === "RESOLVIDOS" ? "Resolvidos" : "Todos"}
          </button>
        ))}
      </div>

      {erro && <p className="mx-5 mt-3 rounded-xl bg-destructive/10 px-3 py-2 text-[11px] text-destructive">{erro}</p>}

      <ul className="mt-3 space-y-2.5 px-5 pb-5">
        {alertas === null && !erro && (
          <p className="py-6 text-center text-[12px] text-muted-foreground">Carregando alertas…</p>
        )}
        {alertas !== null && visiveis.length === 0 && (
          <li>
            <EmptyState
              titulo="Nenhum alerta nesta visão"
              descricao="As ocorrências aparecem aqui conforme as pesagens e o rastreamento."
            />
          </li>
        )}
        {visiveis.map((a) => (
          <li key={a.id}>
            <CartaoAlertaServidor alerta={a} onAlterado={alterado} />
          </li>
        ))}
      </ul>
    </AppShell>
  );
}

export function AlertasPage() {
  const { modo } = useStore();
  return modo === "servidor" ? <AlertasServidor /> : <AlertasDemo />;
}
