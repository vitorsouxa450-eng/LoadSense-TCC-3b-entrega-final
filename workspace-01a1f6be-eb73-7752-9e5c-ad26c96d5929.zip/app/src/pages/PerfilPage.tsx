import { useEffect, useState, type ReactNode } from "react";
import {
  Database,
  Eye,
  EyeOff,
  FileText,
  LifeBuoy,
  LogOut,
  Lock,
  Loader2,
  Mail,
  Monitor,
  Phone,
  ShieldCheck,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { api, ErroApi } from "@shared/lib/api";
import { AppHeader } from "@/components/AppHeader";
import { AppShell } from "@/components/AppShell";
import { useToast } from "@/components/Toast";
import { Section } from "@/components/ui";
import { useStore } from "@/store/store";
import { cn, initials } from "@/lib/utils";

type Sessao = Awaited<ReturnType<typeof api.seguranca.sessoes>>["sessoes"][number];

const formatarData = (valor: string | null) =>
  valor ? new Date(valor).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "—";

const DESCRICAO_CARGO: Record<string, string> = {
  Administrador: "Gerencia a empresa: cadastros, usuários, plano e relatórios.",
  "Supervisor de Operações": "Acompanha operações, alertas e relatórios da equipe.",
  "Operador de Pesagem": "Registra pesagens e operações do dia a dia.",
};

function mascarar(valor: string): string {
  const digitos = valor.replace(/\D/g, "");
  if (digitos.length <= 4) return valor;
  let restante = digitos.length - 4;
  return valor.replace(/\d/g, (d) => (restante-- > 0 ? "•" : d));
}

function LinhaDado({ rotulo, children }: { rotulo: string; children: ReactNode }) {
  return (
    <li className="flex items-start justify-between gap-4 py-2.5">
      <span className="text-sm text-muted-foreground">{rotulo}</span>
      <span className="text-right text-sm font-medium break-all">{children}</span>
    </li>
  );
}

function AcaoPerfil({
  to,
  icone: Icone,
  titulo,
  descricao,
}: {
  to: string;
  icone: typeof Lock;
  titulo: string;
  descricao: string;
}) {
  return (
    <Link
      to={to}
      className="flex min-h-[56px] items-center gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-muted/60 active:bg-muted"
    >
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary">
        <Icone className="h-5 w-5" />
      </span>
      <span className="flex-1">
        <span className="block text-sm font-semibold">{titulo}</span>
        <span className="block text-xs text-muted-foreground">{descricao}</span>
      </span>
    </Link>
  );
}

export function PerfilPage() {
  const navigate = useNavigate();
  const { notificar } = useToast();
  const { profile, sessao, sair, modo } = useStore();
  const [mostrarDados, setMostrarDados] = useState(false);
  const [confirmando, setConfirmando] = useState(false);
  const [saindo, setSaindo] = useState(false);
  const [dupla, setDupla] = useState<{ ativo: boolean; ativoDesde: string | null } | null>(null);
  const [sessoes, setSessoes] = useState<Sessao[] | null>(null);
  const [encerrando, setEncerrando] = useState<number | null>(null);

  const papel = sessao?.usuario.papel ?? "ADMINISTRATOR";
  const ehAdministrador = papel === "ADMINISTRATOR";
  const descricaoCargo = DESCRICAO_CARGO[profile.cargo] ?? "";

  useEffect(() => {
    if (modo !== "servidor") return;
    api.totp
      .estado()
      .then(setDupla)
      .catch(() => setDupla(null));
    api.seguranca
      .sessoes()
      .then((d) => setSessoes(d.sessoes))
      .catch(() => setSessoes([]));
  }, [modo]);

  const encerrarOutraSessao = async (sessao: Sessao) => {
    setEncerrando(sessao.id);
    try {
      const r = await api.seguranca.encerrar(sessao.id);
      if (r.atual) {
        await sair();
        navigate("/login");
        return;
      }
      notificar({ titulo: "Sessão encerrada", descricao: `Acesso de ${sessao.descricao} removido.`, tom: "success" });
      setSessoes((prev) => (prev ?? []).filter((x) => x.id !== sessao.id));
    } catch (e) {
      notificar({
        titulo: "Não foi possível encerrar",
        descricao: e instanceof ErroApi ? e.message : "Tente novamente.",
        tom: "alert",
      });
    } finally {
      setEncerrando(null);
    }
  };

  const encerrarSessao = async () => {
    setSaindo(true);
    try {
      if (modo === "servidor") await sair();
      notificar({ titulo: "Sessão encerrada", descricao: "Você saiu desta conta.", tom: "info" });
      navigate("/login");
    } finally {
      setSaindo(false);
    }
  };

  const telefone = profile.telefone ? profile.telefone : null;

  return (
    <AppShell activeNav="Configurações" headerSlot={<AppHeader back title="Perfil" />}>
      <div className="flex flex-col items-center px-5 pt-6">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/15 text-xl font-bold text-primary">
          {initials(profile.nome)}
        </div>
        <h2 className="mt-3 text-lg font-bold">{profile.nome}</h2>
        <p className="text-sm text-muted-foreground">{profile.cargo}</p>
        {descricaoCargo && <p className="mt-2 max-w-xs text-center text-sm text-muted-foreground">{descricaoCargo}</p>}
      </div>

      <Section title="Dados da conta" className="mt-5">
        <ul className="divide-y divide-border/60">
          <LinhaDado rotulo="Empresa">{profile.empresa}</LinhaDado>
          <LinhaDado rotulo="CNPJ">
            <span className="inline-flex items-center gap-2">
              {profile.cnpj ? (mostrarDados ? profile.cnpj : mascarar(profile.cnpj)) : "Não informado"}
            </span>
          </LinhaDado>
          <LinhaDado rotulo="E-mail">
            <a href={`mailto:${profile.email}`} className="inline-flex items-center gap-1 text-primary">
              <Mail className="h-4 w-4" />
              {profile.email}
            </a>
          </LinhaDado>
          <LinhaDado rotulo="Telefone">
            {telefone ? (
              <a href={`tel:${telefone.replace(/\D/g, "")}`} className="inline-flex items-center gap-1 text-primary">
                <Phone className="h-4 w-4" />
                {mostrarDados ? telefone : mascarar(telefone)}
              </a>
            ) : (
              "Não informado"
            )}
          </LinhaDado>
          {ehAdministrador && <LinhaDado rotulo="Plano atual">{profile.plano}</LinhaDado>}
        </ul>
        <button
          type="button"
          onClick={() => setMostrarDados((v) => !v)}
          className="mt-2 inline-flex min-h-[44px] items-center gap-2 text-sm font-semibold text-primary"
        >
          {mostrarDados ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          {mostrarDados ? "Ocultar CNPJ e telefone" : "Mostrar CNPJ e telefone"}
        </button>
      </Section>

      <Section title="Segurança" className="mt-4">
        <div className="flex flex-col">
          <AcaoPerfil
            to="/configuracoes"
            icone={ShieldCheck}
            titulo="Verificação em duas etapas"
            descricao={
              dupla === null
                ? "Abra as configurações para ver o estado."
                : dupla.ativo
                  ? `Ativa${dupla.ativoDesde ? ` desde ${new Date(dupla.ativoDesde).toLocaleDateString("pt-BR")}` : ""}. Código enviado por e-mail.`
                  : "Desativada. Recomendamos ativar para proteger sua conta."
            }
          />
          {modo === "servidor" && (
            <AcaoPerfil
              to="/alterar-senha"
              icone={Lock}
              titulo="Alterar senha"
              descricao="Use sua senha atual para criar uma nova."
            />
          )}
          <AcaoPerfil
            to="/esqueci-senha"
            icone={Mail}
            titulo="Esqueci minha senha"
            descricao="Receba um código no e-mail cadastrado."
          />
        </div>
        <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-muted-foreground">
          <li>Nunca compartilhe sua senha nem códigos de verificação.</li>
          <li>Em celular compartilhado, use “Sair da conta” ao terminar.</li>
        </ul>
      </Section>

      {modo === "servidor" && (
        <Section title="Sessões ativas" className="mt-4">
          <p className="mb-2 text-xs text-muted-foreground">
            Onde sua conta está conectada agora. Encerre os acessos que não reconhece.
          </p>
          {sessoes === null ? (
            <p className="text-sm text-muted-foreground">Carregando…</p>
          ) : sessoes.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhuma sessão ativa.</p>
          ) : (
            <ul className="divide-y divide-border/60">
              {sessoes.map((s) => (
                <li key={s.id} className="flex items-center gap-3 py-2.5">
                  <Monitor className="h-5 w-5 shrink-0 text-muted-foreground" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">
                      {s.descricao}
                      {s.atual && (
                        <span className="ml-2 rounded-md bg-primary/15 px-1.5 py-0.5 text-[10px] font-bold uppercase text-primary">
                          Este aparelho
                        </span>
                      )}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Entrou em {formatarData(s.criadaEm)} · último uso {formatarData(s.ultimoUso ?? s.criadaEm)}
                    </p>
                  </div>
                  {!s.atual && (
                    <button
                      type="button"
                      disabled={encerrando === s.id}
                      onClick={() => void encerrarOutraSessao(s)}
                      className="flex min-h-[44px] shrink-0 items-center gap-1.5 rounded-xl border border-destructive/40 px-3 text-xs font-semibold text-destructive disabled:opacity-60"
                    >
                      {encerrando === s.id && <Loader2 className="h-3 w-3 animate-spin" />}
                      Encerrar
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Section>
      )}

      <Section title="Privacidade e dados pessoais" className="mt-4">
        <p className="text-sm text-muted-foreground">
          Seus dados são tratados conforme a LGPD (Lei nº 13.709/2018), para operar o sistema de pesagem e controle de
          cargas.
        </p>
        <ul className="mt-3 space-y-2 text-sm">
          <li className="flex items-start gap-3">
            <Database className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <span>
              <strong>Pesagens e operações:</strong> guardadas por 5 anos.
            </span>
          </li>
          <li className="flex items-start gap-3">
            <Database className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <span>
              <strong>Dados técnicos de acesso</strong> (endereço IP e navegador): removidos após 6 meses. O registro de
              ações da conta é mantido para sua segurança.
            </span>
          </li>
        </ul>
        <div className="mt-3 flex flex-col">
          <AcaoPerfil
            to="/configuracoes"
            icone={FileText}
            titulo="Baixar, corrigir ou excluir meus dados"
            descricao="Direitos do titular, em Configurações > Meus dados (LGPD)."
          />
          <AcaoPerfil
            to="/termos"
            icone={FileText}
            titulo="Termos de Uso e Política de Privacidade"
            descricao="Leia como seus dados são usados e protegidos."
          />
        </div>
      </Section>

      <Section title="Ajuda" className="mt-4">
        <AcaoPerfil
          to="/sobre"
          icone={LifeBuoy}
          titulo="Precisa de ajuda?"
          descricao="Informações sobre o sistema e contato com o suporte."
        />
      </Section>

      <div className="mb-5 mt-6 px-5">
        {confirmando ? (
          <div className="rounded-2xl border border-destructive/40 bg-destructive/10 p-4">
            <p className="text-center text-sm font-semibold">Sair desta conta neste celular?</p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setConfirmando(false)}
                className="min-h-[48px] rounded-xl border border-border bg-card text-sm font-semibold"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={saindo}
                onClick={encerrarSessao}
                className="min-h-[48px] rounded-xl bg-destructive text-sm font-semibold text-destructive-foreground disabled:opacity-60"
              >
                Sim, sair
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setConfirmando(true)}
            className={cn(
              "flex min-h-[52px] w-full items-center justify-center gap-2 rounded-2xl border border-destructive/40 bg-destructive/10 py-3 text-sm font-semibold text-destructive",
            )}
          >
            <LogOut className="h-4 w-4" />
            Sair da conta
          </button>
        )}
      </div>
    </AppShell>
  );
}
