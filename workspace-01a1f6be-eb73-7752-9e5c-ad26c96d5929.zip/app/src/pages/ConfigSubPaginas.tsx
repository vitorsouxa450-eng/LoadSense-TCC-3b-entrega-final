import type { ReactNode } from "react";
import { AppShell } from "@/components/AppShell";
import { AppHeader } from "@/components/AppHeader";
import { SegundoFatorPainel } from "@shared/components/SegundoFatorPainel";
import { UsuariosPainel } from "@/components/UsuariosPainel";
import { PermissoesCargosPainel } from "@/components/PermissoesCargosPainel";
import { CargosPainel } from "@/components/CargosPainel";
import { RotasPainel } from "@/components/RotasPainel";
import { MeusDadosPainel } from "@/components/MeusDadosPainel";
import { useStore } from "@/store/store";
import { useNavigate } from "react-router-dom";

function TelaConfig({
  titulo,
  descricao,
  children,
  restrita,
  motivoRestricao,
}: {
  titulo: string;
  descricao: string;
  children: ReactNode;
  restrita?: boolean;
  motivoRestricao?: string;
}) {
  return (
    <AppShell activeNav="Configurações" headerSlot={<AppHeader back title={titulo} />}>
      <div className="px-5 pt-4">
        <h1 className="text-xl font-bold">{titulo}</h1>
        <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">{descricao}</p>
      </div>
      <div className="mx-5 mb-6 mt-4">
        {restrita ? (
          <p className="rounded-xl border border-border/60 bg-card-elev p-4 text-[12px] text-muted-foreground">
            {motivoRestricao}
          </p>
        ) : (
          <div className="rounded-2xl border border-border/60 bg-card p-4">{children}</div>
        )}
      </div>
    </AppShell>
  );
}

export function SegurancaPage() {
  const { modo } = useStore();
  return (
    <TelaConfig
      titulo="Segurança da conta"
      descricao="Código de dois fatores e proteção de acesso da sua conta."
      restrita={modo !== "servidor"}
      motivoRestricao="Disponível quando o aplicativo está conectado ao servidor."
    >
      <SegundoFatorPainel />
    </TelaConfig>
  );
}

export function EquipePage() {
  const { modo, sessao } = useStore();
  const pode = modo === "servidor" && sessao?.usuario.papel === "ADMINISTRATOR";
  return (
    <TelaConfig
      titulo="Equipe e permissões"
      descricao="Veja as contas da empresa, o cargo de cada pessoa e exija a troca de senha quando precisar."
      restrita={!pode}
      motivoRestricao="Esta área é exclusiva para administradores da empresa."
    >
      <UsuariosPainel />
    </TelaConfig>
  );
}

export function RotasCadastroPage() {
  const { modo, sessao } = useStore();
  const papel = sessao?.usuario.papel;
  const pode = modo === "servidor" && (papel === "ADMINISTRATOR" || papel === "SUPERVISOR");
  return (
    <TelaConfig
      titulo="Rotas"
      descricao="Rotas da empresa. Defina a rota antes de criar a operação, escolhendo entre as opções de trajeto."
      restrita={!pode}
      motivoRestricao="Esta área é para administradores e supervisores, com o aplicativo conectado ao servidor."
    >
      <RotasPainel />
    </TelaConfig>
  );
}

export function CargosPage() {
  const { modo, sessao } = useStore();
  const pode = modo === "servidor" && sessao?.usuario.papel === "ADMINISTRATOR";
  return (
    <TelaConfig
      titulo="Cargos"
      descricao="Os cargos da empresa, quantas pessoas têm cada um e o que cada cargo pode fazer."
      restrita={!pode}
      motivoRestricao="Esta área é exclusiva para administradores da empresa."
    >
      <CargosPainel />
    </TelaConfig>
  );
}

export function PermissoesCargosPage() {
  const { modo, sessao } = useStore();
  const pode = modo === "servidor" && sessao?.usuario.papel === "ADMINISTRATOR";
  return (
    <TelaConfig
      titulo="Permissões por cargo"
      descricao="Defina o que Supervisores e Operadores podem fazer. Vale na próxima ação de cada pessoa."
      restrita={!pode}
      motivoRestricao="Esta área é exclusiva para administradores da empresa."
    >
      <PermissoesCargosPainel />
    </TelaConfig>
  );
}

export function MeusDadosPage() {
  const { modo } = useStore();
  const navigate = useNavigate();
  return (
    <TelaConfig
      titulo="Meus dados (LGPD)"
      descricao="Acesse, corrija ou exclua seus dados pessoais."
      restrita={modo !== "servidor"}
      motivoRestricao="Disponível quando o aplicativo está conectado ao servidor."
    >
      <MeusDadosPainel onExcluida={() => navigate("/login")} />
    </TelaConfig>
  );
}
