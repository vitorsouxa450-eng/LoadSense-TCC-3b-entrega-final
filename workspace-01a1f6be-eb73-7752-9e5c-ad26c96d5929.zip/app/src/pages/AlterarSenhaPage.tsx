import { useState, type FormEvent } from "react";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { AppHeader } from "@/components/AppHeader";
import { AppShell } from "@/components/AppShell";
import { useToast } from "@/components/Toast";
import { Section } from "@/components/ui";
import { useStore } from "@/store/store";
import { senhaForte } from "@/pages/RecuperacaoPages";

const campo =
  "mt-1 w-full rounded-xl border border-border/60 bg-card-elev px-3 py-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-primary";

export function AlterarSenhaPage() {
  const navigate = useNavigate();
  const { notificar } = useToast();
  const { alterarSenha } = useStore();
  const [atual, setAtual] = useState("");
  const [nova, setNova] = useState("");
  const [confirmacao, setConfirmacao] = useState("");
  const [mostrar, setMostrar] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  async function enviar(event: FormEvent) {
    event.preventDefault();
    setErro(null);
    if (!senhaForte(nova))
      return setErro("A nova senha precisa de 8 caracteres, com letra maiúscula, número e símbolo.");
    if (nova !== confirmacao) return setErro("A confirmação não confere com a nova senha.");
    if (nova === atual) return setErro("Escolha uma senha diferente da atual.");
    setEnviando(true);
    const falha = await alterarSenha(atual, nova);
    setEnviando(false);
    if (falha) return setErro(falha);
    notificar({
      titulo: "Senha alterada",
      descricao: "As outras sessões desta conta foram encerradas.",
      tom: "success",
    });
    navigate("/perfil", { replace: true });
  }

  return (
    <AppShell activeNav="Configurações" headerSlot={<AppHeader back title="Alterar senha" />}>
      <form onSubmit={enviar} className="px-5 pt-5">
        <Section title="Nova senha">
          <p className="mb-3 text-xs text-muted-foreground">
            Mínimo de 8 caracteres, com letra maiúscula, número e símbolo. Ao trocar, as outras sessões desta conta são
            encerradas.
          </p>
          <label className="block text-sm font-medium">
            Senha atual
            <input
              type="password"
              autoComplete="current-password"
              value={atual}
              onChange={(e) => setAtual(e.target.value)}
              className={campo}
            />
          </label>
          <label className="mt-3 block text-sm font-medium">
            Nova senha
            <input
              type={mostrar ? "text" : "password"}
              autoComplete="new-password"
              value={nova}
              onChange={(e) => setNova(e.target.value)}
              className={campo}
            />
          </label>
          <label className="mt-3 block text-sm font-medium">
            Confirme a nova senha
            <input
              type={mostrar ? "text" : "password"}
              autoComplete="new-password"
              value={confirmacao}
              onChange={(e) => setConfirmacao(e.target.value)}
              className={campo}
            />
          </label>
          <button
            type="button"
            onClick={() => setMostrar((v) => !v)}
            className="mt-2 inline-flex min-h-[44px] items-center gap-2 text-sm font-semibold text-primary"
          >
            {mostrar ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            {mostrar ? "Ocultar senhas" : "Mostrar senhas"}
          </button>
          {erro && (
            <p role="alert" className="mt-3 text-sm text-destructive">
              {erro}
            </p>
          )}
        </Section>
        <button
          type="submit"
          disabled={enviando || !atual || !nova || !confirmacao}
          className="mt-5 flex min-h-[52px] w-full items-center justify-center gap-2 rounded-2xl bg-primary text-sm font-semibold text-primary-foreground disabled:opacity-60"
        >
          {enviando && <Loader2 className="h-4 w-4 animate-spin" />}
          Salvar nova senha
        </button>
      </form>
    </AppShell>
  );
}
