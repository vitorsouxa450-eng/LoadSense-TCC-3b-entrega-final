import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Alert, Operation, Preferences, Profile, ReportDefinition, SensorsState, Weighing } from "@/data/types";
import { LIMITE_LEGAL_KG, ROTAS, seedDatabase } from "@/data/seeder";
import { isActive, pesoRealKg } from "@/lib/analytics";
import { apiDemo, snapshotDemo } from "@shared/lib/demo";
import type { ResolucaoAlerta } from "@shared/lib/alertas";
import { localStore } from "@/lib/storage";
import { uid } from "@/lib/utils";
import {
  api,
  detectarServidor,
  ehDesafioDoisFatores,
  ErroApi,
  guardarSessao,
  sessaoAtual,
  sessaoSalva,
  type SessaoApi,
} from "@shared/lib/api";
import {
  alertaParaApp,
  detalheParaApp,
  operacaoParaApp,
  perfilDaSessao,
  preferenciasDaApi,
  preferenciasParaApi,
  rotasParaApp,
  sensoresDoHardware,
  type MedicaoServidor,
  veiculosParaFormulario,
} from "@/lib/backend";

const STORAGE_KEY = "loadsense-state-v3";

const FATOR_DEMO = 60;

interface PersistedState {
  operations: Operation[];
  alerts: Alert[];
  preferences: Preferences;
  profile: Profile;
  reports: ReportDefinition[];
}

interface NovaOperacaoInput {
  placa: string;
  motorista: string;
  tipoCarga: string;
  rotaIndex: number;
  pesoCargaKg: number;
  taraKg?: number;
  rfid?: string;
}

export type ModoDados = "demo" | "servidor";

export interface DadosCadastro {
  nomeCompleto: string;
  email: string;
  senha: string;
  nomeEmpresa: string;
  cnpj?: string;
  telefone?: string;
  aceitouTermos: true;
}

function mensagemDeErro(erro: unknown): string {
  if (erro instanceof ErroApi) return erro.status === 401 ? "E-mail ou senha inválidos." : erro.message;
  return "Não foi possível falar com o servidor. Verifique se a API está em execução.";
}

export interface OpcaoServidor {
  id: number;
  placa: string;
  frota: string | null;
  taraKg: number;
  limiteKg: number;
  capacidadeKg: number;
  rfid: string | null;
}

export interface RotaServidor {
  id: number;
  codigo: string;
  origem: string;
  destino: string;
  km: number;
  waypoints?: { sequence_number: number; latitude: number; longitude: number }[];
}

export const EXIGE_SERVIDOR = import.meta.env.VITE_EXIGE_SERVIDOR === "1";
function medicaoDe(saude: { disponivel: boolean; latenciaMs?: number; bancoLatenciaMs?: number }): MedicaoServidor {
  return {
    servidorMs: saude.disponivel ? (saude.latenciaMs ?? 0) : undefined,
    bancoMs: saude.disponivel ? saude.bancoLatenciaMs : undefined,
  };
}

const TENTATIVAS_SERVIDOR = 10;
const ESPERA_ENTRE_TENTATIVAS_MS = 1500;

interface StoreValue {
  modo: ModoDados;
  conectando: boolean;
  servidorOnline: boolean;
  servidorIndisponivel: boolean;
  latenciaApi: number;
  sessao: SessaoApi | null;
  erroLogin: string | null;
  veiculosServidor: OpcaoServidor[];
  rotasServidor: RotaServidor[];
  motoristasServidor: { id: number; nome: string }[];
  entrar: (email: string, senha: string) => Promise<boolean>;
  desafioDoisFatores: string | null;
  codigoTesteDoisFatores: string | null;
  lotesAlertas: { id: number; alertas: Alert[] } | null;
  confirmarCodigoDoisFatores: (codigo: string) => Promise<boolean>;
  cancelarDoisFatores: () => void;
  precisaTrocarSenha: boolean;
  alterarSenha: (senhaAtual: string, novaSenha: string) => Promise<string | null>;
  precisaLogin: boolean;
  cadastrar: (dados: DadosCadastro) => Promise<boolean>;
  sair: () => Promise<void>;
  recarregar: () => Promise<void>;
  operations: Operation[];
  alerts: Alert[];
  reports: ReportDefinition[];
  preferences: Preferences;
  profile: Profile;
  sensors: SensorsState;
  ultimaSync: number;
  ativas: Operation[];
  concluidas: Operation[];
  atualizarPreferencias: (patch: Partial<Preferences>) => void;
  atualizarPerfil: (patch: Partial<Profile>) => void;
  resolverAlerta: (id: string, resolucao?: ResolucaoAlerta) => void;
  reabrirAlerta: (id: string) => void;
  resolverTodosAlertas: () => void;
  criarOperacao: (input: NovaOperacaoInput) => Promise<Operation>;
  registrarPesagem: (operacaoId: string, pesoKg: number, local?: string) => Promise<Weighing>;
  registrarPesagemCompleta: (
    operacaoId: string,
    dados: { vazioKg: number; carregadoKg: number; motivo: string },
  ) => Promise<void>;
  iniciarTransporte: (operacaoId: string) => Promise<void>;
  ativarRastreio: (operacaoId: string, codigoRfid: string) => Promise<void>;
  registrarChegada: (operacaoId: string) => Promise<void>;
  avancarOperacao: (operacaoId: string, km: number) => Promise<string | null>;
  sincronizarAgora: () => void;
  recarregarDados: () => Promise<void>;
  resetarDemo: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

function posicaoNaRota(
  waypoints: { latitude: number; longitude: number }[],
  progressoPct: number,
  origem: string,
  destino: string,
): { latitude: number; longitude: number } {
  const pontos = waypoints.length >= 2 ? waypoints : [];
  if (!pontos.length) {
    const fracao = Math.min(1, Math.max(0, progressoPct / 100));
    return { latitude: -23.58 + (-23.96 + 23.58) * fracao, longitude: -46.82 + (-46.33 + 46.82) * fracao };
  }
  const fatia = 100 / (pontos.length - 1);
  const indice = Math.min(pontos.length - 2, Math.floor(progressoPct / fatia));
  const base = pontos[indice];
  const proximo = pontos[indice + 1];
  const fracao = (progressoPct - indice * fatia) / fatia;
  void origem;
  void destino;
  return {
    latitude: Number((base.latitude + (proximo.latitude - base.latitude) * fracao).toFixed(6)),
    longitude: Number((base.longitude + (proximo.longitude - base.longitude) * fracao).toFixed(6)),
  };
}

const PERFIL_PADRAO: Profile = {
  nome: "Administrador LoadSense",
  email: "renato@loadsense.local",
  telefone: "(11) 98765-4321",
  empresa: "LoadSense Transportes",
  cargo: "Administrador",
  plano: "Enterprise",
  permissoes: "Administrador",
  cnpj: "48.221.905/0001-14",
};

const PREFERENCIAS_PADRAO: Preferences = {
  notificacoes: true,
  sons: true,
  apenasCriticos: false,
  autoSync: true,
  biometria: false,
  temaEscuro: true,
  idioma: "PT-BR",
};

function carregarEstado(): PersistedState & { sensors: SensorsState } {
  const seed = seedDatabase();
  if (EXIGE_SERVIDOR) {
    return {
      operations: [],
      alerts: [],
      preferences: PREFERENCIAS_PADRAO,
      profile: PERFIL_PADRAO,
      reports: seed.reports,
      sensors: seed.sensors,
    };
  }
  const demo = snapshotDemo();
  const base = {
    operations: demo.operacoes.map(operacaoParaApp),
    alerts: demo.alertas.map(alertaParaApp),
    preferences: PREFERENCIAS_PADRAO,
    profile: PERFIL_PADRAO,
    reports: seed.reports,
    sensors: seed.sensors,
  };

  const salvo = localStore.getJSON<PersistedState | null>(STORAGE_KEY, null);
  if (!salvo?.operations?.length) return base;

  return {
    ...base,
    ...salvo,
    preferences: { ...PREFERENCIAS_PADRAO, ...salvo.preferences },
    profile: { ...PERFIL_PADRAO, ...salvo.profile },
    reports: salvo.reports?.length ? salvo.reports : seed.reports,
  };
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const inicial = useMemo(carregarEstado, []);
  const [operations, setOperations] = useState<Operation[]>(inicial.operations);
  const [alerts, setAlerts] = useState<Alert[]>(inicial.alerts);
  const [preferences, setPreferences] = useState<Preferences>(inicial.preferences);
  const [profile, setProfile] = useState<Profile>(inicial.profile);
  const [reports] = useState<ReportDefinition[]>(inicial.reports);
  const [sensors, setSensors] = useState<SensorsState>(inicial.sensors);
  const [ultimaSync, setUltimaSync] = useState<number>(inicial.sensors.ultimaSync);
  const proximoId = useRef(2000);

  const [modo, setModo] = useState<ModoDados>("demo");
  const [conectando, setConectando] = useState(true);
  const [servidorOnline, setServidorOnline] = useState(false);
  const [servidorIndisponivel, setServidorIndisponivel] = useState(false);
  const [latenciaApi, setLatenciaApi] = useState(0);
  const [sessao, setSessao] = useState<SessaoApi | null>(sessaoSalva);
  const [erroLogin, setErroLogin] = useState<string | null>(null);
  const [desafioDoisFatores, setDesafioDoisFatores] = useState<string | null>(null);
  const [codigoTesteDoisFatores, setCodigoTesteDoisFatores] = useState<string | null>(null);
  const [lotesAlertas, setLotesAlertas] = useState<{ id: number; alertas: Alert[] } | null>(null);
  const alertasConhecidos = useRef<Set<string> | null>(null);
  const transportesIniciados = useRef<Set<string>>(new Set());

  const processarAlertas = useCallback((lista: Alert[]) => {
    const conhecidos = alertasConhecidos.current;
    alertasConhecidos.current = new Set(lista.map((a) => a.id));
    if (!conhecidos) return;
    const novos = lista.filter((a) => a.status === "ativo" && !conhecidos.has(a.id));
    if (novos.length > 0) setLotesAlertas((anterior) => ({ id: (anterior?.id ?? 0) + 1, alertas: novos }));
  }, []);
  const [veiculosServidor, setVeiculosServidor] = useState<OpcaoServidor[]>([]);
  const [rotasServidor, setRotasServidor] = useState<RotaServidor[]>([]);
  const [motoristasServidor, setMotoristasServidor] = useState<{ id: number; nome: string }[]>([]);

  const carregarDoServidor = useCallback(async () => {
    const [lista, listaAlertas, dispositivos, veiculos, rotas, assinatura, painel, motoristas, saude] =
      await Promise.all([
        api.operacoes(),
        api.alertas(),
        api.dispositivos(),
        api.veiculos(),
        api.rotas(),
        api.assinatura(),
        api.painel(30),
        api.motoristas(),
        detectarServidor(),
      ]);

    const operacoes = lista.operacoes.map(operacaoParaApp);
    setOperations(operacoes);
    const alertasApp = listaAlertas.alertas.map(alertaParaApp);
    setAlerts(alertasApp);
    processarAlertas(alertasApp);
    setVeiculosServidor(veiculosParaFormulario(veiculos.veiculos));
    setRotasServidor(rotasParaApp(rotas.rotas));
    setMotoristasServidor(motoristas.motoristas.map((m) => ({ id: m.id, nome: m.full_name })));
    setSensors(sensoresDoHardware(dispositivos.dispositivos, medicaoDe(saude)));
    setLatenciaApi((atual) => (atual > 0 ? atual : Math.max(1, Math.round((painel?.kpis?.operacoes ?? 0) / 40 + 12))));
    setUltimaSync(Date.now());

    const atual = sessaoAtual();
    if (atual) {
      const preferenciasApi = preferenciasDaApi(atual.preferencias);
      if (preferenciasApi) setPreferences(preferenciasApi);
      setProfile(perfilDaSessao(atual.usuario, atual.empresa, assinatura?.atual ?? null));
    }
    return operacoes;
  }, []);

  const carregarOperacao = useCallback(async (operacaoId: string) => {
    const detalhe = await api.operacao(operacaoId);
    const operacao = detalheParaApp(detalhe);
    setOperations((prev) => prev.map((op) => (op.id === operacao.id ? operacao : op)));
    return operacao;
  }, []);

  useEffect(() => {
    let cancelado = false;
    (async () => {
      let saude = await detectarServidor();
      for (let t = 1; !saude.disponivel && t < TENTATIVAS_SERVIDOR; t++) {
        await new Promise((r) => setTimeout(r, ESPERA_ENTRE_TENTATIVAS_MS));
        if (cancelado) return;
        saude = await detectarServidor();
      }
      if (cancelado) return;
      setServidorIndisponivel(EXIGE_SERVIDOR && !saude.disponivel);
      setServidorOnline(saude.disponivel);
      setLatenciaApi(saude.latenciaMs ?? 0);
      if (saude.disponivel && sessaoSalva()) {
        try {
          await carregarDoServidor();
          if (!cancelado) setModo("servidor");
        } catch {
          guardarSessao(null);
          setSessao(null);
        }
      }
      if (!cancelado) setConectando(false);
    })();
    return () => {
      cancelado = true;
    };
  }, [carregarDoServidor]);

  const entrar = useCallback(
    async (email: string, senha: string) => {
      setErroLogin(null);
      setConectando(true);
      try {
        const dados = await api.entrar(email, senha);
        if (ehDesafioDoisFatores(dados)) {
          setDesafioDoisFatores(dados.desafio);
          setCodigoTesteDoisFatores(dados.codigoDemo ?? null);
          return false;
        }
        setDesafioDoisFatores(null);
        setCodigoTesteDoisFatores(null);
        alertasConhecidos.current = null;
        setSessao(dados);
        setModo("servidor");
        setServidorOnline(true);
        await carregarDoServidor();
        return true;
      } catch (erro) {
        const mensagem =
          erro instanceof ErroApi
            ? erro.status === 401
              ? "E-mail ou senha inválidos."
              : erro.message
            : "Não foi possível falar com o servidor. Verifique se a API está em execução.";
        setErroLogin(mensagem);
        return false;
      } finally {
        setConectando(false);
      }
    },
    [carregarDoServidor, modo],
  );

  const confirmarCodigoDoisFatores = useCallback(
    async (codigo: string) => {
      if (!desafioDoisFatores) return false;
      setErroLogin(null);
      setConectando(true);
      try {
        const dados = await api.concluirLoginDoisFatores(desafioDoisFatores, codigo);
        setDesafioDoisFatores(null);
        setCodigoTesteDoisFatores(null);
        alertasConhecidos.current = null;
        setSessao(dados);
        setModo("servidor");
        setServidorOnline(true);
        await carregarDoServidor();
        return true;
      } catch (erro) {
        setErroLogin(
          erro instanceof ErroApi && erro.status === 401
            ? "Código inválido ou expirado. Confira o e-mail mais recente."
            : mensagemDeErro(erro),
        );
        return false;
      } finally {
        setConectando(false);
      }
    },
    [carregarDoServidor, desafioDoisFatores],
  );

  const cancelarDoisFatores = useCallback(() => {
    setDesafioDoisFatores(null);
    setErroLogin(null);
  }, []);

  const alterarSenha = useCallback(async (senhaAtual: string, novaSenha: string): Promise<string | null> => {
    try {
      await api.alterarSenha(senhaAtual, novaSenha);
      setSessao((atual) => (atual ? { ...atual, usuario: { ...atual.usuario, trocarSenha: false } } : atual));
      return null;
    } catch (erro) {
      return erro instanceof ErroApi ? erro.message : "Não foi possível trocar a senha.";
    }
  }, []);

  const cadastrar = useCallback(
    async (dados: DadosCadastro) => {
      setErroLogin(null);
      setConectando(true);
      try {
        const resposta = await api.cadastrar(dados);
        setSessao(resposta);
        setModo("servidor");
        setServidorOnline(true);
        await carregarDoServidor();
        return true;
      } catch (erro) {
        setErroLogin(mensagemDeErro(erro));
        return false;
      } finally {
        setConectando(false);
      }
    },
    [carregarDoServidor],
  );

  const resetarDemoInterno = useCallback(() => {
    localStore.remove(STORAGE_KEY);
    const seed = seedDatabase();
    const demo = snapshotDemo();
    setOperations(demo.operacoes.map(operacaoParaApp));
    setAlerts(demo.alertas.map(alertaParaApp));
    setSensors(seed.sensors);
    setPreferences(PREFERENCIAS_PADRAO);
    setProfile(PERFIL_PADRAO);
    setUltimaSync(Date.now());
  }, [processarAlertas]);

  const sair = useCallback(async () => {
    await api.sair().catch(() => undefined);
    alertasConhecidos.current = null;
    setSessao(null);
    setModo("demo");
    resetarDemoInterno();
  }, []);

  const opsRef = useRef(operations);
  useEffect(() => {
    opsRef.current = operations;
  }, [operations]);

  const ultimaGravacao = useRef(0);
  const gravacaoAgendada = useRef<number | null>(null);
  useEffect(() => {
    if (modo === "servidor") {
      localStore.remove(STORAGE_KEY);
      return;
    }
    const salvar = () => localStore.setJSON(STORAGE_KEY, { operations, alerts, preferences, profile, reports });

    const decorrido = Date.now() - ultimaGravacao.current;
    if (decorrido >= 20_000) {
      ultimaGravacao.current = Date.now();
      salvar();
      return;
    }

    if (gravacaoAgendada.current) window.clearTimeout(gravacaoAgendada.current);
    gravacaoAgendada.current = window.setTimeout(() => {
      ultimaGravacao.current = Date.now();
      salvar();
    }, 20_000 - decorrido);
  }, [modo, operations, alerts, preferences, profile, reports]);

  useEffect(() => {
    if (modo !== "servidor" || !preferences.autoSync) return;
    const timer = window.setInterval(async () => {
      try {
        const [lista, listaAlertas, dispositivos, saude] = await Promise.all([
          api.operacoes(),
          api.alertas(),
          api.dispositivos(),
          detectarServidor(),
        ]);
        setSensors(sensoresDoHardware(dispositivos.dispositivos, medicaoDe(saude)));
        setOperations(
          lista.operacoes.map(operacaoParaApp).map((op) => {
            const anterior = opsRef.current.find((a) => a.id === op.id);
            return anterior && anterior.pesagens.length > op.pesagens.length
              ? { ...op, pesagens: anterior.pesagens }
              : op;
          }),
        );
        const alertasApp = listaAlertas.alertas.map(alertaParaApp);
        setAlerts(alertasApp);
        processarAlertas(alertasApp);
        setUltimaSync(Date.now());
      } catch {}
    }, 30_000);
    return () => window.clearInterval(timer);
  }, [modo, preferences.autoSync, processarAlertas]);

  useEffect(() => {
    if (modo === "servidor" || !preferences.autoSync) return;

    const timer = window.setInterval(() => {
      setOperations((prev) =>
        prev.map((op) => {
          if (op.status !== "Em trânsito") return op;

          const velocidadeKmH = 62 + (op.distanciaKm % 17);
          const passoKm = (velocidadeKmH * FATOR_DEMO) / 3600;
          const kmPercorrido = Math.min(op.distanciaKm, op.kmPercorrido + passoKm);
          const concluida = kmPercorrido >= op.distanciaKm;

          return {
            ...op,
            kmPercorrido,
            status: concluida ? "Concluída" : op.status,
            finalizadaEm: concluida ? new Date().toISOString() : op.finalizadaEm,
          };
        }),
      );

      setSensors((prev) => ({
        ...prev,
        rfid: { ...prev.rfid, ultimaLeitura: Date.now() - Math.round(1200 + Math.random() * 4000) },
        servidor: { ...prev.servidor, latenciaMs: Math.round(70 + Math.random() * 30) },
        banco: { ...prev.banco, latenciaMs: Math.round(18 + Math.random() * 12) },
        gprs: {
          ...prev.gprs,
          sinalPct: Math.min(99, Math.max(70, Math.round((prev.gprs.sinalPct ?? 90) + (Math.random() * 6 - 3)))),
        },
      }));
      setUltimaSync(Date.now());
    }, 5000);

    return () => window.clearInterval(timer);
  }, [modo, preferences.autoSync]);

  const atualizarPreferencias = useCallback(
    (patch: Partial<Preferences>) => {
      setPreferences((prev) => {
        const proximo = { ...prev, ...patch };
        if (modo === "servidor") api.preferencias(preferenciasParaApi(proximo)).catch(() => undefined);
        return proximo;
      });
    },
    [modo],
  );

  const atualizarPerfil = useCallback(
    (patch: Partial<Profile>) => {
      setProfile((prev) => ({ ...prev, ...patch }));
    },
    [modo],
  );

  const resolverAlerta = useCallback(
    (id: string, resolucao?: ResolucaoAlerta) => {
      const idServidor = Number(id);
      const ehServidor = modo === "servidor" && Number.isInteger(idServidor) && idServidor > 0;
      if (ehServidor && !resolucao) return;
      const agora = new Date().toISOString();
      setAlerts((prev) =>
        prev.map((alert) =>
          alert.id === id
            ? {
                ...alert,
                status: "resolvido",
                resolvidoEm: agora,
                motivoResolucao: resolucao?.motivo,
                extra: resolucao?.acao ?? alert.extra,
              }
            : alert,
        ),
      );
      if (ehServidor && resolucao) api.resolverAlerta(idServidor, resolucao).catch(() => undefined);
    },
    [modo],
  );

  const reabrirAlerta = useCallback(
    (id: string) => {
      setAlerts((prev) => prev.map((alert) => (alert.id === id ? { ...alert, status: "ativo" } : alert)));
      const idServidor = Number(id);
      if (modo === "servidor" && Number.isInteger(idServidor) && idServidor > 0)
        api.reabrirAlerta(idServidor).catch(() => undefined);
    },
    [modo],
  );

  const resolverTodosAlertas = useCallback(() => {
    const agora = new Date().toISOString();
    setAlerts((prev) =>
      prev.map((alert) => (alert.status === "ativo" ? { ...alert, status: "resolvido", resolvidoEm: agora } : alert)),
    );
    if (modo === "servidor") api.resolverTodosAlertas().catch(() => undefined);
  }, [modo]);

  const criarOperacao = useCallback(
    async (input: NovaOperacaoInput): Promise<Operation> => {
      if (modo === "servidor") {
        const rotaServidor = rotasServidor[input.rotaIndex % Math.max(rotasServidor.length, 1)];
        const criada = await api.criarOperacao({
          placa: input.placa,
          rotaCodigo: rotaServidor?.codigo,
          metodo: "GROSS_TARE",
          tipoMovimento: "EXIT",
          pesoDeclaradoKg: input.pesoCargaKg,
          motorista: input.motorista,
          rfid: input.rfid,
          observacoes: "Operação aberta pelo aplicativo",
        });
        const operacao = operacaoParaApp(criada);
        setOperations((prev) => [operacao, ...prev.filter((op) => op.id !== operacao.id)]);
        api
          .alertas()
          .then((r) => setAlerts(r.alertas.map(alertaParaApp)))
          .catch(() => undefined);
        return operacao;
      }

      const rota = ROTAS[input.rotaIndex % ROTAS.length];
      apiDemo
        .criarOperacao({
          placa: input.placa,
          motorista: input.motorista,
          rfid: input.rfid,
          pesoDeclaradoKg: input.pesoCargaKg,
          observacoes: "Operação aberta pelo aplicativo",
        })
        .catch(() => undefined);
      const id = `OP-${proximoId.current++}`;
      const agora = Date.now();
      const taraKg = input.taraKg ?? 8_620;
      const duracaoH = rota.km / 66 + 1.5;

      const operacao: Operation = {
        id,
        rfid: input.rfid ?? `RF-${Math.random().toString(16).slice(2, 8).toUpperCase()}`,
        placa: input.placa.toUpperCase(),
        motorista: input.motorista,
        tipoCarga: input.tipoCarga,
        origem: rota.origem,
        destino: rota.destino,
        distanciaKm: rota.km,
        kmPercorrido: 0,
        saida: new Date(agora).toISOString(),
        previsaoChegada: new Date(agora + Math.round(duracaoH * 3600_000)).toISOString(),
        limiteKg: LIMITE_LEGAL_KG,
        taraKg,
        pesoCargaKg: input.pesoCargaKg,
        desvioKg: 0,
        temperaturaC: Number((20 + Math.random() * 8).toFixed(1)),
        status: "Carregando",
        pesagens: [
          {
            id: `${id}-p0`,
            tipo: "vazio",
            pesoKg: taraKg,
            desvioKg: 0,
            local: "Pátio de origem",
            registradoEm: new Date(agora).toISOString(),
            rfid: input.rfid ?? `RF-${id}`,
          },
          {
            id: `${id}-p1`,
            tipo: "carregado",
            pesoKg: taraKg + input.pesoCargaKg,
            desvioKg: 0,
            local: "Balança de origem",
            registradoEm: new Date(agora + 8 * 60_000).toISOString(),
            rfid: input.rfid ?? `RF-${id}`,
          },
        ],
      };

      setOperations((prev) => [operacao, ...prev]);

      const alertas: Alert[] = [];
      if (taraKg + input.pesoCargaKg > LIMITE_LEGAL_KG) {
        alertas.push({
          id: uid("AL"),
          operacaoId: id,
          placa: operacao.placa,
          motorista: operacao.motorista,
          tipo: "Sobrecarga detectada",
          nivel: "critico",
          status: "ativo",
          descricao:
            "Peso total acima do limite legal já na pesagem de origem. A carga deve ser ajustada antes da liberação da viagem.",
          criadoEm: new Date().toISOString(),
          pesoEsperadoKg: taraKg,
          pesoRealKg: taraKg + input.pesoCargaKg,
          diferencaKg: taraKg + input.pesoCargaKg - LIMITE_LEGAL_KG,
        });
      }
      if (alertas.length) setAlerts((prev) => [...alertas, ...prev]);

      return operacao;
    },
    [modo, rotasServidor],
  );

  const registrarPesagem = useCallback(
    async (operacaoId: string, pesoKg: number, local = "Balança intermediária"): Promise<Weighing> => {
      const aferido = Math.round(pesoKg);

      if (modo === "servidor") {
        const operacao = opsRef.current.find((item) => item.id === operacaoId);
        const jaTemVazio = operacao?.pesagens.some((p) => p.tipo === "vazio") ?? false;
        const estagio = jaTemVazio ? "LOADED_TRUCK" : "EMPTY_TRUCK";
        const resposta = await api.registrarLeitura(Number(operacaoId), { estagio, pesoKg: aferido, origem: "DEVICE" });
        const atualizada = operacaoParaApp(resposta.operacao);
        setOperations((prev) =>
          prev.map((op) => (op.id === atualizada.id ? { ...atualizada, pesagens: op.pesagens } : op)),
        );
        await carregarOperacao(operacaoId).catch(() => undefined);
        const leitura = resposta.leitura;
        return {
          id: String(leitura.id),
          tipo: leitura.estagio === "EMPTY_TRUCK" ? "vazio" : "carregado",
          pesoKg: leitura.pesoKg,
          desvioKg: atualizada.desvioKg,
          local: `${local}${leitura.origem === "MANUAL" ? " · manual" : ""}`,
          registradoEm: leitura.aceitoEm ?? leitura.medidoEm,
          rfid: atualizada.rfid,
        };
      }

      const agoraIso = new Date().toISOString();
      const operacao = opsRef.current.find((item) => item.id === operacaoId);
      const esperado = operacao ? operacao.taraKg + operacao.pesoCargaKg : aferido;
      const desvioKg = aferido - esperado;

      const pesagem: Weighing = {
        id: uid("PG"),
        tipo: "intermediaria",
        pesoKg: aferido,
        desvioKg,
        local,
        registradoEm: agoraIso,
        rfid: operacao?.rfid ?? `RF-${operacaoId}`,
      };

      setOperations((prev) =>
        prev.map((op) =>
          op.id === operacaoId
            ? {
                ...op,
                desvioKg,
                status: op.status === "Carregando" ? "Em trânsito" : op.status,
                pesagens: [...op.pesagens, pesagem],
              }
            : op,
        ),
      );

      if (operacao && Math.abs(desvioKg) > 300) {
        const sobrecarga = desvioKg > 0;
        const novo: Alert = {
          id: uid("AL"),
          operacaoId: operacao.id,
          placa: operacao.placa,
          motorista: operacao.motorista,
          tipo: sobrecarga ? "Sobrecarga detectada" : "Variação de peso",
          nivel: Math.abs(desvioKg) > 1000 ? "critico" : "atencao",
          status: "ativo",
          descricao: sobrecarga
            ? "Divergência identificada na pesagem intermediária: peso acima do previsto. Recomenda-se nova conferência em balança certificada antes de prosseguir."
            : "Divergência identificada na pesagem intermediária: peso abaixo do previsto. Verificar possível perda de carga durante o trajeto.",
          criadoEm: agoraIso,
          pesoEsperadoKg: esperado,
          pesoRealKg: aferido,
          diferencaKg: desvioKg,
          extra: `Diferença: ${desvioKg > 0 ? "+" : ""}${desvioKg.toLocaleString("pt-BR")} kg · ${local}`,
        };
        setAlerts((antes) => [novo, ...antes]);
      }

      return pesagem;
    },
    [modo, carregarOperacao],
  );

  const registrarPesagemCompleta = useCallback(
    async (operacaoId: string, dados: { vazioKg: number; carregadoKg: number; motivo: string }): Promise<void> => {
      const vazio = Math.round(dados.vazioKg);
      const carregado = Math.round(dados.carregadoKg);
      if (modo === "servidor") {
        const motivoManual = dados.motivo.trim();
        const id = Number(operacaoId);
        await api.registrarLeitura(id, { estagio: "EMPTY_TRUCK", pesoKg: vazio, origem: "MANUAL", motivoManual });
        await api.registrarLeitura(id, { estagio: "LOADED_TRUCK", pesoKg: carregado, origem: "MANUAL", motivoManual });
        const fechada = await api.finalizarOperacao(id);
        const atualizada = operacaoParaApp(fechada.operacao);
        setOperations((prev) =>
          prev.map((op) => (op.id === atualizada.id ? { ...atualizada, pesagens: op.pesagens } : op)),
        );
        await carregarOperacao(operacaoId).catch(() => undefined);
        return;
      }
      const agoraIso = new Date().toISOString();
      setOperations((prev) =>
        prev.map((op) => {
          if (op.id !== operacaoId) return op;
          const local = "Pesagem manual (app)";
          const novas: Weighing[] = [
            { id: uid("PG"), tipo: "vazio", pesoKg: vazio, desvioKg: 0, local, registradoEm: agoraIso, rfid: op.rfid },
            {
              id: uid("PG"),
              tipo: "carregado",
              pesoKg: carregado,
              desvioKg: 0,
              local,
              registradoEm: agoraIso,
              rfid: op.rfid,
            },
          ];
          return {
            ...op,
            taraKg: vazio,
            pesoCargaKg: carregado - vazio,
            desvioKg: 0,
            pesagens: [...op.pesagens, ...novas],
            status: op.status === "Carregando" ? "Em trânsito" : op.status,
          };
        }),
      );
    },
    [modo, carregarOperacao],
  );

  const iniciarTransporte = useCallback(
    async (operacaoId: string): Promise<void> => {
      if (modo === "servidor") {
        await api.iniciarTransporte(Number(operacaoId));
        transportesIniciados.current.add(operacaoId);
        await carregarOperacao(operacaoId);
        return;
      }
      setOperations((prev) => prev.map((op) => (op.id === operacaoId ? { ...op, status: "Em trânsito" } : op)));
    },
    [modo, carregarOperacao],
  );

  const ativarRastreio = useCallback(
    async (operacaoId: string, codigoRfid: string): Promise<void> => {
      if (modo === "servidor") {
        await api.ativarRastreio(Number(operacaoId), codigoRfid);
        await carregarOperacao(operacaoId);
        return;
      }
      throw new Error("O rastreio só pode ser ativado com o servidor conectado.");
    },
    [modo, carregarOperacao],
  );

  const registrarChegada = useCallback(
    async (operacaoId: string): Promise<void> => {
      if (modo === "servidor") {
        await api.chegadaTransporte(Number(operacaoId));
        await carregarOperacao(operacaoId);
        const lista = await api.alertas().catch(() => null);
        if (lista) setAlerts(lista.alertas.map(alertaParaApp));
        return;
      }
      setOperations((prev) =>
        prev.map((op) =>
          op.id === operacaoId
            ? { ...op, status: "Concluída", kmPercorrido: op.distanciaKm, finalizadaEm: new Date().toISOString() }
            : op,
        ),
      );
    },
    [modo, carregarOperacao],
  );

  const avancarOperacao = useCallback(
    async (operacaoId: string, km: number): Promise<string | null> => {
      if (modo === "servidor") {
        const operacao = opsRef.current.find((op) => op.id === operacaoId);
        if (!operacao || operacao.distanciaKm <= 0) return null;

        if (!transportesIniciados.current.has(operacaoId)) {
          try {
            await api.iniciarTransporte(Number(operacaoId));
            transportesIniciados.current.add(operacaoId);
          } catch (erro) {
            return erro instanceof ErroApi ? erro.message : "Não foi possível iniciar o transporte.";
          }
        }

        const novoKm = Math.min(operacao.distanciaKm, operacao.kmPercorrido + km);
        const progresso = (novoKm / operacao.distanciaKm) * 100;
        const { waypoints } = await api
          .rastreioDaOperacao(Number(operacaoId))
          .catch(() => ({ waypoints: [] as { latitude: number; longitude: number }[] }));
        const posicao = posicaoNaRota(waypoints, progresso, operacao.origem, operacao.destino);
        const restanteHoras = ((operacao.distanciaKm - novoKm) / 62) * 3600;
        try {
          await api.enviarRastreio(Number(operacaoId), {
            latitude: posicao.latitude,
            longitude: posicao.longitude,
            velocidadeKmh: progresso >= 100 ? 0 : 62,
            progressoPct: Number(progresso.toFixed(2)),
            eta: new Date(Date.now() + restanteHoras * 1000).toISOString(),
          });
          await carregarOperacao(operacaoId);
          const lista = await api.alertas();
          setAlerts(lista.alertas.map(alertaParaApp));
        } catch (erro) {
          return erro instanceof ErroApi ? erro.message : "Não foi possível enviar o rastreio. Tente de novo.";
        }
        return null;
      }

      setOperations((prev) =>
        prev.map((op) => {
          if (op.id !== operacaoId) return op;
          const kmPercorrido = Math.min(op.distanciaKm, op.kmPercorrido + km);
          const concluida = kmPercorrido >= op.distanciaKm;
          return {
            ...op,
            kmPercorrido,
            status: concluida ? "Concluída" : "Em trânsito",
            finalizadaEm: concluida ? new Date().toISOString() : undefined,
          };
        }),
      );
      return null;
    },
    [modo, carregarOperacao],
  );

  const sincronizarAgora = useCallback(() => {
    if (modo === "servidor") {
      void carregarDoServidor().catch(() => undefined);
      return;
    }
    setSensors((prev) => ({
      ...prev,
      ultimaSync: Date.now(),
      rfid: { ...prev.rfid, ultimaLeitura: Date.now() },
    }));
    setUltimaSync(Date.now());
  }, [modo, carregarDoServidor]);

  const resetarDemo = useCallback(() => resetarDemoInterno(), [resetarDemoInterno]);
  const recarregarDados = useCallback(async () => {
    if (modo === "servidor") await carregarDoServidor();
  }, [modo, carregarDoServidor]);

  const precisaLogin = servidorOnline && !conectando && !sessao;
  const precisaTrocarSenha = Boolean(sessao?.usuario.trocarSenha);
  const value = useMemo<StoreValue>(
    () => ({
      modo,
      conectando,
      servidorOnline,
      servidorIndisponivel,
      latenciaApi,
      sessao,
      erroLogin,
      veiculosServidor,
      rotasServidor,
      motoristasServidor,
      entrar,
      desafioDoisFatores,
      codigoTesteDoisFatores,
      lotesAlertas,
      confirmarCodigoDoisFatores,
      cancelarDoisFatores,
      precisaTrocarSenha,
      alterarSenha,
      precisaLogin,
      cadastrar,
      sair,
      recarregar: async () => {
        if (modo === "servidor") await carregarDoServidor();
      },
      operations,
      alerts,
      reports,
      preferences,
      profile,
      sensors,
      ultimaSync,
      ativas: operations.filter(isActive),
      concluidas: operations.filter((op) => op.status === "Concluída"),
      atualizarPreferencias,
      atualizarPerfil,
      resolverAlerta,
      reabrirAlerta,
      resolverTodosAlertas,
      criarOperacao,
      registrarPesagem,
      registrarPesagemCompleta,
      iniciarTransporte,
      ativarRastreio,
      registrarChegada,
      avancarOperacao,
      sincronizarAgora,
      recarregarDados,
      resetarDemo,
    }),
    [
      modo,
      conectando,
      servidorOnline,
      servidorIndisponivel,
      latenciaApi,
      sessao,
      erroLogin,
      veiculosServidor,
      rotasServidor,
      motoristasServidor,
      entrar,
      desafioDoisFatores,
      codigoTesteDoisFatores,
      lotesAlertas,
      confirmarCodigoDoisFatores,
      cancelarDoisFatores,
      precisaTrocarSenha,
      alterarSenha,
      precisaLogin,
      cadastrar,
      sair,
      carregarDoServidor,
      operations,
      alerts,
      reports,
      preferences,
      profile,
      sensors,
      ultimaSync,
      atualizarPreferencias,
      atualizarPerfil,
      resolverAlerta,
      reabrirAlerta,
      resolverTodosAlertas,
      criarOperacao,
      registrarPesagem,
      registrarPesagemCompleta,
      iniciarTransporte,
      ativarRastreio,
      registrarChegada,
      avancarOperacao,
      sincronizarAgora,
      recarregarDados,
      resetarDemo,
    ],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useStore precisa estar dentro de <StoreProvider>.");
  return context;
}

export function useLiveClock(intervalMs = 1000) {
  const [agora, setAgora] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setAgora(Date.now()), intervalMs);
    return () => window.clearInterval(timer);
  }, [intervalMs]);
  return agora;
}

export function usePesoTotal(op: Operation) {
  return pesoRealKg(op);
}
