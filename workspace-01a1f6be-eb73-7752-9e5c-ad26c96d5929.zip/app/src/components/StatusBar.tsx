import { BatteryFull, Signal, Wifi } from "lucide-react";

export function StatusBar() {
  return (
    <div className="flex items-center justify-between px-5 pt-2 pb-1 text-[12px] font-semibold">
      <span className="tabular">9:41</span>
      <div className="flex items-center gap-1 opacity-90">
        <Signal className="h-3 w-3" />
        <Wifi className="h-3 w-3" />
        <BatteryFull className="h-3.5 w-3.5" />
      </div>
    </div>
  );
}
