import { useState } from "react";
import {
  ACAO_MINIMA,
  MOTIVOS_RESOLUCAO,
  type CodigoMotivo,
  type ResolucaoAlerta,
  validarResolucao,
} from "@shared/lib/alertas";
import { cn } from "@/lib/utils";

interface Props {
  ocupado: boolean;
  erro?: string | null;
  onConfirmar: (resolucao: ResolucaoAlerta) => void;
  onCancelar: () => void;
}

const campo =
  "w-full rounded-lg border border-border/60 bg-background px-2.5 py-2 text-[12px] outline-none focus:border-primary";

export function FormResolucaoAlerta({ ocupado, erro, onConfirmar, onCancelar }: Props) {
  const [motivo, setMotivo] = useState<CodigoMotivo | "">("");
  const [acao, setAcao] = useState("");
  const [tentou, setTentou] = useState(false);
  const descricaoMotivo = MOTIVOS_RESOLUCAO.find((m) => m.codigo === motivo)?.descricao;
  const problema = validarResolucao({ motivo, acao });

  function confirmar() {
    setTentou(true);
    if (problema) return;
    onConfirmar({ motivo: motivo as CodigoMotivo, acao: acao.trim() });
  }

  return (
    <div className="mt-3 space-y-2.5 rounded-xl border border-border/60 bg-card-elev p-3">
      <div className="text-[12px] font-semibold">Resolver alerta</div>
      <label className="block">
        <span className="mb-1 block text-[11px] font-semibold text-muted-foreground">Motivo *</span>
        <select
          value={motivo}
          onChange={(e) => setMotivo(e.target.value as CodigoMotivo | "")}
          aria-label="Motivo da resolução"
          className={campo}
        >
          <option value="">Escolha um motivo</option>
          {MOTIVOS_RESOLUCAO.map((m) => (
            <option key={m.codigo} value={m.codigo}>
              {m.rotulo}
            </option>
          ))}
        </select>
        {descricaoMotivo && <span className="mt-1 block text-[10px] text-muted-foreground">{descricaoMotivo}</span>}
      </label>
      <label className="block">
        <span className="mb-1 block text-[11px] font-semibold text-muted-foreground">
          Como foi resolvido * (mínimo {ACAO_MINIMA} caracteres)
        </span>
        <textarea
          value={acao}
          onChange={(e) => setAcao(e.target.value)}
          rows={3}
          maxLength={2000}
          placeholder="Ex.: conferido com o motorista, carga redistribuída e nova pesagem registrada."
          aria-label="Como foi resolvido"
          className={campo}
        />
        <span className="mt-1 block text-right text-[10px] text-muted-foreground">{acao.length}/2000</span>
      </label>
      {tentou && problema && <p className="text-[11px] text-destructive">{problema}</p>}
      {erro && <p className="text-[11px] text-destructive">{erro}</p>}
      <div className="flex justify-end gap-2">
        <button
          type="button"
          disabled={ocupado}
          onClick={onCancelar}
          className="rounded-xl border border-border/60 px-3 py-2 text-[12px] font-semibold disabled:opacity-50"
        >
          Cancelar
        </button>
        <button
          type="button"
          disabled={ocupado}
          onClick={confirmar}
          className={cn(
            "rounded-xl bg-primary px-3 py-2 text-[12px] font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-50",
          )}
        >
          {ocupado ? "Salvando…" : "Confirmar resolução"}
        </button>
      </div>
    </div>
  );
}

export function DetalheResolucao({
  motivo,
  acao,
  por,
  quando,
}: {
  motivo?: string | null;
  acao?: string | null;
  por?: string | null;
  quando?: string | null;
}) {
  if (!motivo && !acao && !por) return null;
  return (
    <dl className="mt-3 grid gap-1.5 rounded-xl bg-card-elev px-3 py-2.5 text-[11px]">
      {motivo && (
        <div>
          <dt className="inline font-semibold">Motivo: </dt>
          <dd className="inline text-muted-foreground">{motivo}</dd>
        </div>
      )}
      {acao && (
        <div>
          <dt className="inline font-semibold">Como foi resolvido: </dt>
          <dd className="inline whitespace-pre-line text-muted-foreground">{acao}</dd>
        </div>
      )}
      {por && (
        <div>
          <dt className="inline font-semibold">Resolvido por: </dt>
          <dd className="inline text-muted-foreground">
            {por}
            {quando ? ` em ${quando}` : ""}
          </dd>
        </div>
      )}
    </dl>
  );
}
