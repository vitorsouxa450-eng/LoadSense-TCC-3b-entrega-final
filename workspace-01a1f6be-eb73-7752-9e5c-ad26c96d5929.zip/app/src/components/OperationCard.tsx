import { ChevronRight, Truck } from "lucide-react";
import { Link } from "react-router-dom";
import type { Operation } from "@/data/types";
import { Ring } from "@/components/charts";
import { Pill, ProgressBar } from "@/components/ui";
import { kmRestantes, progressPct } from "@/lib/analytics";
import { cn, formatTime } from "@/lib/utils";

const TOM_STATUS: Record<Operation["status"], "primary" | "warning" | "success" | "muted"> = {
  "Em trânsito": "primary",
  Parado: "warning",
  Carregando: "muted",
  Concluída: "success",
};

export function OperationCard({ op, mostrarProgresso = true }: { op: Operation; mostrarProgresso?: boolean }) {
  const pct = progressPct(op);
  const divergente = op.desvioKg > 0;

  return (
    <Link
      to={`/operacoes/${op.id}`}
      className="block rounded-2xl border border-border/60 bg-card p-3 transition-colors hover:border-primary/50"
    >
      <div className="flex items-center gap-3">
        <div
          className={cn(
            "flex h-10 w-10 items-center justify-center rounded-xl",
            op.status === "Concluída" ? "bg-success/15 text-success" : "bg-primary/15 text-primary",
          )}
        >
          <Truck className="h-5 w-5" />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="text-[13px] font-bold">{op.placa}</span>
            <Pill tom={op.cancelada ? "destructive" : TOM_STATUS[op.status]}>
              {op.cancelada ? "Cancelada" : op.status}
            </Pill>
          </div>
          <div className="truncate text-[10px] text-muted-foreground">
            {op.origem} → {op.destino}
          </div>
          <div className="text-[10px] text-muted-foreground">
            {op.codigo ?? op.id} · {op.motorista} · {op.tipoCarga}
          </div>
        </div>

        <Ring
          value={pct}
          size={44}
          stroke={4}
          cor={op.status === "Concluída" ? "hsl(var(--success))" : "hsl(var(--primary))"}
        >
          <span className="text-[10px] font-bold tabular">{pct}%</span>
        </Ring>
      </div>

      {mostrarProgresso && (
        <div className="mt-3">
          <div className="mb-1 flex justify-between text-[10px] text-muted-foreground">
            <span>ETA {formatTime(op.previsaoChegada)}</span>
            <span>{kmRestantes(op)} km restantes</span>
          </div>
          <ProgressBar valor={pct} tom={op.status === "Concluída" ? "success" : "primary"} />
        </div>
      )}

      {divergente && (
        <div className="mt-2 flex items-center justify-between rounded-lg bg-destructive/10 px-2 py-1">
          <span className="text-[10px] font-semibold text-destructive">Divergência de peso</span>
          <span className="text-[10px] font-bold text-destructive tabular">
            +{op.desvioKg.toLocaleString("pt-BR")} kg
          </span>
        </div>
      )}
    </Link>
  );
}

export function OperationRow({ op }: { op: Operation }) {
  const pct = progressPct(op);
  return (
    <Link
      to={`/operacoes/${op.id}`}
      className="flex items-center gap-3 rounded-2xl border border-border/60 bg-card p-3"
    >
      <div className="min-w-0 flex-1">
        <div className="text-[13px] font-bold">
          {op.placa}
          <span className="ml-2 text-[10px] font-medium text-muted-foreground">{op.codigo ?? op.id}</span>
        </div>
        <div className={cn("text-[11px]", op.status === "Parado" ? "text-warning" : "text-success")}>
          {op.cancelada ? "Cancelada" : op.status}
        </div>
        <div className="truncate text-[10px] text-muted-foreground">
          {op.origem} → {op.destino}
        </div>
      </div>
      <Ring value={pct} size={44} stroke={4}>
        <span className="text-[10px] font-bold tabular">{pct}%</span>
      </Ring>
      <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
    </Link>
  );
}
