import type { ReactNode } from "react";
import { useSincronia } from "@shared/lib/sincronia";
import { useStore } from "@/store/store";
import { StatusBar } from "@/components/StatusBar";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav, type NavLabel } from "@/components/BottomNav";
import { NotificadorAlertas } from "@/components/NotificadorAlertas";
import { estiloEscala, useEscalaCelular } from "./EscalaCelular";

interface AppShellProps {
  children: ReactNode;
  activeNav?: NavLabel;
  headerSlot?: ReactNode;
  hideHeader?: boolean;
}

export function AppShell({ children, activeNav, headerSlot, hideHeader }: AppShellProps) {
  const { modo, recarregar } = useStore();
  const escala = useEscalaCelular();
  useSincronia(() => {
    void recarregar();
  }, modo === "servidor");
  return (
    <div className="flex h-screen items-stretch justify-center overflow-hidden bg-muted">
      <div style={estiloEscala(escala)} className="relative flex w-full max-w-[420px] flex-col bg-background">
        <StatusBar />
        {!hideHeader && (headerSlot ?? <AppHeader />)}
        <main className="ls-scroll min-h-0 flex-1 overflow-y-auto pb-2">{children}</main>
        <BottomNav ativoOverride={activeNav} />
        <NotificadorAlertas />
      </div>
    </div>
  );
}

export function AuthShell({ children }: { children: ReactNode }) {
  const escala = useEscalaCelular();
  return (
    <div className="flex h-screen items-stretch justify-center overflow-hidden bg-muted">
      <div style={estiloEscala(escala)} className="relative flex w-full max-w-[420px] flex-col bg-background">
        <StatusBar />
        <div className="ls-scroll flex min-h-0 flex-1 flex-col overflow-y-auto px-6 py-8">{children}</div>
      </div>
    </div>
  );
}
