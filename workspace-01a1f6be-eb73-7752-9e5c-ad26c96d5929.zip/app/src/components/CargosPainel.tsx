import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Loader2, UserCog, Users } from "lucide-react";
import { api, ErroApi } from "@shared/lib/api";

type Dados = Awaited<ReturnType<typeof api.papeis.listar>>;
type Cargo = Dados["cargos"][number];

const NOME_CARGO: Record<string, string> = {
  ADMINISTRATOR: "Administrador",
  SUPERVISOR: "Supervisor de Operações",
  OPERATOR: "Operador de Pesagem",
};

const mensagem = (erro: unknown) => (erro instanceof ErroApi ? erro.message : "Não foi possível falar com o servidor.");

export function CargosPainel() {
  const [dados, setDados] = useState<Dados | null>(null);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    api.papeis
      .listar()
      .then(setDados)
      .catch((e) => setErro(mensagem(e)));
  }, []);

  if (erro) return <p className="text-[12px] text-destructive">{erro}</p>;
  if (!dados) {
    return (
      <p className="flex items-center gap-2 text-[12px] text-muted-foreground">
        <Loader2 className="h-3 w-3 animate-spin" /> Carregando cargos…
      </p>
    );
  }

  return (
    <div className="space-y-3">
      {dados.cargos.map((cargo: Cargo) => (
        <div key={cargo.nome} className="rounded-xl border border-border/60 bg-card-elev p-3">
          <div className="flex items-center justify-between gap-2">
            <p className="text-[13px] font-semibold">{NOME_CARGO[cargo.nome] ?? cargo.nome}</p>
            <span className="text-[11px] text-muted-foreground">
              {cargo.usuarios} {cargo.usuarios === 1 ? "pessoa" : "pessoas"}
            </span>
          </div>
          {cargo.descricao && (
            <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">{cargo.descricao}</p>
          )}
          <p className="mt-1 text-[11px] text-muted-foreground">
            {cargo.permissoes.length} {cargo.permissoes.length === 1 ? "permissão" : "permissões"}
            {!cargo.editavel && " · fixo, não pode ser alterado"}
          </p>
        </div>
      ))}

      <div className="flex flex-col gap-2 pt-1">
        <Link to="/equipe" className="inline-flex items-center gap-2 text-[12px] font-medium text-primary">
          <Users className="h-3.5 w-3.5" /> Ver as pessoas de cada cargo
        </Link>
        <Link to="/permissoes-cargos" className="inline-flex items-center gap-2 text-[12px] font-medium text-primary">
          <UserCog className="h-3.5 w-3.5" /> Alterar permissões por cargo
        </Link>
      </div>
    </div>
  );
}
