import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { api, ErroApi } from "@shared/lib/api";
import { useToast } from "@/components/Toast";

type Usuario = Awaited<ReturnType<typeof api.usuarios.listar>>["usuarios"][number];
type Papel = "SUPERVISOR" | "OPERATOR" | "ADMINISTRATOR";

const mensagem = (erro: unknown) => (erro instanceof ErroApi ? erro.message : "Não foi possível falar com o servidor.");

const OPCOES_CARGO: { valor: Papel; rotulo: string }[] = [
  { valor: "OPERATOR", rotulo: "Operador de Pesagem" },
  { valor: "SUPERVISOR", rotulo: "Supervisor de Operações" },
  { valor: "ADMINISTRATOR", rotulo: "Administrador" },
];

export function UsuariosPainel() {
  const { notificar } = useToast();
  const [usuarios, setUsuarios] = useState<Usuario[] | null>(null);
  const [ocupadoId, setOcupadoId] = useState<number | null>(null);
  const [erro, setErro] = useState<string | null>(null);

  const [confirmandoId, setConfirmandoId] = useState<number | null>(null);

  async function carregar() {
    try {
      const dados = await api.usuarios.listar();
      setUsuarios(dados.usuarios);
      setErro(null);
    } catch (e) {
      setErro(mensagem(e));
    }
  }

  useEffect(() => {
    void carregar();
  }, []);

  async function alternar(usuario: Usuario) {
    setOcupadoId(usuario.id);
    try {
      const exigir = !usuario.trocarSenha;
      await api.usuarios.exigirTrocaSenha(usuario.id, exigir);
      notificar({
        titulo: exigir ? "Troca de senha exigida" : "Troca de senha dispensada",
        descricao: exigir
          ? `${usuario.nome} entrará de novo e precisará criar uma nova senha.`
          : `${usuario.nome} poderá entrar normalmente.`,
        tom: "success",
      });
      await carregar();
    } catch (e) {
      notificar({ titulo: "Não foi possível alterar", descricao: mensagem(e), tom: "alert" });
    } finally {
      setOcupadoId(null);
    }
  }

  async function mudarCargo(usuario: Usuario, novo: Papel) {
    setOcupadoId(usuario.id);
    try {
      await api.usuarios.alterarPapel(usuario.id, novo);
      notificar({
        titulo: "Cargo alterado",
        descricao: `${usuario.nome} agora é ${OPCOES_CARGO.find((o) => o.valor === novo)?.rotulo ?? novo}.`,
        tom: "success",
      });
      await carregar();
    } catch (e) {
      notificar({ titulo: "Não foi possível alterar o cargo", descricao: mensagem(e), tom: "alert" });
      await carregar();
    } finally {
      setOcupadoId(null);
    }
  }

  async function alternarAtivo(usuario: Usuario) {
    const ativar = !usuario.ativo;
    setOcupadoId(usuario.id);
    try {
      await api.usuarios.definirAtivo(usuario.id, ativar);
      notificar({
        titulo: ativar ? "Conta reativada" : "Conta desativada",
        descricao: ativar
          ? `${usuario.nome} pode entrar novamente.`
          : `${usuario.nome} não consegue mais entrar e as sessões dela foram encerradas.`,
        tom: "success",
      });
      await carregar();
    } catch (e) {
      notificar({ titulo: "Não foi possível alterar a conta", descricao: mensagem(e), tom: "alert" });
    } finally {
      setOcupadoId(null);
    }
  }

  if (erro) return <p className="text-[12px] text-destructive">{erro}</p>;
  if (!usuarios) return <p className="text-[12px] text-muted-foreground">Carregando equipe…</p>;

  return (
    <div className="space-y-3">
      <ul className="space-y-2">
        {usuarios.map((u) => (
          <li
            key={u.id}
            className="flex items-center gap-3 rounded-xl border border-border/60 bg-card-elev px-3 py-2.5"
          >
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12px] font-semibold">
                {u.nome}
                {u.eu && <span className="ml-1 text-[10px] font-normal text-muted-foreground">(você)</span>}
                {!u.ativo && (
                  <span className="ml-2 rounded-md bg-muted px-1.5 py-0.5 text-[9px] font-semibold uppercase">
                    Inativo
                  </span>
                )}
              </p>
              <p className="truncate text-[10px] text-muted-foreground">
                {u.email} · {u.papelDescricao ?? u.papel}
                {u.verificacaoEmDuasEtapas ? " · 2 etapas ativa" : ""}
              </p>
            </div>
            {!u.eu && (
              <div className="flex shrink-0 flex-col items-end gap-1.5">
                {u.ativo && (
                  <select
                    aria-label={`Cargo de ${u.nome}`}
                    value={u.papel}
                    disabled={ocupadoId === u.id}
                    onChange={(e) => void mudarCargo(u, e.target.value as Papel)}
                    className="min-h-[36px] rounded-lg border border-border/60 bg-card px-2 text-[11px] font-semibold disabled:opacity-60"
                  >
                    {OPCOES_CARGO.map((o) => (
                      <option key={o.valor} value={o.valor}>
                        {o.rotulo}
                      </option>
                    ))}
                  </select>
                )}
                {u.ativo && confirmandoId === u.id ? (
                  <div className="flex flex-col items-end gap-1">
                    <span className="text-[10px] text-muted-foreground">Desativar? A pessoa perde o acesso agora.</span>
                    <div className="flex gap-1.5">
                      <button
                        type="button"
                        onClick={() => setConfirmandoId(null)}
                        className="min-h-[36px] rounded-lg border border-border/60 bg-card px-2 text-[11px] font-semibold"
                      >
                        Cancelar
                      </button>
                      <button
                        type="button"
                        disabled={ocupadoId === u.id}
                        onClick={() => {
                          setConfirmandoId(null);
                          void alternarAtivo(u);
                        }}
                        className="min-h-[36px] rounded-lg bg-destructive px-2 text-[11px] font-semibold text-white disabled:opacity-60"
                      >
                        Sim, desativar
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={ocupadoId === u.id}
                    onClick={() => (u.ativo ? setConfirmandoId(u.id) : void alternarAtivo(u))}
                    className="min-h-[36px] rounded-lg border border-border/60 bg-card px-2 text-[11px] font-semibold text-muted-foreground disabled:opacity-60"
                  >
                    {u.ativo ? "Desativar conta" : "Reativar conta"}
                  </button>
                )}
              </div>
            )}
            {u.ativo && (
              <button
                type="button"
                disabled={ocupadoId === u.id}
                onClick={() => void alternar(u)}
                aria-pressed={u.trocarSenha}
                className={`flex shrink-0 items-center gap-1.5 rounded-xl border px-3 py-1.5 text-[11px] font-semibold disabled:opacity-60 ${
                  u.trocarSenha ? "border-warning/50 bg-warning/10 text-warning" : "border-border/60 bg-card"
                }`}
              >
                {ocupadoId === u.id && <Loader2 className="h-3 w-3 animate-spin" />}
                {u.trocarSenha ? "Troca exigida" : "Exigir troca de senha"}
              </button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
