import { CircleCheck, Info, TriangleAlert } from "lucide-react";
import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import { cn, uid } from "@/lib/utils";

type Tom = "success" | "info" | "alert";

interface ToastItem {
  id: string;
  titulo: string;
  descricao?: string;
  tom: Tom;
}

interface ToastApi {
  notificar: (toast: { titulo: string; descricao?: string; tom?: Tom }) => void;
}

const ToastContext = createContext<ToastApi | null>(null);

const ICONES: Record<Tom, ReactNode> = {
  success: <CircleCheck className="h-4 w-4 text-success" />,
  info: <Info className="h-4 w-4 text-primary" />,
  alert: <TriangleAlert className="h-4 w-4 text-warning" />,
};

const BORDAS: Record<Tom, string> = {
  success: "border-success/40",
  info: "border-border/60",
  alert: "border-warning/50",
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const notificar = useCallback<ToastApi["notificar"]>(({ titulo, descricao, tom = "success" }) => {
    const item: ToastItem = { id: uid("toast"), titulo, descricao, tom };
    setToasts((prev) => [...prev.slice(-2), item]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== item.id));
    }, 3400);
  }, []);

  const api = useMemo(() => ({ notificar }), [notificar]);

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="pointer-events-none fixed bottom-24 left-1/2 z-50 flex w-full max-w-[420px] -translate-x-1/2 flex-col gap-2 px-5">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            role="status"
            className={cn(
              "pointer-events-auto flex items-start gap-3 rounded-xl border bg-card-elev px-4 py-3 shadow-lg animate-ls-toast-in",
              BORDAS[toast.tom],
            )}
          >
            <span className="mt-0.5">{ICONES[toast.tom]}</span>
            <div className="min-w-0">
              <p className="text-[12px] font-semibold">{toast.titulo}</p>
              {toast.descricao && <p className="mt-0.5 text-[10px] text-muted-foreground">{toast.descricao}</p>}
            </div>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) throw new Error("useToast precisa estar dentro de <ToastProvider>.");
  return context;
}
