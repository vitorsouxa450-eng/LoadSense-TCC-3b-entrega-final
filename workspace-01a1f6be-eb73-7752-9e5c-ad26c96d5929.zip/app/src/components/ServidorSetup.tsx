import { useState, type FormEvent } from "react";
import { definirEnderecoServidor, enderecoServidor } from "@shared/lib/api";

export function estaNoAparelho(): boolean {
  const w = window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } };
  return Boolean(w.Capacitor?.isNativePlatform?.());
}

export function precisaConfigurarServidor(): boolean {
  return estaNoAparelho() && !enderecoServidor();
}

export function ServidorSetup({ onConcluir }: { onConcluir: () => void }) {
  const [endereco, setEndereco] = useState("http://");
  const [verificando, setVerificando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  async function conectar(event: FormEvent) {
    event.preventDefault();
    const limpo = endereco.trim().replace(/\/$/, "");
    if (!/^https?:\/\/[^/\s]+$/.test(limpo)) {
      setErro("Digite o endereço completo, por exemplo http://192.168.0.10:5174");
      return;
    }
    setVerificando(true);
    setErro(null);
    try {
      const resposta = await fetch(`${limpo}/api/saude`);
      const dados = (await resposta.json()) as { ok?: boolean };
      if (!resposta.ok || !dados.ok) throw new Error("resposta inesperada");
      definirEnderecoServidor(limpo);
      onConcluir();
    } catch {
      setErro("Não foi possível falar com o servidor. Confira o endereço, o Wi-Fi e se a API está rodando.");
    } finally {
      setVerificando(false);
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#0a0a0a",
        color: "#f5f5f5",
        padding: 24,
        fontFamily: "system-ui, sans-serif",
      }}
    >
      <div style={{ fontSize: 22, fontWeight: 700, marginTop: 48 }}>
        LOAD<span style={{ color: "#ff5a1f" }}>SENSE</span>
      </div>
      <p style={{ color: "#a3a3a3", fontSize: 14, lineHeight: 1.5 }}>
        Antes de entrar, informe o endereço do servidor da escola. Peça esse endereço a quem está com o computador da
        balança.
      </p>
      <form onSubmit={conectar} style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 24 }}>
        <label style={{ fontSize: 13, color: "#a3a3a3" }}>Endereço do servidor</label>
        <input
          value={endereco}
          onChange={(e) => setEndereco(e.target.value)}
          inputMode="url"
          autoCapitalize="none"
          autoCorrect="off"
          placeholder="http://192.168.0.10:5174"
          style={{
            padding: 14,
            borderRadius: 10,
            border: "1px solid #333",
            background: "#141414",
            color: "#f5f5f5",
            fontSize: 16,
          }}
        />
        {erro && <div style={{ color: "#f87171", fontSize: 13 }}>{erro}</div>}
        <button
          type="submit"
          disabled={verificando}
          style={{
            padding: 14,
            borderRadius: 10,
            border: 0,
            background: "#ff5a1f",
            color: "#fff",
            fontWeight: 700,
            fontSize: 16,
          }}
        >
          {verificando ? "Verificando…" : "Conectar"}
        </button>
      </form>
    </div>
  );
}
