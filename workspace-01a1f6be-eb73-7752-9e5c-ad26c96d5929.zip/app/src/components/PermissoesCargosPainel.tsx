import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { api, ErroApi } from "@shared/lib/api";
import { useToast } from "@/components/Toast";

type Dados = Awaited<ReturnType<typeof api.papeis.listar>>;
type Cargo = Dados["cargos"][number];

const NOME_CARGO: Record<string, string> = {
  ADMINISTRATOR: "Administrador",
  SUPERVISOR: "Supervisor de Operações",
  OPERATOR: "Operador de Pesagem",
};

const mensagem = (erro: unknown) => (erro instanceof ErroApi ? erro.message : "Não foi possível falar com o servidor.");

export function PermissoesCargosPainel() {
  const { notificar } = useToast();
  const [dados, setDados] = useState<Dados | null>(null);
  const [erro, setErro] = useState<string | null>(null);
  const [rascunho, setRascunho] = useState<Record<string, string[]>>({});
  const [salvando, setSalvando] = useState<string | null>(null);

  async function carregar() {
    try {
      const d = await api.papeis.listar();
      setDados(d);
      setRascunho(Object.fromEntries(d.cargos.map((c) => [c.nome, c.permissoes])));
      setErro(null);
    } catch (e) {
      setErro(mensagem(e));
    }
  }

  useEffect(() => {
    void carregar();
  }, []);

  if (erro) return <p className="text-[12px] text-destructive">{erro}</p>;
  if (!dados) return <p className="text-[12px] text-muted-foreground">Carregando cargos…</p>;

  const editaveis = dados.catalogo.filter((p) => !p.reservada && p.codigo !== "AUDIT_VIEW");
  const cargos = dados.cargos.filter((c) => c.editavel);

  const alternar = (cargo: Cargo, codigo: string) => {
    setRascunho((prev) => {
      const atual = prev[cargo.nome] ?? [];
      const novo = atual.includes(codigo) ? atual.filter((c) => c !== codigo) : [...atual, codigo];
      return { ...prev, [cargo.nome]: novo };
    });
  };

  const salvar = async (cargo: Cargo) => {
    setSalvando(cargo.nome);
    try {
      await api.papeis.salvarPermissoes(cargo.nome, rascunho[cargo.nome] ?? []);
      notificar({
        titulo: "Permissões salvas",
        descricao: `${NOME_CARGO[cargo.nome] ?? cargo.nome} passa a ter o novo acesso.`,
        tom: "success",
      });
      await carregar();
    } catch (e) {
      notificar({ titulo: "Não foi possível salvar", descricao: mensagem(e), tom: "alert" });
    } finally {
      setSalvando(null);
    }
  };

  return (
    <div className="space-y-4">
      {cargos.map((cargo) => {
        const marcadas = rascunho[cargo.nome] ?? [];
        const mudou =
          marcadas.length !== cargo.permissoes.length || marcadas.some((c) => !cargo.permissoes.includes(c));
        return (
          <div key={cargo.nome} className="rounded-xl border border-border/60 bg-card-elev p-3">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[12px] font-semibold">
                {NOME_CARGO[cargo.nome] ?? cargo.nome}
                <span className="ml-2 text-[10px] font-normal text-muted-foreground">
                  {cargo.usuarios} {cargo.usuarios === 1 ? "usuário" : "usuários"}
                </span>
              </p>
            </div>
            <ul className="space-y-1.5">
              {editaveis.map((p) => (
                <li key={p.codigo}>
                  <label className="flex cursor-pointer items-start gap-2 rounded-lg px-1 py-1.5 hover:bg-muted/50">
                    <input
                      type="checkbox"
                      className="mt-0.5 h-4 w-4 accent-[hsl(var(--primary))]"
                      checked={marcadas.includes(p.codigo)}
                      onChange={() => alternar(cargo, p.codigo)}
                    />
                    <span className="text-[11px]">
                      <span className="block font-medium">{p.descricao}</span>
                    </span>
                  </label>
                </li>
              ))}
            </ul>
            <button
              type="button"
              disabled={!mudou || salvando === cargo.nome}
              onClick={() => void salvar(cargo)}
              className="mt-3 flex min-h-[40px] w-full items-center justify-center gap-2 rounded-xl bg-primary text-[12px] font-semibold text-primary-foreground disabled:opacity-50"
            >
              {salvando === cargo.nome && <Loader2 className="h-3 w-3 animate-spin" />}
              {mudou ? "Salvar permissões" : "Nenhuma alteração"}
            </button>
          </div>
        );
      })}
    </div>
  );
}
