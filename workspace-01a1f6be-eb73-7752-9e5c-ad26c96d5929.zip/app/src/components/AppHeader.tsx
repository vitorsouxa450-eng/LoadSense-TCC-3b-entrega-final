import { Bell, ChevronLeft, Moon, Sun } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Logo } from "@/components/Logo";
import { useStore } from "@/store/store";
import { useTheme } from "@/lib/theme";

interface AppHeaderProps {
  title?: string;
  back?: boolean;
}

export function AppHeader({ title, back }: AppHeaderProps) {
  const navigate = useNavigate();
  const { theme, toggle } = useTheme();
  const { alerts } = useStore();
  const alertasAtivos = alerts.filter((alert) => alert.status === "ativo").length;
  const rotuloTema = theme === "dark" ? "Ativar modo claro" : "Ativar modo escuro";

  return (
    <header className="flex min-h-12 items-center justify-between gap-2 border-b border-border/60 bg-background/95 px-5 py-2 backdrop-blur">
      {back ? (
        <button
          type="button"
          onClick={() => navigate(-1)}
          aria-label={title ? `Voltar para ${title}` : "Voltar"}
          className="flex h-9 min-w-0 items-center gap-1 pr-2 text-sm font-semibold hover:opacity-80"
        >
          <ChevronLeft className="h-5 w-5 shrink-0" />
          <span className="truncate">{title ?? "Voltar"}</span>
        </button>
      ) : (
        <Logo />
      )}

      <div className="flex shrink-0 items-center gap-2">
        <button
          type="button"
          onClick={toggle}
          aria-label={rotuloTema}
          title={rotuloTema}
          className="flex h-8 w-8 items-center justify-center rounded-lg border border-border/60 bg-card"
        >
          {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>

        <Link
          to="/alertas"
          aria-label={alertasAtivos > 0 ? `Alertas em aberto: ${alertasAtivos}` : "Alertas"}
          title={alertasAtivos > 0 ? `${alertasAtivos} alertas em aberto` : "Alertas"}
          className="relative p-1"
        >
          <Bell className="h-5 w-5 text-foreground/90" />
          {alertasAtivos > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[9px] font-bold text-primary-foreground">
              {alertasAtivos}
            </span>
          )}
        </Link>
      </div>
    </header>
  );
}
