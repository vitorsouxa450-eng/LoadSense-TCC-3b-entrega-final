import { cn } from "@/lib/utils";

export function Ring({
  value: valor,
  size = 130,
  stroke = 11,
  cor = "hsl(var(--primary))",
  trilha = "hsl(var(--muted))",
  className,
  children,
}: {
  value: number;
  size?: number;
  stroke?: number;
  cor?: string;
  trilha?: string;
  className?: string;
  children?: React.ReactNode;
}) {
  const raio = (size - stroke) / 2;
  const circunferencia = 2 * Math.PI * raio;
  const preenchido = (Math.min(100, Math.max(0, valor)) / 100) * circunferencia;

  return (
    <div
      className={cn("relative inline-flex items-center justify-center", className)}
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={raio} stroke={trilha} strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={raio}
          stroke={cor}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${preenchido} ${circunferencia}`}
          className="transition-all duration-700"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">{children}</div>
    </div>
  );
}

export function Sparkline({
  data,
  height = 110,
  cor = "hsl(var(--primary))",
  className,
}: {
  data: number[];
  height?: number;
  cor?: string;
  className?: string;
}) {
  const largura = 320;
  const serie = data.length > 1 ? data : [0, 0];
  const maximo = Math.max(...serie);
  const minimo = Math.min(...serie);
  const amplitude = maximo - minimo || 1;
  const passo = largura / (serie.length - 1);

  const pontos = serie.map((valor, index) => {
    const x = index * passo;
    const y = height - ((valor - minimo) / amplitude) * (height - 20) - 10;
    return [x, y] as const;
  });

  const linha = pontos.map(([x, y], index) => `${index === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const area = `${linha} L${largura},${height} L0,${height} Z`;
  const idGradiente = `grad-${Math.round(largura + height + serie.length)}`;

  return (
    <svg viewBox={`0 0 ${largura} ${height}`} className={cn("w-full", className)} preserveAspectRatio="none">
      <defs>
        <linearGradient id={idGradiente} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={cor} stopOpacity="0.35" />
          <stop offset="100%" stopColor={cor} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${idGradiente})`} />
      <path d={linha} fill="none" stroke={cor} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      {pontos.length > 0 && (
        <circle cx={pontos[pontos.length - 1][0]} cy={pontos[pontos.length - 1][1]} r="3.4" fill={cor} />
      )}
    </svg>
  );
}

export function BarChart({
  data,
  labels,
  height = 120,
  cor = "hsl(var(--primary))",
}: {
  data: number[];
  labels?: string[];
  height?: number;
  cor?: string;
}) {
  const maximo = Math.max(...data, 1);

  return (
    <div className="flex w-full items-end gap-1.5" style={{ height }}>
      {data.map((valor, index) => (
        <div key={`${valor}-${index}`} className="flex flex-1 flex-col items-center gap-1">
          <div
            className="w-full rounded-t-md transition-all duration-500"
            style={{
              height: `${Math.max(4, (valor / maximo) * (height - 22))}px`,
              background: cor,
              opacity: 0.35 + (valor / maximo) * 0.65,
            }}
            title={String(valor)}
          />
          {labels && <span className="text-[8px] text-muted-foreground">{labels[index]}</span>}
        </div>
      ))}
    </div>
  );
}

export function Donut({
  fatias,
  size = 112,
}: {
  fatias: Array<{ label: string; valor: number; cor: string }>;
  size?: number;
}) {
  let acumulado = 0;
  const gradiente = fatias
    .map((fatia) => {
      const inicio = acumulado;
      acumulado += fatia.valor;
      return `${fatia.cor} ${inicio}% ${acumulado}%`;
    })
    .join(", ");

  return (
    <div
      className="relative rounded-full"
      style={{ height: size, width: size, background: `conic-gradient(${gradiente})` }}
    >
      <div className="absolute inset-3 rounded-full bg-card" />
    </div>
  );
}
