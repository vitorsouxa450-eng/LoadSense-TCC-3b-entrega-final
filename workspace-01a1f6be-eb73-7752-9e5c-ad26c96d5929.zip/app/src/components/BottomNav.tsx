import { LayoutDashboard, Radar, Settings, FileText, Truck } from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

export type NavLabel = "Dashboard" | "Operações" | "Monitoramento" | "Relatórios" | "Configurações";

const ITENS: Array<{
  rotulo: NavLabel;
  para: string;
  Icone: typeof LayoutDashboard;
  ativo: (pathname: string) => boolean;
}> = [
  { rotulo: "Dashboard", para: "/", Icone: LayoutDashboard, ativo: (p) => p === "/" },
  { rotulo: "Operações", para: "/operacoes", Icone: Truck, ativo: (p) => p.startsWith("/operacoes") },
  {
    rotulo: "Monitoramento",
    para: "/monitoramento",
    Icone: Radar,
    ativo: (p) => p.startsWith("/monitoramento"),
  },
  {
    rotulo: "Relatórios",
    para: "/relatorios",
    Icone: FileText,
    ativo: (p) => p.startsWith("/relatorios") || p.startsWith("/historico"),
  },
  {
    rotulo: "Configurações",
    para: "/configuracoes",
    Icone: Settings,
    ativo: (p) =>
      p.startsWith("/configuracoes") ||
      p.startsWith("/planos") ||
      p.startsWith("/alertas") ||
      p.startsWith("/sobre") ||
      p.startsWith("/perfil") ||
      p.startsWith("/preferencias") ||
      p.startsWith("/status"),
  },
];

export function BottomNav({ ativoOverride }: { ativoOverride?: NavLabel }) {
  const { pathname } = useLocation();

  return (
    <nav className="sticky bottom-0 left-0 right-0 z-20 border-t border-border/60 bg-background/95 px-2 pt-2 ls-safe-bottom backdrop-blur">
      <ul className="flex justify-between">
        {ITENS.map((item) => {
          const ativo = ativoOverride ? ativoOverride === item.rotulo : item.ativo(pathname);
          const Icone = item.Icone;
          return (
            <li key={item.rotulo} className="flex-1">
              <NavLink
                to={item.para}
                className={cn(
                  "flex flex-col items-center gap-1 py-1 text-[10px] font-medium transition-colors duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
                  ativo ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Icone
                  className={cn(
                    "h-5 w-5 transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
                    ativo ? "stroke-[2.4] scale-110" : "scale-100",
                  )}
                />
                <span>{item.rotulo}</span>
              </NavLink>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
