import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { ScanLine, Truck, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/Toast";
import { TIPOS_CARGA, FROTA, LIMITE_LEGAL_KG, MOTORISTAS, ROTAS } from "@/data/seeder";
import { useStore } from "@/store/store";
import { veiculosCadastradosDemo } from "@shared/lib/demo";
import { api, type MotoristaApi, type ProdutoApi, type RotaApi, type VeiculoApi } from "@shared/lib/api";
import { RotaPorDestino } from "@shared/components/RotaPorDestino";
import { cn, formatKg, uid } from "@/lib/utils";

function catalogo(
  modo: string,
  veiculos: { placa: string; taraKg: number; limiteKg: number }[],
  rotas: { origem: string; destino: string; km: number }[],
) {
  const usaServidor = modo === "servidor";
  const extras =
    modo === "demo"
      ? veiculosCadastradosDemo().map((v) => ({
          placa: v.plate,
          taraKg: v.registered_tare_kg ?? 8_620,
          limiteKg: v.gross_weight_limit_kg ?? 0,
        }))
      : [];
  const todos = usaServidor ? veiculos : [...extras];
  return {
    frota: usaServidor ? veiculos.map((v) => v.placa) : [...FROTA, ...extras.map((v) => v.placa)],
    rotas: usaServidor ? rotas : ROTAS,
    taraDe: (placa: string) => todos.find((v) => v.placa === placa)?.taraKg ?? 8_620,
    limiteDe: (placa: string) => todos.find((v) => v.placa === placa)?.limiteKg || LIMITE_LEGAL_KG,
  };
}

function NovaOperacaoDemo({ onFechar }: { onFechar: () => void }) {
  const { criarOperacao, modo, veiculosServidor, rotasServidor, motoristasServidor } = useStore();
  const { notificar } = useToast();
  const navigate = useNavigate();

  const { frota, rotas, taraDe, limiteDe } = catalogo(modo, veiculosServidor, rotasServidor);
  const [placa, setPlaca] = useState<string>(frota[0] ?? "");
  const listaMotoristas = modo === "servidor" ? motoristasServidor.map((m) => m.nome) : MOTORISTAS;
  const [motorista, setMotorista] = useState<string>(listaMotoristas[0] ?? "");
  const [tipoCarga, setTipoCarga] = useState<string>(TIPOS_CARGA[0]);
  const [rotaIndex, setRotaIndex] = useState(0);
  const semCadastros =
    modo === "servidor" && (frota.length === 0 || rotas.length === 0 || listaMotoristas.length === 0);
  const [pesoCarga, setPesoCarga] = useState(22_500);
  const [rfid] = useState(() => `RF-${uid("").slice(1, 7).toUpperCase()}`);

  const taraEstimada = taraDe(placa);
  const total = taraEstimada + pesoCarga;
  const excedeLimite = total > limiteDe(placa);
  const [salvando, setSalvando] = useState(false);

  async function salvar() {
    if (salvando) return;
    setSalvando(true);
    try {
      const operacao = await criarOperacao({ placa, motorista, tipoCarga, rotaIndex, pesoCargaKg: pesoCarga, rfid });
      const rota = rotas[rotaIndex] ?? rotas[0];
      notificar({
        titulo: `Operação ${operacao.codigo ?? operacao.id} registrada`,
        descricao: `${placa} · ${rota.origem} → ${rota.destino}`,
        tom: excedeLimite ? "alert" : "success",
      });
      onFechar();
      navigate(`/operacoes/${operacao.id}`);
    } catch (erro) {
      notificar({
        titulo: "Não foi possível registrar",
        descricao: erro instanceof Error ? erro.message : "Falha ao falar com o servidor.",
        tom: "alert",
      });
    } finally {
      setSalvando(false);
    }
  }

  return (
    <div className="absolute inset-0 z-40 flex items-end bg-black/60 backdrop-blur-sm animate-ls-fade-in">
      <div className="ls-scroll max-h-[86%] w-full overflow-y-auto rounded-t-3xl border-t border-border/60 bg-background p-5 animate-ls-sheet-up">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold">Nova operação</h2>
            <p className="text-[11px] text-muted-foreground">Registre a viagem e a pesagem de origem</p>
          </div>
          <button
            type="button"
            onClick={onFechar}
            aria-label="Fechar"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-border/60 bg-card"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-4 space-y-3">
          <Campo rotulo="Placa do caminhão">
            <div className="flex items-center gap-2">
              <Truck className="h-4 w-4 text-muted-foreground" />
              <select
                value={placa}
                onChange={(event) => setPlaca(event.target.value)}
                className="flex-1 bg-transparent text-[13px] outline-none"
              >
                {frota.map((valor) => (
                  <option key={valor} value={valor} className="bg-card">
                    {valor}
                  </option>
                ))}
              </select>
            </div>
          </Campo>

          <Campo rotulo="Motorista">
            <select
              value={motorista}
              onChange={(event) => setMotorista(event.target.value)}
              className="w-full bg-transparent text-[13px] outline-none"
            >
              {listaMotoristas.map((valor) => (
                <option key={valor} value={valor} className="bg-card">
                  {valor}
                </option>
              ))}
            </select>
          </Campo>

          <Campo rotulo="Tipo de carga">
            <select
              value={tipoCarga}
              onChange={(event) => setTipoCarga(event.target.value)}
              className="w-full bg-transparent text-[13px] outline-none"
            >
              {TIPOS_CARGA.map((valor) => (
                <option key={valor} value={valor} className="bg-card">
                  {valor}
                </option>
              ))}
            </select>
          </Campo>

          <Campo rotulo="Rota">
            {modo === "servidor" ? (
              <RotaPorDestino
                rotas={rotasServidor.map((r) => ({
                  id: r.id,
                  origem: r.origem,
                  destino: r.destino,
                  km: r.km,
                  waypoints: r.waypoints,
                }))}
                valor={rotasServidor[rotaIndex]?.id ?? null}
                onChange={(id) =>
                  setRotaIndex(
                    Math.max(
                      0,
                      rotasServidor.findIndex((r) => r.id === id),
                    ),
                  )
                }
              />
            ) : (
              <select
                value={rotaIndex}
                onChange={(event) => setRotaIndex(Number(event.target.value))}
                className="w-full bg-transparent text-[13px] outline-none"
              >
                {rotas.map((rota, index) => (
                  <option key={`${rota.origem}-${rota.destino}`} value={index} className="bg-card">
                    {rota.origem} → {rota.destino} ({rota.km} km)
                  </option>
                ))}
              </select>
            )}
          </Campo>

          <Campo rotulo={`Peso da carga: ${formatKg(pesoCarga)}`}>
            <input
              type="range"
              min={5_000}
              max={30_000}
              step={100}
              value={pesoCarga}
              onChange={(event) => setPesoCarga(Number(event.target.value))}
              className="w-full accent-[hsl(var(--primary))]"
            />
          </Campo>

          <div className="flex items-center gap-2 rounded-xl bg-card-elev px-3 py-2.5">
            <ScanLine className="h-4 w-4 text-primary" />
            <div className="flex-1">
              <div className="text-[10px] text-muted-foreground">Tag RFID associada</div>
              <div className="text-[12px] font-semibold">{rfid}</div>
            </div>
          </div>

          <div
            className={cn(
              "rounded-xl px-3 py-2.5 text-[11px]",
              excedeLimite
                ? "border border-destructive/40 bg-destructive/10 text-destructive"
                : "border border-success/30 bg-success/10 text-success",
            )}
          >
            Peso total estimado: <strong className="tabular">{formatKg(total)}</strong> · limite legal{" "}
            {formatKg(LIMITE_LEGAL_KG)}
            {excedeLimite ? " · alerta de sobrecarga será gerado" : " · dentro do limite"}
          </div>
        </div>

        {semCadastros && (
          <p className="mt-3 rounded-xl border border-warning/40 bg-warning/10 px-3 py-2 text-[11px] text-warning">
            Antes de registrar, cadastre no site da central (página “Cadastrar operação”):{" "}
            {[
              frota.length === 0 && "um caminhão",
              rotas.length === 0 && "uma rota",
              listaMotoristas.length === 0 && "um motorista",
            ]
              .filter(Boolean)
              .join(", ")}
            .
          </p>
        )}
        <button
          type="button"
          onClick={salvar}
          disabled={semCadastros || salvando}
          className="mt-4 w-full rounded-xl bg-primary py-3 text-[13px] font-semibold text-primary-foreground"
        >
          Registrar operação
        </button>
        <button type="button" onClick={onFechar} className="w-full py-2 text-center text-[12px] text-muted-foreground">
          Cancelar
        </button>
      </div>
    </div>
  );
}

function Campo({ rotulo, children }: { rotulo: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border/60 bg-card-elev px-3 py-2.5">
      <div className="mb-1 text-[10px] uppercase tracking-wide text-muted-foreground">{rotulo}</div>
      {children}
    </div>
  );
}

interface DadosServidor {
  veiculoId: string;
  motoristaId: string;
  produtoId: string;
  rotaId: string;
  cargaDeclarada: string;
  notaFiscal: string;
  mdfe: string;
  ciot: string;
  saida: string;
  chegada: string;
  observacoes: string;
  vazio: string;
  carregado: string;
  motivo: string;
}

const VAZIO_SERVIDOR: DadosServidor = {
  veiculoId: "",
  motoristaId: "",
  produtoId: "",
  rotaId: "",
  cargaDeclarada: "",
  notaFiscal: "",
  mdfe: "",
  ciot: "",
  saida: "",
  chegada: "",
  observacoes: "",
  vazio: "",
  carregado: "",
  motivo: "Pesagem registrada pelo aplicativo (sem balança conectada)",
};

const numeroBr = (texto: string) => Number(texto.replace(",", "."));
const temPesagem = (d: DadosServidor) => Boolean(d.vazio || d.carregado);
const mensagemErro = (e: unknown) => (e instanceof Error ? e.message : "Falha na comunicação com o servidor.");
const CAMPO_INPUT =
  "w-full rounded-lg border border-border/60 bg-background px-2.5 py-2 text-[13px] outline-none focus:border-primary/60";

function CampoServidor({ rotulo, erro, children }: { rotulo: string; erro?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-[11px] font-semibold text-muted-foreground">{rotulo}</span>
      <div className="mt-1">{children}</div>
      {erro && <span className="mt-1 block text-[10px] text-destructive">{erro}</span>}
    </label>
  );
}

function NovaOperacaoServidor({ onFechar }: { onFechar: () => void }) {
  const { recarregarDados } = useStore();
  const { notificar } = useToast();
  const navigate = useNavigate();
  const [veiculos, setVeiculos] = useState<VeiculoApi[] | null>(null);
  const [motoristas, setMotoristas] = useState<MotoristaApi[]>([]);
  const [produtos, setProdutos] = useState<ProdutoApi[]>([]);
  const [rotas, setRotas] = useState<RotaApi[]>([]);
  const [dados, setDados] = useState<DadosServidor>(VAZIO_SERVIDOR);
  const [erros, setErros] = useState<Partial<Record<keyof DadosServidor, string>>>({});
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.veiculos(), api.motoristas(), api.produtos(), api.rotas()])
      .then(([v, m, p, r]) => {
        setVeiculos(v.veiculos);
        setMotoristas(m.motoristas);
        setProdutos(p.produtos);
        setRotas(r.rotas);
      })
      .catch((e) => setErro(mensagemErro(e)));
  }, []);

  const alterar = (campo: keyof DadosServidor) => (valor: string) => {
    setDados((d) => ({ ...d, [campo]: valor }));
    setErros((e) => ({ ...e, [campo]: undefined }));
  };

  function validar() {
    const novos: Partial<Record<keyof DadosServidor, string>> = {};
    if (!dados.veiculoId) novos.veiculoId = "Escolha o caminhão.";
    if (!dados.motoristaId) novos.motoristaId = "Escolha o motorista.";
    if (!dados.produtoId) novos.produtoId = "Escolha o produto transportado.";
    if (!dados.rotaId) novos.rotaId = "Escolha o trajeto.";
    if (dados.cargaDeclarada && !(numeroBr(dados.cargaDeclarada) > 0))
      novos.cargaDeclarada = "Informe um peso maior que zero.";
    if (dados.saida && !dados.chegada) novos.chegada = "Informe a chegada prevista.";
    if (dados.chegada && !dados.saida) novos.saida = "Informe a saída prevista.";
    if (temPesagem(dados)) {
      const vazio = numeroBr(dados.vazio);
      const carregado = numeroBr(dados.carregado);
      if (!(vazio > 0)) novos.vazio = "Informe o peso do caminhão vazio.";
      if (!(carregado > vazio)) novos.carregado = "O caminhão carregado precisa pesar mais que o vazio.";
      if (dados.motivo.trim().length < 5) novos.motivo = "Informe o motivo do registro manual.";
    }
    if (dados.saida && dados.chegada && new Date(dados.chegada) <= new Date(dados.saida))
      novos.chegada = "A chegada precisa ser depois da saída.";
    return novos;
  }

  async function salvar(evento: FormEvent) {
    evento.preventDefault();
    setErro(null);
    const novos = validar();
    setErros(novos);
    if (Object.keys(novos).length > 0) return;

    setSalvando(true);
    try {
      const criada = await api.criarOperacao({
        veiculoId: Number(dados.veiculoId),
        motoristaId: Number(dados.motoristaId),
        produtoId: Number(dados.produtoId),
        rotaId: Number(dados.rotaId),
        pesoDeclaradoKg: dados.cargaDeclarada ? numeroBr(dados.cargaDeclarada) : undefined,
        notaFiscal: dados.notaFiscal.trim() || undefined,
        mdfe: dados.mdfe.trim() || undefined,
        ciot: dados.ciot.trim() || undefined,
        metodo: "GROSS_TARE",
        tipoMovimento: "EXIT",
        observacoes: dados.observacoes.trim() || "Operação registrada pelo aplicativo",
      });
      if (dados.saida && dados.chegada) {
        await api.agendarTransporte(
          criada.id,
          new Date(dados.saida).toISOString(),
          new Date(dados.chegada).toISOString(),
        );
      }
      if (temPesagem(dados)) {
        await api.registrarLeitura(criada.id, {
          estagio: "EMPTY_TRUCK",
          pesoKg: numeroBr(dados.vazio),
          origem: "MANUAL",
          motivoManual: dados.motivo.trim(),
        });
        await api.registrarLeitura(criada.id, {
          estagio: "LOADED_TRUCK",
          pesoKg: numeroBr(dados.carregado),
          origem: "MANUAL",
          motivoManual: dados.motivo.trim(),
        });
        await api.finalizarOperacao(criada.id);
      }
      notificar({ titulo: `Operação ${criada.codigo ?? criada.id} criada`, tom: "success" });
      await recarregarDados();
      onFechar();
      navigate(`/operacoes/${criada.id}`);
    } catch (e) {
      setErro(mensagemErro(e));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <div className="absolute inset-0 z-40 flex items-end bg-black/60 backdrop-blur-sm animate-ls-fade-in">
      <form
        onSubmit={salvar}
        noValidate
        className="ls-scroll max-h-[92%] w-full space-y-5 overflow-y-auto rounded-t-3xl border-t border-border/60 bg-background p-5 animate-ls-sheet-up"
      >
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold">Nova operação</h2>
            <p className="text-[11px] text-muted-foreground">
              Defina o transporte e a carga. Com os dois pesos, a pesagem é finalizada.
            </p>
          </div>
          <button
            type="button"
            onClick={onFechar}
            aria-label="Fechar"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-border/60 bg-card"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {erro && <p className="rounded-xl bg-destructive/10 px-3 py-2 text-[12px] text-destructive">{erro}</p>}

        <fieldset className="space-y-3">
          <legend className="mb-2 text-[12px] font-bold">Transporte</legend>
          <CampoServidor rotulo="Caminhão *" erro={erros.veiculoId}>
            <select
              className={CAMPO_INPUT}
              value={dados.veiculoId}
              onChange={(e) => alterar("veiculoId")(e.target.value)}
            >
              <option value="">Escolha o caminhão</option>
              {(veiculos ?? []).map((v) => (
                <option key={v.id} value={v.id}>
                  {v.plate}
                  {v.fleet_code ? ` · frota ${v.fleet_code}` : ""}
                </option>
              ))}
            </select>
          </CampoServidor>
          <CampoServidor rotulo="Motorista *" erro={erros.motoristaId}>
            <select
              className={CAMPO_INPUT}
              value={dados.motoristaId}
              onChange={(e) => alterar("motoristaId")(e.target.value)}
            >
              <option value="">Escolha o motorista</option>
              {motoristas.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.full_name}
                </option>
              ))}
            </select>
          </CampoServidor>
          <CampoServidor rotulo="Trajeto *" erro={erros.rotaId}>
            <select className={CAMPO_INPUT} value={dados.rotaId} onChange={(e) => alterar("rotaId")(e.target.value)}>
              <option value="">Escolha o trajeto</option>
              {rotas.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.origin} → {r.destination}
                </option>
              ))}
            </select>
          </CampoServidor>
          <div className="grid grid-cols-2 gap-3">
            <CampoServidor rotulo="Saída prevista" erro={erros.saida}>
              <input
                type="datetime-local"
                className={CAMPO_INPUT}
                value={dados.saida}
                onChange={(e) => alterar("saida")(e.target.value)}
              />
            </CampoServidor>
            <CampoServidor rotulo="Chegada prevista" erro={erros.chegada}>
              <input
                type="datetime-local"
                className={CAMPO_INPUT}
                value={dados.chegada}
                onChange={(e) => alterar("chegada")(e.target.value)}
              />
            </CampoServidor>
          </div>
        </fieldset>

        <fieldset className="space-y-3">
          <legend className="mb-2 text-[12px] font-bold">Carga</legend>
          <CampoServidor rotulo="Produto transportado *" erro={erros.produtoId}>
            <select
              className={CAMPO_INPUT}
              value={dados.produtoId}
              onChange={(e) => alterar("produtoId")(e.target.value)}
            >
              <option value="">Escolha o produto</option>
              {produtos.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </CampoServidor>
          <CampoServidor rotulo="Carga declarada (kg)" erro={erros.cargaDeclarada}>
            <input
              inputMode="decimal"
              className={CAMPO_INPUT}
              placeholder="14800"
              value={dados.cargaDeclarada}
              onChange={(e) => alterar("cargaDeclarada")(e.target.value)}
            />
          </CampoServidor>
        </fieldset>

        <fieldset className="space-y-3">
          <legend className="mb-1 text-[12px] font-bold">Pesagem (opcional)</legend>
          <p className="text-[10px] text-muted-foreground">Sem balança conectada, informe os pesos lidos.</p>
          <div className="grid grid-cols-2 gap-3">
            <CampoServidor rotulo="Caminhão vazio (kg)" erro={erros.vazio}>
              <input
                inputMode="decimal"
                className={CAMPO_INPUT}
                placeholder="ex.: 8200"
                value={dados.vazio}
                onChange={(e) => alterar("vazio")(e.target.value)}
              />
            </CampoServidor>
            <CampoServidor rotulo="Caminhão carregado (kg)" erro={erros.carregado}>
              <input
                inputMode="decimal"
                className={CAMPO_INPUT}
                placeholder="ex.: 29336"
                value={dados.carregado}
                onChange={(e) => alterar("carregado")(e.target.value)}
              />
            </CampoServidor>
          </div>
          <CampoServidor rotulo="Motivo do registro manual" erro={erros.motivo}>
            <input
              className={CAMPO_INPUT}
              maxLength={200}
              value={dados.motivo}
              onChange={(e) => alterar("motivo")(e.target.value)}
            />
          </CampoServidor>
        </fieldset>

        <fieldset className="space-y-3">
          <legend className="mb-2 text-[12px] font-bold">Documentos (opcionais)</legend>
          <div className="grid grid-cols-3 gap-2">
            <CampoServidor rotulo="Nota fiscal">
              <input
                className={CAMPO_INPUT}
                maxLength={60}
                value={dados.notaFiscal}
                onChange={(e) => alterar("notaFiscal")(e.target.value)}
              />
            </CampoServidor>
            <CampoServidor rotulo="MDF-e">
              <input
                className={CAMPO_INPUT}
                maxLength={60}
                value={dados.mdfe}
                onChange={(e) => alterar("mdfe")(e.target.value)}
              />
            </CampoServidor>
            <CampoServidor rotulo="CIOT">
              <input
                className={CAMPO_INPUT}
                maxLength={60}
                value={dados.ciot}
                onChange={(e) => alterar("ciot")(e.target.value)}
              />
            </CampoServidor>
          </div>
          <CampoServidor rotulo="Observações">
            <textarea
              className={CAMPO_INPUT}
              rows={3}
              maxLength={500}
              value={dados.observacoes}
              onChange={(e) => alterar("observacoes")(e.target.value)}
            />
          </CampoServidor>
        </fieldset>

        <p className="text-[10px] text-muted-foreground">
          * Campos obrigatórios. Cadastros ficam no site, em Configurações &gt; Cadastros.
        </p>
        <button
          type="submit"
          disabled={salvando || veiculos === null}
          className="w-full rounded-xl bg-primary py-3 text-[13px] font-semibold text-primary-foreground disabled:opacity-50"
        >
          {salvando
            ? "Criando…"
            : dados.vazio || dados.carregado
              ? "Criar operação e registrar pesagem"
              : "Criar operação"}
        </button>
      </form>
    </div>
  );
}

export function NovaOperacaoDialog({ onFechar }: { onFechar: () => void }) {
  const { modo } = useStore();
  return modo === "servidor" ? <NovaOperacaoServidor onFechar={onFechar} /> : <NovaOperacaoDemo onFechar={onFechar} />;
}
