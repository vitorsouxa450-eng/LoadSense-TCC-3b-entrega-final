import { useEffect, useState } from "react";
import { Download, Save, Trash2 } from "lucide-react";
import { api, ErroApi } from "@shared/lib/api";
import { useToast } from "@/components/Toast";
import { useStore } from "@/store/store";

export function MeusDadosPainel({ onExcluida }: { onExcluida: () => void }) {
  const { notificar } = useToast();
  const { sair } = useStore();
  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");
  const [alertasCriticos, setAlertasCriticos] = useState(true);
  const [relatorios, setRelatorios] = useState(true);
  const [excluindo, setExcluindo] = useState(false);
  const [senha, setSenha] = useState("");
  const [ocupado, setOcupado] = useState(false);

  useEffect(() => {
    api.titular
      .perfil()
      .then((p) => {
        setNome(p.nome);
        setTelefone(p.telefone ?? "");
        setAlertasCriticos(p.alertasCriticos);
        setRelatorios(p.relatoriosAutomaticos);
      })
      .catch(() => undefined);
  }, []);

  const erro = (e: unknown) =>
    notificar({
      titulo: "Não foi possível concluir",
      descricao: e instanceof ErroApi ? e.message : "Tente novamente.",
      tom: "alert",
    });

  const baixar = async () => {
    setOcupado(true);
    try {
      await api.titular.baixarMeusDados();
    } catch (e) {
      erro(e);
    } finally {
      setOcupado(false);
    }
  };

  const salvar = async () => {
    setOcupado(true);
    try {
      await api.titular.atualizarMeusDados({
        nome: nome.trim(),
        telefone: telefone.trim() || undefined,
        alertasCriticos,
        relatoriosAutomaticos: relatorios,
      });
      notificar({ titulo: "Dados atualizados", tom: "success" });
    } catch (e) {
      erro(e);
    } finally {
      setOcupado(false);
    }
  };

  const excluir = async () => {
    setOcupado(true);
    try {
      await api.titular.excluirConta(senha);
      notificar({ titulo: "Conta excluída", descricao: "Seus dados pessoais foram anonimizados.", tom: "info" });
      await sair();
      onExcluida();
    } catch (e) {
      erro(e);
    } finally {
      setOcupado(false);
    }
  };

  const campo =
    "mt-1 w-full rounded-xl border border-border/60 bg-background px-3 py-2 text-[12px] outline-none focus-visible:ring-2 focus-visible:ring-primary";

  return (
    <div className="space-y-4">
      <div>
        <div className="text-[12px] font-semibold">Baixar meus dados</div>
        <p className="text-[10px] text-muted-foreground">
          Arquivo com seus dados de conta, sessões, aceites de termos e pesagens vinculadas.
        </p>
        <button
          type="button"
          disabled={ocupado}
          onClick={baixar}
          className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl border border-border/60 py-2.5 text-[12px] font-semibold disabled:opacity-60"
        >
          <Download className="h-4 w-4" />
          Baixar arquivo (JSON)
        </button>
      </div>

      <div className="space-y-2">
        <div className="text-[12px] font-semibold">Corrigir dados e comunicações</div>
        <label className="block text-[10px] text-muted-foreground">
          Nome completo
          <input className={campo} value={nome} onChange={(e) => setNome(e.target.value)} maxLength={140} />
        </label>
        <label className="block text-[10px] text-muted-foreground">
          Telefone
          <input
            className={campo}
            value={telefone}
            onChange={(e) => setTelefone(e.target.value)}
            maxLength={30}
            placeholder="(11) 90000-0000"
          />
        </label>
        <label className="flex items-center gap-2 text-[11px]">
          <input type="checkbox" checked={alertasCriticos} onChange={(e) => setAlertasCriticos(e.target.checked)} />
          Receber alertas críticos por e-mail
        </label>
        <label className="flex items-center gap-2 text-[11px]">
          <input type="checkbox" checked={relatorios} onChange={(e) => setRelatorios(e.target.checked)} />
          Receber relatórios automáticos
        </label>
        <button
          type="button"
          disabled={ocupado || nome.trim().length < 3}
          onClick={salvar}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-2.5 text-[12px] font-semibold text-primary-foreground disabled:opacity-60"
        >
          <Save className="h-4 w-4" />
          Salvar alterações
        </button>
      </div>

      <div className="space-y-2 border-t border-border/60 pt-4">
        <div className="text-[12px] font-semibold text-destructive">Excluir minha conta</div>
        <p className="text-[10px] text-muted-foreground">
          Sua conta é desativada e seus dados pessoais são anonimizados. Pesagens registradas permanecem na empresa, sem
          o seu nome. Não é possível desfazer.
        </p>
        {!excluindo ? (
          <button
            type="button"
            onClick={() => setExcluindo(true)}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-destructive/40 py-2.5 text-[12px] font-semibold text-destructive"
          >
            <Trash2 className="h-4 w-4" />
            Quero excluir minha conta
          </button>
        ) : (
          <div className="space-y-2">
            <label className="block text-[10px] text-muted-foreground">
              Confirme com sua senha
              <input
                type="password"
                autoComplete="current-password"
                className={campo}
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
              />
            </label>
            <div className="flex gap-2">
              <button
                type="button"
                disabled={ocupado || !senha}
                onClick={excluir}
                className="flex-1 rounded-xl bg-destructive py-2.5 text-[12px] font-semibold text-white disabled:opacity-60"
              >
                Excluir definitivamente
              </button>
              <button
                type="button"
                onClick={() => {
                  setExcluindo(false);
                  setSenha("");
                }}
                className="flex-1 rounded-xl border border-border/60 py-2.5 text-[12px] font-semibold"
              >
                Cancelar
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
