import { OctagonAlert, TriangleAlert } from "lucide-react";
import { Link } from "react-router-dom";
import type { Alert } from "@/data/types";
import { cn, formatTime } from "@/lib/utils";

export function AlertCard({ alert, mostrarStatus = true }: { alert: Alert; mostrarStatus?: boolean }) {
  const critico = alert.nivel === "critico";
  const Icone = critico ? OctagonAlert : TriangleAlert;
  const resolvido = alert.status === "resolvido";

  const pill = resolvido
    ? "bg-success text-success-foreground"
    : critico
      ? "bg-destructive text-destructive-foreground"
      : "bg-warning text-warning-foreground";

  return (
    <Link
      to={`/alertas/${alert.id}`}
      className={cn(
        "flex gap-3 rounded-2xl border p-3",
        critico ? "border-destructive/40 bg-destructive/10" : "border-warning/40 bg-warning/10",
      )}
    >
      <div
        className={cn(
          "flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
          critico ? "bg-destructive/20" : "bg-warning/20",
        )}
      >
        <Icone className={cn("h-4 w-4", critico ? "text-destructive" : "text-warning")} />
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <div className="text-[13px] font-semibold">{alert.tipo}</div>
          {mostrarStatus && (
            <span className={cn("rounded-md px-2 py-0.5 text-[9px] font-bold uppercase", pill)}>
              {resolvido ? "Resolvido" : alert.nivel === "critico" ? "Crítico" : "Atenção"}
            </span>
          )}
        </div>
        <div className="text-[10px] text-muted-foreground">
          {alert.placa} · {formatTime(alert.criadoEm)} · {alert.motorista}
        </div>
        <div className="mt-1 text-[11px]">{alert.descricao}</div>
        {alert.extra && <div className="mt-1 text-[10px] font-semibold text-muted-foreground">{alert.extra}</div>}
      </div>
    </Link>
  );
}
