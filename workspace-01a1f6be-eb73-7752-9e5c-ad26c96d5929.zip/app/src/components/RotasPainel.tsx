import { useEffect, useState, type FormEvent } from "react";
import { Loader2 } from "lucide-react";
import { api, ErroApi, type RotaApi } from "@shared/lib/api";
import { useToast } from "@/components/Toast";

type Opcao = Awaited<ReturnType<typeof api.rotasAlternativas>>["opcoes"][number];

const mensagem = (erro: unknown) => (erro instanceof ErroApi ? erro.message : "Não foi possível falar com o servidor.");
const numero = (texto: string) => Number(texto.replace(",", "."));
const coordValida = (texto: string, limite: number) => {
  const n = numero(texto);
  return texto.trim() !== "" && Number.isFinite(n) && Math.abs(n) <= limite;
};

const campo =
  "w-full rounded-xl border border-border/60 bg-card-elev px-3 py-2 text-[13px] outline-none focus:border-primary";

export function RotasPainel() {
  const { notificar } = useToast();
  const [rotas, setRotas] = useState<RotaApi[] | null>(null);
  const [erro, setErro] = useState<string | null>(null);

  const [origem, setOrigem] = useState("");
  const [destino, setDestino] = useState("");
  const [latO, setLatO] = useState("");
  const [lonO, setLonO] = useState("");
  const [latD, setLatD] = useState("");
  const [lonD, setLonD] = useState("");
  const [codigo, setCodigo] = useState("");
  const [distancia, setDistancia] = useState("");
  const [opcoes, setOpcoes] = useState<Opcao[]>([]);
  const [escolhida, setEscolhida] = useState<number | null>(null);
  const [buscando, setBuscando] = useState(false);
  const [salvando, setSalvando] = useState(false);
  const [formErro, setFormErro] = useState<string | null>(null);

  async function carregar() {
    try {
      const r = await api.rotas();
      setRotas(r.rotas);
      setErro(null);
    } catch (e) {
      setErro(mensagem(e));
    }
  }

  useEffect(() => {
    void carregar();
  }, []);

  useEffect(() => {
    setOpcoes([]);
    setEscolhida(null);
  }, [latO, lonO, latD, lonD]);

  async function buscarOpcoes() {
    setFormErro(null);
    if (!coordValida(latO, 90) || !coordValida(lonO, 180) || !coordValida(latD, 90) || !coordValida(lonD, 180)) {
      return setFormErro("Informe as coordenadas de origem e destino para buscar as opções de trajeto.");
    }
    setBuscando(true);
    try {
      const { opcoes: lista } = await api.rotasAlternativas({
        latO: numero(latO),
        lonO: numero(lonO),
        latD: numero(latD),
        lonD: numero(lonD),
      });
      setOpcoes(lista);
      setEscolhida(lista[0]?.id ?? null);
    } catch (e) {
      setFormErro(mensagem(e));
    } finally {
      setBuscando(false);
    }
  }

  async function salvar(e: FormEvent) {
    e.preventDefault();
    setFormErro(null);
    if (origem.trim().length < 2 || destino.trim().length < 2) return setFormErro("Informe a origem e o destino.");
    if (!coordValida(latO, 90) || !coordValida(lonO, 180))
      return setFormErro("Informe a latitude e a longitude da origem.");
    if (!coordValida(latD, 90) || !coordValida(lonD, 180))
      return setFormErro("Informe a latitude e a longitude do destino.");
    const opcao = opcoes.find((o) => o.id === escolhida) ?? null;
    const km = numero(distancia) > 0 ? numero(distancia) : (opcao?.distanciaKm ?? 0);
    if (!(km > 0)) return setFormErro("Informe a distância em km ou busque as opções de trajeto.");
    setSalvando(true);
    try {
      const criada = await api.criarRota({
        origem: origem.trim(),
        destino: destino.trim(),
        latOrigem: numero(latO),
        lonOrigem: numero(lonO),
        latDestino: numero(latD),
        lonDestino: numero(lonD),
        distanciaKm: km,
        codigo: codigo.trim() || undefined,
        paradas:
          opcao?.fonte === "OSRM"
            ? opcao.paradasSugeridas.map((p, i) => ({ nome: `Trecho ${i + 1}`, lat: p.lat, lon: p.lon }))
            : [],
      });
      notificar({ titulo: "Rota cadastrada", descricao: `${criada.origem} → ${criada.destino}.`, tom: "success" });
      setOrigem("");
      setDestino("");
      setLatO("");
      setLonO("");
      setLatD("");
      setLonD("");
      setCodigo("");
      setDistancia("");
      setOpcoes([]);
      setEscolhida(null);
      await carregar();
    } catch (err) {
      setFormErro(mensagem(err));
    } finally {
      setSalvando(false);
    }
  }

  if (erro) return <p className="text-[12px] text-destructive">{erro}</p>;
  if (!rotas) {
    return (
      <p className="flex items-center gap-2 text-[12px] text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Carregando rotas…
      </p>
    );
  }

  return (
    <div className="space-y-6">
      <section>
        <h3 className="mb-2 text-[13px] font-semibold">Rotas cadastradas</h3>
        {rotas.length === 0 ? (
          <p className="text-[12px] text-muted-foreground">Nenhuma rota cadastrada ainda.</p>
        ) : (
          <ul className="divide-y divide-border/60">
            {rotas.map((r) => (
              <li key={r.id} className="py-2 text-[13px]">
                <span className="font-medium">
                  {r.origin} → {r.destination}
                </span>
                <span className="block text-[11px] text-muted-foreground">
                  {r.distance_km != null ? `${String(r.distance_km).replace(".", ",")} km` : "distância não informada"}
                  {r.code ? ` · código ${r.code}` : ""}
                  {r.waypoints.length > 0 ? ` · ${r.waypoints.length} pontos no trajeto` : ""}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <h3 className="mb-1 text-[13px] font-semibold">Nova rota</h3>
        <p className="mb-3 text-[12px] text-muted-foreground">
          Defina a rota antes de criar a operação. Busque as opções de trajeto por estradas e escolha uma.
        </p>
        <form onSubmit={salvar} className="space-y-3">
          <div className="grid gap-3 md:grid-cols-2">
            <label className="space-y-1 text-[12px]">
              <span className="font-medium">Origem</span>
              <input
                className={campo}
                value={origem}
                onChange={(e) => setOrigem(e.target.value)}
                placeholder="Ex.: Taboão da Serra"
              />
            </label>
            <label className="space-y-1 text-[12px]">
              <span className="font-medium">Destino</span>
              <input
                className={campo}
                value={destino}
                onChange={(e) => setDestino(e.target.value)}
                placeholder="Ex.: Campinas"
              />
            </label>
            <label className="space-y-1 text-[12px]">
              <span className="font-medium">Latitude da origem</span>
              <input
                className={campo}
                inputMode="decimal"
                value={latO}
                onChange={(e) => setLatO(e.target.value)}
                placeholder="-23,6"
              />
            </label>
            <label className="space-y-1 text-[12px]">
              <span className="font-medium">Longitude da origem</span>
              <input
                className={campo}
                inputMode="decimal"
                value={lonO}
                onChange={(e) => setLonO(e.target.value)}
                placeholder="-46,8"
              />
            </label>
            <label className="space-y-1 text-[12px]">
              <span className="font-medium">Latitude do destino</span>
              <input
                className={campo}
                inputMode="decimal"
                value={latD}
                onChange={(e) => setLatD(e.target.value)}
                placeholder="-22,9"
              />
            </label>
            <label className="space-y-1 text-[12px]">
              <span className="font-medium">Longitude do destino</span>
              <input
                className={campo}
                inputMode="decimal"
                value={lonD}
                onChange={(e) => setLonD(e.target.value)}
                placeholder="-47,0"
              />
            </label>
          </div>

          <button
            type="button"
            onClick={buscarOpcoes}
            disabled={buscando}
            className="rounded-xl border border-border/60 px-4 py-2 text-[13px] font-medium disabled:opacity-50"
          >
            {buscando ? "Buscando opções…" : "Buscar opções de trajeto"}
          </button>

          {opcoes.length > 0 && (
            <fieldset className="space-y-2 rounded-xl border border-border/60 p-3">
              <legend className="px-1 text-[12px] font-semibold">Opções de trajeto</legend>
              {opcoes.map((o) => (
                <label key={o.id} className="flex cursor-pointer items-start gap-2 rounded-lg p-2 hover:bg-muted/50">
                  <input
                    type="radio"
                    name="trajeto"
                    className="mt-1 accent-[hsl(var(--primary))]"
                    checked={escolhida === o.id}
                    onChange={() => setEscolhida(o.id)}
                  />
                  <span className="text-[12px]">
                    <span className="block font-medium">{o.rotulo}</span>
                    <span className="text-muted-foreground">
                      {o.distanciaKm != null
                        ? `${String(o.distanciaKm).replace(".", ",")} km`
                        : "distância não calculada"}
                      {o.duracaoMin != null ? ` · ${Math.round(o.duracaoMin)} min` : ""}
                      {o.fonte === "LINHA_RETA" ? " · linha reta (sem estradas)" : " · por estradas"}
                    </span>
                  </span>
                </label>
              ))}
            </fieldset>
          )}

          <div className="grid gap-3 md:grid-cols-2">
            <label className="space-y-1 text-[12px]">
              <span className="font-medium">Distância em km (opcional)</span>
              <input
                className={campo}
                inputMode="decimal"
                value={distancia}
                onChange={(e) => setDistancia(e.target.value)}
                placeholder="Usa a da opção escolhida"
              />
            </label>
            <label className="space-y-1 text-[12px]">
              <span className="font-medium">Código (opcional)</span>
              <input
                className={campo}
                value={codigo}
                onChange={(e) => setCodigo(e.target.value)}
                placeholder="Ex.: ROTA-01"
              />
            </label>
          </div>

          {formErro && <p className="text-[12px] text-destructive">{formErro}</p>}

          <button
            type="submit"
            disabled={salvando}
            className="rounded-xl bg-primary px-4 py-2 text-[13px] font-semibold text-primary-foreground disabled:opacity-50"
          >
            {salvando ? "Salvando…" : "Cadastrar rota"}
          </button>
        </form>
      </section>
    </div>
  );
}
