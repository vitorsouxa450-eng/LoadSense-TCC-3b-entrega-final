import { Check, ChevronRight, Search } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cn("rounded-2xl border border-border/60 bg-card", className)}>{children}</div>;
}

export function Section({
  title,
  action,
  className,
  children,
}: {
  title?: string;
  action?: ReactNode;
  className?: string;
  children: ReactNode;
}) {
  return (
    <section className={cn("mx-5 mt-4 rounded-2xl border border-border/60 bg-card p-4", className)}>
      {(title || action) && (
        <div className="mb-2 flex items-center justify-between">
          {title && <h3 className="text-[13px] font-semibold">{title}</h3>}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="px-5 pt-4">
      <h1 className="text-xl font-bold">{title}</h1>
      {subtitle && <p className="mt-0.5 text-[11px] text-muted-foreground">{subtitle}</p>}
    </div>
  );
}

export function InfoList({
  items,
  className,
  destaqueUltimo,
}: {
  items: Array<[string, ReactNode]>;
  className?: string;
  destaqueUltimo?: boolean;
}) {
  return (
    <ul className={cn("divide-y divide-border/60 text-[12px]", className)}>
      {items.map(([rotulo, valor], index) => (
        <li key={rotulo} className="flex justify-between gap-4 py-2">
          <span className="text-muted-foreground">{rotulo}</span>
          <span
            className={cn(
              "text-right",
              destaqueUltimo && index === items.length - 1 ? "font-bold text-primary" : "font-semibold",
            )}
          >
            {valor}
          </span>
        </li>
      ))}
    </ul>
  );
}

export function StatCard({
  valor,
  rotulo,
  detalhe,
  icone,
  className,
}: {
  valor: ReactNode;
  rotulo: string;
  detalhe?: string;
  icone?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("rounded-2xl border border-border/60 bg-card p-3", className)}>
      <div className="flex items-center gap-2">
        {icone && (
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-primary/15 text-primary">{icone}</div>
        )}
        <div className="tabular text-base font-bold">{valor}</div>
      </div>
      <div className="mt-2 text-[11px] font-semibold">{rotulo}</div>
      {detalhe && <div className="text-[10px] text-muted-foreground">{detalhe}</div>}
    </div>
  );
}

export function SegmentedTabs<T extends string>({
  tabs,
  value,
  onChange,
}: {
  tabs: Array<{ value: T; label: string }>;
  value: T;
  onChange: (value: T) => void;
}) {
  return (
    <div className="grid auto-cols-fr grid-flow-col rounded-xl bg-card-elev p-1">
      {tabs.map((tab) => {
        const ativo = tab.value === value;
        return (
          <button
            key={tab.value}
            type="button"
            onClick={() => onChange(tab.value)}
            className={cn(
              "rounded-lg py-2 text-[13px] font-semibold transition",
              ativo ? "bg-primary text-primary-foreground" : "text-muted-foreground",
            )}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );
}

export function Toggle({ on, onChange, rotulo }: { on: boolean; onChange: (on: boolean) => void; rotulo: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-label={rotulo}
      aria-checked={on}
      onClick={() => onChange(!on)}
      className={cn("relative h-6 w-10 rounded-full transition", on ? "bg-primary" : "bg-muted")}
    >
      <span
        className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all", on ? "left-[18px]" : "left-0.5")}
      />
    </button>
  );
}

export function Pill({
  tom = "primary",
  children,
  className,
}: {
  tom?: "primary" | "success" | "warning" | "destructive" | "muted";
  children: ReactNode;
  className?: string;
}) {
  const estilos: Record<string, string> = {
    primary: "bg-primary/15 text-primary",
    success: "bg-success/15 text-success",
    warning: "bg-warning/15 text-warning",
    destructive: "bg-destructive/15 text-destructive",
    muted: "bg-muted text-muted-foreground",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center whitespace-nowrap rounded-full px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wide",
        estilos[tom],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function Banner({
  tom = "success",
  icone,
  children,
  className,
}: {
  tom?: "success" | "warning" | "destructive" | "primary";
  icone?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  const estilos: Record<string, string> = {
    success: "bg-success/10 border-success/30 text-success",
    warning: "bg-warning/10 border-warning/40 text-warning",
    destructive: "bg-destructive/10 border-destructive/40 text-destructive",
    primary: "bg-primary/10 border-primary/40 text-primary",
  };
  return (
    <div className={cn("flex items-center gap-2 rounded-xl border px-3 py-2", estilos[tom], className)}>
      {icone}
      <p className="text-[11px]">{children}</p>
    </div>
  );
}

export function SearchField({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
}) {
  return (
    <div className="flex items-center gap-2 rounded-xl border border-border/60 bg-card-elev px-3 py-2.5">
      <Search className="h-4 w-4 text-muted-foreground" />
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="flex-1 bg-transparent text-[13px] outline-none placeholder:text-muted-foreground"
      />
    </div>
  );
}

export function NavRow({
  icone,
  titulo,
  descricao,
  onClick,
  className,
}: {
  icone: ReactNode;
  titulo: string;
  descricao?: string;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn("flex w-full items-center gap-3 px-3 py-3 text-left", className)}
    >
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 text-primary">{icone}</div>
      <div className="flex-1">
        <div className="text-[12px] font-semibold">{titulo}</div>
        {descricao && <div className="text-[10px] text-muted-foreground">{descricao}</div>}
      </div>
      <ChevronRight className="h-4 w-4 text-muted-foreground" />
    </button>
  );
}

export function CheckSquare({ marcado }: { marcado: boolean }) {
  return (
    <span
      className={cn(
        "flex h-5 w-5 items-center justify-center rounded-md border",
        marcado ? "border-primary bg-primary" : "border-border",
      )}
    >
      {marcado && <Check className="h-3.5 w-3.5 text-primary-foreground" />}
    </span>
  );
}

export function ProgressBar({
  valor,
  tom = "primary",
  className,
}: {
  valor: number;
  tom?: "primary" | "success" | "warning";
  className?: string;
}) {
  const cores: Record<string, string> = {
    primary: "bg-primary",
    success: "bg-success",
    warning: "bg-warning",
  };
  return (
    <div className={cn("h-1.5 overflow-hidden rounded-full bg-muted", className)}>
      <div
        className={cn("h-full rounded-full transition-all", cores[tom])}
        style={{ width: `${Math.min(100, Math.max(0, valor))}%` }}
      />
    </div>
  );
}

export function EmptyState({ titulo, descricao }: { titulo: string; descricao?: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-border/70 bg-card/60 px-4 py-8 text-center">
      <p className="text-[13px] font-semibold">{titulo}</p>
      {descricao && <p className="mt-1 text-[11px] text-muted-foreground">{descricao}</p>}
    </div>
  );
}
