import { useEffect } from "react";
import { useToast } from "@/components/Toast";
import { avisoDoSistema, tocarSomAlerta } from "@shared/lib/avisos";
import { useStore } from "@/store/store";

let loteJaAvisado = 0;

export function NotificadorAlertas() {
  const { lotesAlertas, preferences } = useStore();
  const { notificar } = useToast();

  useEffect(() => {
    if (!lotesAlertas || lotesAlertas.id === loteJaAvisado) return;
    loteJaAvisado = lotesAlertas.id;
    if (!preferences.notificacoes) return;

    const alertas = preferences.apenasCriticos
      ? lotesAlertas.alertas.filter((a) => a.nivel === "critico")
      : lotesAlertas.alertas;
    if (alertas.length === 0) return;

    const primeiro = alertas[0];
    const descricao =
      alertas.length === 1
        ? `${primeiro.placa} · ${primeiro.descricao}`
        : `${alertas.length} novos alertas. Último: ${primeiro.placa} · ${primeiro.descricao}`;
    notificar({
      titulo: primeiro.nivel === "critico" ? "Alerta crítico" : "Atenção: novo alerta",
      descricao,
      tom: "alert",
    });
    if (preferences.sons) tocarSomAlerta();
    avisoDoSistema(`LoadSense: ${alertas.length === 1 ? "novo alerta" : `${alertas.length} novos alertas`}`, descricao);
  }, [lotesAlertas, preferences, notificar]);

  return null;
}
