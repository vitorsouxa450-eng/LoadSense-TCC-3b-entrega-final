import { useState } from "react";
import { Copy, Loader2 } from "lucide-react";
import { api, ErroApi } from "@shared/lib/api";
import { useToast } from "@/components/Toast";

type Papel = "SUPERVISOR" | "OPERATOR" | "ADMINISTRATOR";

const OPCOES_CARGO: { valor: Papel; rotulo: string }[] = [
  { valor: "OPERATOR", rotulo: "Operador de Pesagem" },
  { valor: "SUPERVISOR", rotulo: "Supervisor de Operações" },
  { valor: "ADMINISTRATOR", rotulo: "Administrador" },
];

const mensagem = (erro: unknown) => (erro instanceof ErroApi ? erro.message : "Não foi possível falar com o servidor.");

export function CriarContaPainel() {
  const { notificar } = useToast();
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [papel, setPapel] = useState<Papel>("OPERATOR");
  const [criando, setCriando] = useState(false);
  const [novaConta, setNovaConta] = useState<{ nome: string; email: string; senha: string } | null>(null);

  async function criarConta() {
    if (nome.trim().length < 3) {
      notificar({ titulo: "Nome incompleto", descricao: "Informe pelo menos 3 letras.", tom: "alert" });
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      notificar({ titulo: "E-mail inválido", descricao: "Confira o endereço informado.", tom: "alert" });
      return;
    }
    setCriando(true);
    try {
      const r = await api.usuarios.criar({ nome: nome.trim(), email: email.trim(), papel });
      setNovaConta({ nome: r.usuario.nome, email: r.usuario.email, senha: r.senhaProvisoria });
      setNome("");
      setEmail("");
      setPapel("OPERATOR");
    } catch (e) {
      notificar({ titulo: "Não foi possível criar a conta", descricao: mensagem(e), tom: "alert" });
    } finally {
      setCriando(false);
    }
  }

  const copiarSenha = async () => {
    if (!novaConta) return;
    try {
      await navigator.clipboard.writeText(novaConta.senha);
      notificar({ titulo: "Senha copiada", tom: "success" });
    } catch {
      notificar({ titulo: "Não foi possível copiar", descricao: "Anote a senha manualmente.", tom: "alert" });
    }
  };

  return (
    <div className="space-y-3">
      {novaConta && (
        <div className="rounded-xl border border-success/40 bg-success/10 p-3">
          <p className="text-[12px] font-semibold">Conta criada para {novaConta.nome}</p>
          <p className="mt-1 text-[10px] text-muted-foreground">{novaConta.email}</p>
          <p className="mt-2 text-[10px]">
            Senha provisória (mostrada só agora). Entregue por um canal seguro. A pessoa precisará trocá-la no primeiro
            acesso.
          </p>
          <div className="mt-2 flex items-center gap-2">
            <code className="flex-1 select-all rounded-lg bg-card px-3 py-2 font-mono text-[12px]">
              {novaConta.senha}
            </code>
            <button
              type="button"
              onClick={() => void copiarSenha()}
              className="flex min-h-[40px] items-center gap-1.5 rounded-lg border border-border/60 bg-card px-3 text-[11px] font-semibold"
            >
              <Copy className="h-3.5 w-3.5" />
              Copiar
            </button>
          </div>
          <button
            type="button"
            onClick={() => setNovaConta(null)}
            className="mt-2 text-[11px] font-semibold text-primary"
          >
            Entendi, ocultar senha
          </button>
        </div>
      )}

      <div className="space-y-2 rounded-xl border border-border/60 bg-card-elev p-3">
        <p className="text-[10px] text-muted-foreground">
          A pessoa recebe uma senha provisória e cria a própria senha no primeiro acesso (mínimo de 8 caracteres, com
          maiúscula, número e símbolo).
        </p>
        <label className="block text-[11px] font-semibold">
          Nome completo
          <input
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            maxLength={140}
            className="mt-1 w-full rounded-lg border border-border/60 bg-card px-3 py-2 text-[12px]"
          />
        </label>
        <label className="block text-[11px] font-semibold">
          E-mail
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 w-full rounded-lg border border-border/60 bg-card px-3 py-2 text-[12px]"
          />
        </label>
        <label className="block text-[11px] font-semibold">
          Cargo
          <select
            value={papel}
            onChange={(e) => setPapel(e.target.value as Papel)}
            className="mt-1 w-full rounded-lg border border-border/60 bg-card px-3 py-2 text-[12px]"
          >
            {OPCOES_CARGO.map((o) => (
              <option key={o.valor} value={o.valor}>
                {o.rotulo}
              </option>
            ))}
          </select>
        </label>
        <button
          type="button"
          disabled={criando}
          onClick={() => void criarConta()}
          className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-primary text-[12px] font-semibold text-primary-foreground disabled:opacity-60"
        >
          {criando && <Loader2 className="h-3 w-3 animate-spin" />}
          Criar conta
        </button>
      </div>
    </div>
  );
}
