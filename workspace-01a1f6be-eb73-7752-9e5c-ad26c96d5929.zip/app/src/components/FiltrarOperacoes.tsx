import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Download, Search } from "lucide-react";
import { EmptyState } from "@/components/ui";
import { api, type MotoristaApi, type OperacaoApi, type ProdutoApi, type RotaApi } from "@shared/lib/api";
import { useStore } from "@/store/store";
import { cn, formatShortDate } from "@/lib/utils";

const LIMITE = 20;
const PERIODO_TODO = 3650;

const ESTADOS = [
  { valor: "", rotulo: "Todos os estados" },
  { valor: "COMPLETED", rotulo: "Concluídas" },
  { valor: "IN_PROGRESS", rotulo: "Em andamento" },
  { valor: "CANCELLED", rotulo: "Canceladas" },
];

const ROTULO_ESTADO: Record<string, string> = {
  COMPLETED: "Concluída",
  IN_PROGRESS: "Em andamento",
  CANCELLED: "Cancelada",
  DRAFT: "Rascunho",
};

const campo =
  "h-9 w-full rounded-lg border border-border/60 bg-card px-2 text-[12px] text-foreground focus:outline-none focus:ring-2 focus:ring-primary/60";

interface Filtros {
  de: string;
  ate: string;
  produtoId: string;
  motoristaId: string;
  origem: string;
  destino: string;
  estado: string;
}

const VAZIO: Filtros = { de: "", ate: "", produtoId: "", motoristaId: "", origem: "", destino: "", estado: "" };

function filtrarLocal(lista: ReturnType<typeof useStore>["operations"], f: Filtros) {
  return lista.filter((op) => {
    const data = (op.finalizadaEm ?? op.saida).slice(0, 10);
    if (f.de && data < f.de) return false;
    if (f.ate && data > f.ate) return false;
    if (f.produtoId && op.tipoCarga !== f.produtoId) return false;
    if (f.motoristaId && op.motorista !== f.motoristaId) return false;
    if (f.origem && op.origem !== f.origem) return false;
    if (f.destino && op.destino !== f.destino) return false;
    if (f.estado === "CANCELLED" && !op.cancelada) return false;
    if (f.estado === "COMPLETED" && (op.cancelada || op.status !== "Concluída")) return false;
    if (f.estado === "IN_PROGRESS" && (op.cancelada || op.status === "Concluída")) return false;
    return true;
  });
}

interface LinhaOperacao {
  id: string;
  codigo: string;
  data: string;
  placa: string;
  motorista: string;
  produto: string;
  rota: string;
  estado: string;
}

export function FiltrarOperacoes() {
  const { modo, operations } = useStore();
  const [filtros, setFiltros] = useState<Filtros>(VAZIO);
  const [pagina, setPagina] = useState(1);
  const [motoristas, setMotoristas] = useState<MotoristaApi[]>([]);
  const [produtos, setProdutos] = useState<ProdutoApi[]>([]);
  const [rotas, setRotas] = useState<RotaApi[]>([]);
  const [resultado, setResultado] = useState<{ linhas: LinhaOperacao[]; total: number }>({ linhas: [], total: 0 });
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState("");

  useEffect(() => {
    if (modo === "demo") return;
    Promise.all([api.motoristas(), api.produtos(), api.rotas()])
      .then(([m, p, r]) => {
        setMotoristas(m.motoristas);
        setProdutos(p.produtos);
        setRotas(r.rotas);
      })
      .catch(() => setErro("Não foi possível carregar motoristas, produtos e rotas."));
  }, [modo]);

  const opcoesLocais = useMemo(() => {
    const unicos = (valores: Array<string | undefined | null>) =>
      [...new Set(valores.filter((v): v is string => Boolean(v)))].sort((a, b) => a.localeCompare(b, "pt-BR"));
    return {
      produtos: unicos(operations.map((op) => op.tipoCarga)),
      motoristas: unicos(operations.map((op) => op.motorista)),
      origens: unicos(operations.map((op) => op.origem)),
      destinos: unicos(operations.map((op) => op.destino)),
    };
  }, [operations]);

  const origens = useMemo(
    () => (modo === "demo" ? opcoesLocais.origens : [...new Set(rotas.map((r) => r.origin))].sort()),
    [modo, opcoesLocais, rotas],
  );
  const destinos = useMemo(
    () => (modo === "demo" ? opcoesLocais.destinos : [...new Set(rotas.map((r) => r.destination))].sort()),
    [modo, opcoesLocais, rotas],
  );

  function consultaFiltros(): Record<string, string> {
    const c: Record<string, string> = {};
    if (filtros.de && filtros.ate) {
      c.inicio = filtros.de;
      c.fim = filtros.ate;
    } else {
      c.dias = String(PERIODO_TODO);
    }
    if (filtros.produtoId) c.produtoId = filtros.produtoId;
    if (filtros.motoristaId) c.motoristaId = filtros.motoristaId;
    if (filtros.origem) c.origem = filtros.origem;
    if (filtros.destino) c.destino = filtros.destino;
    if (filtros.estado) c.estado = filtros.estado;
    return c;
  }

  const [exportando, setExportando] = useState(false);

  async function exportarResultado(formato: "xlsx" | "csv") {
    setExportando(true);
    setErro("");
    try {
      if (modo === "demo") {
        const lista = filtrarLocal(operations, filtros);
        const cabecalho = ["Código", "Data", "Placa", "Motorista", "Produto", "Origem", "Destino", "Estado"];
        const linhas = lista.map((op) => [
          op.codigo ?? op.id,
          op.finalizadaEm ?? op.saida,
          op.placa,
          op.motorista,
          op.tipoCarga,
          op.origem,
          op.destino,
          op.cancelada ? "Cancelada" : op.status === "Concluída" ? "Concluída" : "Em andamento",
        ]);
        const csv = [cabecalho, ...linhas]
          .map((l) => l.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(";"))
          .join("\r\n");
        const url = URL.createObjectURL(new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" }));
        const a = document.createElement("a");
        a.href = url;
        a.download = "loadsense-operacoes-filtradas.csv";
        a.click();
        URL.revokeObjectURL(url);
      } else {
        await api.exportarPlanilha(consultaFiltros(), formato);
      }
    } catch (e) {
      setErro(e instanceof Error ? e.message : "Não foi possível exportar.");
    } finally {
      setExportando(false);
    }
  }

  useEffect(() => {
    if (modo === "demo") {
      const lista = filtrarLocal(operations, filtros);
      const inicio = (pagina - 1) * LIMITE;
      setResultado({
        total: lista.length,
        linhas: lista.slice(inicio, inicio + LIMITE).map((op) => ({
          id: op.id,
          codigo: op.codigo ?? op.id,
          data: op.finalizadaEm ?? op.saida,
          placa: op.placa,
          motorista: op.motorista,
          produto: op.tipoCarga,
          rota: `${op.origem} → ${op.destino}`,
          estado: op.cancelada ? "CANCELLED" : op.status === "Concluída" ? "COMPLETED" : "IN_PROGRESS",
        })),
      });
      return;
    }

    const consulta = new URLSearchParams({
      pagina: String(pagina),
      limite: String(LIMITE),
      ordem: "data",
      direcao: "desc",
      ...consultaFiltros(),
    });

    let cancelado = false;
    setCarregando(true);
    api
      .operacoesPagina(consulta.toString())
      .then((dados) => {
        if (cancelado) return;
        setErro("");
        setResultado({
          total: dados.total,
          linhas: dados.operacoes.map((o: OperacaoApi) => ({
            id: String(o.id),
            codigo: o.codigo,
            data: o.datas.concluidaEm ?? o.datas.iniciadaEm ?? o.datas.saidaReal ?? "",
            placa: o.veiculo.placa ?? "—",
            motorista: o.motorista ?? "—",
            produto: o.produto ?? "—",
            rota: `${o.rota.origem ?? "—"} → ${o.rota.destino ?? "—"}`,
            estado: o.estado,
          })),
        });
      })
      .catch(() => {
        if (!cancelado) setErro("Não foi possível consultar as operações.");
      })
      .finally(() => {
        if (!cancelado) setCarregando(false);
      });
    return () => {
      cancelado = true;
    };
  }, [modo, operations, filtros, pagina]);

  const alterar = (chave: keyof Filtros, valor: string) => {
    setFiltros((atual) => ({ ...atual, [chave]: valor }));
    setPagina(1);
  };

  const totalPaginas = Math.max(1, Math.ceil(resultado.total / LIMITE));
  const temFiltro = Object.values(filtros).some(Boolean);

  return (
    <div className="px-5 pt-4">
      <div className="grid grid-cols-2 gap-2 rounded-2xl border border-border/60 bg-card p-3">
        <label className="space-y-1 text-[10px] text-muted-foreground">
          De
          <input type="date" className={campo} value={filtros.de} onChange={(e) => alterar("de", e.target.value)} />
        </label>
        <label className="space-y-1 text-[10px] text-muted-foreground">
          Até
          <input type="date" className={campo} value={filtros.ate} onChange={(e) => alterar("ate", e.target.value)} />
        </label>
        <label className="space-y-1 text-[10px] text-muted-foreground">
          Produto
          <select className={campo} value={filtros.produtoId} onChange={(e) => alterar("produtoId", e.target.value)}>
            <option value="">Todos os produtos</option>
            {modo === "demo"
              ? opcoesLocais.produtos.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))
              : produtos.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
          </select>
        </label>
        <label className="space-y-1 text-[10px] text-muted-foreground">
          Motorista
          <select
            className={campo}
            value={filtros.motoristaId}
            onChange={(e) => alterar("motoristaId", e.target.value)}
          >
            <option value="">Todos os motoristas</option>
            {modo === "demo"
              ? opcoesLocais.motoristas.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))
              : motoristas.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.full_name}
                  </option>
                ))}
          </select>
        </label>
        <label className="space-y-1 text-[10px] text-muted-foreground">
          Origem
          <select className={campo} value={filtros.origem} onChange={(e) => alterar("origem", e.target.value)}>
            <option value="">Todas as origens</option>
            {origens.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
        </label>
        <label className="space-y-1 text-[10px] text-muted-foreground">
          Destino
          <select className={campo} value={filtros.destino} onChange={(e) => alterar("destino", e.target.value)}>
            <option value="">Todos os destinos</option>
            {destinos.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </label>
        <label className="col-span-2 space-y-1 text-[10px] text-muted-foreground">
          Estado
          <select className={campo} value={filtros.estado} onChange={(e) => alterar("estado", e.target.value)}>
            {ESTADOS.map((e) => (
              <option key={e.valor} value={e.valor}>
                {e.rotulo}
              </option>
            ))}
          </select>
        </label>
        {temFiltro && (
          <button
            type="button"
            onClick={() => {
              setFiltros(VAZIO);
              setPagina(1);
            }}
            className="col-span-2 text-left text-[11px] font-semibold text-primary"
          >
            Limpar filtros
          </button>
        )}
      </div>

      <p className="mt-3 flex items-center gap-1 text-[10px] text-muted-foreground" aria-live="polite">
        <Search className="h-3 w-3" />
        {carregando ? "Consultando…" : `${resultado.total} operação(ões) encontrada(s)`}
      </p>
      <div className="mt-2 flex gap-2">
        <button
          type="button"
          onClick={() => exportarResultado("csv")}
          disabled={exportando || carregando || resultado.total === 0}
          className="flex items-center gap-1 rounded-xl border border-border/60 bg-card-elev px-3 py-2 text-[11px] font-semibold disabled:opacity-50"
        >
          <Download className="h-3.5 w-3.5" /> Exportar CSV
        </button>
        {modo !== "demo" && (
          <button
            type="button"
            onClick={() => exportarResultado("xlsx")}
            disabled={exportando || carregando || resultado.total === 0}
            className="flex items-center gap-1 rounded-xl border border-border/60 bg-card-elev px-3 py-2 text-[11px] font-semibold disabled:opacity-50"
          >
            <Download className="h-3.5 w-3.5" /> Exportar planilha (XLSX)
          </button>
        )}
      </div>
      {erro && <p className="mt-2 text-[11px] text-destructive">{erro}</p>}

      <ul className="mt-2 space-y-2 pb-5">
        {resultado.linhas.map((linha) => (
          <li key={linha.id} className="rounded-2xl border border-border/60 bg-card p-3">
            <div className="flex items-center justify-between">
              <div className="text-[12px] font-bold">{linha.codigo}</div>
              <span
                className={cn(
                  "rounded px-2 py-0.5 text-[10px] font-semibold",
                  linha.estado === "CANCELLED"
                    ? "bg-destructive/15 text-destructive"
                    : linha.estado === "COMPLETED"
                      ? "bg-success/15 text-success"
                      : "bg-muted text-muted-foreground",
                )}
              >
                {ROTULO_ESTADO[linha.estado] ?? linha.estado}
              </span>
            </div>
            <div className="mt-1 text-[10px] text-muted-foreground">
              {linha.data ? formatShortDate(linha.data) : "—"} · {linha.placa} · {linha.motorista}
            </div>
            <div className="mt-1 text-[11px]">{linha.rota}</div>
            <div className="text-[10px] text-muted-foreground">Produto: {linha.produto}</div>
          </li>
        ))}

        {!carregando && resultado.linhas.length === 0 && (
          <li>
            <EmptyState
              titulo="Nenhuma operação encontrada"
              descricao="Ajuste os filtros para ver outros resultados."
            />
          </li>
        )}
      </ul>

      {resultado.total > LIMITE && (
        <div className="flex items-center justify-between pb-6">
          <button
            type="button"
            disabled={pagina <= 1}
            onClick={() => setPagina((p) => p - 1)}
            className="flex items-center gap-1 rounded-lg border border-border/60 px-3 py-2 text-[11px] disabled:opacity-40"
          >
            <ChevronLeft className="h-3 w-3" /> Anterior
          </button>
          <span className="text-[10px] text-muted-foreground">
            Página {pagina} de {totalPaginas}
          </span>
          <button
            type="button"
            disabled={pagina >= totalPaginas}
            onClick={() => setPagina((p) => p + 1)}
            className="flex items-center gap-1 rounded-lg border border-border/60 px-3 py-2 text-[11px] disabled:opacity-40"
          >
            Próxima <ChevronRight className="h-3 w-3" />
          </button>
        </div>
      )}
    </div>
  );
}
