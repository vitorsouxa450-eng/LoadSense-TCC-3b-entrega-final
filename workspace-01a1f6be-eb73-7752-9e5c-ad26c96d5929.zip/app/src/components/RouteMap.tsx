import { useState } from "react";
import { Bell, CircleCheck, Crosshair, Locate, Maximize, Minus, Navigation, Plus, Truck } from "lucide-react";
import { Link } from "react-router-dom";
import { Ring } from "@/components/charts";
import { Pill, ProgressBar } from "@/components/ui";
import type { Operation } from "@/data/types";
import { kmRestantes, pesoRealKg, progressPct } from "@/lib/analytics";
import { cn, formatKg, formatTime } from "@/lib/utils";

interface Ponto {
  id: string;
  placa: string;
  status: "Em rota" | "Parado" | "Carregando";
  x: number;
  y: number;
}

export function RouteMap({ operacoes }: { operacoes: Operation[] }) {
  const pontos: Ponto[] = operacoes.slice(0, 6).map((op, index) => ({
    id: op.id,
    placa: op.placa,
    status: op.status === "Em trânsito" ? "Em rota" : op.status === "Parado" ? "Parado" : "Carregando",
    x: 18 + ((index * 23) % 62),
    y: 16 + ((index * 31) % 66),
  }));

  return (
    <div className="relative overflow-hidden rounded-2xl border border-border/60 bg-[#050505]" style={{ height: 300 }}>
      {}
      <div className="absolute inset-0 ls-map-grid opacity-40" />

      <iframe
        title="Mapa de rastreamento"
        src="https://www.openstreetmap.org/export/embed.html?bbox=-48.5%2C-24.5%2C-44.0%2C-19.5&layer=mapnik"
        className="absolute inset-0 h-full w-full pointer-events-none"
        style={{ border: 0, filter: "invert(0.92) hue-rotate(180deg) saturate(0.6) brightness(0.95)" }}
        loading="lazy"
      />

      {}
      <svg viewBox="0 0 300 380" className="pointer-events-none absolute inset-0 h-full w-full">
        <path
          d="M30 340 C 80 280, 90 210, 150 180 S 240 90, 272 46"
          stroke="hsl(var(--primary))"
          strokeWidth="3"
          strokeDasharray="7 7"
          fill="none"
          strokeLinecap="round"
        />
        <circle cx="30" cy="340" r="5" fill="hsl(var(--primary))" />
        <circle cx="272" cy="46" r="5" fill="hsl(var(--success))" />
        <text x="40" y="360" fill="hsl(var(--muted-foreground))" fontSize="10">
          Origem
        </text>
        <text x="228" y="34" fill="hsl(var(--muted-foreground))" fontSize="10">
          Destino
        </text>
      </svg>

      {pontos.map((ponto) => (
        <div key={ponto.id} className="absolute" style={{ top: `${ponto.y}%`, left: `${ponto.x}%` }}>
          <div
            className={cn(
              "flex items-center gap-1 rounded-md px-2 py-1 text-[10px] font-semibold shadow",
              ponto.status === "Parado"
                ? "border border-primary bg-card-elev text-primary"
                : "bg-primary text-primary-foreground",
            )}
          >
            <Truck className="h-3 w-3" />
            {ponto.placa}
          </div>
          <p
            className={cn("mt-0.5 text-center text-[9px]", ponto.status === "Parado" ? "text-warning" : "text-success")}
          >
            {ponto.status}
          </p>
        </div>
      ))}

      <div className="absolute right-3 top-3 flex flex-col gap-2">
        {[Plus, Minus, Crosshair, Maximize].map((Icone, index) => (
          <button
            key={index}
            type="button"
            aria-label="Controle do mapa"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-border/60 bg-card-elev"
          >
            <Icone className="h-4 w-4" />
          </button>
        ))}
      </div>
    </div>
  );
}

export function OperationHighlight({ op }: { op: Operation }) {
  const pct = progressPct(op);
  const [seguindo, setSeguindo] = useState(false);

  return (
    <section className="mx-5 mt-4 rounded-2xl border border-border/60 bg-card p-4">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-primary">
          <Truck className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold">{op.placa}</span>
            <Pill tom={op.status === "Parado" ? "warning" : "success"}>{op.status}</Pill>
          </div>
          <div className="text-[10px] text-muted-foreground">
            {op.origem} → {op.destino}
          </div>
        </div>
        <div className="text-right">
          <div className="text-[10px] text-muted-foreground">ETA {formatTime(op.previsaoChegada)}</div>
          <div className="text-[10px] text-muted-foreground tabular">{kmRestantes(op)} km restantes</div>
        </div>
      </div>

      <dl className="mt-3 grid grid-cols-3 gap-2 text-[10px]">
        <div className="rounded-xl bg-card-elev px-2 py-1.5">
          <dt className="text-muted-foreground">Peso aferido</dt>
          <dd className="font-semibold tabular">{formatKg(pesoRealKg(op))}</dd>
        </div>
        <div className="rounded-xl bg-card-elev px-2 py-1.5">
          <dt className="text-muted-foreground">Carga</dt>
          <dd className="font-semibold">{op.tipoCarga}</dd>
        </div>
        <div className="rounded-xl bg-card-elev px-2 py-1.5">
          <dt className="text-muted-foreground">Motorista</dt>
          <dd className="truncate font-semibold">{op.motorista.split(" ")[0]}</dd>
        </div>
      </dl>

      <div className="mt-3">
        <div className="mb-1 flex justify-between text-[11px]">
          <span className="text-muted-foreground">Progresso da rota</span>
          <span className="font-semibold tabular">{pct}%</span>
        </div>
        <ProgressBar valor={pct} />
      </div>

      <div className="mt-3 flex gap-2">
        <Link
          to={`/operacoes/${op.id}`}
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary py-2.5 text-[12px] font-semibold text-primary-foreground"
        >
          <Ring value={pct} size={18} stroke={3}>
            <span className="text-[6px] font-bold text-primary-foreground">{pct}</span>
          </Ring>
          Abrir operação
        </Link>
        <button
          type="button"
          onClick={() => setSeguindo((valor) => !valor)}
          className={cn(
            "flex items-center gap-2 rounded-xl border px-3 py-2.5 text-[12px] font-semibold",
            seguindo ? "border-primary bg-primary/15 text-primary" : "border-border/60 bg-card-elev",
          )}
        >
          {seguindo ? <Locate className="h-4 w-4" /> : <Navigation className="h-4 w-4" />}
          {seguindo ? "Seguindo" : "Seguir"}
        </button>
      </div>

      {op.desvioKg > 0 && (
        <div className="mt-3 flex items-center gap-2 rounded-xl border border-warning/40 bg-warning/10 px-3 py-2">
          <Bell className="h-4 w-4 text-warning" />
          <p className="text-[11px] text-warning">
            Divergência de {op.desvioKg > 0 ? "+" : ""}
            {op.desvioKg.toLocaleString("pt-BR")} kg identificada nas pesagens desta viagem.
          </p>
        </div>
      )}

      {op.desvioKg === 0 && (
        <div className="mt-3 flex items-center gap-2 rounded-xl border border-success/30 bg-success/10 px-3 py-2">
          <CircleCheck className="h-4 w-4 text-success" />
          <p className="text-[11px] text-success">Pesagens conferidas e dentro da margem esperada.</p>
        </div>
      )}
    </section>
  );
}
