import { useEffect, useState } from "react";

const ALTURA_BASE = 900;
const LARGURA_BASE = 420;

export function useEscalaCelular(): number {
  const calcular = () => {
    if (typeof window === "undefined") return 1;
    const porAltura = window.innerHeight / ALTURA_BASE;
    const porLargura = window.innerWidth / LARGURA_BASE;
    return Math.max(0.5, Math.min(porAltura, porLargura));
  };
  const [escala, setEscala] = useState(calcular);
  useEffect(() => {
    const ajustar = () => setEscala(calcular());
    window.addEventListener("resize", ajustar);
    return () => window.removeEventListener("resize", ajustar);
  }, []);
  return escala;
}

export function estiloEscala(escala: number): React.CSSProperties {
  return { zoom: escala, height: `calc(100vh / ${escala})`, width: `calc(100vw / ${escala})` } as React.CSSProperties;
}
