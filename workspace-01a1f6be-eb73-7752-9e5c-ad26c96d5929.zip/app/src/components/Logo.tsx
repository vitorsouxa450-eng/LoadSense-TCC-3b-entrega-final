import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  size?: "sm" | "lg";
  somenteSimbolo?: boolean;
}

export function Logo({ className, size = "sm", somenteSimbolo = false }: LogoProps) {
  const tamanhoIcone = size === "lg" ? "h-11 w-11" : "h-6 w-6";
  const tamanhoTexto = size === "lg" ? "text-2xl" : "text-base";

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <img src="/loadsense-icon.png" alt="LoadSense" className={cn(tamanhoIcone, "object-contain")} draggable={false} />
      {!somenteSimbolo && (
        <span className={cn("font-brand font-black tracking-tight", tamanhoTexto)}>
          <span className="text-foreground">LOAD</span>
          <span className="text-primary">SENSE</span>
        </span>
      )}
    </div>
  );
}
