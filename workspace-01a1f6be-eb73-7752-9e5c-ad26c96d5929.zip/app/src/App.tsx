import { useState } from "react";
import { ServidorIndisponivelPage } from "@/pages/ServidorIndisponivelPage";
import { precisaConfigurarServidor, ServidorSetup } from "@/components/ServidorSetup";
import { HashRouter, MemoryRouter, Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import { ToastProvider, useToast } from "@/components/Toast";
import { EXIGE_SERVIDOR, StoreProvider, useStore } from "@/store/store";
import { SplashGate } from "@/pages/SplashPage";
import { SplashPage } from "@/pages/SplashPage";
import { TermsPage } from "@/pages/TermsPage";
import { LoginPage } from "@/pages/LoginPage";
import {
  EsqueciSenhaPage,
  NovaSenhaPage,
  SenhaAlteradaPage,
  TrocarSenhaPage,
  VerificarCodigoPage,
} from "@/pages/RecuperacaoPages";
import { DashboardPage } from "@/pages/DashboardPage";
import { MonitoramentoPage } from "@/pages/MonitoramentoPage";
import { OperacoesPage } from "@/pages/OperacoesPage";
import { OperacaoDetalhePage } from "@/pages/OperacaoDetalhePage";
import { AlertasPage } from "@/pages/AlertasPage";
import { AlertaDetalhePage } from "@/pages/AlertaDetalhePage";
import { RelatoriosPage } from "@/pages/RelatoriosPage";
import { RelatorioDetalhePage } from "@/pages/RelatorioDetalhePage";
import { ConfiguracoesPage } from "@/pages/ConfiguracoesPage";
import { PerfilPage } from "@/pages/PerfilPage";
import { AlterarSenhaPage } from "@/pages/AlterarSenhaPage";
import { useInatividade } from "@shared/lib/inatividade";
import { HistoricoPage } from "@/pages/HistoricoPage";
import { PreferenciasPage } from "@/pages/PreferenciasPage";
import { StatusPage } from "@/pages/StatusPage";
import { SobrePage } from "@/pages/SobrePage";
import { PlanosPage } from "@/pages/PlanosPage";
import { NotFoundPage } from "@/pages/NotFoundPage";
import { AjudaPage } from "@/pages/AjudaPage";
import { CriarContaPage } from "@/pages/CriarContaPage";
import {
  SegurancaPage,
  EquipePage,
  CargosPage,
  PermissoesCargosPage,
  MeusDadosPage,
  RotasCadastroPage,
} from "@/pages/ConfigSubPaginas";

const ROTAS_PUBLICAS = /^\/(login|termos|splash|esqueci-senha|verificar-codigo|nova-senha|senha-alterada)$/;

function ConectandoServidor() {
  return (
    <div className="flex h-full min-h-screen items-center justify-center bg-background px-6 text-center">
      <div>
        <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        <p className="mt-4 text-[13px] text-muted-foreground">Conectando ao servidor…</p>
      </div>
    </div>
  );
}

function PortaDeEntrada({ children }: { children: React.ReactNode }) {
  const { precisaLogin, servidorIndisponivel, precisaTrocarSenha, conectando, modo, sessao, sair } = useStore();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { notificar } = useToast();
  useInatividade(modo === "servidor" && !!sessao && !precisaLogin, async () => {
    await sair();
    notificar({
      titulo: "Sessão encerrada",
      descricao: "Você ficou inativo por 30 minutos. Entre novamente.",
      tom: "info",
    });
    navigate("/login", { replace: true });
  });
  if (servidorIndisponivel) return <ServidorIndisponivelPage />;
  if (EXIGE_SERVIDOR && conectando) return <ConectandoServidor />;
  if (precisaLogin && !ROTAS_PUBLICAS.test(pathname)) return <Navigate to="/login" replace />;
  if (precisaTrocarSenha && pathname !== "/trocar-senha") return <Navigate to="/trocar-senha" replace />;
  return <>{children}</>;
}

export function AppRoutes() {
  const { pathname } = useLocation();
  return (
    <PortaDeEntrada>
      {}
      <div key={pathname} className="ls-tela animate-ls-tela min-h-full">
        <Routes>
          <Route
            path="/"
            element={
              <SplashGate>
                <DashboardPage />
              </SplashGate>
            }
          />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/splash" element={<SplashPage />} />
          <Route path="/termos" element={<TermsPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/esqueci-senha" element={<EsqueciSenhaPage />} />
          <Route path="/trocar-senha" element={<TrocarSenhaPage />} />
          <Route path="/verificar-codigo" element={<VerificarCodigoPage />} />
          <Route path="/nova-senha" element={<NovaSenhaPage />} />
          <Route path="/senha-alterada" element={<SenhaAlteradaPage />} />
          <Route path="/monitoramento" element={<MonitoramentoPage />} />
          <Route path="/operacoes" element={<OperacoesPage />} />
          <Route path="/operacoes/:id" element={<OperacaoDetalhePage />} />
          <Route path="/alertas" element={<AlertasPage />} />
          <Route path="/alertas/:id" element={<AlertaDetalhePage />} />
          <Route path="/relatorios" element={<RelatoriosPage />} />
          <Route path="/relatorios/:id" element={<RelatorioDetalhePage />} />
          <Route path="/configuracoes" element={<ConfiguracoesPage />} />
          <Route path="/perfil" element={<PerfilPage />} />
          <Route path="/alterar-senha" element={<AlterarSenhaPage />} />
          <Route path="/historico" element={<HistoricoPage />} />
          <Route path="/preferencias" element={<PreferenciasPage />} />
          <Route path="/status" element={<StatusPage />} />
          <Route path="/sobre" element={<SobrePage />} />
          <Route path="/planos" element={<PlanosPage />} />
          <Route path="/ajuda" element={<AjudaPage />} />
          <Route path="/criar-conta" element={<CriarContaPage />} />
          <Route path="/seguranca" element={<SegurancaPage />} />
          <Route path="/equipe" element={<EquipePage />} />
          <Route path="/cargos" element={<CargosPage />} />
          <Route path="/rotas-cadastro" element={<RotasCadastroPage />} />
          <Route path="/permissoes-cargos" element={<PermissoesCargosPage />} />
          <Route path="/meus-dados" element={<MeusDadosPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </div>
    </PortaDeEntrada>
  );
}

function Roteador({ children }: { children: React.ReactNode }) {
  const base = typeof document !== "undefined" ? document.baseURI : "";
  const temUrlValida = /^https?:/i.test(base);
  const hashInicial = typeof window !== "undefined" ? window.location.hash.replace(/^#/, "") : "";

  return temUrlValida ? (
    <HashRouter>{children}</HashRouter>
  ) : (
    <MemoryRouter initialEntries={[hashInicial || "/"]}>{children}</MemoryRouter>
  );
}

function AppPrincipal() {
  return (
    <StoreProvider>
      <ToastProvider>
        <Roteador>
          <AppRoutes />
        </Roteador>
      </ToastProvider>
    </StoreProvider>
  );
}

export default function App() {
  const [pronto, setPronto] = useState(!precisaConfigurarServidor());
  if (!pronto) return <ServidorSetup onConcluir={() => setPronto(true)} />;
  return <AppPrincipal />;
}
