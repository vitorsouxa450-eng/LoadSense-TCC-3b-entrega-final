const memory = new Map<string, string>();

function getBackend(kind: "local" | "session"): Storage | null {
  try {
    const storage = kind === "local" ? window.localStorage : window.sessionStorage;
    const probe = "__ls_probe__";
    storage.setItem(probe, "1");
    storage.removeItem(probe);
    return storage;
  } catch {
    return null;
  }
}

function read(kind: "local" | "session", key: string): string | null {
  const backend = getBackend(kind);
  if (!backend) return memory.get(`${kind}:${key}`) ?? null;
  try {
    return backend.getItem(key);
  } catch {
    return memory.get(`${kind}:${key}`) ?? null;
  }
}

function write(kind: "local" | "session", key: string, value: string) {
  const backend = getBackend(kind);
  if (!backend) {
    memory.set(`${kind}:${key}`, value);
    return;
  }
  try {
    backend.setItem(key, value);
  } catch {
    memory.set(`${kind}:${key}`, value);
  }
}

function remove(kind: "local" | "session", key: string) {
  const backend = getBackend(kind);
  memory.delete(`${kind}:${key}`);
  try {
    backend?.removeItem(key);
  } catch {}
}

export const localStore = {
  get: (key: string) => read("local", key),
  set: (key: string, value: string) => write("local", key, value),
  remove: (key: string) => remove("local", key),
  getJSON<T>(key: string, fallback: T): T {
    const raw = read("local", key);
    if (!raw) return fallback;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  },
  setJSON: (key: string, value: unknown) => write("local", key, JSON.stringify(value)),
};

export const sessionStore = {
  get: (key: string) => read("session", key),
  set: (key: string, value: string) => write("session", key, value),
  remove: (key: string) => remove("session", key),
};
