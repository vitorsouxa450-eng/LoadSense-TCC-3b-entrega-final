import type { Alert, Operation, ReportKpis } from "@/data/types";
import { PONTOS_PESAGEM, ROTAS } from "@/data/seeder";
import { clamp, formatTime } from "@/lib/utils";

const HOUR = 3600_000;
const DAY = 24 * HOUR;

export function isActive(op: Operation) {
  return op.status !== "Concluída";
}

export function progressPct(op: Operation) {
  if (op.status === "Concluída") return 100;
  if (!op.distanciaKm || !Number.isFinite(op.distanciaKm)) return 0;
  return clamp(Math.round((op.kmPercorrido / op.distanciaKm) * 100), 0, 100);
}

export function pesoRealKg(op: Operation) {
  return op.taraKg + op.pesoCargaKg + op.desvioKg;
}

export function pesoEsperadoKg(op: Operation) {
  return op.taraKg + op.pesoCargaKg;
}

export function kmRestantes(op: Operation) {
  return Math.max(0, Math.round(op.distanciaKm - op.kmPercorrido));
}

export function mesmoDia(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

export function horasDeViagem(op: Operation) {
  const inicio = +new Date(op.saida);
  const fim = op.finalizadaEm ? +new Date(op.finalizadaEm) : Date.now();
  return (fim - inicio) / HOUR;
}

export function dailySeries(operations: Operation[], days: number, metric: "toneladas" | "viagens") {
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  const buckets = Array.from({ length: days }, (_, index) => {
    const dia = new Date(hoje.getTime() - (days - 1 - index) * DAY);
    return { dia, valor: 0 };
  });

  operations.forEach((op) => {
    const saida = new Date(op.saida);
    const indice = buckets.findIndex((bucket) => mesmoDia(bucket.dia, saida));
    if (indice < 0) return;
    buckets[indice].valor += metric === "toneladas" ? op.pesoCargaKg / 1000 : 1;
  });

  return buckets.map((bucket) => Number(bucket.valor.toFixed(1)));
}

export interface DashboardSummary {
  viagensHoje: number;
  emRota: number;
  concluidasHoje: number;
  cargas: number;
  toneladasHoje: number;
  mediaPorViagemT: number;
  frotaAtiva: number;
  alertasAtivos: number;
  alertasCriticos: number;
  alertasAtencao: number;
  eficienciaPct: number;
  divergenciasHoje: number;
  serieToneladas: number[];
  serieViagens: number[];
}

export function dashboardSummary(operations: Operation[], alerts: Alert[]): DashboardSummary {
  const agora = new Date();
  const deHoje = operations.filter((op) => mesmoDia(new Date(op.saida), agora));
  const ativas = operations.filter(isActive);
  const concluidasHoje = deHoje.filter((op) => op.status === "Concluída");
  const alertasAtivosList = alerts.filter((alert) => alert.status === "ativo");
  const divergenciasHoje = deHoje.filter((op) => op.desvioKg > 0).length;
  const atrasadas = deHoje.filter((op) => {
    if (op.status === "Concluída") return false;
    return +new Date(op.previsaoChegada) < Date.now();
  }).length;

  const toneladasHoje = deHoje.reduce((total, op) => total + op.pesoCargaKg / 1000, 0);
  const eficienciaBase = deHoje.length || 1;
  const eficienciaPct = clamp(Math.round(100 - ((divergenciasHoje + atrasadas) / eficienciaBase) * 100), 0, 100);

  return {
    viagensHoje: deHoje.length,
    emRota: ativas.length,
    concluidasHoje: concluidasHoje.length,
    cargas: deHoje.length,
    toneladasHoje: Number(toneladasHoje.toFixed(1)),
    mediaPorViagemT: Number((toneladasHoje / Math.max(1, deHoje.length)).toFixed(1)),
    frotaAtiva: new Set(ativas.map((op) => op.placa)).size,
    alertasAtivos: alertasAtivosList.length,
    alertasCriticos: alertasAtivosList.filter((alert) => alert.nivel === "critico").length,
    alertasAtencao: alertasAtivosList.filter((alert) => alert.nivel === "atencao").length,
    eficienciaPct,
    divergenciasHoje,
    serieToneladas: dailySeries(operations, 10, "toneladas"),
    serieViagens: dailySeries(operations, 10, "viagens"),
  };
}

export interface TipoCargaSlice {
  label: string;
  valorT: number;
  pct: number;
  cor: string;
}

const CORES_TIPO = [
  "hsl(var(--primary))",
  "hsl(38 95% 55%)",
  "hsl(0 0% 45%)",
  "hsl(var(--success))",
  "hsl(16 70% 40%)",
  "hsl(0 0% 62%)",
];

export function distribuicaoPorTipo(operations: Operation[], desde?: number, ate?: number): TipoCargaSlice[] {
  const grupos = new Map<string, number>();
  operations
    .filter((op) => {
      const saida = +new Date(op.saida);
      if (desde && saida < desde) return false;
      if (ate && saida > ate) return false;
      return true;
    })
    .forEach((op) => {
      const chave = op.tipoCarga.replace(/\s*\(.*\)/, "");
      grupos.set(chave, (grupos.get(chave) ?? 0) + op.pesoCargaKg / 1000);
    });

  const total = Array.from(grupos.values()).reduce((acc, value) => acc + value, 0) || 1;
  return Array.from(grupos.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([label, valorT], index) => ({
      label,
      valorT: Number(valorT.toFixed(1)),
      pct: Math.round((valorT / total) * 100),
      cor: CORES_TIPO[index % CORES_TIPO.length],
    }));
}

export interface DivergenciaRow {
  operacaoId: string;
  placa: string;
  diferencaKg: number;
  data: string;
}

export function principaisDivergencias(operations: Operation[], limite = 5): DivergenciaRow[] {
  return operations
    .filter((op) => op.desvioKg > 0)
    .sort((a, b) => b.desvioKg - a.desvioKg)
    .slice(0, limite)
    .map((op) => ({
      operacaoId: op.id,
      placa: op.placa,
      diferencaKg: op.desvioKg,
      data: op.saida,
    }));
}

export function resumirPeriodo(
  operations: Operation[],
  alerts: Alert[],
  desde: number,
  ate: number,
): { kpis: ReportKpis; tipos: TipoCargaSlice[]; divergencias: DivergenciaRow[] } {
  const noPeriodo = operations.filter((op) => {
    const saida = +new Date(op.saida);
    return saida >= desde && saida <= ate;
  });
  const alertasNoPeriodo = alerts.filter((alert) => {
    const criado = +new Date(alert.criadoEm);
    return criado >= desde && criado <= ate;
  });
  const volumeT = noPeriodo.reduce((total, op) => total + op.pesoCargaKg / 1000, 0);
  const divergentes = noPeriodo.filter((op) => op.desvioKg > 0).length;
  const pesagens = noPeriodo.reduce((total, op) => total + op.pesagens.length, 0);

  return {
    kpis: {
      viagens: noPeriodo.length,
      cargas: noPeriodo.length,
      pesagens,
      volumeT: Number(volumeT.toFixed(1)),
      taxaDivergenciaPct: Number(((divergentes / Math.max(1, noPeriodo.length)) * 100).toFixed(1)),
      eficienciaPct: Number(clamp(100 - (divergentes / Math.max(1, noPeriodo.length)) * 100, 0, 100).toFixed(1)),
      alertas: alertasNoPeriodo.length,
      mediaPorViagemT: Number((volumeT / Math.max(1, noPeriodo.length)).toFixed(1)),
    },
    tipos: distribuicaoPorTipo(operations, desde, ate),
    divergencias: principaisDivergencias(noPeriodo.length ? noPeriodo : operations),
  };
}

export interface HistoricoRow {
  id: string;
  data: string;
  placa: string;
  vazioKg: number;
  cargaKg: number;
  realKg: number;
  desvioKg: number;
  status: "ok" | "alerta";
  local: string;
}

export function construirHistorico(operations: Operation[]): HistoricoRow[] {
  return operations
    .filter((op) => op.pesagens.some((pesagem) => pesagem.tipo === "carregado"))
    .map((op) => ({
      id: op.id,
      data: op.pesagens[op.pesagens.length - 1]?.registradoEm ?? op.saida,
      placa: op.placa,
      vazioKg: op.taraKg,
      cargaKg: op.pesoCargaKg,
      realKg: pesoRealKg(op),
      desvioKg: op.desvioKg,
      status: op.desvioKg > 0 ? ("alerta" as const) : ("ok" as const),
      local: op.pesagens[op.pesagens.length - 1]?.local ?? PONTOS_PESAGEM[0],
    }))
    .sort((a, b) => +new Date(b.data) - +new Date(a.data));
}

export function trajetoDaOperacao(op: Operation) {
  const saida = +new Date(op.saida);
  const duracao = Math.max(1, +new Date(op.previsaoChegada) - saida);
  const passos = [
    { local: `${op.origem} (Origem)`, info: "Saída do pátio · 0 km", fracao: 0 },
    { local: "Balança de origem", info: "Pesagem de vazio e carga · 58 km", fracao: 0.12 },
    { local: "Ponto intermediário", info: "Passagem em rota · conferência RFID", fracao: 0.42 },
    { local: "Balança intermediária", info: "Pesagem em rota · conferência de divergência", fracao: 0.7 },
    { local: `${op.destino} (Destino)`, info: "Descarga e baixa da operação", fracao: 1 },
  ];

  return passos.map((passo) => {
    const km = Math.round(op.distanciaKm * passo.fracao);
    const quando = new Date(saida + duracao * passo.fracao);
    const concluido = op.kmPercorrido >= km;
    return {
      ...passo,
      km,
      horario: concluido ? formatTime(quando) : `ETA ${formatTime(quando)}`,
      concluido,
      atual: !concluido && op.kmPercorrido < km && op.kmPercorrido >= km - op.distanciaKm * 0.25,
    };
  });
}

export function statusPrevisao(op: Operation): { texto: string; tom: "success" | "warning" | "muted" } {
  if (op.status === "Concluída") {
    return { texto: "Concluída", tom: "success" };
  }
  const atrasoMin = Math.round((Date.now() - +new Date(op.previsaoChegada)) / 60_000);
  if (atrasoMin > 15) return { texto: `Atrasada em ${Math.round(atrasoMin / 60)} h`, tom: "warning" };
  if (op.status === "Parado") return { texto: "Parado fora da rota", tom: "warning" };
  if (op.status === "Carregando") return { texto: "Em carregamento no pátio", tom: "muted" };
  const restanteMin = Math.round((+new Date(op.previsaoChegada) - Date.now()) / 60_000);
  return { texto: `No prazo · ETA ${Math.max(0, restanteMin)} min`, tom: "success" };
}

export function rotaAleatoriaPara(index: number) {
  return ROTAS[index % ROTAS.length];
}
