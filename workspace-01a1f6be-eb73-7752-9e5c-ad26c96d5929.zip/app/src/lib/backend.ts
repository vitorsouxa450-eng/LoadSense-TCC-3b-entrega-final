import type { Alert, Operation, Preferences, Profile, ReportDefinition, SensorsState, Weighing } from "@/data/types";
import type {
  AlertaApi,
  AssinaturaApi,
  DispositivoApi,
  DocumentoPendenteApi,
  OperacaoApi,
  OperacaoDetalheApi,
  PainelApi,
  RotaApi,
  VeiculoApi,
} from "@shared/lib/api";

const STATUS_POR_ESTAGIO: Record<string, Weighing["tipo"]> = {
  EMPTY_TRUCK: "vazio",
  SEPARATED_CARGO: "intermediaria",
  LOADED_TRUCK: "carregado",
};

const ROTULO_ESTAGIO: Record<string, string> = {
  EMPTY_TRUCK: "Balança — caminhão vazio",
  SEPARATED_CARGO: "Balança — carga separada",
  LOADED_TRUCK: "Balança — caminhão carregado",
};

function statusDoApp(operacao: OperacaoApi): Operation["status"] {
  if (operacao.estado === "CANCELLED") return "Concluída";
  if (operacao.estado === "DRAFT" || operacao.estado === "IN_PROGRESS") return "Carregando";
  const rastreio = operacao.rastreio?.estado ?? "NOT_STARTED";
  if (rastreio === "IN_TRANSIT") return "Em trânsito";
  if (rastreio === "STOPPED" || rastreio === "SIGNAL_LOST") return "Parado";
  if (rastreio === "ARRIVED") return "Concluída";
  if (rastreio === "CANCELLED") return "Concluída";
  if (rastreio === "NOT_STARTED" && !operacao.datas.chegadaReal) return "Carregando";
  return "Concluída";
}

function pesagemDeAgregados(operacao: OperacaoApi): Weighing[] {
  const p = operacao.pesos;
  const rfid = operacao.rfid ?? operacao.veiculo.placa ?? "—";
  const quando = operacao.datas.concluidaEm ?? operacao.datas.iniciadaEm ?? new Date().toISOString();
  const lista: Weighing[] = [];
  if (p.vazioAferidoKg !== null)
    lista.push({
      id: `${operacao.id}-vazio`,
      tipo: "vazio",
      pesoKg: p.vazioAferidoKg,
      desvioKg: 0,
      local: operacao.posto ?? "Balança",
      registradoEm: quando,
      rfid,
    });
  if (p.cargaSeparadaKg !== null)
    lista.push({
      id: `${operacao.id}-separada`,
      tipo: "intermediaria",
      pesoKg: p.cargaSeparadaKg,
      desvioKg: 0,
      local: operacao.posto ?? "Balança",
      registradoEm: quando,
      rfid,
    });
  if (p.brutoAferidoKg !== null && p.vazioAferidoKg !== null)
    lista.push({
      id: `${operacao.id}-carregado`,
      tipo: "carregado",
      pesoKg: p.brutoAferidoKg,
      desvioKg: p.desvioKg ?? 0,
      local: operacao.posto ?? "Balança",
      registradoEm: quando,
      rfid,
    });
  return lista;
}

export function operacaoParaApp(operacao: OperacaoApi): Operation {
  const inicio = operacao.datas.iniciadaEm ?? new Date().toISOString();
  const distancia = operacao.rota.distanciaKm ?? 0;
  const chegou = operacao.rastreio?.estado === "ARRIVED" || Boolean(operacao.datas.chegadaReal);
  const progresso = operacao.rastreio?.progressoPct ?? (chegou ? 100 : 0);
  const previsao =
    operacao.rastreio?.eta ??
    operacao.datas.chegadaPlanejada ??
    new Date(new Date(inicio).getTime() + Math.max(distancia, 1) * 90_000).toISOString();
  const tara = operacao.pesos.vazioAferidoKg ?? operacao.pesos.taraCadastradaKg ?? 0;
  const cargaDeclarada = operacao.pesos.cargaDeclaradaKg ?? operacao.pesos.cargaAferidaKg ?? 0;

  return {
    id: String(operacao.id),
    codigo: operacao.codigo,
    cancelada: operacao.estado === "CANCELLED",
    rfid: operacao.rfid ?? `RF-${operacao.veiculo.placa ?? operacao.id}`,
    rastreioAtivado: Boolean(operacao.rastreioAtivado),
    placa: operacao.veiculo.placa ?? "—",
    motorista: operacao.motorista ?? "Não informado",
    tipoCarga: operacao.produto ?? "Carga geral",
    origem: operacao.rota.origem ?? operacao.unidade ?? "Origem",
    destino: operacao.rota.destino ?? "Destino",
    distanciaKm: distancia,
    kmPercorrido: Math.round(((distancia * progresso) / 100) * 10) / 10,
    saida: operacao.datas.saidaReal ?? inicio,
    previsaoChegada: previsao,
    finalizadaEm: operacao.datas.chegadaReal ?? operacao.datas.concluidaEm ?? undefined,
    limiteKg: operacao.pesos.limiteBrutoKg ?? 0,
    taraKg: tara,
    pesoCargaKg: cargaDeclarada,
    desvioKg: operacao.pesos.desvioKg ?? 0,
    status: statusDoApp(operacao),
    pesagens: pesagemDeAgregados(operacao),
  };
}

export function detalheParaApp(detalhe: OperacaoDetalheApi): Operation {
  const base = operacaoParaApp(detalhe);
  const pesagens: Weighing[] = detalhe.leituras
    .filter((leitura) => leitura.aceita)
    .map((leitura) => ({
      id: String(leitura.id),
      tipo: STATUS_POR_ESTAGIO[leitura.estagio] ?? "intermediaria",
      pesoKg: leitura.pesoKg,
      desvioKg: leitura.estagio === "LOADED_TRUCK" ? base.desvioKg : 0,
      local: `${ROTULO_ESTAGIO[leitura.estagio]}${leitura.origem === "MANUAL" ? " · manual" : ""}`,
      registradoEm: leitura.aceitoEm ?? leitura.medidoEm,
      rfid: base.rfid,
    }));
  return { ...base, pesagens: pesagens.length ? pesagens : base.pesagens };
}

export function alertaParaApp(alerta: AlertaApi): Alert {
  const contexto = alerta.contextoJson ?? {};
  const duracao =
    typeof contexto.duracao_minutos === "number"
      ? (contexto.duracao_minutos as number)
      : typeof contexto.duration_minutes === "number"
        ? (contexto.duration_minutes as number)
        : undefined;
  const pesoReal = alerta.desvioKg !== null && alerta.desvioKg !== undefined ? Math.abs(alerta.desvioKg) : undefined;

  return {
    id: String(alerta.id),
    operacaoId: alerta.operacaoId !== null ? String(alerta.operacaoId) : (alerta.operacaoCodigo ?? ""),
    placa: alerta.veiculo ?? "—",
    motorista: alerta.motorista ?? "—",
    tipo: alerta.titulo,
    nivel: alerta.nivel === "CRITICAL" ? "critico" : "atencao",
    status: alerta.situacao === "RESOLVED" ? "resolvido" : "ativo",
    descricao: alerta.mensagem,
    criadoEm: alerta.criadoEm,
    resolvidoEm: alerta.resolvidoEm ?? undefined,
    diferencaKg: pesoReal,
    duracaoMin: duracao,
    extra: alerta.notasResolucao ?? undefined,
    motivoResolucao: alerta.motivoResolucao ?? undefined,
    resolvidoPor: alerta.resolvidoPor ?? undefined,
  };
}

export interface MedicaoServidor {
  servidorMs?: number;
  bancoMs?: number;
}

export function sensoresDoHardware(dispositivos: DispositivoApi[], medicao: MedicaoServidor = {}): SensorsState {
  const porTipo = (tipo: DispositivoApi["device_type"]) => dispositivos.find((d) => d.device_type === tipo);
  const momento = (texto?: string | null) => (texto ? new Date(texto).getTime() : null);
  const esp32 = porTipo("ESP32");
  const rfid = porTipo("RFID_READER");
  const gprs = porTipo("GPRS_MODEM");
  const balanca = porTipo("SCALE_CONTROLLER") ?? porTipo("LOAD_CELL");

  return {
    esp32: {
      ok: esp32?.state === "ONLINE",
      serie: esp32?.serial_number ?? "—",
      firmware: esp32?.firmware_version ?? "—",
      ultimoSinal: momento(esp32?.last_seen_at),
    },
    rfid: {
      ok: rfid?.state === "ONLINE",
      cadastrado: Boolean(rfid),
      ultimaLeitura: momento(rfid?.last_seen_at),
      tag: rfid?.serial_number ?? "—",
    },
    balanca: {
      ok: balanca?.state === "ONLINE",
      estado: balanca?.state ?? "AUSENTE",
      nome: balanca?.name ?? "Balança não cadastrada",
      calibradoEm: momento(balanca?.calibrado_em ?? balanca?.last_calibrated_at),
      validaAte: momento(balanca?.calibracao_valida_ate),
      ultimoSinal: momento(balanca?.last_seen_at),
    },
    servidor: { ok: medicao.servidorMs !== undefined, latenciaMs: medicao.servidorMs ?? 0 },
    gprs: {
      ok: gprs?.state === "ONLINE",
      cadastrado: Boolean(gprs),
      tecnologia: "GPRS/GSM",
      sinalPct: null,
      ultimoSinal: momento(gprs?.last_seen_at),
    },
    banco: { ok: medicao.bancoMs !== undefined, latenciaMs: medicao.bancoMs ?? null },
    ultimaSync: Date.now(),
  };
}

export function perfilDaSessao(
  usuario: { nome: string; email: string; telefone?: string | null; papel: string },
  empresa: { nome: string; cnpj?: string | null },
  assinatura?: AssinaturaApi | null,
): Profile {
  return {
    nome: usuario.nome,
    email: usuario.email,
    telefone: usuario.telefone ?? "",
    empresa: empresa.nome,
    cargo:
      usuario.papel === "ADMINISTRATOR"
        ? "Administrador"
        : usuario.papel === "SUPERVISOR"
          ? "Supervisor de Operações"
          : "Operador de Pesagem",
    plano: assinatura?.plan_name ?? "—",
    permissoes: usuario.papel,
    cnpj: empresa.cnpj ?? "",
  };
}

export function preferenciasDaApi(preferencias: Record<string, unknown> | null | undefined): Preferences | null {
  if (!preferencias) return null;
  return {
    notificacoes: Boolean(preferencias.push_notifications_enabled ?? 1),
    sons: Boolean(preferencias.sound_alerts_enabled ?? 1),
    apenasCriticos: false,
    autoSync: Boolean(preferencias.automatic_sync_enabled ?? 1),
    biometria: false,
    temaEscuro: String(preferencias.theme ?? "DARK") !== "LIGHT",
    idioma: "PT-BR",
  };
}

export function preferenciasParaApi(preferencias: Preferences) {
  return {
    tema: preferencias.temaEscuro ? "DARK" : "LIGHT",
    notificacoes: preferencias.notificacoes,
    sons: preferencias.sons,
    autoSync: preferencias.autoSync,
    idioma: "pt-BR",
  };
}

export function rotasParaApp(rotas: RotaApi[]) {
  return rotas.map((rota) => ({
    id: rota.id,
    codigo: rota.code ?? String(rota.id),
    origem: rota.origin,
    destino: rota.destination,
    km: rota.distance_km ?? 0,
    waypoints: rota.waypoints ?? [],
  }));
}

export function veiculosParaFormulario(veiculos: VeiculoApi[]) {
  return veiculos.map((v) => ({
    id: v.id,
    placa: v.plate,
    frota: v.fleet_code,
    taraKg: v.registered_tare_kg ?? 0,
    limiteKg: v.gross_weight_limit_kg ?? 0,
    capacidadeKg: v.payload_limit_kg ?? 0,
    rfid: v.rfid_code,
  }));
}

export function serieDoPainel(painel: PainelApi) {
  return painel.serie.map((dia) => ({
    dia: dia.dia,
    operacoes: dia.operacoes,
    concluidas: dia.concluidas,
    toneladas: Math.round((dia.carga_kg / 1000) * 10) / 10,
    criticas: dia.criticas,
  }));
}

export function relatorioParaApp(relatorio: {
  id: number;
  tipo: string;
  inicio: string;
  fim: string;
  formato?: string;
  geradoEm?: string;
}): ReportDefinition {
  const tipo = relatorio.tipo.toLowerCase();
  const tipoApp: ReportDefinition["tipo"] =
    tipo.includes("SEMANAL") || tipo.includes("WEEKLY")
      ? "semanal"
      : tipo.includes("TRIMESTRAL") || tipo.includes("QUARTERLY")
        ? "trimestral"
        : "mensal";
  const inicio = relatorio.inicio.slice(0, 10);
  const fim = relatorio.fim.slice(0, 10);
  return {
    id: String(relatorio.id),
    titulo: `${tipoApp === "semanal" ? "Relatório semanal" : tipoApp === "trimestral" ? "Relatório trimestral" : "Relatório mensal"} · ${inicio.slice(8, 10)}/${inicio.slice(5, 7)} a ${fim.slice(8, 10)}/${fim.slice(5, 7)}`,
    periodo: `${inicio.slice(8, 10)}/${inicio.slice(5, 7)}/${inicio.slice(0, 4)} – ${fim.slice(8, 10)}/${fim.slice(5, 7)}/${fim.slice(0, 4)}`,
    tipo: tipoApp,
    inicio,
    fim,
  };
}

export function documentoPendenteParaTermo(documento: DocumentoPendenteApi) {
  return {
    id: documento.legal_document_id,
    titulo: documento.title,
    versao: documento.version,
    tipo: documento.document_type,
    conteudo: documento.content ?? "",
  };
}
