export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

const kgFormatter = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 });
const tFormatter = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 1 });

export function formatKg(value: number, unit = "kg") {
  return `${kgFormatter.format(Math.round(value))} ${unit}`.trim();
}

export function formatNumber(value: number, digits = 0) {
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: digits }).format(value);
}

export function formatTons(valueInTons: number) {
  return `${tFormatter.format(valueInTons)} t`;
}

export function formatSigned(value: number, unit = "kg") {
  const sign = value > 0 ? "+" : value < 0 ? "-" : "";
  return `${sign}${kgFormatter.format(Math.abs(Math.round(value)))} ${unit}`.trim();
}

const dateFormatter = new Intl.DateTimeFormat("pt-BR", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
});

const shortDateFormatter = new Intl.DateTimeFormat("pt-BR", {
  day: "2-digit",
  month: "2-digit",
});

const timeFormatter = new Intl.DateTimeFormat("pt-BR", {
  hour: "2-digit",
  minute: "2-digit",
});

export function formatDate(iso: string | Date) {
  return dateFormatter.format(typeof iso === "string" ? new Date(iso) : iso);
}

export function formatShortDate(iso: string | Date) {
  return shortDateFormatter.format(typeof iso === "string" ? new Date(iso) : iso);
}

export function formatTime(iso: string | Date) {
  return timeFormatter.format(typeof iso === "string" ? new Date(iso) : iso);
}

export function timeAgo(timestamp: number) {
  const diff = Math.max(0, Date.now() - timestamp);
  const seconds = Math.floor(diff / 1000);
  if (seconds < 60) return `há ${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `há ${minutes} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `há ${hours} h`;
  return `há ${Math.floor(hours / 24)} d`;
}

export function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

export function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

export function uid(prefix = "id") {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-3)}`;
}
