import { useCallback, useEffect, useState } from "react";
import { localStore } from "@/lib/storage";

export type Theme = "dark" | "light";
const THEME_KEY = "loadsense-theme";

function detectInitialTheme(): Theme {
  const stored = localStore.get(THEME_KEY);
  if (stored === "light" || stored === "dark") return stored;
  return "dark";
}

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => detectInitialTheme());

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("light", theme === "light");
    root.classList.toggle("dark", theme === "dark");
    root.style.colorScheme = theme;
    localStore.set(THEME_KEY, theme);
  }, [theme]);

  const toggle = useCallback(() => {
    setTheme((current) => (current === "dark" ? "light" : "dark"));
  }, []);

  return { theme, setTheme, toggle };
}
