import type { Alert, Operation, ReportDefinition, SensorsState, Weighing } from "@/data/types";

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rnd = mulberry32(20260208);
const between = (min: number, max: number) => min + rnd() * (max - min);
const intBetween = (min: number, max: number) => Math.round(between(min, max));

const HOUR = 3600_000;
const DAY = 24 * HOUR;

export const ROTAS = [
  { origem: "São Paulo – SP", destino: "Uberlândia – MG", km: 612 },
  { origem: "São Paulo – SP", destino: "Goiânia – GO", km: 926 },
  { origem: "Campinas – SP", destino: "Porto Alegre – RS", km: 1180 },
  { origem: "São Paulo – SP", destino: "Belo Horizonte – MG", km: 586 },
  { origem: "Ribeirão Preto – SP", destino: "Curitiba – PR", km: 674 },
  { origem: "Sorocaba – SP", destino: "Rio de Janeiro – RJ", km: 449 },
  { origem: "São José dos Campos – SP", destino: "Vitória – ES", km: 838 },
  { origem: "Jundiaí – SP", destino: "Brasília – DF", km: 1015 },
  { origem: "Santos – SP", destino: "Florianópolis – SC", km: 786 },
  { origem: "Limeira – SP", destino: "Salvador – BA", km: 1965 },
  { origem: "São Paulo – SP", destino: "Campo Grande – MS", km: 1014 },
  { origem: "Piracicaba – SP", destino: "Cuiabá – MT", km: 1620 },
] as const;

export const TIPOS_CARGA = [
  "Grãos (soja)",
  "Grãos (milho)",
  "Cimento",
  "Minério",
  "Fertilizantes",
  "Aço laminado",
  "Açúcar",
  "Cargas gerais",
] as const;

export const MOTORISTAS = [
  "Carlos Henrique",
  "João Batista",
  "Marcos Vinícius",
  "Antônio Ferreira",
  "Rafael Lima",
  "Pedro Alves",
  "José Ricardo",
  "Bruno Cardoso",
  "Diego Martins",
  "Luís Fernando",
  "Eduardo Prado",
  "Sérgio Nunes",
] as const;

export const FROTA = [
  "ABC1234",
  "DEF5678",
  "XYZ4567",
  "MNO7650",
  "GHI9012",
  "JKL3456",
  "OHI8872",
  "PQR6789",
  "STU2458",
  "VWX1357",
  "YZA6876",
  "BCD5432",
  "EFG4321",
  "HIJ8765",
  "KLM2109",
  "NOP6543",
  "QRS0987",
  "TUV3210",
  "WXY7654",
  "ZAB1098",
  "CDE9876",
  "FGH5432",
  "IJK2109",
  "LMN7654",
] as const;

export const PONTOS_PESAGEM = [
  "Pátio de origem",
  "Balança Jundiaí – SP",
  "Balança Campinas – SP",
  "Balança Ribeirão Preto – SP",
  "Balança Uberaba – MG",
  "Destino",
] as const;

export const LIMITE_LEGAL_KG = 33_000;
const TARA_MIN = 8_400;
const TARA_MAX = 9_300;
const CARGA_MIN = 9_500;
const CARGA_MAX = 17_800;

function rfidTag(placa: string) {
  let hash = 0;
  for (const char of placa) hash = (hash * 31 + char.charCodeAt(0)) % 0xffffff;
  return `RF-${hash.toString(16).toUpperCase().padStart(6, "0")}`;
}

function isoDay(offsetDays: number, hour: number, minute: number) {
  const base = new Date();
  base.setHours(hour, minute, 0, 0);
  return new Date(base.getTime() - offsetDays * DAY).toISOString();
}

function buildWeighings(
  placa: string,
  taraKg: number,
  pesoCargaKg: number,
  desvioKg: number,
  saida: Date,
  progresso: number,
  pontos: number,
): Weighing[] {
  const rfid = rfidTag(placa);
  const list: Weighing[] = [
    {
      id: `${placa}-p0`,
      tipo: "vazio",
      pesoKg: taraKg,
      desvioKg: 0,
      local: PONTOS_PESAGEM[0],
      registradoEm: saida.toISOString(),
      rfid,
    },
    {
      id: `${placa}-p1`,
      tipo: "carregado",
      pesoKg: taraKg + pesoCargaKg,
      desvioKg: 0,
      local: PONTOS_PESAGEM[1],
      registradoEm: new Date(saida.getTime() + 42 * 60_000).toISOString(),
      rfid,
    },
  ];

  if (pontos > 2 && progresso > 0.35) {
    const intermediaria = new Date(saida.getTime() + Math.max(90, Math.round(progresso * 8 * 60)) * 60_000);
    list.push({
      id: `${placa}-p2`,
      tipo: "intermediaria",
      pesoKg: taraKg + pesoCargaKg + desvioKg,
      desvioKg,
      local: PONTOS_PESAGEM[2],
      registradoEm: intermediaria.toISOString(),
      rfid,
    });
  }

  if (progresso >= 1) {
    list.push({
      id: `${placa}-p3`,
      tipo: "carregado",
      pesoKg: taraKg + pesoCargaKg + desvioKg,
      desvioKg,
      local: PONTOS_PESAGEM[PONTOS_PESAGEM.length - 1],
      registradoEm: new Date(saida.getTime() + Math.round(between(6, 14) * HOUR)).toISOString(),
      rfid,
    });
  }

  return list;
}

function makeOperationId(index: number) {
  return `OP-${1042 - index}`;
}

interface SeedOperation {
  operation: Operation;
  alerts: Omit<Alert, "id">[];
  divergente: boolean;
}

function seedOperation(options: {
  index: number;
  placa: string;
  status: Operation["status"];
  progresso: number;
  diaOffset: number;
  horaSaida: number;
  desvioKg?: number;
  pontosPesagem?: number;
  comAlerta?: boolean;
  paradaMin?: number;
  atrasoMin?: number;
}): SeedOperation {
  const {
    index,
    placa,
    status,
    progresso,
    diaOffset,
    horaSaida,
    desvioKg = 0,
    pontosPesagem = 3,
    comAlerta = false,
    paradaMin = 18,
    atrasoMin = 40,
  } = options;

  const rota = ROTAS[index % ROTAS.length];
  const motorista = MOTORISTAS[index % MOTORISTAS.length];
  const tipoCarga = TIPOS_CARGA[index % TIPOS_CARGA.length];
  const taraKg = Math.round(between(TARA_MIN, TARA_MAX));
  const pesoCargaKg = Math.round(between(CARGA_MIN, CARGA_MAX));
  const saida = new Date(isoDay(diaOffset, horaSaida, intBetween(0, 55)));
  const duracaoH = Math.max(5, rota.km / between(58, 72) + 1.5);
  const previsaoChegada = new Date(saida.getTime() + Math.round(duracaoH * HOUR) + atrasoMin * 60_000);
  const kmPercorrido = Math.round(rota.km * progresso);
  const concluida = progresso >= 1;

  const operation: Operation = {
    id: makeOperationId(index),
    rfid: rfidTag(placa),
    placa,
    motorista,
    tipoCarga,
    origem: rota.origem,
    destino: rota.destino,
    distanciaKm: rota.km,
    kmPercorrido: concluida ? rota.km : kmPercorrido,
    saida: saida.toISOString(),
    previsaoChegada: previsaoChegada.toISOString(),
    finalizadaEm: concluida ? new Date(saida.getTime() + Math.round(duracaoH * HOUR)).toISOString() : undefined,
    limiteKg: LIMITE_LEGAL_KG,
    taraKg,
    pesoCargaKg,
    desvioKg,
    temperaturaC: Number(between(18, 31).toFixed(1)),
    status: concluida ? "Concluída" : status,
    pesagens: buildWeighings(placa, taraKg, pesoCargaKg, desvioKg, saida, progresso, pontosPesagem),
  };

  const alerts: Omit<Alert, "id">[] = [];

  if (desvioKg > 300) {
    const critico = taraKg + pesoCargaKg + desvioKg > LIMITE_LEGAL_KG || desvioKg > 1000;
    alerts.push({
      operacaoId: operation.id,
      placa,
      motorista,
      tipo: "Sobrecarga detectada",
      nivel: critico ? "critico" : "atencao",
      status: "ativo",
      descricao:
        "Peso total da carga acima do limite permitido para o veículo. Recomenda-se ajuste imediato e nova pesagem antes de seguir viagem.",
      criadoEm: new Date(saida.getTime() + Math.round(4.5 * HOUR)).toISOString(),
      pesoEsperadoKg: taraKg + pesoCargaKg,
      pesoRealKg: taraKg + pesoCargaKg + desvioKg,
      diferencaKg: desvioKg,
      extra: `Diferença: ${desvioKg > 0 ? "+" : ""}${desvioKg.toLocaleString("pt-BR")} kg`,
    });
  }

  if (comAlerta && paradaMin > 0) {
    alerts.push({
      operacaoId: operation.id,
      placa,
      motorista,
      tipo: "Parada não programada",
      nivel: paradaMin > 25 ? "critico" : "atencao",
      status: desvioKg > 0 ? "resolvido" : "ativo",
      descricao: "Veículo parado fora da rota prevista por tempo acima do tolerado pela operação.",
      criadoEm: new Date(saida.getTime() + Math.round(2.2 * HOUR)).toISOString(),
      duracaoMin: paradaMin,
      extra: `Duração: ${paradaMin} min`,
      resolvidoEm: desvioKg > 0 ? new Date(saida.getTime() + Math.round(3 * HOUR)).toISOString() : undefined,
    });
  }

  if (atrasoMin > 30 && !concluida) {
    alerts.push({
      operacaoId: operation.id,
      placa,
      motorista,
      tipo: "Atraso na entrega",
      nivel: "atencao",
      status: "ativo",
      descricao: "ETA acima da janela prevista para a entrega. Cliente deve ser comunicado.",
      criadoEm: new Date(saida.getTime() + Math.round(3.6 * HOUR)).toISOString(),
      extra: `Atraso estimado: ${atrasoMin} min`,
    });
  }

  return { operation, alerts, divergente: desvioKg > 0 };
}

export interface SeedResult {
  operations: Operation[];
  alerts: Alert[];
  sensors: SensorsState;
  reports: ReportDefinition[];
  geradoEm: number;
}

export function seedDatabase(): SeedResult {
  const seeds: SeedOperation[] = [];
  const now = new Date();

  const hojeEmRota: Array<Partial<Parameters<typeof seedOperation>[0]> & { placa: string; progresso: number }> = [
    { placa: "ABC1234", progresso: 0.72, status: "Em trânsito", horaSaida: 6, desvioKg: 0 },
    { placa: "DEF5678", progresso: 0.48, status: "Em trânsito", horaSaida: 6, comAlerta: true },
    { placa: "XYZ4567", progresso: 0.3, status: "Parado", horaSaida: 5, comAlerta: true, paradaMin: 34 },
    { placa: "MNO7650", progresso: 0.96, status: "Em trânsito", horaSaida: 4 },
    { placa: "GHI9012", progresso: 0.61, status: "Em trânsito", horaSaida: 7, atrasoMin: 52 },
    { placa: "JKL3456", progresso: 0.42, status: "Em trânsito", horaSaida: 7, desvioKg: 450 },
    { placa: "OHI8872", progresso: 0.18, status: "Carregando", horaSaida: 9, pontosPesagem: 1 },
    { placa: "PQR6789", progresso: 0.55, status: "Em trânsito", horaSaida: 8 },
    { placa: "STU2458", progresso: 0.83, status: "Em trânsito", horaSaida: 5 },
    { placa: "VWX1357", progresso: 0.26, status: "Em trânsito", horaSaida: 9 },
    { placa: "YZA6876", progresso: 0.67, status: "Em trânsito", horaSaida: 6, desvioKg: 230 },
    { placa: "BCD5432", progresso: 0.12, status: "Carregando", horaSaida: 10, pontosPesagem: 1 },
    { placa: "EFG4321", progresso: 0.74, status: "Em trânsito", horaSaida: 5 },
    { placa: "HIJ8765", progresso: 0.36, status: "Parado", horaSaida: 8, comAlerta: true, paradaMin: 21 },
    { placa: "KLM2109", progresso: 0.9, status: "Em trânsito", horaSaida: 4 },
    { placa: "NOP6543", progresso: 0.5, status: "Em trânsito", horaSaida: 7 },
    { placa: "QRS0987", progresso: 0.22, status: "Em trânsito", horaSaida: 10 },
    { placa: "TUV3210", progresso: 0.79, status: "Em trânsito", horaSaida: 5, atrasoMin: 0 },
  ];

  const hojeConcluidas = ["WXY7654", "ZAB1098", "CDE9876", "FGH5432", "IJK2109", "LMN7654"];

  hojeEmRota.forEach((item, index) => {
    const alvo = Math.max(0.05, Math.min(0.98, item.progresso));
    seeds.push(
      seedOperation({
        index,
        placa: item.placa,
        status: (item.status ?? "Em trânsito") as Operation["status"],
        progresso: alvo,
        diaOffset: 0,
        horaSaida: (item.horaSaida ?? 6) as number,
        desvioKg: item.desvioKg ?? 0,
        pontosPesagem: (item.pontosPesagem ?? 3) as number,
        comAlerta: Boolean(item.comAlerta),
        paradaMin: (item.paradaMin ?? 18) as number,
        atrasoMin: (item.atrasoMin ?? 0) as number,
      }),
    );
  });

  hojeConcluidas.forEach((placa, i) => {
    seeds.push(
      seedOperation({
        index: 18 + i,
        placa,
        status: "Concluída",
        progresso: 1,
        diaOffset: 0,
        horaSaida: 3 + i,
        desvioKg: i === 2 ? 320 : 0,
        comAlerta: false,
        atrasoMin: 0,
      }),
    );
  });

  const historicoPlacas = FROTA.slice(6);
  let indiceHistorico = 0;
  for (let diaOffset = 1; diaOffset <= 30; diaOffset += 1) {
    const viagensDoDia = intBetween(7, 13);
    for (let j = 0; j < viagensDoDia; j += 1) {
      const placa = historicoPlacas[indiceHistorico % historicoPlacas.length];
      const desvio =
        indiceHistorico % 29 === 4 ? intBetween(210, 480) : indiceHistorico % 71 === 7 ? intBetween(1200, 2100) : 0;
      seeds.push(
        seedOperation({
          index: 24 + indiceHistorico,
          placa,
          status: "Concluída",
          progresso: 1,
          diaOffset,
          horaSaida: intBetween(4, 11),
          desvioKg: desvio,
          comAlerta: indiceHistorico % 7 === 3,
          paradaMin: intBetween(15, 40),
          atrasoMin: 0,
        }),
      );
      indiceHistorico += 1;
    }
  }

  const operations = seeds.map((seed) => seed.operation);

  const alerts: Alert[] = seeds
    .flatMap((seed) => seed.alerts)
    .map((alert, index) => ({ ...alert, id: `AL-${String(index + 1).padStart(3, "0")}` }))
    .sort((a, b) => +new Date(b.criadoEm) - +new Date(a.criadoEm));

  const finalizadas = new Set(operations.filter((op) => op.status === "Concluída").map((op) => op.id));
  alerts.forEach((alert) => {
    if (finalizadas.has(alert.operacaoId) && alert.status === "ativo") {
      alert.status = "resolvido";
      alert.resolvidoEm = new Date(new Date(alert.criadoEm).getTime() + 70 * 60_000).toISOString();
    }
  });

  const dayStart = new Date(now);
  dayStart.setHours(0, 0, 0, 0);
  const reports: ReportDefinition[] = [
    {
      id: "rel-mensal",
      titulo: "Relatório Mensal — Operação completa",
      periodo: "Últimos 30 dias",
      tipo: "mensal",
      inicio: new Date(dayStart.getTime() - 29 * DAY).toISOString(),
      fim: dayStart.toISOString(),
    },
    {
      id: "rel-semanal",
      titulo: "Relatório Semanal — Semana atual",
      periodo: "Últimos 7 dias",
      tipo: "semanal",
      inicio: new Date(dayStart.getTime() - 6 * DAY).toISOString(),
      fim: new Date(dayStart.getTime() + DAY).toISOString(),
    },
    {
      id: "rel-trimestral",
      titulo: "Relatório Trimestral — Últimos 90 dias",
      periodo: "Últimos 90 dias",
      tipo: "trimestral",
      inicio: new Date(dayStart.getTime() - 89 * DAY).toISOString(),
      fim: new Date(dayStart.getTime() + DAY).toISOString(),
    },
  ];

  const sensors: SensorsState = {
    esp32: { ok: true, serie: "LS-ESP32-0021", firmware: "v1.4.2", ultimoSinal: Date.now() - 4_000 },
    rfid: { ok: true, cadastrado: true, ultimaLeitura: Date.now() - 12_000, tag: rfidTag("ABC1234") },
    balanca: {
      ok: true,
      estado: "ONLINE",
      nome: "HX711 · Célula de carga",
      calibradoEm: Date.now() - 10 * 86_400_000,
      validaAte: Date.now() + 83 * 86_400_000,
      ultimoSinal: Date.now() - 2_000,
    },
    servidor: { ok: true, latenciaMs: 84 },
    gprs: { ok: true, cadastrado: true, tecnologia: "4G", sinalPct: 92, ultimoSinal: Date.now() - 4_000 },
    banco: { ok: true, latenciaMs: 22 },
    ultimaSync: Date.now() - 62_000,
  };

  return { operations, alerts, sensors, reports, geradoEm: now.getTime() };
}

export const PESO_LIMITE_POR_EIXO_KG = LIMITE_LEGAL_KG;
