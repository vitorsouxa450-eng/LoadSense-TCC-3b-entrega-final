export type OperationStatus = "Em trânsito" | "Parado" | "Carregando" | "Concluída";

export type AlertLevel = "critico" | "atencao";
export type AlertStatus = "ativo" | "resolvido";

export type WeighingKind = "vazio" | "carregado" | "intermediaria";

export interface Weighing {
  id: string;
  tipo: WeighingKind;
  pesoKg: number;
  desvioKg: number;
  local: string;
  registradoEm: string;
  rfid: string;
}

export interface Operation {
  id: string;
  codigo?: string;
  rastreioAtivado?: boolean;
  cancelada?: boolean;
  rfid: string;
  placa: string;
  motorista: string;
  tipoCarga: string;
  origem: string;
  destino: string;
  distanciaKm: number;
  kmPercorrido: number;
  saida: string;
  previsaoChegada: string;
  finalizadaEm?: string;
  limiteKg: number;
  taraKg: number;
  pesoCargaKg: number;
  desvioKg: number;
  temperaturaC?: number;
  status: OperationStatus;
  pesagens: Weighing[];
}

export interface Alert {
  id: string;
  operacaoId: string;
  placa: string;
  motorista: string;
  tipo: string;
  nivel: AlertLevel;
  status: AlertStatus;
  descricao: string;
  criadoEm: string;
  resolvidoEm?: string;
  pesoEsperadoKg?: number;
  pesoRealKg?: number;
  diferencaKg?: number;
  duracaoMin?: number;
  extra?: string;
  motivoResolucao?: string;
  resolvidoPor?: string;
}

export interface SensorEndpoint {
  id: string;
  nome: string;
  icone: "cpu" | "scan" | "refresh" | "server" | "signal" | "database";
  status: string;
  detalhe: string;
  ok: boolean;
}

export type EstadoBalanca = "ONLINE" | "OFFLINE" | "MAINTENANCE" | "DISABLED" | "AUSENTE";

export interface SensorsState {
  esp32: { ok: boolean; serie: string; firmware: string; ultimoSinal: number | null };
  rfid: { ok: boolean; cadastrado: boolean; ultimaLeitura: number | null; tag: string };
  balanca: {
    ok: boolean;
    estado: EstadoBalanca;
    nome: string;
    calibradoEm: number | null;
    validaAte: number | null;
    ultimoSinal: number | null;
  };
  servidor: { ok: boolean; latenciaMs: number };
  gprs: { ok: boolean; cadastrado: boolean; tecnologia: string; sinalPct: number | null; ultimoSinal: number | null };
  banco: { ok: boolean; latenciaMs: number | null };
  ultimaSync: number;
}

export interface Preferences {
  notificacoes: boolean;
  sons: boolean;
  apenasCriticos: boolean;
  autoSync: boolean;
  biometria: boolean;
  temaEscuro: boolean;
  idioma: "PT-BR" | "EN" | "ES";
}

export interface Profile {
  nome: string;
  email: string;
  telefone: string;
  empresa: string;
  cargo: string;
  plano: string;
  permissoes: string;
  cnpj: string;
}

export interface ReportKpis {
  viagens: number;
  cargas: number;
  pesagens: number;
  volumeT: number;
  taxaDivergenciaPct: number;
  eficienciaPct: number;
  alertas: number;
  mediaPorViagemT: number;
}

export interface ReportDefinition {
  id: string;
  titulo: string;
  periodo: string;
  tipo: "mensal" | "semanal" | "trimestral";
  inicio: string;
  fim: string;
}
