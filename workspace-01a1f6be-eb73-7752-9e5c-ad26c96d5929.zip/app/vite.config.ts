import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const API_ALVO =
  (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env?.LS_API_URL ??
  "http://127.0.0.1:5174";

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": new URL("./src", import.meta.url).pathname,
      "@shared": new URL("../shared/src", import.meta.url).pathname,
    },
    dedupe: ["react", "react-dom", "lucide-react", "leaflet"],
  },
  server: {
    host: "0.0.0.0",
    port: 5173,
    allowedHosts: true,
    strictPort: false,
    proxy: {
      "/api": {
        target: API_ALVO,
        changeOrigin: true,
      },
    },
  },
  preview: {
    host: "0.0.0.0",
    port: 4173,
    allowedHosts: true,
    proxy: {
      "/api": { target: API_ALVO, changeOrigin: true },
    },
  },
  build: {
    outDir: "dist",
    sourcemap: false,
  },
});
