import { ErroHttp } from "./util.js";

export function limitarTentativas({ janelaMs, max, chave = "ip", nome }) {
  const registros = new Map();

  setInterval(
    () => {
      const agora = Date.now();
      for (const [k, v] of registros) if (v.inicio + janelaMs < agora) registros.delete(k);
    },
    Math.max(janelaMs, 60_000),
  ).unref();

  return (req, _res, next) => {
    if (process.env.LS_LIMITE_DESATIVADO === "1") return next();
    const ip = req.ip ?? "desconhecido";
    const extra =
      chave === "email"
        ? String(req.body?.email ?? "")
            .toLowerCase()
            .trim()
        : "";
    const k = `${nome}|${ip}|${extra}`;
    const agora = Date.now();
    let r = registros.get(k);
    if (!r || r.inicio + janelaMs < agora) {
      r = { inicio: agora, total: 0 };
      registros.set(k, r);
    }
    r.total += 1;
    if (r.total > max) {
      const minutos = Math.ceil((r.inicio + janelaMs - agora) / 60_000);
      return next(new ErroHttp(429, `Muitas tentativas. Aguarde ${minutos} min e tente de novo.`));
    }
    next();
  };
}
