import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { ErroHttp, asyncHandler, id, requerer, texto } from "./util.js";
import { exec, um, q } from "./db.js";
import { segredoJwt } from "./segredo.js";
import { consumirCodigo, enviarCodigo } from "./segundo-fator.js";

const SEGREDO = segredoJwt();
const VALIDADE_ACESSO = process.env.LS_ACCESS_TTL ?? "30m";
const DIAS_REFRESH = Number(process.env.LS_REFRESH_DIAS ?? 30);
const MAX_TENTATIVAS = 5;
const BLOQUEIO_MINUTOS = 15;

export const hashParaSessao = (token) => crypto.createHash("sha256").update(token).digest("hex");
export const hashSenha = (senha) => bcrypt.hash(senha, 12);
export const conferirSenha = (senha, hash) => bcrypt.compare(senha, hash);

export async function buscarUsuario(email) {
  return q(
    `SELECT u.id, u.company_id, u.role_id, u.full_name, u.email, u.password_hash, u.phone,
            u.active, u.must_change_password, u.failed_login_attempts, u.locked_until,
            u.totp_enabled,
            c.trade_name AS empresa, c.legal_name AS razao_social, c.slug AS empresa_slug,
            c.document_number AS cnpj, c.timezone_name,
            r.name AS papel, r.description AS papel_descricao
       FROM users u
       JOIN companies c ON c.id = u.company_id
       JOIN roles r ON r.company_id = u.company_id AND r.id = u.role_id
      WHERE u.email = ?
        AND u.active = 1
        AND c.active = 1`,
    [email],
  );
}

export async function permissoesDoUsuario(companyId, roleId) {
  const linhas = await q(
    `SELECT p.code
       FROM role_permissions rp
       JOIN permissions p ON p.id = rp.permission_id
      WHERE rp.role_id = ?
        AND EXISTS (SELECT 1 FROM roles r WHERE r.id = rp.role_id AND r.company_id = ? AND r.active = 1)
      ORDER BY p.code`,
    [roleId, companyId],
  );
  return linhas.map((l) => l.code);
}

async function registrarDispositivo(usuario, corpo, agente, ip) {
  const uuid = texto(corpo.dispositivoUuid) ?? `web-${crypto.randomUUID()}`;
  const existente = await um(
    `SELECT id FROM user_devices WHERE company_id = ? AND user_id = ? AND device_uuid = ? LIMIT 1`,
    [usuario.company_id, usuario.id, uuid],
  );
  if (existente) {
    await exec(
      `UPDATE user_devices
          SET platform = ?, device_name = ?, app_version_name = ?, os_version = ?,
              active = 1, last_seen_at = CURRENT_TIMESTAMP(3)
        WHERE id = ?`,
      [
        texto(corpo.plataforma) ?? "WEB",
        texto(corpo.dispositivoNome),
        texto(corpo.versaoApp),
        texto(agente)?.slice(0, 60),
        existente.id,
      ],
    );
    return existente.id;
  }
  const res = await exec(
    `INSERT INTO user_devices (company_id, user_id, device_uuid, platform, device_name, app_version_name, os_version, last_seen_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP(3))`,
    [
      usuario.company_id,
      usuario.id,
      uuid,
      texto(corpo.plataforma) ?? "WEB",
      texto(corpo.dispositivoNome),
      texto(corpo.versaoApp),
      texto(agente)?.slice(0, 60),
    ],
  );
  void ip;
  return res.insertId;
}

async function criarSessao(usuario, dispositivoId, corpo, ip, agente) {
  const refresh = crypto.randomBytes(32).toString("hex");
  const expira = new Date(Date.now() + DIAS_REFRESH * 86_400_000);

  const res = await exec(
    `INSERT INTO auth_sessions (company_id, user_id, user_device_id, refresh_token_hash, expires_at, ip_address, user_agent)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      usuario.company_id,
      usuario.id,
      dispositivoId,
      hashParaSessao(refresh),
      expira.toISOString().slice(0, 23).replace("T", " "),
      ip?.slice(0, 45) ?? null,
      agente?.slice(0, 500) ?? null,
    ],
  );

  const acesso = jwt.sign(
    { sub: usuario.id, cid: usuario.company_id, sid: res.insertId, papel: usuario.papel },
    SEGREDO,
    { expiresIn: VALIDADE_ACESSO, algorithm: "HS256" },
  );

  return { acesso, refresh, sessaoId: res.insertId, expiraEm: expira.toISOString() };
}

export async function registrarAuditoria(companyId, userId, acao, entidade, entidadeId, valores, ip, agente) {
  try {
    await exec(
      `INSERT INTO audit_logs (company_id, user_id, action, entity_name, entity_id, new_values, ip_address, user_agent)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        companyId,
        userId,
        acao,
        entidade,
        entidadeId ? String(entidadeId) : null,
        valores ? JSON.stringify(valores) : null,
        ip ?? null,
        agente ?? null,
      ],
    );
  } catch {}
}

export const login = asyncHandler(async (req, res) => {
  const email = texto(req.body?.email)?.toLowerCase();
  const senha = String(req.body?.senha ?? "");
  if (!email || !senha) throw new ErroHttp(400, "Informe e-mail e senha.");

  const candidatos = await buscarUsuario(email);
  if (!candidatos.length) throw new ErroHttp(401, "E-mail ou senha inválidos.");

  const empresaSlug = texto(req.body?.empresaSlug)?.toLowerCase();
  const usuario = empresaSlug ? candidatos.find((c) => c.empresa_slug === empresaSlug) : candidatos[0];
  if (!usuario) throw new ErroHttp(401, "E-mail ou senha inválidos.");

  if (usuario.locked_until && new Date(usuario.locked_until) > new Date()) {
    throw new ErroHttp(423, "Conta temporariamente bloqueada por tentativas inválidas. Tente novamente mais tarde.");
  }

  const confere = await conferirSenha(senha, usuario.password_hash);
  if (!confere) {
    const tentativas = (usuario.failed_login_attempts ?? 0) + 1;
    const bloquear = tentativas >= MAX_TENTATIVAS;
    await exec(
      `UPDATE users
          SET failed_login_attempts = ?, locked_until = ?
        WHERE company_id = ? AND id = ?`,
      [
        bloquear ? 0 : tentativas,
        bloquear ? new Date(Date.now() + BLOQUEIO_MINUTOS * 60_000).toISOString().slice(0, 23).replace("T", " ") : null,
        usuario.company_id,
        usuario.id,
      ],
    );
    await registrarAuditoria(
      usuario.company_id,
      usuario.id,
      bloquear ? "LOGIN_LOCKED" : "LOGIN_FAILED",
      "users",
      usuario.id,
      { tentativas, bloqueada: bloquear },
      req.ip,
      req.get("user-agent"),
    );
    throw new ErroHttp(401, "E-mail ou senha inválidos.");
  }

  if (usuario.totp_enabled) {
    const envio = await enviarCodigo(req, usuario, "LOGIN");
    return res.json({ doisFatores: true, desafio: emitirDesafio(usuario), ...envio });
  }

  await exec(
    `UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login_at = CURRENT_TIMESTAMP(3)
      WHERE company_id = ? AND id = ?`,
    [usuario.company_id, usuario.id],
  );

  return emitirSessao(usuario, req, res);
});

const VALIDADE_DESAFIO = "5m";

function emitirDesafio(usuario) {
  return jwt.sign({ sub: usuario.id, cid: usuario.company_id, tipo: "totp" }, SEGREDO, {
    expiresIn: VALIDADE_DESAFIO,
    algorithm: "HS256",
  });
}

function lerDesafio(desafio) {
  try {
    const dados = jwt.verify(String(desafio ?? ""), SEGREDO, { algorithms: ["HS256"] });
    if (dados?.tipo !== "totp") return null;
    return dados;
  } catch {
    return null;
  }
}

async function usuarioComSegundoFator(companyId, userId) {
  return um(
    `SELECT u.id, u.company_id, u.role_id, u.full_name, u.email, u.active, u.totp_enabled,
            u.failed_login_attempts, u.locked_until, u.password_hash, c.trade_name AS empresa,
            c.legal_name AS razao_social, c.slug AS empresa_slug, c.document_number AS cnpj,
            c.timezone_name, r.name AS papel, r.description AS papel_descricao, u.phone,
            u.must_change_password, u.last_login_at
       FROM users u
       JOIN companies c ON c.id = u.company_id
       JOIN roles r ON r.company_id = u.company_id AND r.id = u.role_id
      WHERE u.company_id = ? AND u.id = ? AND u.active = 1 AND c.active = 1`,
    [companyId, userId],
  );
}

export const loginTotp = asyncHandler(async (req, res) => {
  const desafio = lerDesafio(req.body?.desafio);
  if (!desafio) throw new ErroHttp(401, "Sessão de verificação expirada. Entre novamente.");

  const usuario = await usuarioComSegundoFator(desafio.cid, desafio.sub);
  if (!usuario || !usuario.totp_enabled) {
    throw new ErroHttp(401, "Sessão de verificação expirada. Entre novamente.");
  }
  await consumirCodigo(usuario, "LOGIN", req.body?.codigo);

  await exec(
    `UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login_at = CURRENT_TIMESTAMP(3)
      WHERE company_id = ? AND id = ?`,
    [usuario.company_id, usuario.id],
  );
  return emitirSessao(usuario, req, res);
});

export const estadoTotp = asyncHandler(async (req, res) => {
  const linha = await um(`SELECT totp_enabled, totp_enabled_at FROM users WHERE company_id = ? AND id = ?`, [
    req.usuario.companyId,
    req.usuario.id,
  ]);
  res.json({ ativo: Boolean(linha?.totp_enabled), ativoDesde: linha?.totp_enabled_at ?? null, metodo: "EMAIL" });
});

export const configurarTotp = asyncHandler(async (req, res) => {
  const usuario = await usuarioComSegundoFator(req.usuario.companyId, req.usuario.id);
  requerer(
    !usuario?.totp_enabled,
    409,
    "A verificação em duas etapas já está ativa. Desative antes de ativar de novo.",
  );
  res.json(await enviarCodigo(req, usuario, "ENABLE"));
});

export const enviarCodigoDesativacao = asyncHandler(async (req, res) => {
  const usuario = await usuarioComSegundoFator(req.usuario.companyId, req.usuario.id);
  requerer(usuario?.totp_enabled, 409, "A verificação em duas etapas não está ativa.");
  res.json(await enviarCodigo(req, usuario, "DISABLE"));
});

export const ativarTotp = asyncHandler(async (req, res) => {
  const usuario = await usuarioComSegundoFator(req.usuario.companyId, req.usuario.id);
  requerer(!usuario?.totp_enabled, 409, "A verificação em duas etapas já está ativa.");
  await consumirCodigo(usuario, "ENABLE", req.body?.codigo);
  await exec(
    `UPDATE users SET totp_enabled = 1, totp_enabled_at = CURRENT_TIMESTAMP(3) WHERE company_id = ? AND id = ?`,
    [req.usuario.companyId, req.usuario.id],
  );
  await registrarAuditoria(
    req.usuario.companyId,
    req.usuario.id,
    "TOTP_ENABLED",
    "users",
    req.usuario.id,
    null,
    req.ip,
    req.get("user-agent"),
  );
  res.json({ ok: true, ativo: true });
});

export const desativarTotp = asyncHandler(async (req, res) => {
  const usuario = await usuarioComSegundoFator(req.usuario.companyId, req.usuario.id);
  requerer(usuario?.totp_enabled, 409, "A verificação em duas etapas não está ativa.");
  requerer(await conferirSenha(String(req.body?.senha ?? ""), usuario.password_hash), 401, "Senha incorreta.");
  await consumirCodigo(usuario, "DISABLE", req.body?.codigo);
  await exec(`UPDATE users SET totp_enabled = 0, totp_enabled_at = NULL WHERE company_id = ? AND id = ?`, [
    req.usuario.companyId,
    req.usuario.id,
  ]);
  await registrarAuditoria(
    req.usuario.companyId,
    req.usuario.id,
    "TOTP_DISABLED",
    "users",
    req.usuario.id,
    null,
    req.ip,
    req.get("user-agent"),
  );
  res.json({ ok: true, ativo: false });
});

export async function emitirSessao(usuario, req, res) {
  const dispositivoId = await registrarDispositivo(usuario, req.body ?? {}, req.get("user-agent"), req.ip);
  const sessao = await criarSessao(usuario, dispositivoId, req.body ?? {}, req.ip, req.get("user-agent"));
  const permissoes = await permissoesDoUsuario(usuario.company_id, usuario.role_id);

  const preferencias = await um(
    `SELECT theme, language_code, push_notifications_enabled, sound_alerts_enabled,
            automatic_sync_enabled, dashboard_alert_limit, alerts_page_size, default_period_days
       FROM user_app_preferences WHERE company_id = ? AND user_id = ?`,
    [usuario.company_id, usuario.id],
  );

  await registrarAuditoria(
    usuario.company_id,
    usuario.id,
    "LOGIN",
    "auth_sessions",
    sessao.sessaoId,
    { dispositivoId },
    req.ip,
    req.get("user-agent"),
  );

  res.json({
    accessToken: sessao.acesso,
    refreshToken: sessao.refresh,
    expiraEm: sessao.expiraEm,
    dispositivoId,
    usuario: {
      id: usuario.id,
      nome: usuario.full_name,
      email: usuario.email,
      telefone: usuario.phone,
      papel: usuario.papel,
      papelDescricao: usuario.papel_descricao,
      trocarSenha: Boolean(usuario.must_change_password),
    },
    empresa: {
      id: usuario.company_id,
      nome: usuario.empresa,
      razaoSocial: usuario.razao_social,
      slug: usuario.empresa_slug,
      cnpj: usuario.cnpj,
      fusoHorario: usuario.timezone_name,
    },
    permissoes,
    preferencias,
  });
}

export const refresh = asyncHandler(async (req, res) => {
  const token = texto(req.body?.refreshToken);
  if (!token) throw new ErroHttp(400, "refreshToken obrigatório.");

  const sessao = await um(
    `SELECT s.id, s.company_id, s.user_id, s.user_device_id, s.expires_at, s.revoked_at,
            u.role_id, u.active, u.full_name, u.email, u.phone, u.must_change_password,
            r.name AS papel, c.trade_name AS empresa, c.slug AS empresa_slug, c.timezone_name, c.document_number AS cnpj
       FROM auth_sessions s
       JOIN users u ON u.company_id = s.company_id AND u.id = s.user_id
       JOIN roles r ON r.company_id = u.company_id AND r.id = u.role_id
       JOIN companies c ON c.id = s.company_id
      WHERE s.refresh_token_hash = ?`,
    [hashParaSessao(token)],
  );

  if (!sessao || sessao.revoked_at || new Date(sessao.expires_at) <= new Date() || !sessao.active) {
    throw new ErroHttp(401, "Sessão expirada. Entre novamente.");
  }

  await exec(`UPDATE auth_sessions SET last_used_at = CURRENT_TIMESTAMP(3) WHERE id = ?`, [sessao.id]);

  const acesso = jwt.sign(
    { sub: sessao.user_id, cid: sessao.company_id, sid: sessao.id, papel: sessao.papel },
    SEGREDO,
    { expiresIn: VALIDADE_ACESSO, algorithm: "HS256" },
  );
  const permissoes = await permissoesDoUsuario(sessao.company_id, sessao.role_id);

  res.json({
    accessToken: acesso,
    refreshToken: token,
    expiraEm: sessao.expires_at,
    usuario: {
      id: sessao.user_id,
      nome: sessao.full_name,
      email: sessao.email,
      telefone: sessao.phone,
      papel: sessao.papel,
      trocarSenha: Boolean(sessao.must_change_password),
    },
    empresa: {
      id: sessao.company_id,
      nome: sessao.empresa,
      slug: sessao.empresa_slug,
      cnpj: sessao.cnpj,
      fusoHorario: sessao.timezone_name,
    },
    permissoes,
  });
});

export const logout = asyncHandler(async (req, res) => {
  const token = texto(req.body?.refreshToken);
  const todos = req.body?.todos === true;
  if (req.usuario) {
    if (todos) {
      await exec(
        `UPDATE auth_sessions SET revoked_at = CURRENT_TIMESTAMP(3), revoke_reason = 'LOGOUT_TOTAL'
          WHERE company_id = ? AND user_id = ? AND revoked_at IS NULL`,
        [req.usuario.companyId, req.usuario.id],
      );
    } else if (req.usuario.sessaoId) {
      await exec(
        `UPDATE auth_sessions SET revoked_at = CURRENT_TIMESTAMP(3), revoke_reason = 'LOGOUT'
          WHERE id = ? AND revoked_at IS NULL`,
        [req.usuario.sessaoId],
      );
    }
  } else if (token) {
    await exec(
      `UPDATE auth_sessions SET revoked_at = CURRENT_TIMESTAMP(3), revoke_reason = 'LOGOUT'
        WHERE refresh_token_hash = ? AND revoked_at IS NULL`,
      [hashParaSessao(token)],
    );
  }
  res.json({ ok: true });
});

export const autenticar = asyncHandler(async (req, _res, next) => {
  const cabecalho = req.get("authorization") ?? "";
  const [, token] = cabecalho.split(" ");
  if (!token) throw new ErroHttp(401, "Token de acesso ausente.");

  let dados;
  try {
    dados = jwt.verify(token, SEGREDO, { algorithms: ["HS256"] });
  } catch {
    throw new ErroHttp(401, "Sessão expirada. Entre novamente.");
  }

  const sessao = await um(
    `SELECT s.id, s.revoked_at, s.expires_at, u.id AS user_id, u.active, u.full_name, u.email, u.phone, u.company_id, u.role_id,
            r.name AS papel, c.trade_name AS empresa, c.slug AS empresa_slug, c.timezone_name, c.document_number AS cnpj
       FROM auth_sessions s
       JOIN users u ON u.company_id = s.company_id AND u.id = s.user_id
       JOIN roles r ON r.company_id = u.company_id AND r.id = u.role_id
       JOIN companies c ON c.id = s.company_id
      WHERE s.id = ? AND s.company_id = ? AND s.user_id = ?`,
    [dados.sid, dados.cid, dados.sub],
  );

  if (!sessao || sessao.revoked_at || !sessao.active) throw new ErroHttp(401, "Sessão inválida ou revogada.");
  if (new Date(sessao.expires_at) <= new Date()) throw new ErroHttp(401, "Sessão expirada. Entre novamente.");

  req.usuario = {
    id: sessao.user_id,
    companyId: sessao.company_id,
    roleId: sessao.role_id,
    sessaoId: sessao.id,
    nome: sessao.full_name,
    email: sessao.email,
    telefone: sessao.phone,
    papel: sessao.papel,
    empresa: sessao.empresa,
    empresaSlug: sessao.empresa_slug,
    cnpj: sessao.cnpj,
    fusoHorario: sessao.timezone_name,
    permissoes: await permissoesDoUsuario(sessao.company_id, sessao.role_id),
  };
  next();
});

export const exigirPermissao =
  (...codigos) =>
  (req, _res, next) => {
    const tem = req.usuario?.permissoes?.some((p) => codigos.includes(p));
    if (!tem) return next(new ErroHttp(403, `Permissão necessária: ${codigos.join(" ou ")}.`));
    return next();
  };

export async function garantirVinculo(req, tabela, campoId = "id", campoEmpresa = "company_id") {
  const valor = id(req.params.id);
  requererId(valor);
  const linha = await um(`SELECT id FROM ${tabela} WHERE ${campoId} = ? AND ${campoEmpresa} = ? LIMIT 1`, [
    valor,
    req.usuario.companyId,
  ]);
  if (!linha) throw new ErroHttp(404, "Registro não encontrado.");
  return linha.id;
}

export function requererId(valor) {
  if (!valor || valor <= 0) throw new ErroHttp(400, "Identificador inválido.");
}
