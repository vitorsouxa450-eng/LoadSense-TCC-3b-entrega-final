import { ErroHttp, asyncHandler } from "./util.js";
import { um } from "./db.js";

export const HISTORICO_ESSENCIAL_DIAS = 90;

export const TOLERANCIA_INADIMPLENCIA_DIAS = 7;

export const PLANOS = {
  ESSENCIAL: { nivel: 1, nome: "Essencial", veiculos: 3, usuarios: 3 },
  PROFISSIONAL: { nivel: 2, nome: "Profissional", veiculos: 10, usuarios: 5 },
  AVANCADO: { nivel: 3, nome: "Avançado", veiculos: 25, usuarios: null },
  ENTERPRISE: { nivel: 4, nome: "Enterprise", veiculos: null, usuarios: null },
};

export const RECURSOS = {
  historico_completo: { nivel: 2, nome: "Histórico completo (além de 90 dias)" },
  importar_planilha: { nivel: 2, nome: "Importação de planilha" },
  exportar_planilha: { nivel: 2, nome: "Exportação de planilha (XLSX e CSV)" },
  auditoria: { nivel: 3, nome: "Auditoria consultável e exportável" },
};

const APELIDOS = {
  BASIC: "ESSENCIAL",
  BASIC_PLUS: "PROFISSIONAL",
  PREMIUM: "AVANCADO",
};

const STATUS_COM_FIM = new Set(["CANCELLED", "EXPIRED"]);

export function codigoDoPlano(codigo) {
  const normalizado = String(codigo ?? "").toUpperCase();
  const resolvido = APELIDOS[normalizado] ?? normalizado;
  return PLANOS[resolvido] ? resolvido : "ESSENCIAL";
}

export async function planoEfetivo(companyId) {
  const assinatura = await um(
    `SELECT plan_code, status, current_period_end FROM vw_company_current_subscription
      WHERE company_id = ? LIMIT 1`,
    [companyId],
  );
  if (!assinatura) return "ESSENCIAL";
  const codigo = codigoDoPlano(assinatura.plan_code);
  const fim = assinatura.current_period_end ? new Date(assinatura.current_period_end) : null;
  const vencido = !fim || fim.getTime() < Date.now();
  if (STATUS_COM_FIM.has(assinatura.status) && vencido) return "ESSENCIAL";
  if (assinatura.status === "TRIAL" && vencido) return "ESSENCIAL";
  if (assinatura.status === "PAST_DUE") {
    const limite = fim ? fim.getTime() + TOLERANCIA_INADIMPLENCIA_DIAS * 86_400_000 : 0;
    if (limite < Date.now()) return "ESSENCIAL";
  }
  return codigo;
}

export function temRecurso(codigoPlano, recurso) {
  const exigido = RECURSOS[recurso];
  if (!exigido) throw new Error(`Recurso desconhecido: ${recurso}`);
  return PLANOS[codigoPlano].nivel >= exigido.nivel;
}

export function mensagemBloqueio(codigoPlano, recurso) {
  const exigido = RECURSOS[recurso];
  const alvo = Object.values(PLANOS).find((p) => p.nivel === exigido.nivel);
  return `${exigido.nome} não está disponível no plano ${PLANOS[codigoPlano].nome}. Disponível a partir do plano ${alvo.nome}.`;
}

export const exigirRecurso = (recurso) =>
  asyncHandler(async (req, _res, next) => {
    const plano = await planoEfetivo(req.usuario.companyId);
    req.plano = plano;
    if (!temRecurso(plano, recurso)) {
      throw new ErroHttp(403, mensagemBloqueio(plano, recurso), { codigo: "PLANO_INSUFICIENTE", recurso });
    }
    next();
  });

export async function limiteUsuariosDaEmpresa(companyId) {
  const linha = await um(
    `SELECT limite_usuarios FROM company_subscriptions WHERE company_id = ? AND current_marker = 1 LIMIT 1`,
    [companyId],
  );
  return linha?.limite_usuarios ?? null;
}

export async function garantirLimite(companyId, tipo, rotulo) {
  const plano = await planoEfetivo(companyId);
  const override = tipo === "usuarios" ? await limiteUsuariosDaEmpresa(companyId) : null;
  const limite = override ?? PLANOS[plano][tipo];
  if (limite === null) return;
  const tabela = {
    veiculos: "SELECT COUNT(*) AS total FROM vehicles WHERE company_id = ? AND active = 1",
    usuarios: "SELECT COUNT(*) AS total FROM users WHERE company_id = ? AND active = 1",
  }[tipo];
  const { total } = await um(tabela, [companyId]);
  if (Number(total) >= limite) {
    const aviso =
      override !== null
        ? `O limite de ${rotulo} desta empresa é ${limite}, definido pela consultoria. Fale com a consultoria para ampliar.`
        : `O plano ${PLANOS[plano].nome} inclui até ${limite} ${rotulo}. Faça upgrade para cadastrar mais.`;
    throw new ErroHttp(403, aviso, {
      codigo: "LIMITE_DO_PLANO",
      tipo,
      limite,
    });
  }
}

export async function queryComLimiteHistorico(req) {
  const plano = req.plano ?? (await planoEfetivo(req.usuario.companyId));
  const consulta = { ...req.query };
  if (temRecurso(plano, "historico_completo")) return consulta;
  const minimo = new Date(Date.now() - HISTORICO_ESSENCIAL_DIAS * 86_400_000);
  const pedido = consulta.inicio ? new Date(consulta.inicio) : null;
  if (!pedido || pedido.getTime() < minimo.getTime()) {
    consulta.inicio = minimo.toISOString().slice(0, 10);
    consulta.fim = consulta.fim || new Date().toISOString().slice(0, 10);
  }
  return consulta;
}

export function resumoDoPlano(codigoPlano, limiteUsuarios = null) {
  const plano = PLANOS[codigoPlano];
  return {
    codigo: codigoPlano,
    nome: plano.nome,
    limites: {
      veiculos: plano.veiculos,
      usuarios: limiteUsuarios ?? plano.usuarios,
      usuariosDefinidosPelaConsultoria: true,
    },
    recursos: Object.fromEntries(Object.keys(RECURSOS).map((r) => [r, temRecurso(codigoPlano, r)])),
    historicoDias: temRecurso(codigoPlano, "historico_completo") ? null : HISTORICO_ESSENCIAL_DIAS,
  };
}
