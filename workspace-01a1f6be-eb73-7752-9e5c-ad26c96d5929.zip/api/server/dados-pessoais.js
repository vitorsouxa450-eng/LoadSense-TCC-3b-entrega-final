import crypto from "node:crypto";
import { segredoJwt } from "./segredo.js";

const PREFIXO = "v1:";

function chaveBase() {
  return process.env.LS_CHAVE_DADOS || segredoJwt();
}

function chaveCifra() {
  return crypto.createHash("sha256").update(`${chaveBase()}|dados-pessoais-v1`).digest();
}

function chaveBusca() {
  return crypto.createHash("sha256").update(`${chaveBase()}|busca-cpf-v1`).digest();
}

export function cifrar(valor) {
  if (valor === null || valor === undefined || valor === "") return null;
  const iv = crypto.randomBytes(12);
  const cifra = crypto.createCipheriv("aes-256-gcm", chaveCifra(), iv);
  const dados = Buffer.concat([cifra.update(String(valor), "utf8"), cifra.final()]);
  return `${PREFIXO}${iv.toString("base64")}.${cifra.getAuthTag().toString("base64")}.${dados.toString("base64")}`;
}

export function decifrar(valor) {
  if (valor === null || valor === undefined) return null;
  const texto = String(valor);
  if (!texto.startsWith(PREFIXO)) return texto;
  try {
    const [ivB64, tagB64, dadosB64] = texto.slice(PREFIXO.length).split(".");
    const decifra = crypto.createDecipheriv("aes-256-gcm", chaveCifra(), Buffer.from(ivB64, "base64"));
    decifra.setAuthTag(Buffer.from(tagB64, "base64"));
    return Buffer.concat([decifra.update(Buffer.from(dadosB64, "base64")), decifra.final()]).toString("utf8");
  } catch {
    return null;
  }
}

export function hashBusca(valor) {
  if (!valor) return null;
  return crypto.createHmac("sha256", chaveBusca()).update(String(valor).replace(/\D/g, "")).digest("hex");
}

export const estaCifrado = (valor) => typeof valor === "string" && valor.startsWith(PREFIXO);
