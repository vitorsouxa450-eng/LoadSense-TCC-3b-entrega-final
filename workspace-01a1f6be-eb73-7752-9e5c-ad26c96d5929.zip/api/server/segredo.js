import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ARQUIVO = path.join(path.dirname(fileURLToPath(import.meta.url)), "segredo-jwt.txt");

export function segredoJwt() {
  if (process.env.LS_JWT_SECRET) return process.env.LS_JWT_SECRET;
  try {
    const salvo = fs.readFileSync(ARQUIVO, "utf8").trim();
    if (salvo) {
      if ((fs.statSync(ARQUIVO).mode & 0o077) !== 0) fs.chmodSync(ARQUIVO, 0o600);
      return salvo;
    }
  } catch {}
  const novo = crypto.randomBytes(48).toString("hex");
  fs.writeFileSync(ARQUIVO, novo, { mode: 0o600 });
  return novo;
}
