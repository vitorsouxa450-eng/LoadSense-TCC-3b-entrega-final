export class ErroHttp extends Error {
  constructor(status, mensagem, detalhe) {
    super(mensagem);
    this.status = status;
    this.detalhe = detalhe;
  }
}

export const requerer = (condicao, status, mensagem) => {
  if (!condicao) throw new ErroHttp(status, mensagem);
};

export function numero(valor, padrao = null) {
  if (valor === undefined || valor === null || valor === "") return padrao;
  const n = Number(valor);
  return Number.isFinite(n) ? n : padrao;
}

export function id(valor, padrao = null) {
  const n = numero(valor, padrao);
  return n === null ? null : Math.trunc(n);
}

export function texto(valor, padrao = null) {
  if (valor === undefined || valor === null) return padrao;
  const s = String(valor).trim();
  return s === "" ? padrao : s;
}

export function dataMysql(valor) {
  if (!valor) return null;
  const d = valor instanceof Date ? valor : new Date(valor);
  if (Number.isNaN(d.getTime())) throw new ErroHttp(400, "Data inválida.");
  return d.toISOString().slice(0, 23).replace("T", " ");
}

export function periodo(query) {
  if (query.inicio && query.fim) {
    return { inicio: dataMysql(query.inicio), fim: dataMysql(query.fim) };
  }
  const dias = numero(query.dias, 30);
  const fim = new Date();
  const inicio = new Date(fim.getTime() - dias * 86_400_000);
  return { inicio: dataMysql(inicio), fim: dataMysql(fim) };
}

export const ORDEM_SEGURA = (valor, mapa, padrao) => mapa[String(valor ?? "")] ?? padrao;

export function paginacao(query) {
  const pagina = Math.max(1, Math.trunc(numero(query.pagina, 1)));
  const limite = Math.min(200, Math.max(1, Math.trunc(numero(query.limite, 50))));
  return { pagina, limite, offset: (pagina - 1) * limite };
}

export function serializar(linha) {
  if (linha === null || linha === undefined) return linha;
  if (Array.isArray(linha)) return linha.map(serializar);
  if (linha instanceof Date) return linha.toISOString();
  if (typeof linha === "object") {
    const saida = {};
    for (const [chave, valor] of Object.entries(linha)) {
      if (valor instanceof Date) saida[chave] = valor.toISOString();
      else if (valor && typeof valor === "object" && !Buffer.isBuffer(valor)) saida[chave] = serializar(valor);
      else saida[chave] = valor;
    }
    return saida;
  }
  return linha;
}

export function jsonSeguro(valor) {
  if (valor === null || valor === undefined) return null;
  if (typeof valor === "object") return valor;
  try {
    return JSON.parse(String(valor));
  } catch {
    return null;
  }
}

export function traduzirErroSql(erro) {
  const codigo = erro?.code ?? "";
  const sqlstate = erro?.sqlState ?? erro?.sqlstate ?? "";
  const bruto = String(erro?.sqlMessage ?? erro?.message ?? "");
  const limpa = bruto.replace(/^.*?:\s*/, "").trim();

  if (codigo === "ER_DUP_ENTRY") return new ErroHttp(409, "Registro duplicado.", limpa);
  if (codigo === "ER_NO_REFERENCED_ROW_2" || codigo === "ER_NO_REFERENCED_ROW")
    return new ErroHttp(422, "Referência inválida: o registro relacionado não existe nesta empresa.", limpa);
  if (codigo === "ER_ROW_IS_REFERENCED_2") return new ErroHttp(409, "Registro em uso: não é possível excluir.", limpa);
  if (codigo === "ER_CHECK_CONSTRAINT_VIOLATED" || /CONSTRAINT `.*` failed/i.test(bruto))
    return new ErroHttp(422, "Valor inválido para uma das regras do banco.", limpa);
  if (codigo === "ER_SIGNAL_EXCEPTION" || sqlstate === "45000" || sqlstate === "S45000")
    return new ErroHttp(422, limpa, bruto);
  if (codigo === "ER_BAD_NULL_ERROR") return new ErroHttp(422, "Campo obrigatório não informado.", limpa);
  if (codigo === "ER_DATA_TOO_LONG") return new ErroHttp(422, "Texto maior do que o permitido.", limpa);
  if (codigo === "ER_TRUNCATED_WRONG_VALUE" || codigo === "WARN_DATA_TRUNCATED")
    return new ErroHttp(422, "Valor incompatível com o tipo da coluna.", limpa);
  return new ErroHttp(500, "Erro ao executar a operação no banco de dados.");
}

export const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
