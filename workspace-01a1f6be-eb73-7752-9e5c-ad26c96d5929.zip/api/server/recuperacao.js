import crypto from "node:crypto";
import { ErroHttp, asyncHandler, texto } from "./util.js";
import { exec, q, um } from "./db.js";
import { hashSenha } from "./auth.js";
import { segredoJwt } from "./segredo.js";
import { emailConfigurado, enviarEmail } from "./email.js";

const SEGREDO = segredoJwt();
const MINUTOS_VALIDADE = 15;
const EXIBIR_CODIGO = process.env.LS_EXIBIR_CODIGO === "1";

const hashCodigo = (userId, codigo) =>
  crypto.createHash("sha256").update(`${userId}|${codigo}|${SEGREDO}`).digest("hex");

const sqlDataMysql = (d) => d.toISOString().slice(0, 23).replace("T", " ");

const senhaForte = (senha) =>
  senha.length >= 8 && /[A-Z]/.test(senha) && /[0-9]/.test(senha) && /[^A-Za-z0-9]/.test(senha);

async function usuarioPorEmail(email) {
  return um(
    `SELECT u.id, u.company_id FROM users u JOIN companies c ON c.id = u.company_id
      WHERE u.email = ? AND u.active = 1 AND c.active = 1 ORDER BY u.company_id LIMIT 1`,
    [email],
  );
}

async function tokenValido(usuario, codigo) {
  return um(
    `SELECT id FROM password_reset_tokens
      WHERE company_id = ? AND user_id = ? AND token_hash = ?
        AND used_at IS NULL AND expires_at > CURRENT_TIMESTAMP(3)`,
    [usuario.company_id, usuario.id, hashCodigo(usuario.id, codigo)],
  );
}

function ehLocal(req) {
  const ip = req.socket?.remoteAddress ?? "";
  return ip === "127.0.0.1" || ip === "::1" || ip === "::ffff:127.0.0.1";
}

export const solicitarCodigo = asyncHandler(async (req, res) => {
  const email = texto(req.body?.email)?.toLowerCase();
  if (!email) throw new ErroHttp(400, "Informe o e-mail corporativo.");

  const resposta = { enviado: true, mensagem: "Se o e-mail estiver cadastrado, enviaremos um código de verificação." };
  const usuario = await usuarioPorEmail(email);
  if (!usuario) return res.json(resposta);

  await exec(
    `UPDATE password_reset_tokens SET used_at = CURRENT_TIMESTAMP(3)
      WHERE company_id = ? AND user_id = ? AND used_at IS NULL`,
    [usuario.company_id, usuario.id],
  );

  const expira = sqlDataMysql(new Date(Date.now() + MINUTOS_VALIDADE * 60_000));
  let codigo;
  for (let tentativa = 0; ; tentativa += 1) {
    codigo = String(crypto.randomInt(0, 1_000_000)).padStart(6, "0");
    try {
      await exec(
        `INSERT INTO password_reset_tokens (company_id, user_id, token_hash, expires_at)
         VALUES (?, ?, ?, ?)`,
        [usuario.company_id, usuario.id, hashCodigo(usuario.id, codigo), expira],
      );
      break;
    } catch (erro) {
      if (erro.code !== "ER_DUP_ENTRY" || tentativa >= 5) throw erro;
    }
  }

  const configurado = emailConfigurado();
  if (configurado) {
    const envio = await enviarEmail({
      para: usuario.email,
      assunto: "Código para redefinir sua senha no LoadSense",
      texto: `Seu código é ${codigo}.\n\nEle vale por ${MINUTOS_VALIDADE} minutos e só pode ser usado uma vez.\nSe você não pediu este código, ignore esta mensagem.`,
    });
    if (!envio.enviado) {
      await exec(
        `UPDATE password_reset_tokens SET used_at = CURRENT_TIMESTAMP(3) WHERE company_id = ? AND user_id = ? AND used_at IS NULL`,
        [usuario.company_id, usuario.id],
      );
      throw new ErroHttp(503, "Não foi possível enviar o código por e-mail. Tente de novo em instantes.");
    }
  }
  if (ehLocal(req) && (EXIBIR_CODIGO || !configurado)) resposta.codigoDemo = codigo;
  res.json(resposta);
});

export const verificarCodigo = asyncHandler(async (req, res) => {
  const email = texto(req.body?.email)?.toLowerCase();
  const codigo = texto(req.body?.codigo)?.replace(/\D/g, "");
  if (!email || !codigo || codigo.length !== 6) throw new ErroHttp(400, "Informe o e-mail e o código de 6 dígitos.");
  const usuario = await usuarioPorEmail(email);
  if (!usuario || !(await tokenValido(usuario, codigo))) {
    throw new ErroHttp(422, "Código inválido ou expirado.");
  }
  res.json({ valido: true });
});

export const definirNovaSenha = asyncHandler(async (req, res) => {
  const email = texto(req.body?.email)?.toLowerCase();
  const codigo = texto(req.body?.codigo)?.replace(/\D/g, "");
  const senha = String(req.body?.senha ?? "");
  if (!email || !codigo || codigo.length !== 6) throw new ErroHttp(400, "Informe o e-mail e o código de 6 dígitos.");
  if (!senhaForte(senha)) {
    throw new ErroHttp(422, "A senha deve ter 8+ caracteres, uma letra maiúscula, um número e um caractere especial.");
  }
  const usuario = await usuarioPorEmail(email);
  const token = usuario && (await tokenValido(usuario, codigo));
  if (!token) throw new ErroHttp(422, "Código inválido ou expirado.");

  await exec(`UPDATE password_reset_tokens SET used_at = CURRENT_TIMESTAMP(3) WHERE company_id = ? AND id = ?`, [
    usuario.company_id,
    token.id,
  ]);
  await exec(
    `UPDATE users SET password_hash = ?, must_change_password = 0, failed_login_attempts = 0, locked_until = NULL
      WHERE company_id = ? AND id = ?`,
    [await hashSenha(senha), usuario.company_id, usuario.id],
  );
  await exec(
    `UPDATE auth_sessions SET revoked_at = CURRENT_TIMESTAMP(3)
      WHERE company_id = ? AND user_id = ? AND revoked_at IS NULL`,
    [usuario.company_id, usuario.id],
  ).catch(() => {});
  res.json({ alterada: true });
});
