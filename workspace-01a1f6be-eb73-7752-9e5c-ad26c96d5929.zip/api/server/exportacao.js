import ExcelJS from "exceljs";
import { q } from "./db.js";
import { ErroHttp } from "./util.js";
import { decifrar } from "./dados-pessoais.js";
import { SELECAO_OPERACAO, montarFiltrosOperacoes } from "./routes/operacoes.js";

export const LIMITE_EXPORTACAO = 5000;
export const LIMITE_EXPORTACAO_COMPLETA = 50000;
export const LIMITE_IMPORTACAO_LINHAS = 2000;

const FUSO = "America/Sao_Paulo";
const formatadorDataHora = new Intl.DateTimeFormat("pt-BR", {
  timeZone: FUSO,
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hour12: false,
});

export function normalizarCabecalho(valor) {
  return String(valor ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

export const COLUNAS_PLANILHA = [
  { chave: "codigo", rotulo: "Código", campo: "operation_code", editavel: true, apelidos: ["operacao", "id"] },
  { chave: "placa", rotulo: "Placa", campo: "vehicle_plate", editavel: true },
  { chave: "motorista", rotulo: "Motorista", campo: "driver_name", editavel: true },
  { chave: "produto", rotulo: "Produto", campo: "cargo_product_name", editavel: true },
  { chave: "rota_codigo", rotulo: "Rota (código)", campo: "route_code", editavel: true, apelidos: ["rota"] },
  {
    chave: "tipo_movimento",
    rotulo: "Tipo de movimento",
    campo: "movement_type",
    editavel: true,
    apelidos: ["movimento"],
  },
  { chave: "metodo", rotulo: "Método", campo: "weighing_method", editavel: true },
  { chave: "nota_fiscal", rotulo: "Nota fiscal", campo: "invoice_number", editavel: true, apelidos: ["nf"] },
  { chave: "mdfe", rotulo: "MDF-e", campo: "mdfe_number", editavel: true, apelidos: ["mdf_e"] },
  { chave: "ciot", rotulo: "CIOT", campo: "ciot_number", editavel: true },
  {
    chave: "peso_declarado_kg",
    rotulo: "Peso declarado (kg)",
    campo: "declared_cargo_weight_kg",
    editavel: true,
    tipo: "numero",
  },
  { chave: "observacoes", rotulo: "Observações", campo: "observations", editavel: true },
  { chave: "estado", rotulo: "Estado", campo: "state", editavel: false },
  { chave: "status", rotulo: "Status", campo: "status", editavel: false },
  { chave: "inicio", rotulo: "Início", campo: "started_at", editavel: false, tipo: "data" },
  { chave: "vazio_kg", rotulo: "Vazio (kg)", campo: "empty_truck_weight_kg", editavel: false, tipo: "numero" },
  { chave: "carga_kg", rotulo: "Carga (kg)", campo: "actual_cargo_weight_kg", editavel: false, tipo: "numero" },
  { chave: "esperado_kg", rotulo: "Esperado (kg)", campo: "expected_gross_weight_kg", editavel: false, tipo: "numero" },
  { chave: "real_kg", rotulo: "Real (kg)", campo: "loaded_truck_weight_kg", editavel: false, tipo: "numero" },
  { chave: "dif_kg", rotulo: "Dif. kg", campo: "difference_kg", editavel: false, tipo: "numero" },
  { chave: "dif_pct", rotulo: "Dif. %", campo: "difference_percent", editavel: false, tipo: "percentual" },
  { chave: "rastreio", rotulo: "Rastreio", campo: "tracking_state", editavel: false },
];

function linhaPlanilha(r) {
  const saida = {};
  for (const col of COLUNAS_PLANILHA) saida[col.chave] = r[col.campo] ?? null;
  return saida;
}

export async function linhasOperacoesPlanilha(empresa, query) {
  const { onde, params, coluna, direcao } = montarFiltrosOperacoes(query, empresa);
  const linhas = await q(`${SELECAO_OPERACAO} WHERE ${onde} ORDER BY ${coluna} ${direcao}, o.id DESC LIMIT ?`, [
    ...params,
    LIMITE_EXPORTACAO,
  ]);
  return linhas.map(linhaPlanilha);
}

const formatarValorCsv = (valor, tipo) => {
  if (valor === null || valor === undefined) return "";
  let texto;
  if (valor instanceof Date) texto = formatadorDataHora.format(valor).replace(",", "");
  else if (typeof valor === "number") texto = String(valor).replace(".", ",");
  else if ((tipo === "numero" || tipo === "percentual") && /^-?\d+(\.\d+)?$/.test(String(valor)))
    texto = String(valor).replace(".", ",");
  else if (typeof valor === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(valor)) {
    texto = formatadorDataHora.format(new Date(valor)).replace(",", "");
  } else {
    texto = String(valor);
    if (/^[=+\-@\t\r]/.test(texto)) texto = `'${texto}`;
  }
  return /[;"\r\n]/.test(texto) ? `"${texto.replace(/"/g, '""')}"` : texto;
};

export function gerarCsv(colunas, linhas) {
  const cabecalho = colunas.map((c) => formatarValorCsv(c.rotulo)).join(";");
  const corpo = linhas.map((l) => colunas.map((c) => formatarValorCsv(l[c.chave], c.tipo)).join(";"));
  return `\uFEFF${[cabecalho, ...corpo].join("\r\n")}\r\n`;
}

const COR = {
  destaque: "FF1F4E78",
  textoDestaque: "FFFFFFFF",
  listra: "FFF2F6FB",
  borda: "FFD0D7E2",
  subtitulo: "FF5B6B7F",
};
const BORDA_FINA = {
  top: { style: "thin", color: { argb: COR.borda } },
  left: { style: "thin", color: { argb: COR.borda } },
  bottom: { style: "thin", color: { argb: COR.borda } },
  right: { style: "thin", color: { argb: COR.borda } },
};
const FORMATO_DATA = "dd/mm/yyyy hh:mm";
const FORMATO_NUMERO = "#,##0.00";
const FORMATO_PERCENTUAL = '#,##0.00"%"';
const FORMATO_POR_TIPO = { data: FORMATO_DATA, numero: FORMATO_NUMERO, percentual: FORMATO_PERCENTUAL };
const ISO_DATA_HORA = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/;

function nomeDaAba(nome, usados) {
  const base =
    String(nome || "Planilha")
      .replace(/[\\/?*[\]:]/g, "-")
      .trim()
      .slice(0, 31) || "Planilha";
  let candidato = base;
  for (let i = 2; usados.has(candidato.toLowerCase()); i++) {
    candidato = `${base.slice(0, 31 - String(i).length - 1)} ${i}`;
  }
  usados.add(candidato.toLowerCase());
  return candidato;
}

function larguraDaColuna(coluna, linhas) {
  if (coluna.tipo === "data") return 18;
  let maior = String(coluna.rotulo ?? "").length;
  for (const linha of linhas) {
    const valor = linha[coluna.chave];
    if (valor === null || valor === undefined) continue;
    const tamanho =
      valor instanceof Date ? 16 : typeof valor === "number" ? String(valor).length + 3 : String(valor).length;
    if (tamanho > maior) maior = tamanho;
  }
  return Math.min(48, Math.max(10, maior + 3));
}

function valorDaCelula(valor, coluna) {
  if (valor === null || valor === undefined || valor === "") return null;
  if (coluna.tipo === "data" && typeof valor === "string" && ISO_DATA_HORA.test(valor)) return new Date(valor);
  return valor;
}

export async function gerarXlsx(abas, { titulo, subtitulo } = {}) {
  const livro = new ExcelJS.Workbook();
  livro.creator = "LoadSense";
  livro.company = "LoadSense";
  livro.title = titulo ?? "Planilha LoadSense";
  livro.created = new Date();
  livro.modified = new Date();
  const geradoEm = formatadorDataHora.format(new Date()).replace(",", "");
  const usados = new Set();

  for (const aba of abas) {
    const colunas = aba.colunas ?? [];
    const linhas = aba.linhas ?? [];
    const comTitulo = Boolean(titulo);
    const linhaCabecalho = comTitulo ? 4 : 1;

    const planilha = livro.addWorksheet(nomeDaAba(aba.nome, usados), {
      views: [{ state: "frozen", ySplit: linhaCabecalho, showGridLines: false }],
      properties: { tabColor: { argb: COR.destaque } },
      pageSetup: {
        orientation: "landscape",
        paperSize: 9,
        fitToPage: colunas.length <= 10,
        fitToWidth: 1,
        fitToHeight: 0,
      },
      headerFooter: { oddFooter: "&L&8LoadSense&R&8Página &P de &N" },
    });
    planilha.pageSetup.printTitlesRow = `${linhaCabecalho}:${linhaCabecalho}`;

    colunas.forEach((c, i) => {
      planilha.getColumn(i + 1).width = larguraDaColuna(c, linhas);
    });

    if (comTitulo) {
      const tituloCelula = planilha.getCell(1, 1);
      tituloCelula.value = titulo;
      tituloCelula.font = { bold: true, size: 14, color: { argb: COR.destaque } };
      const subCelula = planilha.getCell(2, 1);
      subCelula.value = [subtitulo, `Gerado em ${geradoEm}`].filter(Boolean).join(" · ");
      subCelula.font = { italic: true, size: 9, color: { argb: COR.subtitulo } };
      planilha.getRow(1).height = 22;
    }

    const cabecalho = planilha.getRow(linhaCabecalho);
    colunas.forEach((c, i) => {
      const celula = cabecalho.getCell(i + 1);
      celula.value = c.rotulo;
      celula.font = { bold: true, size: 10, color: { argb: COR.textoDestaque } };
      celula.fill = { type: "pattern", pattern: "solid", fgColor: { argb: COR.destaque } };
      celula.alignment = { vertical: "middle", horizontal: "center", wrapText: true };
      celula.border = BORDA_FINA;
    });
    cabecalho.height = 30;
    cabecalho.commit();

    linhas.forEach((linha, indice) => {
      const registro = planilha.getRow(linhaCabecalho + 1 + indice);
      colunas.forEach((c, i) => {
        const celula = registro.getCell(i + 1);
        const tipo = linha.__tipos?.[c.chave] ?? c.tipo;
        const valor = valorDaCelula(linha[c.chave], { ...c, tipo });
        celula.value = valor;
        celula.font = { size: 10 };
        celula.border = BORDA_FINA;
        const alinhamentoNumerico = tipo === "numero" || tipo === "percentual";
        celula.alignment = { vertical: "middle", horizontal: alinhamentoNumerico ? "right" : "left" };
        if (valor instanceof Date) celula.numFmt = FORMATO_DATA;
        else if (FORMATO_POR_TIPO[tipo] && typeof valor === "number") celula.numFmt = FORMATO_POR_TIPO[tipo];
        if (indice % 2 === 1) celula.fill = { type: "pattern", pattern: "solid", fgColor: { argb: COR.listra } };
      });
      registro.commit();
    });

    if (colunas.length) {
      planilha.autoFilter = {
        from: { row: linhaCabecalho, column: 1 },
        to: { row: linhaCabecalho, column: colunas.length },
      };
    }
  }
  if (!abas.length) livro.addWorksheet("Vazio");
  return Buffer.from(await livro.xlsx.writeBuffer());
}

const ABA = (nome, colunas, linhas) => ({ nome, colunas, linhas });

function tipoDoCampoResumo(campo) {
  if (/\(%\)$/.test(campo)) return "percentual";
  if (/\(kg\)$/.test(campo)) return "numero";
  if (campo === "Início" || campo === "Concluída em") return "data";
  return undefined;
}

export async function abasDaOperacao(empresa, opId) {
  const [op] = await q(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
  if (!op) throw new ErroHttp(404, "Operação não encontrada.");
  const [leituras, eventos, alertas, rastreio] = await Promise.all([
    q(
      `SELECT operation_id, stage, sequence_number, weight_kg, source, is_stable, is_accepted, checksum_valid, manual_reason, measured_at, accepted_at
         FROM weighing_readings WHERE company_id = ? AND operation_id = ? ORDER BY stage, sequence_number`,
      [empresa, opId],
    ),
    q(
      `SELECT e.event_type, e.event_data, e.created_at, usr.full_name AS usuario
         FROM operation_events e LEFT JOIN users usr ON usr.company_id = e.company_id AND usr.id = e.user_id
        WHERE e.company_id = ? AND e.operation_id = ? ORDER BY e.created_at, e.id`,
      [empresa, opId],
    ),
    q(
      `SELECT alert_type, severity, state, title, message, difference_kg, difference_percent, detected_at, resolved_at
         FROM alerts WHERE company_id = ? AND operation_id = ? ORDER BY detected_at`,
      [empresa, opId],
    ),
    q(
      `SELECT recorded_at, latitude, longitude, speed_kmh, progress_percent, route_deviation_meters, estimated_arrival_at
         FROM operation_tracking_points WHERE company_id = ? AND operation_id = ? ORDER BY recorded_at`,
      [empresa, opId],
    ),
  ]);

  const resumoCampos = [
    ["Código", op.operation_code],
    ["Estado", op.state],
    ["Status", op.status],
    ["Motivo do status", op.status_reason],
    ["Movimento", op.movement_type],
    ["Método", op.weighing_method],
    ["Placa", op.vehicle_plate],
    ["Veículo", [op.vehicle_type].filter(Boolean).join("")],
    ["Motorista", op.driver_name],
    ["RFID", op.rfid_code],
    ["Produto", op.cargo_product_name],
    ["Rota", op.route_code ? `${op.origin} → ${op.destination} (${op.route_distance_km} km)` : null],
    ["Início", op.started_at],
    ["Concluída em", op.completed_at],
    ["Tara registrada (kg)", op.registered_tare_snapshot_kg],
    ["Limite bruto (kg)", op.gross_limit_snapshot_kg],
    ["Vazio aferido (kg)", op.empty_truck_weight_kg],
    ["Carga separada (kg)", op.separated_cargo_weight_kg],
    ["Peso declarado (kg)", op.declared_cargo_weight_kg],
    ["Bruto esperado (kg)", op.expected_gross_weight_kg],
    ["Bruto aferido (kg)", op.loaded_truck_weight_kg],
    ["Carga aferida (kg)", op.actual_cargo_weight_kg],
    ["Diferença (kg)", op.difference_kg],
    ["Diferença (%)", op.difference_percent],
    ["Tolerância (%)", op.tolerance_percent_snapshot],
    ["Nota fiscal", op.invoice_number],
    ["MDF-e", op.mdfe_number],
    ["CIOT", op.ciot_number],
    ["Observações", op.observations],
    ["Rastreio", op.tracking_state],
    ["Progresso (%)", op.progress_percent],
    ["Responsável", op.responsible_user_name],
    ["Criada por", op.created_by_user_name],
  ].map(([campo, valor]) => ({ campo, valor: valor ?? "", __tipos: { valor: tipoDoCampoResumo(campo) } }));

  const dataCol = (chave, rotulo) => ({ chave, rotulo, tipo: "data", largura: 18 });
  const numCol = (chave, rotulo) => ({ chave, rotulo, tipo: "numero", largura: 14 });
  const pctCol = (chave, rotulo) => ({ chave, rotulo, tipo: "percentual", largura: 14 });
  const txtCol = (chave, rotulo, largura = 18) => ({ chave, rotulo, largura });

  return [
    ABA("Resumo", [txtCol("campo", "Campo", 24), txtCol("valor", "Valor", 48)], resumoCampos),
    ABA(
      "Pesagens",
      [
        txtCol("stage", "Etapa", 16),
        txtCol("sequence_number", "Sequência", 10),
        numCol("weight_kg", "Peso (kg)"),
        txtCol("source", "Origem", 12),
        txtCol("is_stable", "Estável", 10),
        txtCol("is_accepted", "Aceita", 10),
        txtCol("checksum_valid", "Checksum válido", 14),
        txtCol("manual_reason", "Motivo manual", 30),
        dataCol("measured_at", "Medida em"),
        dataCol("accepted_at", "Aceita em"),
      ],
      leituras.map((l) => ({
        ...l,
        is_stable: sim(l.is_stable),
        is_accepted: sim(l.is_accepted),
        checksum_valid: sim(l.checksum_valid),
      })),
    ),
    ABA(
      "Eventos",
      [
        dataCol("created_at", "Data/hora"),
        txtCol("event_type", "Evento", 28),
        txtCol("usuario", "Usuário", 24),
        txtCol("event_data", "Detalhes", 50),
      ],
      eventos.map((e) => ({
        ...e,
        event_data: typeof e.event_data === "string" ? e.event_data : JSON.stringify(e.event_data ?? ""),
      })),
    ),
    ABA(
      "Alertas",
      [
        txtCol("alert_type", "Tipo", 24),
        txtCol("severity", "Severidade", 12),
        txtCol("state", "Estado", 12),
        txtCol("title", "Título", 36),
        numCol("difference_kg", "Diferença (kg)"),
        pctCol("difference_percent", "Diferença (%)"),
        dataCol("detected_at", "Detectado em"),
        dataCol("resolved_at", "Resolvido em"),
      ],
      alertas,
    ),
    ABA(
      "Rastreio",
      [
        dataCol("recorded_at", "Registrado em"),
        txtCol("latitude", "Latitude", 14),
        txtCol("longitude", "Longitude", 14),
        numCol("speed_kmh", "Velocidade (km/h)"),
        pctCol("progress_percent", "Progresso (%)"),
        numCol("route_deviation_meters", "Desvio (m)"),
        dataCol("estimated_arrival_at", "Chegada prevista"),
      ],
      rastreio,
    ),
  ];
}

const sim = (v) => (v === null || v === undefined ? "" : v ? "Sim" : "Não");

export async function abasDosDados(empresa) {
  const L = LIMITE_EXPORTACAO_COMPLETA;
  const [operacoes, pesagens, eventos, rastreio, alertas, veiculos, motoristas, rotas, produtos, relatorios] =
    await Promise.all([
      q(
        `SELECT o.operation_code, o.state, o.status, o.movement_type, o.weighing_method, o.started_at, o.completed_at,
                v.plate AS vehicle_plate, d.full_name AS driver_name, cp.name AS cargo_product_name, rt.code AS route_code,
                o.declared_cargo_weight_kg, o.empty_truck_weight_kg, o.actual_cargo_weight_kg, o.expected_gross_weight_kg,
                o.loaded_truck_weight_kg, o.difference_kg, o.difference_percent, o.invoice_number, o.mdfe_number, o.ciot_number, o.observations
           FROM weighing_operations o
           JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
           LEFT JOIN drivers d ON d.company_id = o.company_id AND d.id = o.driver_id
           LEFT JOIN cargo_products cp ON cp.company_id = o.company_id AND cp.id = o.cargo_product_id
           LEFT JOIN routes rt ON rt.company_id = o.company_id AND rt.id = o.route_id
          WHERE o.company_id = ? ORDER BY o.id LIMIT ?`,
        [empresa, L],
      ),
      q(
        `SELECT o.operation_code, r.stage, r.sequence_number, r.weight_kg, r.source, r.is_stable, r.is_accepted, r.checksum_valid, r.measured_at
           FROM weighing_readings r JOIN weighing_operations o ON o.company_id = r.company_id AND o.id = r.operation_id
          WHERE r.company_id = ? ORDER BY r.id LIMIT ?`,
        [empresa, L],
      ),
      q(
        `SELECT o.operation_code, e.event_type, e.event_data, e.created_at
           FROM operation_events e JOIN weighing_operations o ON o.company_id = e.company_id AND o.id = e.operation_id
          WHERE e.company_id = ? ORDER BY e.id LIMIT ?`,
        [empresa, L],
      ),
      q(
        `SELECT o.operation_code, p.recorded_at, p.latitude, p.longitude, p.speed_kmh, p.progress_percent, p.route_deviation_meters
           FROM operation_tracking_points p JOIN weighing_operations o ON o.company_id = p.company_id AND o.id = p.operation_id
          WHERE p.company_id = ? ORDER BY p.id LIMIT ?`,
        [empresa, L],
      ),
      q(
        `SELECT o.operation_code, a.alert_context, a.alert_type, a.severity, a.state, a.title, a.difference_kg, a.detected_at, a.resolved_at
           FROM alerts a LEFT JOIN weighing_operations o ON o.company_id = a.company_id AND o.id = a.operation_id
          WHERE a.company_id = ? ORDER BY a.id LIMIT ?`,
        [empresa, L],
      ),
      q(
        `SELECT plate, fleet_code, vehicle_type, manufacturer, model, registered_tare_kg, gross_weight_limit_kg, payload_limit_kg, active
           FROM vehicles WHERE company_id = ? ORDER BY plate LIMIT ?`,
        [empresa, L],
      ),
      q(
        `SELECT full_name, employee_code, license_category, license_expiration_date, phone, active FROM drivers WHERE company_id = ? ORDER BY full_name LIMIT ?`,
        [empresa, L],
      ),
      q(
        `SELECT code, origin, destination, distance_km, description, active FROM routes WHERE company_id = ? ORDER BY code LIMIT ?`,
        [empresa, L],
      ),
      q(
        `SELECT code, name, default_unit, description, active FROM cargo_products WHERE company_id = ? ORDER BY name LIMIT ?`,
        [empresa, L],
      ),
      q(
        `SELECT report_type, period_start, period_end, file_format, summary_json, recommendations, generated_at
           FROM generated_reports WHERE company_id = ? ORDER BY id LIMIT ?`,
        [empresa, L],
      ),
    ]);

  const cols = (lista) => lista.map(([chave, rotulo, extra = {}]) => ({ chave, rotulo, largura: 18, ...extra }));
  const D = { tipo: "data" };
  const N = { tipo: "numero" };

  return [
    ABA(
      "Operações",
      cols([
        ["operation_code", "Código", { largura: 20 }],
        ["state", "Estado"],
        ["status", "Status"],
        ["movement_type", "Movimento"],
        ["weighing_method", "Método"],
        ["started_at", "Início", D],
        ["completed_at", "Concluída em", D],
        ["vehicle_plate", "Placa"],
        ["driver_name", "Motorista", { largura: 26 }],
        ["cargo_product_name", "Produto"],
        ["route_code", "Rota"],
        ["declared_cargo_weight_kg", "Peso declarado (kg)", N],
        ["empty_truck_weight_kg", "Vazio (kg)", N],
        ["actual_cargo_weight_kg", "Carga (kg)", N],
        ["expected_gross_weight_kg", "Esperado (kg)", N],
        ["loaded_truck_weight_kg", "Real (kg)", N],
        ["difference_kg", "Dif. kg", N],
        ["difference_percent", "Dif. %", { tipo: "percentual" }],
        ["invoice_number", "Nota fiscal"],
        ["mdfe_number", "MDF-e"],
        ["ciot_number", "CIOT"],
        ["observations", "Observações", { largura: 36 }],
      ]),
      operacoes,
    ),
    ABA(
      "Pesagens",
      cols([
        ["operation_code", "Operação", { largura: 20 }],
        ["stage", "Etapa"],
        ["sequence_number", "Sequência"],
        ["weight_kg", "Peso (kg)", N],
        ["source", "Origem"],
        ["is_stable", "Estável"],
        ["is_accepted", "Aceita"],
        ["checksum_valid", "Checksum"],
        ["measured_at", "Medida em", D],
      ]).map((c) =>
        c.chave === "is_stable" || c.chave === "is_accepted" || c.chave === "checksum_valid" ? { ...c } : c,
      ),
      pesagens.map((p) => ({
        ...p,
        is_stable: sim(p.is_stable),
        is_accepted: sim(p.is_accepted),
        checksum_valid: sim(p.checksum_valid),
      })),
    ),
    ABA(
      "Eventos",
      cols([
        ["operation_code", "Operação", { largura: 20 }],
        ["event_type", "Evento", { largura: 28 }],
        ["created_at", "Data/hora", D],
        ["event_data", "Detalhes", { largura: 50 }],
      ]),
      eventos.map((e) => ({
        ...e,
        event_data: typeof e.event_data === "string" ? e.event_data : JSON.stringify(e.event_data ?? ""),
      })),
    ),
    ABA(
      "Rastreio",
      cols([
        ["operation_code", "Operação", { largura: 20 }],
        ["recorded_at", "Registrado em", D],
        ["latitude", "Latitude", { largura: 14 }],
        ["longitude", "Longitude", { largura: 14 }],
        ["speed_kmh", "Velocidade (km/h)", N],
        ["progress_percent", "Progresso (%)", { tipo: "percentual" }],
        ["route_deviation_meters", "Desvio (m)", N],
      ]),
      rastreio,
    ),
    ABA(
      "Alertas",
      cols([
        ["operation_code", "Operação", { largura: 20 }],
        ["alert_context", "Contexto"],
        ["alert_type", "Tipo", { largura: 24 }],
        ["severity", "Severidade"],
        ["state", "Estado"],
        ["title", "Título", { largura: 36 }],
        ["difference_kg", "Diferença (kg)", N],
        ["detected_at", "Detectado em", D],
        ["resolved_at", "Resolvido em", D],
      ]),
      alertas,
    ),
    ABA(
      "Veículos",
      cols([
        ["plate", "Placa"],
        ["fleet_code", "Frota"],
        ["vehicle_type", "Tipo"],
        ["manufacturer", "Fabricante"],
        ["model", "Modelo"],
        ["registered_tare_kg", "Tara (kg)", N],
        ["gross_weight_limit_kg", "Limite bruto (kg)", N],
        ["payload_limit_kg", "Carga útil (kg)", N],
        ["active", "Ativo"],
      ]),
      veiculos.map((v) => ({ ...v, active: sim(v.active) })),
    ),
    ABA(
      "Motoristas",
      cols([
        ["full_name", "Nome", { largura: 28 }],
        ["employee_code", "Matrícula"],
        ["license_category", "Categoria CNH"],
        ["license_expiration_date", "Validade CNH", D],
        ["phone", "Telefone"],
        ["active", "Ativo"],
      ]),
      motoristas.map((m) => ({ ...m, phone: decifrar(m.phone), active: sim(m.active) })),
    ),
    ABA(
      "Rotas",
      cols([
        ["code", "Código"],
        ["origin", "Origem", { largura: 26 }],
        ["destination", "Destino", { largura: 26 }],
        ["distance_km", "Distância (km)", N],
        ["description", "Descrição", { largura: 30 }],
        ["active", "Ativa"],
      ]),
      rotas.map((r) => ({ ...r, active: sim(r.active) })),
    ),
    ABA(
      "Produtos",
      cols([
        ["code", "Código"],
        ["name", "Produto", { largura: 26 }],
        ["default_unit", "Unidade"],
        ["description", "Descrição", { largura: 30 }],
        ["active", "Ativo"],
      ]),
      produtos.map((p) => ({ ...p, active: sim(p.active) })),
    ),
    ABA(
      "Relatórios",
      cols([
        ["report_type", "Tipo"],
        ["period_start", "Início", D],
        ["period_end", "Fim", D],
        ["file_format", "Formato"],
        ["summary_json", "Resumo", { largura: 40 }],
        ["recommendations", "Recomendações", { largura: 50 }],
        ["generated_at", "Gerado em", D],
      ]),
      relatorios.map((r) => ({
        ...r,
        summary_json: typeof r.summary_json === "string" ? r.summary_json : JSON.stringify(r.summary_json ?? ""),
      })),
    ),
  ];
}

function valorCelula(celula) {
  const v = celula?.value;
  if (v === null || v === undefined) return null;
  if (v instanceof Date) return v;
  if (typeof v === "object") {
    if (v.richText) return v.richText.map((t) => t.text).join("");
    if ("result" in v) return v.result ?? null;
    if ("text" in v) return v.text;
  }
  return v;
}

function lerCsv(textoCsv) {
  const primeira = textoCsv.split(/\r?\n/, 1)[0] ?? "";
  const separador = (primeira.match(/;/g)?.length ?? 0) >= (primeira.match(/,/g)?.length ?? 0) ? ";" : ",";
  const linhas = [];
  let campo = "";
  let linha = [];
  let aspas = false;
  for (let i = 0; i < textoCsv.length; i++) {
    const c = textoCsv[i];
    if (aspas) {
      if (c === '"' && textoCsv[i + 1] === '"') {
        campo += '"';
        i++;
      } else if (c === '"') aspas = false;
      else campo += c;
    } else if (c === '"') aspas = true;
    else if (c === separador) {
      linha.push(campo);
      campo = "";
    } else if (c === "\n" || c === "\r") {
      if (c === "\r" && textoCsv[i + 1] === "\n") i++;
      linha.push(campo);
      linhas.push(linha);
      linha = [];
      campo = "";
    } else campo += c;
  }
  if (campo !== "" || linha.length) {
    linha.push(campo);
    linhas.push(linha);
  }
  return linhas;
}

export async function lerPlanilha(buffer) {
  const ehXlsx = buffer.length > 2 && buffer[0] === 0x50 && buffer[1] === 0x4b;
  let matriz;
  if (ehXlsx) {
    const livro = new ExcelJS.Workbook();
    try {
      await livro.xlsx.load(buffer);
    } catch {
      throw new ErroHttp(422, "Não consegui abrir a planilha. Verifique se é um XLSX válido.");
    }
    const aba = livro.worksheets[0];
    if (!aba) throw new ErroHttp(422, "A planilha não tem abas.");
    matriz = [];
    aba.eachRow({ includeEmpty: true }, (linha, numero) => {
      const valores = [];
      linha.eachCell({ includeEmpty: true }, (celula, coluna) => {
        valores[coluna - 1] = valorCelula(celula);
      });
      matriz[numero - 1] = valores;
    });
    matriz = matriz.filter(Boolean);
  } else {
    matriz = lerCsv(buffer.toString("utf8").replace(/^\uFEFF/, ""));
  }
  if (!matriz.length) throw new ErroHttp(422, "A planilha está vazia.");

  const cabecalhos = matriz[0].map(normalizarCabecalho);
  const linhas = [];
  for (let i = 1; i < matriz.length; i++) {
    const valores = matriz[i] ?? [];
    if (valores.every((v) => v === null || v === undefined || String(v).trim() === "")) continue;
    const dados = {};
    cabecalhos.forEach((cab, idx) => {
      if (cab) dados[cab] = valores[idx] ?? null;
    });
    linhas.push({ numero: i + 1, dados });
  }
  return { cabecalhos, linhas };
}

export function mapearColunas(cabecalhos) {
  const mapa = {};
  for (const col of COLUNAS_PLANILHA) {
    const nomes = [col.chave, normalizarCabecalho(col.rotulo), ...(col.apelidos ?? []).map(normalizarCabecalho)];
    const achado = cabecalhos.find((c) => nomes.includes(c));
    if (achado) mapa[col.chave] = achado;
  }
  return mapa;
}
