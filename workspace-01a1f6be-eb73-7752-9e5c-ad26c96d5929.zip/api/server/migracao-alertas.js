import { q, exec } from "./db.js";

export async function garantirEstruturaAlertas() {
  const linhas = await q(
    `SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'alerts' AND COLUMN_NAME = 'resolution_reason'`,
  );
  if (linhas.length === 0) {
    await exec("ALTER TABLE alerts ADD COLUMN resolution_reason VARCHAR(40) DEFAULT NULL AFTER resolution_notes");
    return true;
  }
  return false;
}
