const BASE = (process.argv[2] ?? process.env.LS_API ?? "http://127.0.0.1:5174").replace(/\/$/, "");
const API = `${BASE}/api`;
const EMAIL = process.env.LS_EMAIL ?? "admin@loadsense.local";
const SENHA = process.env.LS_SENHA ?? "LoadSense@2026";

let ok = 0;
const falhas = [];
const verde = (t) => `\u001b[32m${t}\u001b[0m`;
const vermelho = (t) => `\u001b[31m${t}\u001b[0m`;

function passou(desc, extra = "") {
  ok++;
  console.log(`  ${verde("[OK]")} ${desc}${extra ? ` ${extra}` : ""}`);
}
function falhou(desc, detalhe) {
  falhas.push(desc);
  console.log(
    `  ${vermelho("[FALHA]")} ${desc}\n     → ${typeof detalhe === "string" ? detalhe : JSON.stringify(detalhe).slice(0, 240)}`,
  );
}
function verificar(desc, condicao, detalhe = "") {
  condicao ? passou(desc, detalhe) : falhou(desc, detalhe || "condição não atendida");
}
const titulo = (t) => console.log(`\n\u001b[1m${t}\u001b[0m`);

let token = null;
let refreshToken = null;

async function chamar(metodo, caminho, corpo, { auth = true, bruto = false } = {}) {
  const res = await fetch(`${API}${caminho}`, {
    method: metodo,
    headers: {
      ...(corpo ? { "content-type": "application/json" } : {}),
      ...(auth && token ? { authorization: `Bearer ${token}` } : {}),
    },
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  const texto = await res.text();
  let dados;
  try {
    dados = JSON.parse(texto);
  } catch {
    dados = texto;
  }
  return { status: res.status, dados, cabecalhos: res.headers };
}

console.log("======================================================================");
console.log(" LoadSense — testes da API REST");
console.log(` Servidor: ${BASE}`);
console.log("======================================================================");

titulo("1. Disponibilidade");
{
  const r = await chamar("GET", "/saude", null, { auth: false });
  verificar("GET /api/saude responde 200", r.status === 200, r.status);
  verificar(
    "banco acessível e migração registrada",
    r.dados?.banco?.migracao?.version >= 3,
    JSON.stringify(r.dados?.banco),
  );
}

titulo("2. Autenticação");
{
  const errado = await chamar("POST", "/auth/login", { email: EMAIL, senha: "senha-errada" }, { auth: false });
  verificar("login com senha inválida é recusado (401)", errado.status === 401, errado.status);

  const r = await chamar(
    "POST",
    "/auth/login",
    { email: EMAIL, senha: SENHA, dispositivoUuid: "teste-automatizado", plataforma: "WEB" },
    { auth: false },
  );
  verificar(
    "login válido devolve tokens",
    r.status === 200 && !!r.dados.accessToken && !!r.dados.refreshToken,
    r.status,
  );
  verificar(
    "login devolve empresa, papel e permissões",
    !!r.dados.empresa?.nome && Array.isArray(r.dados.permissoes) && r.dados.permissoes.length > 10,
    `${r.dados?.permissoes?.length} permissões`,
  );
  token = r.dados.accessToken;
  refreshToken = r.dados.refreshToken;

  const eu = await chamar("GET", "/auth/eu");
  verificar("GET /api/auth/eu reconhece a sessão", eu.status === 200 && eu.dados.usuario?.email === EMAIL, eu.status);
  verificar(
    "perfil traz preferências e assinatura",
    !!eu.dados.preferencias && !!eu.dados.assinatura?.plan_name,
    eu.dados?.assinatura?.plan_name,
  );

  const semToken = await chamar("GET", "/auth/eu", null, { auth: false });
  verificar("rota protegida sem token responde 401", semToken.status === 401, semToken.status);

  const renovado = await chamar("POST", "/auth/refresh", { refreshToken }, { auth: false });
  verificar(
    "refresh renova o token de acesso",
    renovado.status === 200 && !!renovado.dados.accessToken,
    renovado.status,
  );
  token = renovado.dados.accessToken;
}

titulo("3. Cadastros de apoio");
{
  const veiculos = await chamar("GET", "/veiculos");
  verificar(
    "lista de veículos com tara e limites",
    veiculos.dados?.veiculos?.length >= 6 && veiculos.dados.veiculos[0].registered_tare_kg > 0,
    `${veiculos.dados?.veiculos?.length} veículos`,
  );
  const motoristas = await chamar("GET", "/motoristas");
  verificar(
    "lista de motoristas ativos",
    motoristas.dados?.motoristas?.length >= 5,
    `${motoristas.dados?.motoristas?.length}`,
  );
  const rotas = await chamar("GET", "/rotas");
  const comWaypoints = rotas.dados?.rotas?.filter((r) => r.waypoints?.length);
  verificar(
    "rotas trazem o traçado (waypoints) do mapa",
    comWaypoints?.length >= 1,
    `${comWaypoints?.[0]?.waypoints?.length} pontos em ${comWaypoints?.[0]?.code}`,
  );
  const dispositivos = await chamar("GET", "/dispositivos");
  verificar(
    "dispositivos embarcados com estado e calibração",
    dispositivos.dados?.dispositivos?.length >= 4 && !!dispositivos.dados.resumo,
    JSON.stringify(dispositivos.dados?.resumo),
  );
  const postos = await chamar("GET", "/postos");
  verificar(
    "posto de pesagem com balança e leitor RFID",
    postos.dados?.postos?.[0]?.balanca && postos.dados.postos[0].leitor_rfid,
    postos.dados?.postos?.[0]?.name,
  );
}

titulo("4. Painel e indicadores");
{
  const painel = await chamar("GET", "/painel?dias=30");
  const k = painel.dados?.kpis ?? {};
  verificar(
    "painel responde com KPIs do período",
    painel.status === 200 && k.operacoes > 0,
    `${k?.operacoes} operações, ${k?.toneladas} t`,
  );
  verificar(
    "série diária disponível para o gráfico",
    painel.dados?.serie?.length > 5,
    `${painel.dados?.serie?.length} dias`,
  );
  verificar(
    "alertas abertos listados no painel",
    Array.isArray(painel.dados?.alertasAbertos),
    `${painel.dados?.alertasAbertos?.length} alertas`,
  );
  verificar("eficiência calculada a partir dos status", typeof k?.eficienciaPct === "number", `${k?.eficienciaPct}%`);
}

titulo("5. Operações: criação, leitura, aceite e finalização");
let operacaoId = null;
{
  const lista = await chamar("GET", "/operacoes?limite=5");
  verificar(
    "lista paginada de operações",
    lista.status === 200 && lista.dados.operacoes.length > 0 && lista.dados.total > 0,
    `${lista.dados?.total} operações`,
  );

  const criada = await chamar("POST", "/operacoes", {
    placa: "ABC1A23",
    rotaCodigo: "R-01",
    metodo: "THREE_STAGE",
    tipoMovimento: "EXIT",
    pesoDeclaradoKg: 14000,
    observacoes: "Teste automatizado da API",
  });
  operacaoId = criada.dados?.id;
  verificar(
    "operações são criadas com código e snapshots do banco",
    criada.status === 201 && criada.dados.codigo?.startsWith("PES-") && criada.dados.pesos.taraCadastradaKg > 0,
    `${criada.dados?.codigo}`,
  );
  verificar(
    "operação nasce em rascunho e em análise",
    criada.dados?.estado === "DRAFT" && criada.dados?.status === "ANALYSIS",
  );

  const leituraVazio = await chamar("POST", `/operacoes/${operacaoId}/leituras`, {
    estagio: "EMPTY_TRUCK",
    pesoKg: 8500,
    origem: "DEVICE",
  });
  verificar(
    "leitura automática aceita via procedure",
    leituraVazio.status === 201 && leituraVazio.dados.leitura.aceita === true,
    leituraVazio.dados?.leitura?.pesoKg,
  );
  verificar(
    "operação passa a em andamento",
    leituraVazio.dados.operacao.estado === "IN_PROGRESS",
    leituraVazio.dados?.operacao?.estado,
  );

  const veiculosRfid = await chamar("GET", "/veiculos");
  const etiquetaCaminhao = veiculosRfid.dados?.veiculos?.find((v) => v.plate === "ABC1A23")?.rfid_code;
  const ativou = await chamar("POST", `/operacoes/${operacaoId}/rastreio/ativar`, {
    codigoRfid: etiquetaCaminhao,
  });
  verificar(
    "rastreio ativado com a etiqueta RFID do caminhão",
    ativou.status === 200 && ativou.dados?.rastreioAtivado === true,
    `${ativou.status} ${JSON.stringify(ativou.dados)}`,
  );

  const leituraSemEstabilidade = await chamar("POST", `/operacoes/${operacaoId}/leituras`, {
    estagio: "SEPARATED_CARGO",
    pesoKg: 13800,
    origem: "DEVICE",
    estavel: false,
    aceitar: true,
  });
  verificar(
    "aceite de leitura instável é bloqueado pelo banco",
    leituraSemEstabilidade.status === 422,
    `${leituraSemEstabilidade.status} ${leituraSemEstabilidade.dados?.erro}`,
  );
  await chamar("POST", `/operacoes/${operacaoId}/leituras`, {
    estagio: "SEPARATED_CARGO",
    pesoKg: 13800,
    origem: "DEVICE",
    estavel: true,
  });

  const semMotivo = await chamar("POST", `/operacoes/${operacaoId}/leituras`, {
    estagio: "LOADED_TRUCK",
    pesoKg: 22300,
    origem: "MANUAL",
  });
  verificar(
    "leitura manual sem motivo é recusada",
    semMotivo.status === 422,
    `${semMotivo.status} ${semMotivo.dados?.erro}`,
  );

  await chamar("POST", `/operacoes/${operacaoId}/leituras`, {
    estagio: "LOADED_TRUCK",
    pesoKg: 22780,
    origem: "DEVICE",
  });
  const finalizada = await chamar("POST", `/operacoes/${operacaoId}/finalizar`);
  verificar(
    "finalização calcula carga e status",
    finalizada.status === 200 && finalizada.dados.operacao.estado === "COMPLETED",
    `${finalizada.dados?.operacao?.status} · ${finalizada.dados?.operacao?.pesos?.cargaAferidaKg} kg`,
  );
  verificar(
    "divergência de 480 kg (2,15%) classificada como atenção",
    finalizada.dados?.operacao?.status === "ATTENTION",
    `desvio ${finalizada.dados?.operacao?.pesos?.desvioKg} kg / ${finalizada.dados?.operacao?.pesos?.desvioPct}%`,
  );
  verificar(
    "alerta de divergência gerado no fechamento",
    finalizada.dados?.alertas?.some((a) => ["POSSIBLE_EXTRA_CARGO", "POSSIBLE_MISSING_CARGO"].includes(a.tipo)),
    finalizada.dados?.alertas?.map((a) => a.tipo).join(","),
  );

  const detalhe = await chamar("GET", `/operacoes/${operacaoId}`);
  const aceitas = (detalhe.dados.leituras ?? []).filter((l) => l.aceita).length;
  verificar(
    "detalhe traz as 4 leituras (3 aceitas) e os eventos",
    (detalhe.dados.leituras ?? []).length === 4 && aceitas === 3 && (detalhe.dados.eventos ?? []).length >= 4,
    `${detalhe.dados?.leituras?.length} leituras (${aceitas} aceitas), ${detalhe.dados?.eventos?.length} eventos`,
  );
  verificar(
    "leitura instável permanece registrada e recusada",
    (detalhe.dados.leituras ?? []).some((l) => !l.aceita && l.origem === "DEVICE"),
  );
  verificar(
    "trilha registra criação, aceites e finalização",
    (detalhe.dados.eventos ?? []).some((e) => e.tipo === "CREATED") &&
      (detalhe.dados.eventos ?? []).some((e) => e.tipo === "READING_ACCEPTED") &&
      (detalhe.dados.eventos ?? []).some((e) => e.tipo === "FINALIZED"),
  );

  const semPermissao = await fetch(`${API}/operacoes/${operacaoId}`, {
    headers: { authorization: "Bearer token-invalido" },
  });
  verificar("token inválido recebe 401", semPermissao.status === 401, semPermissao.status);
}

titulo("6. Transporte e rastreamento");
{
  const agenda = await chamar("POST", `/operacoes/${operacaoId}/transporte/agenda`, {
    saidaPlanejada: new Date(Date.now() - 30 * 60000).toISOString(),
    chegadaPlanejada: new Date(Date.now() + 60 * 60000).toISOString(),
  });
  verificar(
    "agenda da viagem gravada",
    agenda.status === 200 && !!agenda.dados.datas.saidaPlanejada,
    agenda.dados?.datas?.saidaPlanejada,
  );

  const iniciado = await chamar("POST", `/operacoes/${operacaoId}/transporte/iniciar`);
  verificar(
    "transporte iniciado com estado IN_TRANSIT",
    iniciado.dados?.rastreio?.estado === "IN_TRANSIT",
    iniciado.dados?.rastreio?.estado,
  );

  const ponto = await chamar("POST", `/operacoes/${operacaoId}/rastreio`, {
    latitude: -23.65,
    longitude: -46.69,
    velocidadeKmh: 72,
    progressoPct: 22,
    eta: new Date(Date.now() + 50 * 60000).toISOString(),
  });
  verificar(
    "ponto de rastreio aceito e consolidado pelo trigger",
    ponto.status === 201 && ponto.dados.operacao.rastreio.progressoPct === 22,
    `progresso ${ponto.dados?.operacao?.rastreio?.progressoPct}%`,
  );

  const parado1 = await chamar("POST", `/operacoes/${operacaoId}/rastreio`, {
    latitude: -23.66,
    longitude: -46.68,
    velocidadeKmh: 0,
    progressoPct: 24,
  });
  verificar(
    "velocidade zero muda o estado para parado",
    parado1.dados.operacao.rastreio.estado === "STOPPED",
    parado1.dados?.operacao?.rastreio?.estado,
  );

  const desvio = await chamar("POST", `/operacoes/${operacaoId}/rastreio`, {
    latitude: -23.5,
    longitude: -46.3,
    velocidadeKmh: 60,
    progressoPct: 40,
    desvioMetros: 1500,
  });
  const alertasRastreio = await chamar("GET", `/alertas?operacaoId=${operacaoId}&situacao=OPEN`);
  verificar(
    "desvio de rota gera alerta de rastreio",
    alertasRastreio.dados.alertas.some((a) => a.tipo === "ROUTE_DEVIATION"),
    alertasRastreio.dados?.alertas?.map((a) => a.tipo).join(","),
  );

  const ativos = await chamar("GET", "/rastreio/ativo");
  verificar(
    "monitoramento lista viagens em andamento",
    ativos.dados.viagens.length >= 2,
    `${ativos.dados?.viagens?.length} viagens`,
  );

  const rastreio = await chamar("GET", `/operacoes/${operacaoId}/rastreio`);
  verificar(
    "trajeto devolve pontos e waypoints da rota",
    rastreio.dados.pontos.length >= 3 && rastreio.dados.waypoints.length >= 2,
    `${rastreio.dados?.pontos?.length} pontos, ${rastreio.dados?.waypoints?.length} waypoints`,
  );

  const chegada = await chamar("POST", `/operacoes/${operacaoId}/transporte/chegada`);
  verificar(
    "chegada encerra o rastreio em 100%",
    chegada.dados?.rastreio?.estado === "ARRIVED" && chegada.dados.rastreio.progressoPct === 100,
    chegada.dados?.rastreio?.estado,
  );

  const ativosDepois = await chamar("GET", "/rastreio/ativo");
  verificar("viagem concluída sai do monitoramento", !ativosDepois.dados.viagens.some((v) => v.id === operacaoId));

  const varredura = await chamar("POST", "/rastreio/avaliar");
  verificar("varredura de perda de sinal executa sem erro", varredura.status === 200 && varredura.dados.ok === true);
}

titulo("7. Central de alertas");
{
  const lista = await chamar("GET", "/alertas?limite=10");
  verificar(
    "lista de alertas com filtros e totalizadores",
    lista.status === 200 && lista.dados.alertas.length > 0,
    `${lista.dados?.total} alertas (${lista.dados?.abertos} abertos)`,
  );
  const comContexto = await chamar("GET", "/alertas?contexto=TRACKING&limite=5");
  verificar(
    "filtro por contexto de rastreio funciona",
    comContexto.dados.alertas.every((a) => a.contexto === "TRACKING"),
    `${comContexto.dados?.alertas?.length} alertas de rastreio`,
  );

  const alvo = lista.dados.alertas.find((a) => a.situacao !== "RESOLVED");
  const reconhecido = await chamar("POST", `/alertas/${alvo.id}/reconhecer`);
  verificar(
    "alerta reconhecido com usuário e data",
    reconhecido.dados?.situacao === "ACKNOWLEDGED" && !!reconhecido.dados.reconhecidoPor,
    reconhecido.dados?.reconhecidoPor,
  );

  const semMotivo = await chamar("POST", `/alertas/${alvo.id}/resolver`, {
    acao: "Conferido com o motorista; carga redistribuída.",
  });
  verificar("resolver sem motivo é recusado", semMotivo.status === 422, `${semMotivo.status}`);
  const acaoCurta = await chamar("POST", `/alertas/${alvo.id}/resolver`, { motivo: "OUTRO", acao: "ok" });
  verificar("resolver com descrição curta é recusado", acaoCurta.status === 422, `${acaoCurta.status}`);
  const resolvido = await chamar("POST", `/alertas/${alvo.id}/resolver`, {
    motivo: "CARGA_CORRIGIDA",
    acao: "Conferido com o motorista; carga redistribuída.",
  });
  verificar(
    "alerta resolvido com motivo e ação",
    resolvido.dados?.situacao === "RESOLVED" &&
      resolvido.dados.motivoResolucao === "CARGA_CORRIGIDA" &&
      !!resolvido.dados.notasResolucao &&
      !!resolvido.dados.resolvidoPor,
    `${resolvido.dados?.motivoResolucao} · ${resolvido.dados?.resolvidoPor}`,
  );
  const resolvidoDeNovo = await chamar("POST", `/alertas/${alvo.id}/resolver`, {
    motivo: "OUTRO",
    acao: "Tentativa de resolver duas vezes.",
  });
  verificar("resolver alerta já resolvido é recusado", resolvidoDeNovo.status === 422, `${resolvidoDeNovo.status}`);

  const detalhe = await chamar("GET", `/alertas/${alvo.id}`);
  verificar(
    "detalhe do alerta traz histórico da operação",
    Array.isArray(detalhe.dados.historico),
    `${detalhe.dados?.historico?.length} eventos`,
  );

  const reaberto = await chamar("POST", `/alertas/${alvo.id}/reabrir`);
  verificar(
    "alerta resolvido pode ser reaberto",
    reaberto.status === 200 && reaberto.dados.situacao === "OPEN",
    reaberto.dados?.situacao,
  );
  const reabrirDeNovo = await chamar("POST", `/alertas/${alvo.id}/reabrir`);
  verificar(
    "reabrir alerta já aberto é recusado",
    reabrirDeNovo.status === 422,
    `${reabrirDeNovo.status} ${reabrirDeNovo.dados?.erro}`,
  );
  await chamar("POST", `/alertas/${alvo.id}/resolver`, {
    motivo: "DIVERGENCIA_JUSTIFICADA",
    acao: "Encerrado após nova conferência.",
  });

  const emLote = await chamar("POST", "/alertas/resolver-todos");
  verificar(
    "resolução em lote conclui os alertas abertos",
    emLote.status === 200,
    `${emLote.dados?.resolvidos} resolvidos`,
  );
}

titulo("8. Relatórios");
{
  const resumo = await chamar("GET", "/relatorios/resumo?dias=30");
  verificar(
    "resumo do período calculado na hora",
    resumo.status === 200 && resumo.dados.resumo.operacoes > 0,
    `${resumo.dados?.resumo?.operacoes} operações · ${resumo.dados?.resumo?.toneladas} t`,
  );
  verificar(
    "resumo detalha pesagens automáticas e manuais",
    !!resumo.dados.resumo.pesagens,
    JSON.stringify(resumo.dados?.resumo?.pesagens),
  );

  const criado = await chamar("POST", "/relatorios", {
    inicio: new Date(Date.now() - 30 * 86400000).toISOString(),
    fim: new Date().toISOString(),
    tipo: "MENSAL",
    formato: "PDF",
  });
  verificar(
    "relatório registrado com resumo e recomendações",
    criado.status === 201 && !!criado.dados.resumo && !!criado.dados.recomendacoes?.length,
    criado.dados?.recomendacoes?.slice(0, 80),
  );

  const lista = await chamar("GET", "/relatorios");
  verificar(
    "histórico de relatórios listado",
    lista.dados.relatorios.length >= 1,
    `${lista.dados?.relatorios?.length} relatórios`,
  );

  const detalhe = await chamar("GET", `/relatorios/${criado.dados.id}`);
  verificar(
    "detalhe do relatório recupera o resumo",
    detalhe.status === 200 && !!detalhe.dados.resumo,
    detalhe.dados?.tipo,
  );

  const csv = await chamar("GET", `/relatorios/${criado.dados.id}/exportar.csv`);
  verificar(
    "exportação CSV gera arquivo com cabeçalho",
    typeof csv.dados === "string" && csv.dados.includes("operacao;"),
    `${String(csv.dados).split("\n").length} linhas`,
  );
}

titulo("9. Configurações, preferências e plano");
{
  const atuais = await chamar("GET", "/configuracoes");
  const toleranciaAntiga = atuais.dados.configuracoes.tolerance_percent;
  verificar(
    "configurações da empresa disponíveis",
    !!atuais.dados.configuracoes.tracking_alerts_enabled,
    `tolerância ${toleranciaAntiga}%`,
  );

  const patch = await chamar("PATCH", "/configuracoes", { tolerance_percent: 2.0, require_rfid: false });
  verificar(
    "tolerância atualizada pela API",
    patch.dados?.configuracoes?.tolerance_percent === 2.0,
    patch.dados?.configuracoes?.tolerance_percent,
  );
  await chamar("PATCH", "/configuracoes", { tolerance_percent: toleranciaAntiga });

  const prefsAntigas = (await chamar("GET", "/preferencias")).dados?.preferencias;
  const prefs = await chamar("PUT", "/preferencias", {
    tema: "DARK",
    notificacoes: true,
    sons: false,
    autoSync: true,
    limiteAlertasPainel: 5,
  });
  verificar(
    "preferências do app gravadas",
    prefs.dados?.preferencias?.sound_alerts_enabled === 0 && prefs.dados.preferencias.dashboard_alert_limit === 5,
    JSON.stringify(prefs.dados?.preferencias),
  );
  if (prefsAntigas) {
    await chamar("PUT", "/preferencias", {
      tema: prefsAntigas.theme,
      idioma: prefsAntigas.language_code,
      notificacoes: prefsAntigas.push_notifications_enabled === 1,
      sons: prefsAntigas.sound_alerts_enabled === 1,
      autoSync: prefsAntigas.automatic_sync_enabled === 1,
      limiteAlertasPainel: prefsAntigas.dashboard_alert_limit,
      alertasPorPagina: prefsAntigas.alerts_page_size,
      periodoPadraoDias: prefsAntigas.default_period_days,
    });
  }

  const assinatura = await chamar("GET", "/assinatura");
  verificar(
    "assinatura atual e histórico",
    !!assinatura.dados.atual?.plan_name && assinatura.dados.historico.length >= 1,
    assinatura.dados?.atual?.plan_name,
  );

  const planos = await chamar("GET", "/planos", null, { auth: false });
  verificar(
    "catálogo público de planos",
    planos.dados.planos.length === 4 &&
      planos.dados.planos.map((p) => p.code).join(",") === "ESSENCIAL,PROFISSIONAL,AVANCADO,ENTERPRISE",
    planos.dados?.planos?.map((p) => p.code).join(","),
  );

  const plataforma = await chamar("GET", "/plataforma?plataforma=ANDROID", null, { auth: false });
  verificar(
    "versão mínima e modo manutenção",
    plataforma.status === 200 && plataforma.dados.minimum_supported_build_number >= 1,
    JSON.stringify(plataforma.dados).slice(0, 80),
  );

  const publicado = await chamar("POST", "/documentos-legais", {
    tipo: "TERMS_OF_USE",
    versao: `teste-${Date.now()}`,
    titulo: "Termos de Uso — versão de teste automatizado",
    conteudo: "# Termos de Uso (teste)\n\nDocumento criado pela suíte de testes da API para validar o fluxo de aceite.",
    formato: "MARKDOWN",
  });
  verificar(
    "nova versão de termo publicada com hash do conteúdo",
    publicado.status === 201 && publicado.dados.hash?.length === 64,
    `v${publicado.dados?.versao}`,
  );

  const pendentes = await chamar("GET", "/documentos-legais/pendentes");
  verificar(
    "termos pendentes de aceite listados",
    pendentes.dados.pendentes.length >= 1,
    `${pendentes.dados?.pendentes?.length} documento(s)`,
  );
  const primeiro = pendentes.dados.pendentes[0];
  const aceite = await chamar("POST", `/documentos-legais/${primeiro.legal_document_id}/aceitar`, {
    versaoApp: "1.0.0",
    buildApp: 1,
  });
  verificar(
    "aceite de termo registrado com auditoria",
    aceite.status === 200 && aceite.dados.ok === true,
    primeiro?.title,
  );
  const pendentesDepois = await chamar("GET", "/documentos-legais/pendentes");
  verificar(
    "termo aceito sai da lista de pendências",
    pendentesDepois.dados.pendentes.length === pendentes.dados.pendentes.length - 1,
  );
}

titulo("10. Cadastro público de empresa");
{
  const invalido = await chamar(
    "POST",
    "/empresas/solicitacoes",
    { razaoSocial: "X", cnpj: "1", responsavel: "", email: "a", aceitouPrivacidade: false },
    { auth: false },
  );
  verificar("solicitação incompleta é recusada com detalhes", invalido.status === 422, invalido.dados?.erro);

  const cnpj = String(Date.now()).slice(-14).padStart(14, "0");
  const criada = await chamar(
    "POST",
    "/empresas/solicitacoes",
    {
      razaoSocial: "Transportadora Teste Automatizado LTDA",
      cnpj,
      responsavel: "Fulano de Tal",
      email: `teste${Date.now()}@exemplo.com`,
      telefone: "(11) 99999-0000",
      aceitouPrivacidade: true,
    },
    { auth: false },
  );
  verificar(
    "solicitação registrada como pendente",
    criada.status === 201 && criada.dados.situacao === "PENDING",
    criada.dados?.mensagem?.slice(0, 60),
  );

  const duplicada = await chamar(
    "POST",
    "/empresas/solicitacoes",
    {
      razaoSocial: "Transportadora Teste Automatizado LTDA",
      cnpj,
      responsavel: "Fulano de Tal",
      email: `teste${Date.now()}@exemplo.com`,
      aceitouPrivacidade: true,
    },
    { auth: false },
  );
  verificar("CNPJ com solicitação pendente não duplica", duplicada.status === 409, duplicada.status);
}

titulo("10b. Cadastro de caminhão (POST /api/veiculos)");
{
  const sorteio = Math.random()
    .toString(36)
    .slice(2, 7)
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "X");
  const letras = "ABCDEFGHJKLMNPRSTUVWXYZ";
  const placa = `TST${Math.floor(Math.random() * 9)}${letras[Math.floor(Math.random() * letras.length)]}${String(Math.floor(Math.random() * 90) + 10)}`;
  const rfid = `TST-${sorteio}`;

  const semLogin = await chamar("POST", "/veiculos", { placa }, { auth: false });
  verificar("cadastro de caminhão sem login é recusado (401)", semLogin.status === 401, semLogin.status);

  const placaRuim = await chamar("POST", "/veiculos", { placa: "XX" });
  verificar("placa inválida é recusada (422)", placaRuim.status === 422, placaRuim.status);

  const pesoRuim = await chamar("POST", "/veiculos", {
    placa: `${placa.slice(0, 6)}${(Number(placa[6]) + 1) % 10}`,
    taraKg: 9000,
    limitePbtKg: 8000,
  });
  verificar("limite de peso menor que a tara é recusado (422)", pesoRuim.status === 422, pesoRuim.status);

  const novo = await chamar("POST", "/veiculos", {
    placa: placa.slice(0, 3) + "-" + placa.slice(3),
    tipo: "TRUCK",
    rfid,
    frota: `F-${sorteio}`,
    fabricante: "Volvo",
    modelo: "FH 540",
    anoFabricacao: 2023,
    eixos: 3,
    taraKg: 8200,
    limitePbtKg: 23000,
    limiteCargaKg: 14800,
  });
  verificar(
    "cadastro válido responde 201",
    novo.status === 201,
    `${novo.status} ${JSON.stringify(novo.dados).slice(0, 160)}`,
  );
  verificar("placa é normalizada (sem hífen, maiúscula)", novo.dados?.plate === placa, novo.dados?.plate);
  verificar("RFID vinculado ao caminhão novo", novo.dados?.rfid_code === rfid, novo.dados?.rfid_code);
  verificar(
    "pesos gravados como número",
    novo.dados?.registered_tare_kg === 8200 && novo.dados?.payload_limit_kg === 14800,
  );

  const dupPlaca = await chamar("POST", "/veiculos", { placa });
  verificar("placa repetida é recusada (409)", dupPlaca.status === 409, dupPlaca.status);

  const dupRfid = await chamar("POST", "/veiculos", {
    placa: `${placa.slice(0, 6)}${(Number(placa[6]) + 1) % 10}`,
    rfid,
  });
  verificar("etiqueta RFID já em uso é recusada (409)", dupRfid.status === 409, dupRfid.status);

  const lista = await chamar("GET", "/veiculos");
  const achou = (lista.dados?.veiculos ?? []).find((v) => v.plate === placa);
  verificar("caminhão cadastrado aparece na lista de veículos", Boolean(achou) && achou.rfid_code === rfid);
}

titulo("11. Encerramento de sessão");
{
  const saida = await chamar("POST", "/auth/logout", { refreshToken });
  verificar("logout executado", saida.status === 200 && saida.dados.ok === true);
  const depois = await chamar("POST", "/auth/refresh", { refreshToken }, { auth: false });
  verificar("refresh com sessão revogada é recusado", depois.status === 401, depois.status);
}

const total = ok + falhas.length;
console.log("\n======================================================================");
console.log(
  ` ${total} testes executados: ${verde(`${ok} OK`)}, ${falhas.length ? vermelho(`${falhas.length} falhas`) : "0 falhas"}`,
);
if (falhas.length) {
  console.log("\n Falhas:");
  for (const f of falhas) console.log(`  - ${f}`);
}
console.log("======================================================================");
process.exit(falhas.length ? 1 : 0);
