import { q, um } from "../db.js";

const API = `${(process.env.LS_API ?? "http://127.0.0.1:5174").replace(/\/$/, "")}/api`;
let ok = 0;
let falhas = 0;
const verificar = (descricao, condicao, detalhe = "") => {
  if (condicao) {
    ok += 1;
    console.log(`  OK     ${descricao}`);
  } else {
    falhas += 1;
    console.log(`  FALHA  ${descricao} ${detalhe}`);
  }
};

async function chamar(metodo, caminho, corpo, token) {
  const res = await fetch(API + caminho, {
    method: metodo,
    headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  return { status: res.status, dados: await res.json().catch(() => null) };
}

console.log("\nFluxo real");
const login = await chamar("POST", "/auth/login", { email: "admin@loadsense.local", senha: "LoadSense@2026" });
const token = login.dados?.accessToken;
verificar("login admin", login.status === 200 && Boolean(token));

const empresa = await um(`SELECT company_id FROM users WHERE email = 'admin@loadsense.local'`);
const motorista = await um(`SELECT full_name FROM drivers WHERE company_id = ? AND active = 1 ORDER BY id LIMIT 1`, [
  empresa.company_id,
]);
const criada = await chamar(
  "POST",
  "/operacoes",
  {
    placa: "ABC1A23",
    rotaCodigo: "R-01",
    metodo: "THREE_STAGE",
    tipoMovimento: "EXIT",
    pesoDeclaradoKg: 14000,
    motorista: motorista.full_name,
    observacoes: "Teste de evento de rastreio",
  },
  token,
);
verificar("operação criada", criada.status === 201, `(${criada.status})`);
const opId = criada.dados?.id;
const etiqueta = await um(
  "SELECT r.code FROM weighing_operations o JOIN rfid_tags r ON r.company_id = o.company_id AND r.vehicle_id = o.vehicle_id AND r.active = 1 WHERE o.id = ? LIMIT 1",
  [opId],
);
const ativado = await chamar("POST", `/operacoes/${opId}/rastreio/ativar`, { codigoRfid: etiqueta?.code }, token);
verificar("rastreio ativado com o código RFID", ativado.status === 200, `(${ativado.status})`);
for (const [estagio, peso] of [
  ["EMPTY_TRUCK", 8200],
  ["SEPARATED_CARGO", 13800],
  ["LOADED_TRUCK", 22780],
]) {
  await chamar(
    "POST",
    `/operacoes/${opId}/leituras`,
    { estagio, pesoKg: peso, origem: "DEVICE", estavel: true },
    token,
  );
}
const fin = await chamar("POST", `/operacoes/${opId}/finalizar`, null, token);
verificar("pesagem finalizada", fin.status === 200, `(${fin.status})`);

const eventosDeRastreio = async () =>
  (
    await q(
      `SELECT event_type FROM operation_events WHERE operation_id = ? AND event_type LIKE 'TRACKING_%' ORDER BY id`,
      [opId],
    )
  ).map((e) => e.event_type);
const enviarPonto = async (corpo) => chamar("POST", `/operacoes/${opId}/rastreio`, corpo, token);
const sequencia = (lista) => lista.join(" > ");

const p1 = await enviarPonto({ latitude: -23.5, longitude: -46.6, velocidadeKmh: 60, progressoPct: 40 });
verificar("primeiro ponto aceito", p1.status === 201, `(${p1.status})`);
let ev = await eventosDeRastreio();
verificar("início grava um único TRACKING_STARTED", sequencia(ev) === "TRACKING_STARTED", sequencia(ev));

await enviarPonto({ latitude: -23.6, longitude: -46.7, velocidadeKmh: 55, progressoPct: 45 });
await enviarPonto({ latitude: -23.61, longitude: -46.71, velocidadeKmh: 52, progressoPct: 47 });
ev = await eventosDeRastreio();
verificar("pontos em trânsito não duplicam evento", sequencia(ev) === "TRACKING_STARTED", sequencia(ev));

await enviarPonto({ latitude: -23.62, longitude: -46.72, velocidadeKmh: 0, progressoPct: 50 });
await enviarPonto({ latitude: -23.62, longitude: -46.72, velocidadeKmh: 0, progressoPct: 50 });
await enviarPonto({ latitude: -23.62, longitude: -46.72, velocidadeKmh: 0, progressoPct: 50 });
ev = await eventosDeRastreio();
verificar(
  "parada grava TRACKING_STOPPED uma única vez",
  sequencia(ev) === "TRACKING_STARTED > TRACKING_STOPPED",
  sequencia(ev),
);

await enviarPonto({ latitude: -23.63, longitude: -46.73, velocidadeKmh: 60, progressoPct: 60 });
ev = await eventosDeRastreio();
verificar(
  "retomada grava TRACKING_RESUMED",
  sequencia(ev) === "TRACKING_STARTED > TRACKING_STOPPED > TRACKING_RESUMED",
  sequencia(ev),
);

const chegada = await enviarPonto({ latitude: -23.7, longitude: -46.8, velocidadeKmh: 0, progressoPct: 100 });
verificar("ponto de chegada aceito", chegada.status === 201, `(${chegada.status})`);
const estado = (
  await um(`SELECT tracking_state AS e FROM operation_tracking_status WHERE company_id = ? AND operation_id = ?`, [
    empresa.company_id,
    opId,
  ])
)?.e;
verificar("estado consolidado como ARRIVED após 100%", estado === "ARRIVED", `(estado: ${estado})`);
await enviarPonto({ latitude: -23.7, longitude: -46.8, velocidadeKmh: 0, progressoPct: 100 });
ev = await eventosDeRastreio();
const arrivals = ev.filter((t) => t === "TRACKING_ARRIVED").length;
verificar("chegada grava TRACKING_ARRIVED uma única vez", arrivals === 1, sequencia(ev));

console.log(`\n${ok} OK, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
