const BASE = (process.argv[2] ?? process.env.LS_API ?? "http://127.0.0.1:5174").replace(/\/$/, "");
const API = `${BASE}/api`;
const EMAIL = process.env.LS_EMAIL ?? "admin@loadsense.local";
const SENHA = process.env.LS_SENHA ?? "LoadSense@2026";

let ok = 0;
const falhas = [];
const passou = (d) => {
  ok++;
  console.log(`  [OK] ${d}`);
};
const falhou = (d, detalhe) => {
  falhas.push(d);
  console.log(
    `  [FALHA] ${d}\n     → ${typeof detalhe === "string" ? detalhe : JSON.stringify(detalhe).slice(0, 300)}`,
  );
};
const verificar = (d, cond, detalhe = "") => (cond ? passou(d) : falhou(d, detalhe || "condição não atendida"));
const titulo = (t) => console.log(`\n${t}`);

let token = null;
async function http(metodo, caminho, corpo, { bruto = false } = {}) {
  const res = await fetch(`${API}${caminho}`, {
    method: metodo,
    headers: {
      ...(corpo !== undefined ? { "content-type": "application/json" } : {}),
      ...(token ? { authorization: `Bearer ${token}` } : {}),
    },
    body: corpo !== undefined ? JSON.stringify(corpo) : undefined,
  });
  if (bruto) return { status: res.status, headers: res.headers, buffer: Buffer.from(await res.arrayBuffer()) };
  const texto = await res.text();
  let json = null;
  try {
    json = JSON.parse(texto);
  } catch {}
  return { status: res.status, json, texto };
}

const ehXlsx = (b) => b.length > 4 && b[0] === 0x50 && b[1] === 0x4b;
const csvLinhas = (buf) =>
  buf
    .toString("utf8")
    .replace(/^\uFEFF/, "")
    .split(/\r\n/)
    .filter(Boolean);

async function main() {
  titulo("Login");
  const login = await http("POST", "/auth/login", {
    email: EMAIL,
    senha: SENHA,
    dispositivoUuid: "teste-exp",
    plataforma: "WEB",
  });
  verificar("login do administrador", login.status === 200 && login.json?.accessToken, login.status);
  token = login.json?.accessToken ?? login.json?.token ?? null;
  if (!token) {
    console.log("Sem token: encerrando.");
    process.exit(1);
  }

  titulo("Exportação da planilha operacional");
  const lista = await http("GET", "/operacoes?status=CRITICAL&limite=200");
  const totalCriticas = lista.json?.total ?? -1;
  const xlsx = await http("GET", "/operacoes/exportar?formato=xlsx&status=CRITICAL", undefined, { bruto: true });
  verificar("XLSX da planilha é um arquivo Excel (PK)", xlsx.status === 200 && ehXlsx(xlsx.buffer), xlsx.status);
  verificar(
    "XLSX traz o nome de arquivo com data",
    /attachment; filename="loadsense-operacoes-\d{4}-\d{2}-\d{2}\.xlsx"/.test(
      xlsx.headers.get("content-disposition") ?? "",
    ),
    xlsx.headers.get("content-disposition"),
  );

  const csv = await http("GET", "/operacoes/exportar?formato=csv&status=CRITICAL", undefined, { bruto: true });
  const linhasCsv = csvLinhas(csv.buffer);
  verificar(
    "CSV começa com BOM e cabeçalho Código;Placa",
    csv.buffer[0] === 0xef && linhasCsv[0]?.startsWith("Código;Placa"),
    linhasCsv[0],
  );
  verificar(
    "CSV tem o mesmo número de operações que o filtro da tela",
    linhasCsv.length - 1 === totalCriticas,
    `csv=${linhasCsv.length - 1} tela=${totalCriticas}`,
  );

  const ops = await http("GET", "/operacoes?limite=1");
  const opId = ops.json?.operacoes?.[0]?.id;
  verificar("há uma operação para testar exportação individual", Boolean(opId), ops.status);
  if (opId) {
    const detalhe = await http("GET", `/operacoes/${opId}/exportar?formato=xlsx`, undefined, { bruto: true });
    verificar(
      "XLSX de uma operação (abas de resumo, pesagens, eventos, alertas e rastreio)",
      detalhe.status === 200 && ehXlsx(detalhe.buffer),
      detalhe.status,
    );
    const detCsv = await http("GET", `/operacoes/${opId}/exportar?formato=csv`, undefined, { bruto: true });
    verificar(
      "CSV de uma operação (aba de resumo)",
      detCsv.status === 200 && csvLinhas(detCsv.buffer)[0]?.startsWith("Campo;Valor"),
      detCsv.status,
    );
  }
  const semOp = await http("GET", "/operacoes/999999999/exportar?formato=xlsx", undefined, { bruto: true });
  verificar("operação inexistente retorna 404", semOp.status === 404, semOp.status);
  const formatoErrado = await http("GET", "/operacoes/exportar?formato=pdf", undefined, { bruto: true });
  verificar("formato inválido retorna 422", formatoErrado.status === 422, formatoErrado.status);

  const completa = await http("GET", "/exportar/dados?formato=xlsx", undefined, { bruto: true });
  verificar(
    "exportação completa em XLSX",
    completa.status === 200 && ehXlsx(completa.buffer) && completa.buffer.length > 5000,
    completa.status,
  );
  const completaCsv = await http("GET", "/exportar/dados?formato=csv", undefined, { bruto: true });
  verificar("exportação completa recusa CSV (somente XLSX)", completaCsv.status === 422, completaCsv.status);

  titulo("Importação de planilha");
  const cabecalho =
    "Código;Placa;Motorista;Produto;Rota (código);Tipo de movimento;Método;Nota fiscal;MDF-e;CIOT;Peso declarado (kg);Observações";
  const abertaExistente = (await http("GET", "/operacoes?estado=DRAFT&limite=1")).json?.operacoes?.[0];
  const codigoExistente = abertaExistente?.codigo ?? "SEM-OPERACAO-ABERTA";
  const base64 = (texto) => Buffer.from(texto, "utf8").toString("base64");

  const arquivoOk = [
    cabecalho,
    `;XYZ9Z99;;;;WEIGHING_ONLY;GROSS_TARE;NF-TESTE-1;;;;Criada pela planilha de teste`,
    `${codigoExistente};;;;;;;NF-ATUALIZADA-9;;;;Observação atualizada pela planilha`,
  ].join("\n");

  const simulacao = await http("POST", "/operacoes/importar", {
    nomeArquivo: "teste.csv",
    conteudoBase64: base64(arquivoOk),
    simular: true,
  });
  verificar(
    "simulação valida sem gravar",
    simulacao.status === 200 &&
      simulacao.json?.aplicada === false &&
      simulacao.json?.criar === 1 &&
      simulacao.json?.atualizar === 1,
    simulacao.json ?? simulacao.status,
  );

  const contagemAntes = (await http("GET", "/operacoes?limite=1")).json?.total;

  const arquivoErrado = [
    cabecalho,
    `;XYZ9Z99;;;;WEIGHING_ONLY;GROSS_TARE;;;;;Linha válida`,
    `PES-99999999-9999;;;;;;;;;;;Código inexistente`,
    `${codigoExistente};ABC1234;;;;;;;;;;;Tentando trocar a placa`,
  ].join("\n");
  const recusada = await http("POST", "/operacoes/importar", {
    nomeArquivo: "errado.csv",
    conteudoBase64: base64(arquivoErrado),
  });
  const mensagens = (recusada.json?.erros ?? []).map((e) => `${e.linha}: ${e.mensagem}`).join(" | ");
  verificar(
    "planilha com erros é recusada (422)",
    recusada.status === 422 && recusada.json?.aplicada === false,
    recusada.status,
  );
  verificar(
    "erro de código inexistente é apontado com a linha",
    /3: Código PES-99999999-9999 não encontrado/.test(mensagens),
    mensagens,
  );
  verificar(
    "troca de placa em operação existente é recusada",
    /Placa não pode ser alterado/.test(mensagens),
    mensagens,
  );
  const contagemDepois = (await http("GET", "/operacoes?limite=1")).json?.total;
  verificar(
    "nenhuma linha é gravada quando há erro (tudo ou nada)",
    contagemAntes === contagemDepois,
    `${contagemAntes} → ${contagemDepois}`,
  );

  const aplicada = await http("POST", "/operacoes/importar", {
    nomeArquivo: "ok.csv",
    conteudoBase64: base64(arquivoOk),
  });
  verificar(
    "planilha válida é aplicada",
    aplicada.status === 200 && aplicada.json?.aplicada === true && aplicada.json?.criadas === 1,
    aplicada.json ?? aplicada.status,
  );
  const depois = await http("GET", `/operacoes?limite=1&busca=${encodeURIComponent(codigoExistente)}`);
  const atualizada = (depois.json?.operacoes ?? []).find((o) => o.codigo === codigoExistente);
  const det = atualizada ? (await http("GET", `/operacoes/${atualizada.id}`)).json : null;
  verificar(
    "observações da operação existente foram atualizadas",
    det?.observacoes === "Observação atualizada pela planilha",
    det?.observacoes ?? "sem operação",
  );
  verificar(
    "nota fiscal da operação existente foi atualizada",
    det?.documentoFiscal === "NF-ATUALIZADA-9",
    det?.documentoFiscal ?? "—",
  );
  const contagemFinal = (await http("GET", "/operacoes?limite=1")).json?.total;
  verificar(
    "importação criou exatamente uma operação nova",
    contagemFinal === contagemAntes + 1,
    `${contagemAntes} → ${contagemFinal}`,
  );
}

main().catch((erro) => {
  console.error("Erro nos testes:", erro);
  process.exit(1);
});
