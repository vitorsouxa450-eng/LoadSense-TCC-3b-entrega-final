import { exec, um } from "../db.js";
import { hashSenha } from "../auth.js";

if (process.env.LS_DB_NAME !== "loadsense_testes") {
  console.error(
    "testes-lgpd: rode com LS_DB_NAME=loadsense_testes (banco de teste). Não roda no banco de demonstração.",
  );
  process.exit(2);
}

const BASE = (process.env.LS_API ?? "http://127.0.0.1:5174").replace(/\/$/, "");
const API = `${BASE}/api`;
const SENHA_ADMIN = process.env.LS_SENHA ?? "LoadSense@2026";

let ok = 0;
let falhas = 0;
const verificar = (descricao, condicao, detalhe = "") => {
  if (condicao) {
    ok += 1;
    console.log(`  OK     ${descricao}`);
  } else {
    falhas += 1;
    console.log(`  FALHA  ${descricao} ${detalhe}`);
  }
};

async function chamar(metodo, caminho, corpo, token, cabecalhos = {}) {
  const res = await fetch(API + caminho, {
    method: metodo,
    headers: {
      "content-type": "application/json",
      ...(token ? { authorization: `Bearer ${token}` } : {}),
      ...cabecalhos,
    },
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  const texto = await res.text();
  let dados;
  try {
    dados = JSON.parse(texto);
  } catch {
    dados = texto;
  }
  return { status: res.status, dados, cabecalhos: res.headers };
}

async function login(email, senha) {
  return chamar("POST", "/auth/login", { email, senha });
}

const sufixo = Date.now();
const emailOperador = `operador.lgpd.${sufixo}@teste.local`;
const senhaOperador = "Teste@2026";
const admin = await um(`SELECT company_id FROM users WHERE email = ?`, ["admin@loadsense.local"]);
const papelOperador = await um(`SELECT id FROM roles WHERE name = 'OPERATOR' AND company_id = ?`, [admin.company_id]);
await exec(
  `INSERT INTO users (company_id, role_id, full_name, email, password_hash, active, must_change_password,
                      receive_critical_alerts, receive_automatic_reports, failed_login_attempts, totp_enabled)
   VALUES (?, ?, 'Operador Teste LGPD', ?, ?, 1, 0, 1, 1, 0, 0)`,
  [admin.company_id, papelOperador.id, emailOperador, await hashSenha(senhaOperador)],
);

console.log("\nDireitos do titular");
const adminLogin = await login("admin@loadsense.local", SENHA_ADMIN);
const tokenAdmin = adminLogin.dados.accessToken;
const opLogin = await login(emailOperador, senhaOperador);
verificar("operador consegue entrar", opLogin.status === 200, `(status ${opLogin.status})`);
const tokenOp = opLogin.dados.accessToken;

const meus = await chamar("GET", "/titular/meus-dados", null, tokenOp);
verificar(
  "acesso: meus-dados traz conta, sessões e pesagens",
  meus.status === 200 && meus.dados.conta?.email === emailOperador && Array.isArray(meus.dados.sessoes),
);
verificar("acesso: arquivo para download", /attachment/.test(meus.cabecalhos.get("content-disposition") ?? ""));
verificar("acesso: não expõe hash de senha", !JSON.stringify(meus.dados).includes("$2"));

const perfil = await chamar("GET", "/titular/perfil", null, tokenOp);
verificar("perfil devolve comunicações", perfil.status === 200 && perfil.dados.alertasCriticos === true);

const corrige = await chamar(
  "PATCH",
  "/titular/meus-dados",
  { nome: "Operador Corrigido LGPD", telefone: "(11) 95555-4444", alertasCriticos: false },
  tokenOp,
);
verificar("correção: PATCH 200", corrige.status === 200, `(status ${corrige.status})`);
const depoisCorrecao = await chamar("GET", "/titular/perfil", null, tokenOp);
verificar(
  "correção: nome e telefone gravados",
  depoisCorrecao.dados.nome === "Operador Corrigido LGPD" && depoisCorrecao.dados.telefone === "(11) 95555-4444",
);
verificar("consentimento: alerta crítico revisado para desligado", depoisCorrecao.dados.alertasCriticos === false);

verificar("exclusão sem senha: 422", (await chamar("POST", "/titular/excluir-conta", {}, tokenOp)).status === 422);
verificar(
  "exclusão com senha errada: 401",
  (await chamar("POST", "/titular/excluir-conta", { senha: "errada" }, tokenOp)).status === 401,
);
await exec(
  `UPDATE users SET active = 0
    WHERE company_id = ? AND email <> ? AND role_id = (SELECT id FROM roles WHERE name = 'ADMINISTRATOR' AND company_id = ?)`,
  [admin.company_id, "admin@loadsense.local", admin.company_id],
);
const ultimoAdmin = await chamar("POST", "/titular/excluir-conta", { senha: SENHA_ADMIN }, tokenAdmin);
verificar(
  "último administrador não pode excluir a conta: 409",
  ultimoAdmin.status === 409,
  `(status ${ultimoAdmin.status})`,
);

const exclusao = await chamar("POST", "/titular/excluir-conta", { senha: senhaOperador }, tokenOp);
verificar("exclusão com senha correta: 200", exclusao.status === 200, `(status ${exclusao.status})`);
verificar("após a exclusão não entra mais", (await login(emailOperador, senhaOperador)).status !== 200);
verificar("sessão antiga foi revogada", (await chamar("GET", "/titular/meus-dados", null, tokenOp)).status === 401);

console.log("\nEliminação de motorista");
const cpf = `8${String(Date.now()).slice(-10)}`;
const criado = await chamar(
  "POST",
  "/motoristas",
  { nome: "Motorista Para Anonimizar", cpf, cnh: "CNH777", telefone: "(11) 97777-7777", categoriaCnh: "D" },
  tokenAdmin,
);
const anonimizado = await chamar("POST", `/motoristas/${criado.dados.id}/anonimizar`, null, tokenAdmin);
verificar("anonimizar: 200", anonimizado.status === 200, `(status ${anonimizado.status})`);
const lista = await chamar("GET", "/motoristas?incluirInativos=1", null, tokenAdmin);
const motorista = lista.dados.motoristas.find((m) => m.id === criado.dados.id);
verificar(
  "motorista fica sem CPF/CNH/telefone, inativo e com nome genérico",
  motorista &&
    motorista.full_name === `Motorista anonimizado #${criado.dados.id}` &&
    !motorista.document_number &&
    !motorista.license_number &&
    !motorista.phone &&
    !motorista.active,
);
verificar(
  "o CPF anonimizado pode ser reutilizado",
  (await chamar("POST", "/motoristas", { nome: "Outro Motorista Teste", cpf, cnh: "X" }, tokenAdmin)).status === 201,
);

console.log("\nCadastro de motorista cifrado");
const cpfCadastro = `7${String(Date.now()).slice(-10)}`;
const novo = await chamar(
  "POST",
  "/motoristas",
  { nome: "Motorista Cifrado", cpf: cpfCadastro, cnh: "CNH555", telefone: "(11) 96666-5555" },
  tokenAdmin,
);
const listaNovo = await chamar("GET", "/motoristas", null, tokenAdmin);
const lidoNovo = listaNovo.dados.motoristas.find((m) => m.id === novo.dados.id);
verificar(
  "leitura devolve CPF, CNH e telefone em claro",
  lidoNovo?.document_number === cpfCadastro &&
    lidoNovo?.license_number === "CNH555" &&
    lidoNovo?.phone === "(11) 96666-5555",
);
const bruto = await um(`SELECT document_number, document_hash FROM drivers WHERE id = ?`, [novo.dados.id]);
verificar(
  "no banco o CPF está cifrado e tem hash",
  bruto.document_number.startsWith("v1:") && bruto.document_hash?.length === 64,
);
verificar(
  "CPF repetido é recusado (409)",
  (await chamar("POST", "/motoristas", { nome: "Repetido Teste", cpf: cpfCadastro }, tokenAdmin)).status === 409,
);

console.log("\nCORS e acesso sem token");
const cors = await fetch(`${API}/saude`, { headers: { origin: "http://localhost:5173" } });
verificar("CORS: localhost liberado", cors.headers.get("access-control-allow-origin") === "http://localhost:5173");
const corsEstranho = await fetch(`${API}/saude`, { headers: { origin: "https://site-estranho.exemplo" } });
verificar("CORS: origem estranha bloqueada", !corsEstranho.headers.get("access-control-allow-origin"));
const semToken = await chamar("GET", "/painel?dias=30", null, null);
verificar("sem token: rota protegida responde 401", semToken.status === 401, `(status ${semToken.status})`);

console.log("\nAlertas: painel e lista batem");
await exec(
  `UPDATE alerts SET state = 'OPEN', resolved_at = NULL, created_at = DATE_SUB(NOW(), INTERVAL 60 DAY)
    WHERE company_id = ? AND state = 'RESOLVED' ORDER BY id LIMIT 1`,
  [admin.company_id],
);
const painel = await chamar("GET", "/painel?dias=7", null, tokenAdmin);
const listaAbertos = await chamar("GET", "/alertas?situacao=OPEN,ACKNOWLEDGED&dias=7&limite=200", null, tokenAdmin);
const abertosPainel = painel.dados?.resumo?.alertas?.abertos ?? painel.dados?.alertas?.abertos;
const totalLista = listaAbertos.dados?.total ?? listaAbertos.dados?.paginacao?.total;
verificar("há alerta aberto fora do período e ele aparece na lista", Number(totalLista) > 0, `(lista=${totalLista})`);
verificar(
  "painel e lista mostram a mesma quantidade de alertas abertos",
  abertosPainel !== undefined && Number(abertosPainel) === Number(totalLista),
  `(painel=${abertosPainel}, lista=${totalLista})`,
);

console.log(`\n${ok} OK, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
