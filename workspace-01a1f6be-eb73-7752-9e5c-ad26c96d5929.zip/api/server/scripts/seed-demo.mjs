import mysql from "mysql2/promise";
import bcrypt from "bcryptjs";

const args = process.argv.slice(2);
const DIAS = Number((args[args.indexOf("--dias") + 1] || "90").replace(/\D/g, "")) || 90;
const LIMPAR = args.includes("--limpar");
const SENHA_DEMO = process.env.LS_SENHA_DEMO ?? "LoadSense@2026";

const conn = await mysql.createConnection({
  host: process.env.LS_DB_HOST ?? "127.0.0.1",
  port: Number(process.env.LS_DB_PORT ?? 3306),
  user: process.env.LS_DB_USER ?? "root",
  password: process.env.LS_DB_PASSWORD ?? "",
  database: process.env.LS_DB_NAME ?? "loadsense",
  decimalNumbers: true,
  timezone: "Z",
  charset: "utf8mb4_0900_ai_ci",
});
await conn.query("SET time_zone = '+00:00'");

const [empresa] = await conn.query("SELECT id, trade_name FROM companies WHERE slug = 'loadsense-demo' LIMIT 1");
if (!empresa.length) throw new Error("Empresa 'loadsense-demo' não encontrada. Rode antes: db/01_demo_seed.sql");
const CID = empresa[0].id;

const [{ id: unidadeId }] = (
  await conn.query("SELECT id FROM operational_units WHERE company_id = ? AND code='MATRIZ'", [CID])
)[0];
const [{ id: postoId }] = (
  await conn.query("SELECT id FROM weighing_stations WHERE company_id = ? AND code='BAL-01'", [CID])
)[0];
const [{ id: deviceBalanca }] = (
  await conn.query("SELECT id FROM devices WHERE company_id = ? AND serial_number='LS-CEL-0001'", [CID])
)[0];
const [{ id: deviceGprs }] = (
  await conn.query("SELECT id FROM devices WHERE company_id = ? AND serial_number='LS-GPRS-0001'", [CID])
)[0];

const [veiculos] = await conn.query(
  `SELECT v.id, v.plate, v.registered_tare_kg, v.gross_weight_limit_kg, v.payload_limit_kg, r.id AS rfid_id
     FROM vehicles v
     LEFT JOIN rfid_tags r ON r.company_id = v.company_id AND r.vehicle_id = v.id AND r.active = 1
    WHERE v.company_id = ? AND v.active = 1 ORDER BY v.plate`,
  [CID],
);
const [motoristas] = await conn.query(
  "SELECT id, full_name FROM drivers WHERE company_id = ? AND active = 1 ORDER BY id",
  [CID],
);
const [produtos] = await conn.query(
  "SELECT id, name FROM cargo_products WHERE company_id = ? AND active = 1 ORDER BY id",
  [CID],
);
const [rotas] = await conn.query(
  "SELECT id, code, origin, destination, distance_km FROM routes WHERE company_id = ? AND active = 1 ORDER BY id",
  [CID],
);
const [usuarios] = await conn.query("SELECT id, email FROM users WHERE company_id = ? ORDER BY id", [CID]);

const operador = usuarios.find((u) => u.email === "operador@loadsense.local")?.id ?? usuarios[0].id;
const supervisor = usuarios.find((u) => u.email === "supervisor@loadsense.local")?.id ?? usuarios[0].id;

if (!LIMPAR) {
  const hash = await bcrypt.hash(SENHA_DEMO, 12);
  await conn.query("UPDATE users SET password_hash = ?, must_change_password = 0 WHERE company_id = ?", [hash, CID]);
  console.log(`• Senha dos usuários de demonstração definida para: ${SENHA_DEMO}`);
}

if (LIMPAR) {
  await conn.query("UPDATE alerts SET state='RESOLVED' WHERE company_id = ?", [CID]).catch(() => {});
  const [res] = await conn.query("DELETE FROM weighing_operations WHERE company_id = ?", [CID]);
  console.log(`• Histórico anterior removido (${res.affectedRows} operações).`);
  await conn.end();
  process.exit(0);
}

const rnd = (min, max) => min + Math.random() * (max - min);
const escolha = (arr) => arr[Math.floor(Math.random() * arr.length)];
const agoraUtc = () => new Date();
const fmt = (d) => d.toISOString().slice(0, 23).replace("T", " ");
const diaBase = (dias) => {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() - dias);
  return d;
};

async function proximaSequencia(operationId, estagio) {
  const [[linha]] = await conn.query(
    "SELECT COALESCE(MAX(sequence_number),0)+1 AS n FROM weighing_readings WHERE operation_id = ? AND stage = ?",
    [operationId, estagio],
  );
  return linha.n;
}

async function inserirLeitura(
  operationId,
  estagio,
  pesoKg,
  { origem = "DEVICE", estavel = 1, quando, motivo = null } = {},
) {
  const sequencia = await proximaSequencia(operationId, estagio);
  const [res] = await conn.query(
    `INSERT INTO weighing_readings
       (company_id, operation_id, stage, sequence_number, weight_kg, source, device_id, is_stable, checksum_valid, measured_at, created_by_user_id, manual_reason)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`,
    [
      CID,
      operationId,
      estagio,
      sequencia,
      pesoKg,
      origem,
      origem === "DEVICE" ? deviceBalanca : null,
      estavel,
      fmt(quando ?? new Date()),
      operador,
      motivo,
    ],
  );
  if (estavel) await conn.query("CALL sp_accept_weighing_reading(?, ?, ?)", [CID, res.insertId, operador]);
  return res.insertId;
}

async function criarOperacao({
  veiculo,
  motoristaId,
  produtoId,
  rotaId,
  metodo,
  movimento,
  declaradoKg,
  rfidId,
  quando,
  observacoes,
}) {
  const [res] = await conn.query(
    `INSERT INTO weighing_operations
       (company_id, operational_unit_id, weighing_station_id, movement_type, weighing_method, vehicle_id, driver_id,
        rfid_tag_id, cargo_product_id, route_id, responsible_user_id, created_by_user_id, declared_cargo_weight_kg, observations)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      CID,
      unidadeId,
      postoId,
      movimento,
      metodo,
      veiculo.id,
      motoristaId,
      rfidId,
      produtoId,
      rotaId,
      operador,
      operador,
      declaradoKg,
      observacoes,
    ],
  );
  await conn.query("UPDATE weighing_operations SET started_at = ?, created_at = ? WHERE id = ?", [
    fmt(quando),
    fmt(quando),
    res.insertId,
  ]);
  return res.insertId;
}

async function ajustarDatas(operationId, { iniciada, concluida }) {
  await conn.query("UPDATE weighing_operations SET started_at = ?, completed_at = ?, created_at = ? WHERE id = ?", [
    fmt(iniciada),
    concluida ? fmt(concluida) : null,
    fmt(iniciada),
    operationId,
  ]);
  if (concluida) {
    await conn.query("UPDATE alerts SET created_at = ?, detected_at = ? WHERE company_id = ? AND operation_id = ?", [
      fmt(concluida),
      fmt(concluida),
      CID,
      operationId,
    ]);
    await conn.query("UPDATE operation_events SET created_at = ? WHERE company_id = ? AND operation_id = ?", [
      fmt(concluida),
      CID,
      operationId,
    ]);
  }
}

async function operacaoHistorica(quando, perfil) {
  const veiculo = escolha(veiculos);
  const motorista = escolha(motoristas);
  const produto = escolha(produtos);
  const rota = escolha(rotas);
  const metodo = Math.random() < 0.25 ? "THREE_STAGE" : "GROSS_TARE";

  const tara = veiculo.registered_tare_kg || 8500;
  const capacidade = veiculo.payload_limit_kg || 14000;
  const cargaBase = Math.min(capacidade * rnd(0.62, 0.96), capacidade);
  let declarado = Math.round(cargaBase);
  let cargaReal = declarado;
  let taraMedida = tara;

  if (perfil === "atencao")
    cargaReal = Math.round(declarado * (Math.random() < 0.5 ? rnd(0.976, 0.985) : rnd(1.016, 1.024)));
  if (perfil === "critico") cargaReal = Math.round(declarado * rnd(1.035, 1.08));
  if (perfil === "tara") taraMedida = Math.round(tara * rnd(1.06, 1.09));

  const opId = await criarOperacao({
    veiculo,
    motoristaId: motorista.id,
    produtoId: produto.id,
    rotaId: rota.id,
    metodo,
    movimento: escolha(["EXIT", "ENTRY", "TRANSFER"]),
    declaradoKg: declarado,
    rfidId: veiculo.rfid_id,
    quando,
    observacoes: `Operação de demonstração (${perfil})`,
  });

  const tVazio = new Date(quando.getTime() + 5 * 60000);
  const tCarga = new Date(quando.getTime() + 25 * 60000);
  const tFim = new Date(quando.getTime() + 35 * 60000);

  await inserirLeitura(opId, "EMPTY_TRUCK", taraMedida, { quando: tVazio });
  if (metodo === "THREE_STAGE") {
    await inserirLeitura(opId, "SEPARATED_CARGO", Math.max(cargaReal - 120, 100), {
      quando: new Date(quando.getTime() + 15 * 60000),
    });
  }
  if (perfil === "manual") {
    await inserirLeitura(opId, "LOADED_TRUCK", taraMedida + cargaReal, {
      origem: "MANUAL",
      quando: tCarga,
      motivo: "Balança em manutenção — leitura manual conferida",
    });
  } else {
    await inserirLeitura(opId, "LOADED_TRUCK", taraMedida + cargaReal, { quando: tCarga });
  }

  try {
    await conn.query("CALL sp_finalize_weighing_operation(?, ?, ?)", [CID, opId, operador]);
  } catch (e) {
    console.warn(`  ! operação ${opId} não finalizou: ${e.sqlMessage ?? e.message}`);
    await ajustarDatas(opId, { iniciada: quando, concluida: tFim });
    return { opId, viagem: false, estado: "IN_PROGRESS" };
  }

  const fazViagem = Math.random() < 0.75;
  if (fazViagem) {
    const saida = new Date(tFim.getTime() + rnd(10, 60) * 60000);
    const chegadaPlan = new Date(saida.getTime() + (rota.distance_km / 62) * 3600000);
    const chegadaReal = new Date(chegadaPlan.getTime() + rnd(-20, 45) * 60000);
    try {
      await conn.query("CALL sp_set_transport_schedule(?, ?, ?, ?, ?)", [
        CID,
        opId,
        supervisor,
        fmt(saida),
        fmt(chegadaPlan),
      ]);
      await conn.query("CALL sp_start_transport(?, ?, ?)", [CID, opId, supervisor]);
      await conn.query(
        `INSERT INTO operation_tracking_points
           (company_id, operation_id, device_id, latitude, longitude, speed_kmh, heading_degrees, progress_percent, estimated_arrival_at, recorded_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          CID,
          opId,
          deviceGprs,
          -23.61,
          -46.71,
          rnd(55, 85),
          180,
          45,
          fmt(chegadaReal),
          fmt(new Date(saida.getTime() + 40 * 60000)),
        ],
      );
      await conn.query("CALL sp_mark_transport_arrived(?, ?, ?)", [CID, opId, supervisor]);
      await conn.query("UPDATE weighing_operations SET departed_at = ?, arrived_at = ? WHERE id = ?", [
        fmt(saida),
        fmt(chegadaReal),
        opId,
      ]);
      await conn.query(
        "UPDATE operation_tracking_status SET last_position_at = ? WHERE company_id = ? AND operation_id = ?",
        [fmt(chegadaReal), CID, opId],
      );
    } catch (e) {
      console.warn(`  ! transporte da operação ${opId}: ${e.sqlMessage ?? e.message}`);
    }
  }

  await ajustarDatas(opId, { iniciada: quando, concluida: tFim });
  const [[op]] = await conn.query("SELECT status, actual_cargo_weight_kg FROM weighing_operations WHERE id = ?", [
    opId,
  ]);
  return { opId, viagem: fazViagem, estado: "COMPLETED", status: op.status, carga: op.actual_cargo_weight_kg };
}

console.log(`\nSemeando ${DIAS} dias de operações para ${empresa[0].trade_name}…`);
const resultados = { total: 0, normais: 0, atencao: 0, criticas: 0, toneladas: 0, viagens: 0 };

for (let d = DIAS; d >= 1; d--) {
  const base = diaBase(d);
  const quantidade = 6 + Math.floor(Math.random() * 7);
  for (let i = 0; i < quantidade; i++) {
    const quando = new Date(base.getTime() + (7 * 60 + i * 55 + Math.floor(rnd(0, 40))) * 60000);
    const sorteio = Math.random();
    const perfil =
      sorteio < 0.72
        ? "normal"
        : sorteio < 0.88
          ? "atencao"
          : sorteio < 0.95
            ? "critico"
            : sorteio < 0.98
              ? "tara"
              : "manual";
    const r = await operacaoHistorica(quando, perfil);
    resultados.total++;
    if (r.status === "CRITICAL") resultados.criticas++;
    else if (r.status === "ATTENTION") resultados.atencao++;
    else if (r.status === "NORMAL") resultados.normais++;
    if (r.viagem) resultados.viagens++;
    resultados.toneladas += Number(r.carga ?? 0) / 1000;
  }
  process.stdout.write(`\r  dia -${String(d).padStart(2)} → ${resultados.total} operações`);
}

console.log("\n\nCriando operações em andamento (monitoramento ao vivo)…");
const vivas = [
  { progresso: 42, velocidade: 74, estado: "IN_TRANSIT" },
  { progresso: 68, velocidade: 63, estado: "IN_TRANSIT" },
  { progresso: 23, velocidade: 81, estado: "IN_TRANSIT" },
  { progresso: 55, velocidade: 0, estado: "STOPPED" },
  { progresso: 12, velocidade: 58, estado: "IN_TRANSIT" },
  { progresso: 88, velocidade: 66, estado: "IN_TRANSIT" },
];

for (const viva of vivas) {
  const agora = agoraUtc();
  const inicio = new Date(agora.getTime() - 90 * 60000);
  const veiculo = escolha(veiculos);
  const rota = escolha(rotas);
  const produto = escolha(produtos);
  const motorista = escolha(motoristas);
  const tara = veiculo.registered_tare_kg || 8500;
  const carga = Math.round((veiculo.payload_limit_kg || 14000) * rnd(0.7, 0.95));

  const opId = await criarOperacao({
    veiculo,
    motoristaId: motorista.id,
    produtoId: produto.id,
    rotaId: rota.id,
    metodo: "GROSS_TARE",
    movimento: "EXIT",
    declaradoKg: carga,
    rfidId: veiculo.rfid_id,
    quando: inicio,
    observacoes: "Viagem em andamento (dados de demonstração)",
  });
  await inserirLeitura(opId, "EMPTY_TRUCK", tara, { quando: new Date(inicio.getTime() + 5 * 60000) });
  await inserirLeitura(opId, "LOADED_TRUCK", tara + carga, { quando: new Date(inicio.getTime() + 20 * 60000) });
  await conn.query("CALL sp_finalize_weighing_operation(?, ?, ?)", [CID, opId, operador]);

  const saida = new Date(agora.getTime() - 60 * 60000);
  const chegadaPlan = new Date(saida.getTime() + (rota.distance_km / 62) * 3600000);
  await conn.query("CALL sp_set_transport_schedule(?, ?, ?, ?, ?)", [
    CID,
    opId,
    supervisor,
    fmt(saida),
    fmt(chegadaPlan),
  ]);
  await conn.query("CALL sp_start_transport(?, ?, ?)", [CID, opId, supervisor]);
  await conn.query("UPDATE weighing_operations SET started_at = ?, completed_at = ?, departed_at = ? WHERE id = ?", [
    fmt(inicio),
    fmt(new Date(inicio.getTime() + 30 * 60000)),
    fmt(saida),
    opId,
  ]);

  const [waypoints] = await conn.query(
    "SELECT latitude, longitude FROM route_waypoints WHERE company_id = ? AND route_id = ? ORDER BY sequence_number",
    [CID, rota.id],
  );
  const pontos = [];
  for (let i = 0; i < Math.max(waypoints.length - 1, 1); i++) {
    const a = waypoints[i] ?? { latitude: -23.5861, longitude: -46.82 };
    const b = waypoints[i + 1] ?? { latitude: -23.9608, longitude: -46.3336 };
    for (const frac of [0.15, 0.45, 0.75]) {
      pontos.push({
        lat: a.latitude + (b.latitude - a.latitude) * frac,
        lng: a.longitude + (b.longitude - a.longitude) * frac,
      });
    }
  }
  const percorridos = Math.max(1, Math.round((viva.progresso / 100) * pontos.length));
  const eta = new Date(agora.getTime() + ((100 - viva.progresso) / 100) * (rota.distance_km / 62) * 3600000);

  for (let i = 0; i < percorridos; i++) {
    const quando = new Date(agora.getTime() - (percorridos - 1 - i) * 3 * 60000);
    const progresso = Math.min(99, ((i + 1) / pontos.length) * 100);
    await conn.query(
      `INSERT INTO operation_tracking_points
         (company_id, operation_id, device_id, latitude, longitude, speed_kmh, heading_degrees, accuracy_meters, progress_percent, estimated_arrival_at, signal_strength_dbm, recorded_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        CID,
        opId,
        deviceGprs,
        pontos[i].lat,
        pontos[i].lng,
        viva.velocidade,
        190,
        rnd(4, 14),
        progresso,
        fmt(eta),
        Math.round(rnd(-95, -62)),
        fmt(quando),
      ],
    );
  }
  if (viva.estado === "STOPPED") {
    for (let m = 0; m <= 25; m += 5) {
      await conn.query(
        `INSERT INTO operation_tracking_points
           (company_id, operation_id, device_id, latitude, longitude, speed_kmh, progress_percent, estimated_arrival_at, recorded_at)
         VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)`,
        [
          CID,
          opId,
          deviceGprs,
          pontos[Math.max(0, percorridos - 1)].lat + 0.004,
          pontos[Math.max(0, percorridos - 1)].lng + 0.004,
          viva.progresso,
          fmt(new Date(eta.getTime() + 25 * 60000)),
          fmt(new Date(agora.getTime() - (25 - m) * 60000)),
        ],
      );
    }
  }
  console.log(`  • ${veiculo.plate} → ${rota.destination} (${viva.progresso}% do trajeto, ${viva.estado})`);
}

console.log("\nCriando operações em andamento (aguardando pesagem)…");
const pendentes = [
  { etapa: "rascunho", minutos: 15 },
  { etapa: "rascunho", minutos: 40 },
  { etapa: "rascunho", minutos: 75 },
  { etapa: "vazio", minutos: 25 },
  { etapa: "vazio", minutos: 60 },
  { etapa: "vazio", minutos: 110 },
];
for (const pendente of pendentes) {
  const agora = agoraUtc();
  const quando = new Date(agora.getTime() - pendente.minutos * 60000);
  const veiculo = escolha(veiculos);
  const rota = escolha(rotas);
  const tara = veiculo.registered_tare_kg || 8500;
  const declarado = Math.round((veiculo.payload_limit_kg || 14000) * rnd(0.65, 0.92));
  const opId = await criarOperacao({
    veiculo,
    motoristaId: escolha(motoristas).id,
    produtoId: escolha(produtos).id,
    rotaId: rota.id,
    metodo: "GROSS_TARE",
    movimento: "EXIT",
    declaradoKg: declarado,
    rfidId: veiculo.rfid_id,
    quando,
    observacoes: `Operação em andamento (dados de demonstração, ${pendente.etapa})`,
  });
  if (pendente.etapa === "vazio") {
    await inserirLeitura(opId, "EMPTY_TRUCK", tara, { quando: new Date(quando.getTime() + 5 * 60000) });
  }
  console.log(`  • ${veiculo.plate} → ${rota.destination} (${pendente.etapa})`);
}

await conn.query(
  `UPDATE operation_tracking_status SET last_position_at = DATE_SUB(NOW(3), INTERVAL 40 MINUTE)
    WHERE company_id = ? AND tracking_state IN ('IN_TRANSIT','STOPPED') ORDER BY operation_id DESC LIMIT 1`,
  [CID],
);
try {
  await conn.query("CALL sp_evaluate_tracking_alerts(?)", [CID]);
} catch (e) {
  console.warn("  ! avaliação de rastreio:", e.sqlMessage ?? e.message);
}

await conn.query(
  `UPDATE weighing_operations o
      SET o.tracking_enabled = 1,
          o.tracking_activated_at = COALESCE(o.tracking_activated_at, o.started_at, CURRENT_TIMESTAMP(3))
    WHERE o.company_id = ?`,
  [CID],
);

console.log("Renumerando códigos das operações (PES-AAAAMMDD-NNNN)…");
await conn.query("UPDATE weighing_operations SET operation_code = CONCAT('TMP-', id) WHERE company_id = ?", [CID]);
const [renumeradas] = await conn.query(
  `UPDATE weighing_operations o
     JOIN (
       SELECT id,
              CONCAT('PES-', DATE_FORMAT(COALESCE(started_at, created_at), '%Y%m%d'), '-',
                     LPAD(ROW_NUMBER() OVER (PARTITION BY company_id, DATE(COALESCE(started_at, created_at))
                                             ORDER BY id), 4, '0')) AS novo_codigo
         FROM weighing_operations
        WHERE company_id = ?
     ) t ON t.id = o.id
      SET o.operation_code = t.novo_codigo`,
  [CID],
);
console.log(`  códigos renumerados: ${renumeradas.affectedRows}`);

const [[totais]] = await conn.query(
  `SELECT (SELECT COUNT(*) FROM weighing_operations WHERE company_id = ?) AS operacoes,
          (SELECT COUNT(*) FROM weighing_readings WHERE company_id = ?) AS leituras,
          (SELECT COUNT(*) FROM alerts WHERE company_id = ?) AS alertas,
          (SELECT COUNT(*) FROM alerts WHERE company_id = ? AND state IN ('OPEN','ACKNOWLEDGED')) AS alertas_abertos,
          (SELECT COUNT(*) FROM operation_tracking_points WHERE company_id = ?) AS pontos,
          (SELECT COUNT(*) FROM operation_tracking_status WHERE company_id = ? AND tracking_state IN ('IN_TRANSIT','STOPPED','SIGNAL_LOST')) AS em_viagem`,
  [CID, CID, CID, CID, CID, CID],
);

console.log(`\nResumo da semeadura:`);
console.log(
  `  operações: ${totais.operacoes} (criadas agora: ${resultados.total}, ${resultados.normais} normais, ${resultados.atencao} atenção, ${resultados.criticas} críticas)`,
);
console.log(`  leituras: ${totais.leituras} · alertas: ${totais.alertas} (${totais.alertas_abertos} abertos)`);
console.log(`  pontos de rastreio: ${totais.pontos} · viagens em andamento: ${totais.em_viagem}`);
console.log(`  carga total histórica: ${resultados.toneladas.toFixed(1)} t\n`);

await conn.end();
