import { writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { q } from "../db.js";

const idEmpresa = Number(process.argv[2] ?? 1);
const papeis = await q(`SELECT id, name, description FROM roles WHERE company_id = ? AND active = 1 ORDER BY id`, [
  idEmpresa,
]);
const permissoesPorPapel = {};
for (const p of papeis) {
  const linhas = await q(
    `SELECT pe.code FROM role_permissions rp JOIN permissions pe ON pe.id = rp.permission_id WHERE rp.role_id = ? ORDER BY pe.code`,
    [p.id],
  );
  permissoesPorPapel[p.name] = linhas.map((l) => l.code);
}
const [configuracoes] = await q(`SELECT * FROM company_settings WHERE company_id = ?`, [idEmpresa]);
const { company_id, updated_by_user_id, updated_at, ...config } = configuracoes;
const documentos = await q(
  `SELECT document_type, version, title, content_format, content, content_hash, mandatory, requires_reacceptance
     FROM legal_documents WHERE company_id = ? AND active = 1 ORDER BY id`,
  [idEmpresa],
);
const modelo = {
  geradoEm: new Date().toISOString(),
  papeis: papeis.map((p) => ({
    nome: p.name,
    descricao: p.description,
    sistema: true,
    permissoes: permissoesPorPapel[p.name],
  })),
  configuracoes: config,
  documentosLegais: documentos,
};
const saida = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "dados", "modelo-empresa.json");
writeFileSync(saida, JSON.stringify(modelo, null, 2));
console.log("ok", saida, papeis.length, "papeis", documentos.length, "docs");
process.exit(0);
