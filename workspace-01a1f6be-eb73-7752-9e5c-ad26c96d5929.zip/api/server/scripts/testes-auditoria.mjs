import { exec, q, um } from "../db.js";
import { hashSenha } from "../auth.js";

const API = `${(process.env.LS_API ?? "http://127.0.0.1:5174").replace(/\/$/, "")}/api`;
const SENHA_ADMIN = process.env.LS_SENHA ?? "LoadSense@2026";

let ok = 0;
let falhas = 0;
const verificar = (descricao, condicao, detalhe = "") => {
  if (condicao) {
    ok += 1;
    console.log(`  OK     ${descricao}`);
  } else {
    falhas += 1;
    console.log(`  FALHA  ${descricao} ${detalhe}`);
  }
};

async function chamar(metodo, caminho, corpo, token) {
  const res = await fetch(API + caminho, {
    method: metodo,
    headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  const bruto = new Uint8Array(await res.arrayBuffer());
  const texto = new TextDecoder("utf-8", { ignoreBOM: true }).decode(bruto);
  let dados = null;
  try {
    dados = JSON.parse(texto);
  } catch {
    dados = null;
  }
  return {
    status: res.status,
    dados,
    texto,
    bruto,
    tipo: res.headers.get("content-type") ?? "",
    disposicao: res.headers.get("content-disposition") ?? "",
  };
}
const login = (email, senha) => chamar("POST", "/auth/login", { email, senha });

const admin = await um(`SELECT company_id FROM users WHERE email = 'admin@loadsense.local'`);
const papelOperador = await um(`SELECT id FROM roles WHERE name = 'OPERATOR' AND company_id = ?`, [admin.company_id]);
const sufixo = Date.now();
const emailOperador = `auditoria.${sufixo}@teste.local`;
const senhaOperador = "Auditoria@2026";
await exec(
  `INSERT INTO users (company_id, role_id, full_name, email, password_hash, active, must_change_password,
                      receive_critical_alerts, receive_automatic_reports, failed_login_attempts, totp_enabled)
   VALUES (?, ?, ?, ?, ?, 1, 0, 1, 1, 0, 0)`,
  [admin.company_id, papelOperador.id, `=CMD|' /C calc'!A1 ${sufixo}`, emailOperador, await hashSenha(senhaOperador)],
);

console.log("\nGeração de evento de login");
const erroLogin = await login(emailOperador, "senha-errada-123");
verificar("senha errada responde 401", erroLogin.status === 401, `(${erroLogin.status})`);

const tokenAdmin = (await login("admin@loadsense.local", SENHA_ADMIN)).dados?.accessToken;
verificar("admin entra", Boolean(tokenAdmin));

console.log("\nTipos e filtros");
const tipos = await chamar("GET", "/auditoria/tipos", undefined, tokenAdmin);
verificar(
  "lista de tipos inclui LOGIN_FAILED",
  tipos.dados?.tipos?.includes("LOGIN_FAILED"),
  JSON.stringify(tipos.dados),
);

const porTipo = await chamar("GET", "/auditoria?tipo=LOGIN_FAILED&formato=json", undefined, tokenAdmin);
const regs = porTipo.dados?.registros ?? [];
verificar(
  "filtro por tipo devolve só LOGIN_FAILED",
  porTipo.status === 200 && regs.length > 0 && regs.every((r) => r.evento === "LOGIN_FAILED"),
);
verificar(
  "registro traz o usuário e o e-mail",
  regs.some((r) => r.emailUsuario === emailOperador),
);

const vazio = await chamar("GET", "/auditoria?de=2000-01-01&ate=2000-01-02&formato=json", undefined, tokenAdmin);
verificar("período sem registros volta vazio", vazio.status === 200 && vazio.dados.registros.length === 0);

const dataInvalida = await chamar("GET", "/auditoria?de=2026-13-01", undefined, tokenAdmin);
verificar("data inválida responde 422", dataInvalida.status === 422, `(${dataInvalida.status})`);

const invertido = await chamar("GET", "/auditoria?de=2026-10-10&ate=2026-10-01", undefined, tokenAdmin);
verificar("período invertido responde 422", invertido.status === 422, `(${invertido.status})`);

console.log("\nCSV");
const csv = await chamar("GET", "/auditoria?tipo=LOGIN_FAILED&formato=csv", undefined, tokenAdmin);
verificar(
  "responde 200 como text/csv",
  csv.status === 200 && csv.tipo.startsWith("text/csv"),
  `(${csv.status} ${csv.tipo})`,
);
verificar("tem BOM UTF-8 para o Excel", csv.bruto[0] === 0xef && csv.bruto[1] === 0xbb && csv.bruto[2] === 0xbf);
const dataFeb = await chamar("GET", "/auditoria?de=2026-02-30", undefined, tokenAdmin);
verificar("dia inexistente (30/02) responde 422", dataFeb.status === 422, `(${dataFeb.status})`);
verificar(
  "cabeçalho em pt-BR separado por ;",
  csv.texto.replace(/^\uFEFF/, "").startsWith("Data/hora;Evento;Entidade;"),
);
verificar(
  "nome do arquivo no Content-Disposition",
  /attachment; filename="auditoria-/.test(csv.disposicao),
  csv.disposicao,
);
verificar("nome com = fica neutralizado (apóstrofo antes)", csv.texto.includes(`'=CMD|`) && !/;=CMD\|/.test(csv.texto));

console.log("\nPermissão");
const login2 = await login(emailOperador, senhaOperador);
verificar("operador entra com a senha certa", login2.status === 200, `(${login2.status})`);
const tokenOp = login2.dados?.accessToken;
const negado = await chamar("GET", "/auditoria?formato=json", undefined, tokenOp);
verificar("operador sem AUDIT_VIEW recebe 403", negado.status === 403, `(${negado.status})`);
const semToken = await chamar("GET", "/auditoria?formato=json");
verificar("sem token recebe 401", semToken.status === 401, `(${semToken.status})`);

console.log("\nBloqueio e troca de senha");
const emailBloqueio = `bloqueio.${sufixo}@teste.local`;
const emailTroca = `troca.${sufixo}@teste.local`;
for (const email of [emailBloqueio, emailTroca]) {
  await exec(
    `INSERT INTO users (company_id, role_id, full_name, email, password_hash, active, must_change_password,
                        receive_critical_alerts, receive_automatic_reports, failed_login_attempts, totp_enabled)
     VALUES (?, ?, ?, ?, ?, 1, 0, 1, 1, 0, 0)`,
    [admin.company_id, papelOperador.id, `Conta ${email}`, email, await hashSenha(senhaOperador)],
  );
}
let ultimo = null;
for (let i = 0; i < 5; i++) ultimo = await login(emailBloqueio, "senha-errada-" + i);
verificar("quinta senha errada responde 401 ou 423", [401, 423].includes(ultimo.status), `(${ultimo.status})`);
const idBloqueio = (await um(`SELECT id FROM users WHERE email = ?`, [emailBloqueio])).id;
const bloqueado = await q(
  `SELECT action FROM audit_logs WHERE entity_name = 'users' AND entity_id = ? AND action = 'LOGIN_LOCKED'`,
  [String(idBloqueio)],
);
verificar("auditoria registra LOGIN_LOCKED", bloqueado.length >= 1, `(${bloqueado.length})`);
const comSenhaCerta = await login(emailBloqueio, senhaOperador);
verificar(
  "conta bloqueada não entra mesmo com a senha certa",
  comSenhaCerta.status !== 200,
  `(${comSenhaCerta.status})`,
);

const entrouTroca = await login(emailTroca, senhaOperador);
const tokenTroca = entrouTroca.dados?.accessToken;
verificar("conta de troca entra", entrouTroca.status === 200 && Boolean(tokenTroca));
const trocou = await chamar(
  "PATCH",
  "/auth/senha",
  { senhaAtual: senhaOperador, novaSenha: "NovaSenha@2026" },
  tokenTroca,
);
verificar("troca de senha responde 200", trocou.status === 200, `(${trocou.status})`);
const idTroca = (await um(`SELECT id FROM users WHERE email = ?`, [emailTroca])).id;
const trocaAud = await q(
  `SELECT action FROM audit_logs WHERE entity_name = 'users' AND entity_id = ? AND action = 'PASSWORD_CHANGED'`,
  [String(idTroca)],
);
verificar("auditoria registra PASSWORD_CHANGED", trocaAud.length >= 1, `(${trocaAud.length})`);
const novaEntra = await login(emailTroca, "NovaSenha@2026");
verificar("nova senha funciona", novaEntra.status === 200, `(${novaEntra.status})`);

console.log(`\n${ok} OK, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
