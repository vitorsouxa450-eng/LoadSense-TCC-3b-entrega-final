import { q, um } from "../db.js";

const API = `${(process.env.LS_API ?? "http://127.0.0.1:5174").replace(/\/$/, "")}/api`;
let ok = 0;
let falhas = 0;
const verificar = (descricao, condicao, detalhe = "") => {
  if (condicao) {
    ok += 1;
    console.log(`  OK     ${descricao}`);
  } else {
    falhas += 1;
    console.log(`  FALHA  ${descricao} ${detalhe}`);
  }
};

async function chamar(metodo, caminho, corpo, token) {
  const res = await fetch(API + caminho, {
    method: metodo,
    headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  return { status: res.status, dados: await res.json().catch(() => null) };
}

const entrar = async (email) =>
  (await chamar("POST", "/auth/login", { email, senha: "LoadSense@2026" })).dados?.accessToken;

const inicio = new Date(Date.now() - 1000);
console.log("\nManutenção de cadastros");
const admin = await entrar("admin@loadsense.local");
verificar("login administrador", Boolean(admin));
const operador = await entrar("operador@loadsense.local");
verificar("login operador", Boolean(operador));

const empresa = (await um(`SELECT company_id FROM users WHERE email = 'admin@loadsense.local'`)).company_id;
const motorista = await um(
  `SELECT id, full_name FROM drivers WHERE company_id = ? AND active = 1 ORDER BY id DESC LIMIT 1`,
  [empresa],
);
const veiculo = await um(`SELECT id, plate FROM vehicles WHERE company_id = ? AND active = 1 ORDER BY id LIMIT 1`, [
  empresa,
]);
const rota = await um(`SELECT id, code FROM routes WHERE company_id = ? AND active = 1 ORDER BY id LIMIT 1`, [empresa]);

let r = await chamar("PATCH", `/motoristas/${motorista.id}`, { ativo: false }, admin);
verificar("administrador desativa motorista", r.status === 200, `(${r.status})`);
const ativos = await chamar("GET", "/motoristas", null, admin);
verificar("motorista desativado sai da lista padrão", !ativos.dados.motoristas.some((m) => m.id === motorista.id));
const todos = await chamar("GET", "/motoristas?incluirInativos=1", null, admin);
const desativado = todos.dados.motoristas.find((m) => m.id === motorista.id);
verificar(
  "motorista desativado continua listado com inativo",
  desativado && !desativado.active,
  JSON.stringify(desativado),
);
const novaOperacaoInativo = await chamar(
  "POST",
  "/operacoes",
  {
    placa: veiculo.plate,
    rotaCodigo: rota.code,
    metodo: "THREE_STAGE",
    tipoMovimento: "EXIT",
    pesoDeclaradoKg: 14000,
    motorista: motorista.full_name,
  },
  admin,
);
verificar(
  "motorista inativo não entra em operação nova",
  novaOperacaoInativo.status >= 400,
  `(${novaOperacaoInativo.status})`,
);
r = await chamar("PATCH", `/motoristas/${motorista.id}`, { ativo: true }, admin);
verificar("administrador reativa motorista", r.status === 200 && r.dados?.ativo === true, `(${r.status})`);

r = await chamar("PATCH", `/veiculos/${veiculo.id}`, { ativo: false }, admin);
verificar("administrador desativa caminhão", r.status === 200, `(${r.status})`);
const veiculosInativos = await chamar("GET", "/veiculos?incluirInativos=1", null, admin);
verificar(
  "caminhão desativado aparece com inativo",
  veiculosInativos.dados.veiculos.some((v) => v.id === veiculo.id && !v.active),
);
r = await chamar("PATCH", `/veiculos/${veiculo.id}`, { ativo: true }, admin);
verificar("administrador reativa caminhão", r.status === 200, `(${r.status})`);

r = await chamar("PATCH", `/rotas/${rota.id}`, { ativo: false }, admin);
verificar("administrador desativa rota", r.status === 200, `(${r.status})`);
const rotasInativas = await chamar("GET", "/rotas?incluirInativos=1", null, admin);
verificar(
  "rota desativada aparece com inativo",
  rotasInativas.dados.rotas.some((x) => x.id === rota.id && !x.active),
);
r = await chamar("PATCH", `/rotas/${rota.id}`, { ativo: true }, admin);
verificar("administrador reativa rota", r.status === 200, `(${r.status})`);

const criada = await chamar(
  "POST",
  "/operacoes",
  {
    placa: veiculo.plate,
    rotaCodigo: rota.code,
    metodo: "THREE_STAGE",
    tipoMovimento: "EXIT",
    pesoDeclaradoKg: 14000,
    motorista: motorista.full_name,
    observacoes: "Antes da manutenção",
  },
  admin,
);
verificar("operação aberta criada para o teste", criada.status === 201, `(${criada.status})`);
const opId = criada.dados?.id;
r = await chamar("PATCH", `/operacoes/${opId}/manutencao`, { observacoes: "Corrigida pelo administrador" }, admin);
verificar("operação em aberto aceita correção de observações", r.status === 200, `(${r.status})`);
const depois = await um(`SELECT observations FROM weighing_operations WHERE company_id = ? AND id = ?`, [
  empresa,
  opId,
]);
verificar(
  "observações gravadas no banco",
  depois?.observations === "Corrigida pelo administrador",
  JSON.stringify(depois),
);

const detalhe = await chamar("GET", `/operacoes/${opId}`, null, admin);
verificar(
  "detalhe traz o telefone do motorista",
  detalhe.status === 200 && "motoristaTelefone" in detalhe.dados,
  `(${detalhe.status})`,
);
verificar(
  "detalhe traz a correção feita na auditoria",
  (detalhe.dados?.auditoria ?? []).some((a) => a.acao === "UPDATE_OPERATION" && a.usuario),
  JSON.stringify(detalhe.dados?.auditoria?.slice(0, 1)),
);

const concluida = await um(
  `SELECT id FROM weighing_operations WHERE company_id = ? AND state = 'COMPLETED' ORDER BY id LIMIT 1`,
  [empresa],
);
r = await chamar("PATCH", `/operacoes/${concluida.id}/manutencao`, { observacoes: "não deve gravar" }, admin);
verificar("operação concluída é recusada (409)", r.status === 409, `(${r.status})`);

r = await chamar("PATCH", `/motoristas/${motorista.id}`, { ativo: false });
verificar("sem login não altera cadastro (401)", r.status === 401, `(${r.status})`);
r = await chamar("PATCH", `/motoristas/${motorista.id}`, { ativo: false }, operador);
verificar("operador sem permissão não altera cadastro (403)", r.status === 403, `(${r.status})`);
const aindaAtivo = await um(`SELECT active FROM drivers WHERE company_id = ? AND id = ?`, [empresa, motorista.id]);
verificar("cadastro continua ativo depois da tentativa recusada", aindaAtivo?.active === 1);

const auditados = await q(
  `SELECT action FROM audit_logs WHERE company_id = ? AND created_at >= ? AND action IN ('UPDATE_DRIVER','UPDATE_VEHICLE','UPDATE_ROUTE','UPDATE_OPERATION')`,
  [empresa, inicio],
);
verificar("alterações de manutenção aparecem na auditoria", auditados.length >= 7, `(${auditados.length})`);

console.log(`\n${ok} OK, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
