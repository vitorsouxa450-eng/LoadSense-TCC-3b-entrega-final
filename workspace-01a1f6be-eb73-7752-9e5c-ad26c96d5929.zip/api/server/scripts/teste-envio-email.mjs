import { enviarEmail, emailConfigurado } from "../email.js";

const destino = process.argv[2];
if (!destino || !destino.includes("@")) {
  console.error("Informe o destinatário: node server/scripts/teste-envio-email.mjs destinatario@exemplo.com");
  process.exit(2);
}
if (!emailConfigurado()) {
  console.error("LS_SMTP_HOST não está definido. Nada foi enviado.");
  process.exit(2);
}

const codigo = String(Math.floor(100000 + Math.random() * 900000));
const resultado = await enviarEmail({
  para: destino,
  assunto: "Teste de envio — LoadSense",
  texto: `Este é um e-mail de teste do LoadSense.\n\nCódigo de exemplo: ${codigo}\n\nSe você recebeu esta mensagem, o envio está funcionando.`,
});

if (resultado.enviado) {
  console.log(`OK: e-mail de teste enviado para ${destino}.`);
  process.exit(0);
}
console.error(`FALHA: ${resultado.motivo}. Veja a mensagem de erro acima e confira usuário, senha de app e porta.`);
process.exit(1);
