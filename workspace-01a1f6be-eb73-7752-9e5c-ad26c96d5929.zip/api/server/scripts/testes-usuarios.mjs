import { hashSenha } from "../auth.js";
import { exec, um } from "../db.js";

const API = `${(process.env.LS_API ?? "http://127.0.0.1:5174").replace(/\/$/, "")}/api`;
const SENHA_ADMIN = process.env.LS_SENHA ?? "LoadSense@2026";

let ok = 0;
let falhas = 0;
const verificar = (descricao, condicao, detalhe = "") => {
  if (condicao) {
    ok += 1;
    console.log(`  OK     ${descricao}`);
  } else {
    falhas += 1;
    console.log(`  FALHA  ${descricao} ${detalhe}`);
  }
};

async function chamar(metodo, caminho, corpo, token) {
  const res = await fetch(API + caminho, {
    method: metodo,
    headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  const dados = await res.json().catch(() => null);
  return { status: res.status, dados };
}

const login = (email, senha) => chamar("POST", "/auth/login", { email, senha });

const admin = await um(`SELECT company_id FROM users WHERE email = 'admin@loadsense.local'`);
const papelOperador = await um(`SELECT id FROM roles WHERE name = 'OPERATOR' AND company_id = ?`, [admin.company_id]);
const sufixo = Date.now();
const emailOperador = `equipe.${sufixo}@teste.local`;
const emailInativo = `equipe.inativo.${sufixo}@teste.local`;
const senhaOperador = "Equipe@2026";

await exec(
  `INSERT INTO users (company_id, role_id, full_name, email, password_hash, active, must_change_password,
                      receive_critical_alerts, receive_automatic_reports, failed_login_attempts, totp_enabled)
   VALUES (?, ?, 'Operador Equipe', ?, ?, 1, 0, 1, 1, 0, 0)`,
  [admin.company_id, papelOperador.id, emailOperador, await hashSenha(senhaOperador)],
);
await exec(
  `INSERT INTO users (company_id, role_id, full_name, email, password_hash, active, must_change_password,
                      receive_critical_alerts, receive_automatic_reports, failed_login_attempts, totp_enabled)
   VALUES (?, ?, 'Inativo Equipe', ?, ?, 0, 0, 1, 1, 0, 0)`,
  [admin.company_id, papelOperador.id, emailInativo, await hashSenha(senhaOperador)],
);
const operador = await um(`SELECT id FROM users WHERE email = ?`, [emailOperador]);
const inativo = await um(`SELECT id FROM users WHERE email = ?`, [emailInativo]);

console.log("\nListagem da equipe");
const tokenAdmin = (await login("admin@loadsense.local", SENHA_ADMIN)).dados?.accessToken;
verificar("administrador entra", Boolean(tokenAdmin));
const lista = await chamar("GET", "/usuarios", null, tokenAdmin);
verificar("GET /usuarios responde 200 com a equipe", lista.status === 200 && lista.dados.usuarios.length >= 2);
const texto = JSON.stringify(lista.dados);
verificar("listagem não expõe hash, senha nem segredo", !/password|senha_|hash|totp_secret|\$2[aby]\$/i.test(texto));
verificar(
  "listagem marca o próprio usuário",
  lista.dados.usuarios.some((u) => u.eu === true),
);

const tokenOperador = (await login(emailOperador, senhaOperador)).dados?.accessToken;
verificar("operador entra", Boolean(tokenOperador));
verificar("operador não lista a equipe (403)", (await chamar("GET", "/usuarios", null, tokenOperador)).status === 403);
verificar(
  "operador não exige troca em outra conta (403)",
  (await chamar("PATCH", `/usuarios/${operador.id}/troca-senha`, { exigir: true }, tokenOperador)).status === 403,
);

console.log("\nExigir troca de senha");
const exigiu = await chamar("PATCH", `/usuarios/${operador.id}/troca-senha`, { exigir: true }, tokenAdmin);
verificar(
  "administrador exige a troca: 200",
  exigiu.status === 200 && exigiu.dados.trocarSenha === true,
  `(${exigiu.status})`,
);
verificar(
  "sessão antiga do operador foi encerrada (401)",
  (await chamar("GET", "/painel?dias=7", null, tokenOperador)).status === 401,
);
const novoLogin = await login(emailOperador, senhaOperador);
verificar("novo login do operador sinaliza trocarSenha", novoLogin.dados?.usuario?.trocarSenha === true);

const liberou = await chamar("PATCH", `/usuarios/${operador.id}/troca-senha`, { exigir: false }, tokenAdmin);
verificar("administrador dispensa a troca: 200", liberou.status === 200 && liberou.dados.trocarSenha === false);
verificar(
  "depois de dispensar, login não pede troca",
  (await login(emailOperador, senhaOperador)).dados?.usuario?.trocarSenha === false,
);

console.log("\nCasos de erro");
verificar(
  "conta inexistente: 404",
  (await chamar("PATCH", `/usuarios/999999999/troca-senha`, { exigir: true }, tokenAdmin)).status === 404,
);
verificar(
  "sem o campo exigir: 422",
  (await chamar("PATCH", `/usuarios/${operador.id}/troca-senha`, {}, tokenAdmin)).status === 422,
);
verificar(
  "conta inativa: 409",
  (await chamar("PATCH", `/usuarios/${inativo.id}/troca-senha`, { exigir: true }, tokenAdmin)).status === 409,
);

console.log("\nAuditoria");
const auditoria = await um(
  `SELECT COUNT(*) AS n FROM audit_logs WHERE company_id = ? AND action IN ('PASSWORD_CHANGE_REQUIRED','PASSWORD_CHANGE_CLEARED') AND entity_id = ?`,
  [admin.company_id, String(operador.id)],
);
verificar("exigir e dispensar gravam auditoria", Number(auditoria.n) >= 2, `(${auditoria.n})`);

console.log(`\n${ok} OK, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
