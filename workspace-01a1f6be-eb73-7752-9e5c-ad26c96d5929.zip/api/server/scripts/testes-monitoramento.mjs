import { um } from "../db.js";
const API = process.env.LS_API ?? "http://127.0.0.1:5174/api";
let ok = 0;
const falhas = [];
const verificar = (desc, condicao, detalhe = "") => {
  if (condicao) {
    ok++;
    console.log(`  [OK] ${desc}${detalhe ? ` ${detalhe}` : ""}`);
  } else {
    falhas.push(desc);
    console.log(`  [FALHA] ${desc}${detalhe ? ` ${detalhe}` : ""}`);
  }
};

const login = await fetch(`${API}/auth/login`, {
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify({ email: "admin@loadsense.local", senha: "LoadSense@2026" }),
}).then((r) => r.json());
const H = { authorization: `Bearer ${login.accessToken}`, "content-type": "application/json" };
const get = (c) => fetch(`${API}${c}`, { headers: H }).then(async (r) => ({ status: r.status, corpo: await r.json() }));
const post = (c, corpo) =>
  fetch(`${API}${c}`, { method: "POST", headers: H, body: JSON.stringify(corpo ?? {}) }).then(async (r) => ({
    status: r.status,
    corpo: await r.json(),
  }));

console.log("\nMonitoramento: operação com motorista avança na tela");
const veiculos = (await get("/veiculos")).corpo.veiculos ?? [];
const motoristas = (await get("/motoristas")).corpo.motoristas ?? [];
const rotas = ((await get("/rotas")).corpo.rotas ?? []).filter((r) => r.ativa !== false);
verificar(
  "há caminhões, motoristas e rotas cadastrados",
  veiculos.length > 0 && motoristas.length > 0 && rotas.length > 0,
  `(${veiculos.length}/${motoristas.length}/${rotas.length})`,
);
if (!(veiculos.length && motoristas.length && rotas.length)) {
  console.log(
    "\nEste teste precisa de caminhão, motorista e rota cadastrados. Rode-o no banco de demonstração ou cadastre os itens antes.",
  );
  process.exit(2);
}
const veiculo = veiculos.find((v) => v.active !== false) ?? veiculos[0];
const motorista = motoristas[0];
const rota = rotas[0];

const criada = await post("/operacoes", {
  veiculoId: veiculo.id,
  motoristaId: motorista.id,
  rotaId: rota.id,
  tipoMovimento: "WEIGHING_ONLY",
  metodo: "GROSS_TARE",
});
verificar(
  "operação criada com motorista e rota",
  criada.status === 201 || criada.status === 200,
  `(HTTP ${criada.status})`,
);
const opId = criada.corpo.id;
const etiqueta = await um("SELECT code FROM rfid_tags WHERE vehicle_id = ? AND active = 1 LIMIT 1", [veiculo.id]);
const rfid = etiqueta?.code ?? null;
const ativacao = await post(`/operacoes/${opId}/rastreio/ativar`, { codigoRfid: rfid });
verificar(
  "rastreio ativado com o código RFID do caminhão",
  ativacao.status === 200,
  `(HTTP ${ativacao.status}, rfid=${rfid})`,
);
verificar(
  "operação criada tem o motorista escolhido",
  criada.corpo.motoristaId === motorista.id,
  `(${criada.corpo.motorista})`,
);

const antes = await get("/rastreio/ativo");
const naListaAntes = (antes.corpo.viagens ?? []).find((v) => v.id === opId);
verificar("operação nova aparece no monitoramento", Boolean(naListaAntes));
verificar(
  "antes de iniciar, o motorista aparece com o estado de viagem",
  naListaAntes?.motorista === motorista.full_name || naListaAntes?.motorista === criada.corpo.motorista,
  `(${naListaAntes?.rastreio?.estado ?? naListaAntes?.rastreioEstado ?? "sem estado"})`,
);

const v = await post(`/operacoes/${opId}/leituras`, {
  estagio: "EMPTY_TRUCK",
  pesoKg: 8200,
  origem: "MANUAL",
  motivoManual: "Teste de monitoramento",
});
const c = await post(`/operacoes/${opId}/leituras`, {
  estagio: "LOADED_TRUCK",
  pesoKg: 14000,
  origem: "MANUAL",
  motivoManual: "Teste de monitoramento",
});
const fin = await post(`/operacoes/${opId}/finalizar`);
verificar(
  "pesagem registrada e concluída",
  v.status < 300 && c.status < 300 && fin.status === 200,
  `(HTTP ${v.status}/${c.status}/${fin.status})`,
);

const agenda = new Date(Date.now() + 3600e3).toISOString();
const ag = await post(`/operacoes/${opId}/transporte/agenda`, {
  saidaPlanejada: agenda,
  chegadaPlanejada: new Date(Date.now() + 7200e3).toISOString(),
});
verificar("agenda do transporte gravada", ag.status === 200, `(HTTP ${ag.status})`);

const ini = await post(`/operacoes/${opId}/transporte/iniciar`);
verificar("iniciar transporte responde OK", ini.status === 200, `(HTTP ${ini.status})`);
const emViagem = (await get("/rastreio/ativo")).corpo.viagens.find((v) => v.id === opId);
const estadoViagem = emViagem?.rastreio?.estado ?? emViagem?.rastreioEstado;
verificar("após iniciar, o estado passa a em trânsito", estadoViagem === "IN_TRANSIT", `(${estadoViagem})`);

const cheg = await post(`/operacoes/${opId}/transporte/chegada`);
verificar("chegada do transporte responde OK", cheg.status === 200, `(HTTP ${cheg.status})`);
const depoisChegada = (await get("/rastreio/ativo")).corpo.viagens.find((v) => v.id === opId);
verificar("após a chegada, a operação sai das viagens ativas", !depoisChegada);

await post(`/operacoes/${opId}/cancelar`, { motivo: "Teste automatizado de monitoramento" });

const detalhe = await get(`/operacoes/${opId}`);
verificar(
  "detalhe mostra o rastreio chegado",
  detalhe.corpo.rastreio?.estado === "ARRIVED",
  `(${detalhe.corpo.rastreio?.estado})`,
);

console.log(`\n${ok} OK, ${falhas.length} falhas`);
process.exit(falhas.length ? 1 : 0);
