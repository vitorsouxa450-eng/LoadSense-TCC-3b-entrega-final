import express from "express";
import cors from "cors";
import { ErroHttp, asyncHandler, traduzirErroSql } from "./util.js";
import { ping, um } from "./db.js";
import { rotasAuth } from "./routes/auth.js";
import { rotasCatalogo } from "./routes/catalogo.js";
import { rotasCadastros } from "./routes/cadastros.js";
import { rotasManutencao } from "./routes/manutencao.js";
import { rotasOperacoes } from "./routes/operacoes.js";
import { rotasExportacao } from "./routes/exportacao.js";
import { rotasGestao } from "./routes/gestao.js";
import { rotasUsuarios } from "./routes/usuarios.js";
import { rotasAuditoria } from "./routes/auditoria.js";
import { rotasHistorico } from "./routes/historico.js";
import { protegerDadosPessoais } from "./migracao-dados.js";
import { garantirEstruturaAlertas } from "./migracao-alertas.js";
import { rotasTitular } from "./routes/titular.js";
import { rotasSeguranca } from "./routes/seguranca.js";
import { rotasPapeis } from "./routes/papeis.js";
import { rotasDispositivos } from "./routes/dispositivos.js";
import { agendarRetencao } from "./retencao.js";

const app = express();
app.disable("x-powered-by");
app.use((_req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Cross-Origin-Resource-Policy", "same-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  if (process.env.NODE_ENV === "production") {
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  }
  next();
});
const origensPermitidas = (process.env.LS_CORS_ORIGENS ?? "")
  .split(",")
  .map((o) => o.trim())
  .filter(Boolean);
app.use(
  cors({
    origin(origem, retorno) {
      if (!origem) return retorno(null, true);
      const local = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origem);
      return retorno(null, local || origensPermitidas.includes(origem));
    },
  }),
);
app.use(express.json({ limit: "4mb" }));
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const repetidos = Object.keys(req.query).filter((chave) => Array.isArray(req.query[chave]));
  if (repetidos.length) {
    return res.status(400).json({ erro: `Parâmetro repetido: ${repetidos.join(", ")}.` });
  }
  next();
});

app.use((req, res, next) => {
  if (req.path === "/api/saude") return next();
  const inicio = process.hrtime.bigint();
  res.on("finish", () => {
    console.log(
      JSON.stringify({
        ts: new Date().toISOString(),
        nivel: res.statusCode >= 500 ? "erro" : "info",
        metodo: req.method,
        caminho: req.path,
        status: res.statusCode,
        ms: Number(process.hrtime.bigint() - inicio) / 1e6,
      }),
    );
  });
  next();
});

app.get(
  "/api/saude",
  asyncHandler(async (_req, res) => {
    const latencia = await ping();
    const migracao = await um(
      `SELECT version, name, applied_at FROM schema_migrations ORDER BY version DESC LIMIT 1`,
    ).catch(() => null);
    res.json({
      ok: true,
      servico: "LoadSense API",
      versao: "1.0.0",
      banco: { latenciaMs: latencia, migracao },
      agora: new Date().toISOString(),
    });
  }),
);

app.use("/api", rotasAuth);
app.use("/api", rotasDispositivos);
app.use("/api", rotasCatalogo);
app.use("/api", rotasCadastros);
app.use("/api", rotasManutencao);
app.use("/api", rotasExportacao);
app.use("/api", rotasOperacoes);
app.use("/api", rotasGestao);
app.use("/api", rotasUsuarios);
app.use("/api", rotasAuditoria);
app.use("/api", rotasHistorico);
app.use("/api", rotasTitular);
app.use("/api", rotasSeguranca);
app.use("/api", rotasPapeis);

app.use("/api", (_req, res) => res.status(404).json({ erro: "Rota não encontrada." }));

app.use((erro, _req, res, _next) => {
  const traduzido = erro instanceof ErroHttp ? erro : traduzirErroSql(erro);
  if (traduzido.status >= 500 || (traduzido.status >= 400 && process.env.LS_LOG_ERROS))
    console.error("[erro]", erro?.code ?? "", erro?.sqlMessage ?? erro?.message ?? erro);
  res.status(traduzido.status).json({
    erro: traduzido.message,
    detalhe: traduzido.detalhe ?? undefined,
    status: traduzido.status,
  });
});

try {
  if (await garantirEstruturaAlertas()) console.log("Alertas: coluna resolution_reason criada.");
} catch (erro) {
  console.error("Alertas: falha na migração da estrutura:", erro?.message ?? erro);
}
try {
  await (await import("./segundo-fator.js")).garantirTabela();
} catch (erro) {
  console.error("Segundo fator: falha na migração da estrutura:", erro?.message ?? erro);
}

try {
  const protegidos = await protegerDadosPessoais();
  if (protegidos) console.log(`LGPD: ${protegidos} cadastro(s) de motorista protegido(s) (cifrados).`);
} catch (erro) {
  console.error("LGPD: falha ao proteger dados de motoristas:", erro?.message ?? erro);
}
agendarRetencao();

const porta = Number(process.env.LS_PORT ?? 5174);
app.listen(porta, "0.0.0.0", () => {
  console.log(`LoadSense API ouvindo em http://0.0.0.0:${porta}`);
  console.log(
    `Banco: ${process.env.LS_DB_USER ?? "root"}@${process.env.LS_DB_HOST ?? "127.0.0.1"}:${process.env.LS_DB_PORT ?? 3306}/${process.env.LS_DB_NAME ?? "loadsense"}`,
  );
});
