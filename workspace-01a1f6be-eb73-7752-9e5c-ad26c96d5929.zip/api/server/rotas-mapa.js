const BASE = (process.env.LS_ROTAS_URL ?? "https://router.project-osrm.org").replace(/\/$/, "");
const TEMPO_LIMITE_MS = 7000;
const VALIDADE_OSRM_MS = 24 * 60 * 60 * 1000;
const VALIDADE_FALLBACK_MS = 5 * 60 * 1000;

const cache = new Map();

export async function calcularRota(paradas) {
  const pontos = paradas
    .map((p) => [Number(p.latitude), Number(p.longitude)])
    .filter(([a, b]) => Number.isFinite(a) && Number.isFinite(b));
  if (pontos.length < 2) {
    return {
      fonte: "SEM_ROTA",
      geometria: pontos,
      distanciaKm: null,
      duracaoMin: null,
      aviso: "Esta rota ainda não tem origem e destino cadastrados.",
    };
  }

  const chave = pontos.map(([a, b]) => `${a.toFixed(5)},${b.toFixed(5)}`).join(";");
  const emCache = cache.get(chave);
  if (emCache && emCache.expira > Date.now()) return emCache.valor;

  let valor;
  let validade;
  try {
    const coordenadas = pontos.map(([lat, lon]) => `${lon},${lat}`).join(";");
    const controle = new AbortController();
    const temporizador = setTimeout(() => controle.abort(), TEMPO_LIMITE_MS);
    let resposta;
    try {
      resposta = await fetch(`${BASE}/route/v1/driving/${coordenadas}?overview=full&geometries=geojson`, {
        signal: controle.signal,
        headers: { "user-agent": "LoadSense-TCC/1.0" },
      });
    } finally {
      clearTimeout(temporizador);
    }
    if (!resposta.ok) throw new Error(`OSRM respondeu ${resposta.status}`);
    const dados = await resposta.json();
    const rota = dados.routes?.[0];
    if (!rota?.geometry?.coordinates?.length) throw new Error("OSRM sem rota");
    valor = {
      fonte: "OSRM",
      geometria: rota.geometry.coordinates.map(([lon, lat]) => [lat, lon]),
      distanciaKm: Math.round((rota.distance / 1000) * 10) / 10,
      duracaoMin: Math.round(rota.duration / 60),
    };
    validade = VALIDADE_OSRM_MS;
  } catch (erro) {
    console.warn("[rota] traçado por estradas indisponível:", erro.message);
    valor = {
      fonte: "LINHA_RETA",
      geometria: pontos,
      distanciaKm: null,
      duracaoMin: null,
      aviso: "Rota por estradas indisponível no momento. Mostrando a linha reta entre as paradas.",
    };
    validade = VALIDADE_FALLBACK_MS;
  }
  cache.set(chave, { valor, expira: Date.now() + validade });
  return valor;
}

export async function buscarAlternativas(origem, destino) {
  const linhaReta = () => [
    {
      id: 1,
      rotulo: "Linha reta (sem estradas)",
      fonte: "LINHA_RETA",
      distanciaKm: null,
      duracaoMin: null,
      geometria: [
        [origem.lat, origem.lon],
        [destino.lat, destino.lon],
      ],
      paradasSugeridas: [],
    },
  ];
  try {
    const controle = new AbortController();
    const temporizador = setTimeout(() => controle.abort(), TEMPO_LIMITE_MS);
    let resposta;
    try {
      resposta = await fetch(
        `${BASE}/route/v1/driving/${origem.lon},${origem.lat};${destino.lon},${destino.lat}?alternatives=3&overview=full&geometries=geojson`,
        { signal: controle.signal, headers: { "user-agent": "LoadSense-TCC/1.0" } },
      );
    } finally {
      clearTimeout(temporizador);
    }
    if (!resposta.ok) throw new Error(`OSRM respondeu ${resposta.status}`);
    const dados = await resposta.json();
    const rotas = (dados.routes ?? []).filter((r) => r.geometry?.coordinates?.length > 1);
    if (rotas.length === 0) throw new Error("OSRM sem rota");
    const ordenadas = [...rotas].sort((a, b) => a.duration - b.duration);
    const menorDistancia = Math.min(...rotas.map((r) => r.distance));
    return ordenadas.slice(0, 3).map((r, i) => {
      const geometria = r.geometry.coordinates.map(([lon, lat]) => [lat, lon]);
      const rotulo = i === 0 ? "Mais rápida" : r.distance <= menorDistancia + 1 ? "Mais curta" : `Alternativa ${i + 1}`;
      const paradasSugeridas = [1, 2, 3, 4]
        .map((k) => Math.floor((geometria.length * k) / 5))
        .map((idx) => ({ lat: geometria[idx][0], lon: geometria[idx][1] }));
      return {
        id: i + 1,
        rotulo,
        fonte: "OSRM",
        distanciaKm: Math.round((r.distance / 1000) * 10) / 10,
        duracaoMin: Math.round(r.duration / 60),
        geometria,
        paradasSugeridas,
      };
    });
  } catch (erro) {
    console.warn("[rota] alternativas indisponíveis:", erro.message);
    return linhaReta();
  }
}
