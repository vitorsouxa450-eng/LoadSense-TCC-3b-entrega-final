import { jsonSeguro, serializar } from "./util.js";

export function mapearOperacao(linha) {
  if (!linha) return null;
  return serializar({
    id: linha.id,
    codigo: linha.operation_code,
    empresaId: linha.company_id,
    estado: linha.state,
    status: linha.status,
    statusMotivo: linha.status_reason,
    metodo: linha.weighing_method,
    tipoMovimento: linha.movement_type,
    unidade: linha.operational_unit_name ?? null,
    posto: linha.weighing_station_name ?? null,
    veiculo: {
      id: linha.vehicle_id ?? null,
      placa: linha.vehicle_plate ?? null,
      frota: linha.fleet_code ?? null,
      tipo: linha.vehicle_type ?? null,
    },
    motorista: linha.driver_name ?? null,
    motoristaId: linha.driver_id ?? null,
    produto: linha.cargo_product_name ?? null,
    produtoId: linha.cargo_product_id ?? null,
    rfid: linha.rfid_code ?? null,
    rota: {
      id: linha.route_id ?? null,
      origem: linha.origin ?? null,
      destino: linha.destination ?? null,
      distanciaKm: linha.route_distance_km ?? null,
    },
    responsavel: linha.responsible_user_name ?? null,
    criadoPor: linha.created_by_user_name ?? null,
    observacoes: linha.observations ?? null,
    documentoFiscal: linha.invoice_number ?? null,
    mdfe: linha.mdfe_number ?? null,
    ciot: linha.ciot_number ?? null,
    datas: {
      iniciadaEm: linha.started_at ?? null,
      concluidaEm: linha.completed_at ?? null,
      saidaPlanejada: linha.planned_departure_at ?? null,
      saidaReal: linha.departed_at ?? null,
      chegadaPlanejada: linha.planned_arrival_at ?? null,
      chegadaReal: linha.arrived_at ?? null,
      canceladaEm: linha.cancelled_at ?? null,
    },
    pesos: {
      taraCadastradaKg: linha.registered_tare_snapshot_kg ?? null,
      vazioAferidoKg: linha.empty_truck_weight_kg ?? null,
      cargaSeparadaKg: linha.separated_cargo_weight_kg ?? null,
      cargaDeclaradaKg: linha.declared_cargo_weight_kg ?? null,
      brutoEsperadoKg: linha.expected_gross_weight_kg ?? null,
      brutoAferidoKg: linha.loaded_truck_weight_kg ?? null,
      cargaAferidaKg: linha.actual_cargo_weight_kg ?? null,
      desvioKg: linha.difference_kg ?? null,
      desvioPct: linha.difference_percent ?? null,
      taraDesvioPct: linha.tare_difference_percent ?? null,
      limiteBrutoKg: linha.gross_limit_snapshot_kg ?? null,
      limiteCargaKg: linha.payload_limit_snapshot_kg ?? null,
      toleranciaPct: linha.tolerance_percent_snapshot ?? null,
      limiteCriticoPct: linha.critical_limit_snapshot ?? null,
      toleranciaTaraPct: linha.tare_tolerance_snapshot ?? null,
    },
    versaoCalculo: linha.calculation_version ?? 0,
    versaoLinha: linha.row_version ?? 1,
    rastreio: mapearRastreio(linha),
    rastreioAtivado: Boolean(linha.tracking_enabled),
  });
}

export function mapearRastreio(linha) {
  if (!linha) return null;
  const estado = linha.tracking_state ?? null;
  if (!estado && linha.current_latitude === undefined) return null;
  return serializar({
    estado,
    latitude: linha.current_latitude ?? null,
    longitude: linha.current_longitude ?? null,
    velocidadeKmh: linha.speed_kmh ?? null,
    rumo: linha.heading_degrees ?? null,
    progressoPct: linha.progress_percent ?? null,
    desvioMetros: linha.route_deviation_meters ?? null,
    eta: linha.estimated_arrival_at ?? null,
    atrasoMin: linha.delay_minutes ?? null,
    ultimaPosicaoEm: linha.last_position_at ?? null,
    paradoDesde: linha.stopped_since ?? null,
    atualizadoEm: linha.updated_at ?? null,
  });
}

export function mapearLeitura(linha) {
  return serializar({
    id: linha.id,
    operacaoId: linha.operation_id,
    estagio: linha.stage,
    sequencia: linha.sequence_number,
    pesoKg: linha.weight_kg,
    origem: linha.source,
    dispositivoId: linha.device_id,
    estavel: Boolean(linha.is_stable),
    aceita: Boolean(linha.is_accepted),
    checksumValido: linha.checksum_valid === null ? null : Boolean(linha.checksum_valid),
    sinalDbm: linha.signal_strength_dbm,
    motivoManual: linha.manual_reason,
    medidoEm: linha.measured_at,
    recebidoEm: linha.received_at,
    aceitoEm: linha.accepted_at,
    aceitoPorId: linha.accepted_by_user_id,
    criadoPorId: linha.created_by_user_id,
  });
}

export function mapearAlerta(linha) {
  if (!linha) return null;
  return serializar({
    id: linha.id,
    operacaoId: linha.operation_id ?? null,
    operacaoCodigo: linha.operation_code ?? null,
    contexto: linha.alert_context,
    tipo: linha.alert_type,
    nivel: linha.severity,
    situacao: linha.state,
    origem: linha.source,
    chaveDeduplicacao: linha.deduplication_key,
    titulo: linha.title,
    mensagem: linha.message,
    desvioKg: linha.difference_kg ?? null,
    desvioPct: linha.difference_percent ?? null,
    contextoJson: jsonSeguro(linha.context_json),
    veiculo: linha.vehicle_plate ?? null,
    motorista: linha.driver_name ?? null,
    origemRota: linha.origin ?? null,
    destinoRota: linha.destination ?? null,
    detectadoEm: linha.detected_at,
    criadoEm: linha.created_at,
    reconhecidoEm: linha.acknowledged_at ?? null,
    reconhecidoPor: linha.acknowledged_by_user_name ?? null,
    resolvidoEm: linha.resolved_at ?? null,
    resolvidoPor: linha.resolved_by_user_name ?? null,
    motivoResolucao: linha.resolution_reason ?? null,
    notasResolucao: linha.resolution_notes ?? null,
    versaoCalculo: linha.calculation_version ?? null,
  });
}

export function mapearEvento(linha) {
  return serializar({
    id: linha.id,
    tipo: linha.event_type,
    usuarioId: linha.user_id,
    usuario: linha.user_name ?? null,
    dispositivoId: linha.device_id,
    dados: jsonSeguro(linha.event_data),
    criadoEm: linha.created_at,
  });
}

export const ROTULOS = {
  estado: {
    DRAFT: "Rascunho",
    IN_PROGRESS: "Em andamento",
    COMPLETED: "Concluída",
    CANCELLED: "Cancelada",
  },
  status: { ANALYSIS: "Em análise", NORMAL: "Normal", ATTENTION: "Atenção", CRITICAL: "Crítico" },
  estagio: { EMPTY_TRUCK: "Caminhão vazio", SEPARATED_CARGO: "Carga separada", LOADED_TRUCK: "Caminhão carregado" },
  metodo: { THREE_STAGE: "Três etapas", GROSS_TARE: "Bruto/tara" },
  rastreio: {
    NOT_STARTED: "Não iniciado",
    IN_TRANSIT: "Em trânsito",
    STOPPED: "Parado",
    ARRIVED: "Chegou",
    SIGNAL_LOST: "Sinal perdido",
    CANCELLED: "Cancelado",
  },
  alertaTipo: {
    OVER_GROSS_LIMIT: "Peso bruto acima do limite",
    OVER_PAYLOAD_LIMIT: "Carga acima da capacidade",
    POSSIBLE_MISSING_CARGO: "Possível falta de carga",
    POSSIBLE_EXTRA_CARGO: "Possível excesso de carga",
    TARE_DIVERGENCE: "Divergência de tara",
    UNSTABLE_READING: "Leitura instável",
    MANUAL_READING: "Leitura manual",
    WEIGHING_INCONSISTENCY: "Inconsistência de pesagem",
    DEVICE_OFFLINE: "Dispositivo offline",
    UNPLANNED_STOP: "Parada não programada",
    DELIVERY_DELAY: "Atraso na entrega",
    ROUTE_DEVIATION: "Desvio de rota",
    TRACKING_SIGNAL_LOST: "Sinal de rastreamento perdido",
  },
};
