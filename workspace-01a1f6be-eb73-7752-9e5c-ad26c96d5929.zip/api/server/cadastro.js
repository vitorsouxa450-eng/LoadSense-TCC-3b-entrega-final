import { randomBytes } from "node:crypto";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { ErroHttp, texto } from "./util.js";
import { q, tx } from "./db.js";
import { buscarUsuario, emitirSessao, hashSenha } from "./auth.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const MODELO = JSON.parse(readFileSync(path.join(DIR, "dados", "modelo-empresa.json"), "utf8"));
const DIAS_TESTE = 14;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const semAcento = (valor) => valor.normalize("NFD").replace(/[\u0300-\u036f]/g, "");

function slugBase(nome) {
  return (
    semAcento(nome)
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60) || "empresa"
  );
}

async function slugUnico(nome, conn) {
  for (let tentativa = 0; tentativa < 8; tentativa++) {
    const slug = `${slugBase(nome)}-${randomBytes(3).toString("hex")}`;
    const [[existe]] = await conn.execute(`SELECT id FROM companies WHERE slug = ? LIMIT 1`, [slug]);
    if (!existe) return slug;
  }
  throw new ErroHttp(500, "Não foi possível gerar um identificador para a empresa. Tente novamente.");
}

async function criarEmpresaComAdministrador({ nomeCompleto, email, senhaHash, nomeEmpresa, cnpj, telefone }, req) {
  const cnpjLimpo = cnpj ? cnpj.replace(/\D/g, "") : null;
  if (cnpjLimpo && cnpjLimpo.length < 11) throw new ErroHttp(422, "Informe um CNPJ válido ou deixe em branco.");

  const slug = await tx(async (conn) => {
    const [[emUso]] = await conn.execute(`SELECT id FROM users WHERE email = ? LIMIT 1`, [email]);
    if (emUso) throw new ErroHttp(409, "Já existe uma conta com este e-mail. Entre com sua senha.");
    if (cnpjLimpo) {
      const [[cnpjUsado]] = await conn.execute(`SELECT id FROM companies WHERE document_number = ? LIMIT 1`, [
        cnpjLimpo,
      ]);
      if (cnpjUsado) throw new ErroHttp(409, "Este CNPJ já está cadastrado no LoadSense.");
    }

    const slugEmpresa = await slugUnico(nomeEmpresa, conn);
    const [empresa] = await conn.execute(
      `INSERT INTO companies (legal_name, trade_name, document_number, slug, email, phone)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [nomeEmpresa.slice(0, 180), nomeEmpresa.slice(0, 140), cnpjLimpo, slugEmpresa, email, telefone],
    );
    const companyId = empresa.insertId;

    const config = { ...MODELO.configuracoes, company_id: companyId };
    const colunas = Object.keys(config);
    await conn.execute(
      `INSERT INTO company_settings (${colunas.join(", ")}) VALUES (${colunas.map(() => "?").join(", ")})`,
      colunas.map((c) => config[c]),
    );

    let roleAdmin = null;
    for (const papel of MODELO.papeis) {
      const [r] = await conn.execute(
        `INSERT INTO roles (company_id, name, description, is_system_role, active) VALUES (?, ?, ?, 1, 1)`,
        [companyId, papel.nome, papel.descricao],
      );
      if (papel.nome === "ADMINISTRATOR") roleAdmin = r.insertId;
      for (const codigo of papel.permissoes) {
        await conn.execute(
          `INSERT INTO role_permissions (role_id, permission_id) SELECT ?, id FROM permissions WHERE code = ?`,
          [r.insertId, codigo],
        );
      }
    }

    const [unidade] = await conn.execute(
      `INSERT INTO operational_units (company_id, code, name, description, active)
       VALUES (?, 'MATRIZ', ?, 'Unidade principal', 1)`,
      [companyId, nomeEmpresa.slice(0, 140)],
    );
    await conn.execute(
      `INSERT INTO weighing_stations (company_id, operational_unit_id, code, name, description, active)
       VALUES (?, ?, 'BAL-01', 'Balança 01', 'Balança principal', 1)`,
      [companyId, unidade.insertId],
    );

    const [usuario] = await conn.execute(
      `INSERT INTO users (company_id, role_id, full_name, email, password_hash, phone)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [companyId, roleAdmin, nomeCompleto.slice(0, 140), email, senhaHash, telefone],
    );
    const userId = usuario.insertId;
    await conn.execute(`INSERT INTO user_app_preferences (company_id, user_id) VALUES (?, ?)`, [companyId, userId]);

    const [[plano]] = await conn.execute(
      `SELECT id FROM subscription_plans WHERE code IN ('PROFISSIONAL', 'BASIC_PLUS')
        ORDER BY (code = 'PROFISSIONAL') DESC LIMIT 1`,
    );
    if (plano) {
      await conn.execute(
        `INSERT INTO company_subscriptions (company_id, plan_id, status, starts_at, current_period_start, current_period_end)
         VALUES (?, ?, 'TRIAL', CURRENT_TIMESTAMP(3), CURRENT_TIMESTAMP(3), DATE_ADD(CURRENT_TIMESTAMP(3), INTERVAL ? DAY))`,
        [companyId, plano.id, DIAS_TESTE],
      );
    }

    for (const doc of MODELO.documentosLegais) {
      const [d] = await conn.execute(
        `INSERT INTO legal_documents (company_id, document_type, version, title, content_format, content, content_hash,
                                      mandatory, requires_reacceptance, active, published_at, effective_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP(3), CURRENT_TIMESTAMP(3))`,
        [
          companyId,
          doc.document_type,
          doc.version,
          doc.title,
          doc.content_format,
          doc.content,
          doc.content_hash,
          doc.mandatory,
          doc.requires_reacceptance,
        ],
      );
      await conn.execute(
        `INSERT INTO legal_acceptances (company_id, user_id, legal_document_id, ip_address, user_agent, app_version_name)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          companyId,
          userId,
          d.insertId,
          req.ip?.slice(0, 45) ?? null,
          (req.get("user-agent") ?? "").slice(0, 500),
          "cadastro",
        ],
      );
    }
    return slugEmpresa;
  });

  const candidatos = await buscarUsuario(email);
  return candidatos.find((c) => c.empresa_slug === slug);
}

export function opcoesAuth(_req, res) {
  res.json({ cadastro: true });
}

export async function cadastrar(req, res) {
  const nomeCompleto = texto(req.body?.nomeCompleto);
  const email = texto(req.body?.email)?.toLowerCase();
  const senha = String(req.body?.senha ?? "");
  const nomeEmpresa = texto(req.body?.nomeEmpresa);
  const cnpj = texto(req.body?.cnpj);
  const telefone = texto(req.body?.telefone)?.slice(0, 30) ?? null;

  if (!nomeCompleto || nomeCompleto.length < 3) throw new ErroHttp(422, "Informe seu nome completo.");
  if (!email || !EMAIL_RE.test(email)) throw new ErroHttp(422, "Informe um e-mail válido.");
  if (senha.length < 8) throw new ErroHttp(422, "A senha precisa ter pelo menos 8 caracteres.");
  if (!nomeEmpresa || nomeEmpresa.length < 3) throw new ErroHttp(422, "Informe o nome da empresa.");
  if (req.body?.aceitouTermos !== true)
    throw new ErroHttp(422, "É necessário aceitar os termos de uso e a política de privacidade.");

  const usuario = await criarEmpresaComAdministrador(
    { nomeCompleto, email, senhaHash: await hashSenha(senha), nomeEmpresa, cnpj, telefone },
    req,
  );
  res.status(201);
  return emitirSessao(usuario, req, res);
}
