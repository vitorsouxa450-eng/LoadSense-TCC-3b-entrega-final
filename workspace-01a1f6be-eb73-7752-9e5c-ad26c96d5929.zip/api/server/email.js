import nodemailer from "nodemailer";

let transporte = null;

function configuracao() {
  const host = process.env.LS_SMTP_HOST?.trim();
  if (!host) return null;
  const porta = Number(process.env.LS_SMTP_PORT ?? 587);
  return {
    host,
    port: porta,
    secure: process.env.LS_SMTP_SEGURO === "1" || porta === 465,
    auth: process.env.LS_SMTP_USUARIO
      ? { user: process.env.LS_SMTP_USUARIO, pass: process.env.LS_SMTP_SENHA ?? "" }
      : undefined,
    remetente:
      process.env.LS_EMAIL_REMETENTE || process.env.LS_SMTP_USUARIO || "LoadSense <nao-responder@loadsense.local>",
  };
}

export function emailConfigurado() {
  return configuracao() !== null;
}

export async function enviarEmail({ para, assunto, texto }) {
  const cfg = configuracao();
  if (!cfg) return { enviado: false, motivo: "smtp-nao-configurado" };
  if (!transporte) transporte = nodemailer.createTransport({ ...cfg, connectionTimeout: 8000, greetingTimeout: 8000 });
  try {
    await transporte.sendMail({ from: cfg.remetente, to: para, subject: assunto, text: texto });
    return { enviado: true };
  } catch (erro) {
    console.error(`e-mail não enviado para ${mascararEmail(para)}: ${erro.code ?? erro.message}`);
    return { enviado: false, motivo: "falha-envio" };
  }
}

export function mascararEmail(email) {
  const [usuario = "", dominio = ""] = String(email ?? "").split("@");
  const visivel = usuario.slice(0, Math.min(3, Math.max(1, usuario.length - 2)));
  return `${visivel}${"*".repeat(Math.max(2, usuario.length - visivel.length))}@${dominio}`;
}
