import { call, exec, q } from "./db.js";

const LOTE = 500;

async function purgarPesagensAntigas() {
  const antigas = await q(
    `SELECT id, company_id FROM weighing_operations
      WHERE created_at < DATE_SUB(NOW(3), INTERVAL 5 YEAR)
      ORDER BY created_at LIMIT ?`,
    [LOTE],
  );
  for (const op of antigas) {
    await call("sp_purge_weighing_operation", [op.company_id, op.id]);
  }
  return antigas.length;
}

async function removerIdentificadoresDosLogs() {
  const sessoes = await exec(
    `UPDATE auth_sessions SET ip_address = NULL, user_agent = NULL
      WHERE issued_at < DATE_SUB(NOW(3), INTERVAL 6 MONTH)
        AND (ip_address IS NOT NULL OR user_agent IS NOT NULL)`,
  );
  const auditoria = await exec(
    `UPDATE audit_logs SET ip_address = NULL, user_agent = NULL
      WHERE created_at < DATE_SUB(NOW(3), INTERVAL 6 MONTH)
        AND (ip_address IS NOT NULL OR user_agent IS NOT NULL)`,
  );
  return (sessoes.affectedRows ?? 0) + (auditoria.affectedRows ?? 0);
}

export async function executarRetencao() {
  await call("sp_manutencao_diaria", []);
  const identificadores = await removerIdentificadoresDosLogs();
  let pesagens = 0;
  for (;;) {
    const apagadas = await purgarPesagensAntigas();
    pesagens += apagadas;
    if (apagadas < LOTE) break;
  }
  return { pesagensApagadas: pesagens, identificadoresRemovidos: identificadores };
}

export function agendarRetencao() {
  const rodar = async () => {
    try {
      const r = await executarRetencao();
      if (r.pesagensApagadas || r.identificadoresRemovidos) {
        console.log(
          `Retenção: ${r.pesagensApagadas} pesagem(ns) fora do prazo apagada(s); ` +
            `${r.identificadoresRemovidos} registro(s) de log sem IP/navegador.`,
        );
      }
    } catch (erro) {
      console.error("Retenção: falha na rotina diária:", erro?.sqlMessage ?? erro?.message ?? erro);
    }
  };
  rodar();
  const timer = setInterval(rodar, 24 * 60 * 60 * 1000);
  timer.unref();
  return timer;
}
