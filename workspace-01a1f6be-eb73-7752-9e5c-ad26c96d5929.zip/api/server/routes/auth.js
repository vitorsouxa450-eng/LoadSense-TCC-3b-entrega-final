import { Router } from "express";
import { asyncHandler, ErroHttp, texto, requerer } from "../util.js";
import { exec, q, um } from "../db.js";
import {
  ativarTotp,
  autenticar,
  configurarTotp,
  desativarTotp,
  enviarCodigoDesativacao,
  estadoTotp,
  login,
  loginTotp,
  logout,
  permissoesDoUsuario,
  refresh,
  registrarAuditoria,
} from "../auth.js";
import { definirNovaSenha, solicitarCodigo, verificarCodigo } from "../recuperacao.js";
import { cadastrar, opcoesAuth } from "../cadastro.js";

export const rotasAuth = Router();

import { limitarTentativas } from "../limite.js";

const JANELA = 15 * 60_000;
rotasAuth.post("/auth/login", limitarTentativas({ janelaMs: JANELA, max: 30, chave: "email", nome: "login" }), login);
rotasAuth.get("/auth/opcoes", opcoesAuth);
rotasAuth.post(
  "/auth/login/totp",
  limitarTentativas({ janelaMs: JANELA, max: 30, chave: "ip", nome: "login-totp" }),
  loginTotp,
);
rotasAuth.get("/auth/totp", autenticar, estadoTotp);
rotasAuth.post("/auth/totp/configurar", autenticar, configurarTotp);
rotasAuth.post("/auth/totp/enviar-desativacao", autenticar, enviarCodigoDesativacao);
rotasAuth.post("/auth/totp/ativar", autenticar, ativarTotp);
rotasAuth.post("/auth/totp/desativar", autenticar, desativarTotp);
rotasAuth.post(
  "/auth/cadastro",
  limitarTentativas({ janelaMs: JANELA, max: 100, chave: "ip", nome: "cadastro" }),
  asyncHandler(cadastrar),
);
rotasAuth.post("/auth/refresh", refresh);
rotasAuth.post("/auth/logout", logout);
rotasAuth.post(
  "/auth/recuperacao/codigo",
  limitarTentativas({ janelaMs: JANELA, max: 6, chave: "email", nome: "rec-codigo" }),
  solicitarCodigo,
);
rotasAuth.post(
  "/auth/recuperacao/verificar",
  limitarTentativas({ janelaMs: JANELA, max: 15, chave: "email", nome: "rec-verificar" }),
  verificarCodigo,
);
rotasAuth.post(
  "/auth/recuperacao/nova-senha",
  limitarTentativas({ janelaMs: JANELA, max: 15, chave: "email", nome: "rec-senha" }),
  definirNovaSenha,
);

rotasAuth.get(
  "/auth/eu",
  autenticar,
  asyncHandler(async (req, res) => {
    const { companyId, id: userId } = req.usuario;

    const preferencias = await um(
      `SELECT theme, language_code, push_notifications_enabled, sound_alerts_enabled,
              automatic_sync_enabled, dashboard_alert_limit, alerts_page_size, default_period_days
         FROM user_app_preferences WHERE company_id = ? AND user_id = ?`,
      [companyId, userId],
    );

    const assinatura = await um(
      `SELECT status, starts_at, current_period_start, current_period_end,
              plan_code, plan_name, monthly_price_brl, features_json
         FROM vw_company_current_subscription WHERE company_id = ? LIMIT 1`,
      [companyId],
    );

    const documentosPendentes = await q(
      `SELECT legal_document_id, document_type, version, title, content_format
         FROM vw_pending_legal_documents WHERE company_id = ? AND user_id = ?`,
      [companyId, userId],
    );

    res.json({
      usuario: {
        id: req.usuario.id,
        nome: req.usuario.nome,
        email: req.usuario.email,
        telefone: req.usuario.telefone,
        papel: req.usuario.papel,
      },
      empresa: {
        id: companyId,
        nome: req.usuario.empresa,
        slug: req.usuario.empresaSlug,
        cnpj: req.usuario.cnpj,
        fusoHorario: req.usuario.fusoHorario,
      },
      permissoes: req.usuario.permissoes,
      preferencias,
      assinatura,
      documentosPendentes,
    });
  }),
);

rotasAuth.patch(
  "/auth/senha",
  autenticar,
  asyncHandler(async (req, res) => {
    const atual = String(req.body?.senhaAtual ?? "");
    const nova = String(req.body?.novaSenha ?? "");
    requerer(nova.length >= 8, 422, "A nova senha deve ter pelo menos 8 caracteres.");

    const linha = await um(`SELECT password_hash FROM users WHERE company_id = ? AND id = ?`, [
      req.usuario.companyId,
      req.usuario.id,
    ]);
    const { conferirSenha, hashSenha } = await import("../auth.js");
    requerer(await conferirSenha(atual, linha.password_hash), 401, "Senha atual incorreta.");

    await exec(`UPDATE users SET password_hash = ?, must_change_password = 0 WHERE company_id = ? AND id = ?`, [
      await hashSenha(nova),
      req.usuario.companyId,
      req.usuario.id,
    ]);
    await registrarAuditoria(
      req.usuario.companyId,
      req.usuario.id,
      "PASSWORD_CHANGED",
      "users",
      req.usuario.id,
      null,
      req.ip,
      req.get("user-agent"),
    );
    await exec(
      `UPDATE auth_sessions SET revoked_at = CURRENT_TIMESTAMP(3), revoke_reason = 'PASSWORD_CHANGED'
        WHERE company_id = ? AND user_id = ? AND revoked_at IS NULL AND id <> ?`,
      [req.usuario.companyId, req.usuario.id, req.usuario.sessaoId],
    );
    res.json({ ok: true });
  }),
);

rotasAuth.get(
  "/planos",
  asyncHandler(async (_req, res) => {
    const planos = await q(
      `SELECT id, code, name, description, monthly_price_brl, features_json, sort_order
         FROM subscription_plans WHERE active = 1 ORDER BY sort_order, monthly_price_brl`,
    );
    res.json({ planos });
  }),
);

rotasAuth.get(
  "/plataforma",
  asyncHandler(async (req, res) => {
    const plataforma = texto(req.query.plataforma)?.toUpperCase() === "IOS" ? "IOS" : "ANDROID";
    const dados = await um(
      `SELECT platform, current_version_name, current_build_number, minimum_supported_build_number,
              maintenance_mode, maintenance_message, store_url
         FROM app_platform_settings WHERE platform = ?`,
      [plataforma],
    );
    res.json(dados ?? {});
  }),
);

rotasAuth.post(
  "/empresas/solicitacoes",
  asyncHandler(async (req, res) => {
    const razaoSocial = texto(req.body?.razaoSocial);
    const documento = texto(req.body?.cnpj);
    const responsavel = texto(req.body?.responsavel);
    const email = texto(req.body?.email)?.toLowerCase();
    const telefone = texto(req.body?.telefone);
    const aceite = req.body?.aceitouPrivacidade === true;

    requerer(razaoSocial && razaoSocial.length >= 3, 422, "Informe a razão social da empresa.");
    requerer(documento && documento.replace(/\D/g, "").length >= 11, 422, "Informe um CNPJ válido.");
    requerer(responsavel, 422, "Informe o nome do responsável.");
    requerer(email && /.+@.+\..+/.test(email), 422, "Informe um e-mail válido.");
    requerer(aceite, 422, "É necessário aceitar a política de privacidade.");

    const repetido = await um(
      `SELECT id FROM company_requests WHERE document_number = ? AND status = 'PENDING' LIMIT 1`,
      [documento.replace(/\D/g, "").slice(0, 20)],
    );
    if (repetido) throw new ErroHttp(409, "Já existe uma solicitação pendente para este CNPJ.");

    const res1 = await exec(
      `INSERT INTO company_requests (legal_name, document_number, responsible_name, email, phone, privacy_accepted)
       VALUES (?, ?, ?, ?, ?, 1)`,
      [
        razaoSocial.slice(0, 180),
        documento.replace(/\D/g, "").slice(0, 20),
        responsavel.slice(0, 140),
        email.slice(0, 160),
        telefone?.slice(0, 30) ?? null,
      ],
    );

    res.status(201).json({
      id: res1.insertId,
      situacao: "PENDING",
      mensagem: "Solicitação registrada. Nossa equipe entrará em contato para concluir a criação da empresa.",
    });
  }),
);

rotasAuth.get(
  "/permissoes",
  autenticar,
  asyncHandler(async (req, res) => {
    const linhas = await q(`SELECT code, description FROM permissions ORDER BY code`);
    res.json({ permissoes: linhas, doUsuario: await permissoesDoUsuario(req.usuario.companyId, req.usuario.roleId) });
  }),
);
