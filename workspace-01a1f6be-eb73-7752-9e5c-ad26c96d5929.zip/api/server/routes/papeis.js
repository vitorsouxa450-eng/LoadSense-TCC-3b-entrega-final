import { Router } from "express";
import { ErroHttp, asyncHandler, requerer, texto } from "../util.js";
import { autenticar, exigirPermissao, registrarAuditoria } from "../auth.js";
import { q, um, tx } from "../db.js";

const CARGOS_CONFIGURAVEIS = ["SUPERVISOR", "OPERATOR"];
const PERMISSOES_RESERVADAS = ["USER_MANAGE", "SETTINGS_MANAGE", "SUBSCRIPTION_MANAGE"];

export const rotasPapeis = Router();
rotasPapeis.use(autenticar);

rotasPapeis.get(
  "/papeis",
  exigirPermissao("USER_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const catalogo = await q(`SELECT code, description FROM permissions ORDER BY code`);
    const cargos = await q(
      `SELECT r.id, r.name, r.description, COUNT(u.id) AS usuarios
         FROM roles r
         LEFT JOIN users u ON u.company_id = r.company_id AND u.role_id = r.id
        WHERE r.company_id = ? AND r.active = 1
        GROUP BY r.id, r.name, r.description
        ORDER BY FIELD(r.name, 'ADMINISTRATOR', 'SUPERVISOR', 'OPERATOR'), r.name`,
      [empresa],
    );
    const concessoes = await q(
      `SELECT rp.role_id, p.code
         FROM role_permissions rp
         JOIN roles r ON r.id = rp.role_id AND r.company_id = ?
         JOIN permissions p ON p.id = rp.permission_id`,
      [empresa],
    );
    const porCargo = new Map();
    for (const c of concessoes) {
      if (!porCargo.has(Number(c.role_id))) porCargo.set(Number(c.role_id), []);
      porCargo.get(Number(c.role_id)).push(c.code);
    }

    res.json({
      catalogo: catalogo.map((p) => ({
        codigo: p.code,
        descricao: p.description,
        reservada: PERMISSOES_RESERVADAS.includes(p.code),
      })),
      cargos: cargos.map((r) => ({
        nome: r.name,
        descricao: r.description,
        usuarios: Number(r.usuarios),
        editavel: CARGOS_CONFIGURAVEIS.includes(r.name),
        permissoes: (porCargo.get(Number(r.id)) ?? []).sort(),
      })),
    });
  }),
);

rotasPapeis.put(
  "/papeis/:nome/permissoes",
  exigirPermissao("USER_MANAGE"),
  asyncHandler(async (req, res) => {
    const nomeCargo = texto(req.params.nome);
    if (!CARGOS_CONFIGURAVEIS.includes(nomeCargo)) {
      throw new ErroHttp(403, "Este cargo não pode ser alterado. Apenas Supervisor e Operador são configuráveis.");
    }

    const pedidas = req.body?.permissoes;
    requerer(Array.isArray(pedidas), 422, "Informe a lista de permissões.");
    const codigos = [...new Set(pedidas.map((p) => String(p)))];

    const existentes = await q(`SELECT code FROM permissions`);
    const validos = new Set(existentes.map((p) => p.code));
    for (const codigo of codigos) {
      requerer(validos.has(codigo), 422, `Permissão desconhecida: ${codigo}.`);
      requerer(!PERMISSOES_RESERVADAS.includes(codigo), 422, `A permissão ${codigo} é exclusiva do administrador.`);
    }

    const minhas = new Set(req.usuario.permissoes);
    const semAcesso = codigos.filter((c) => !minhas.has(c));
    requerer(semAcesso.length === 0, 403, `Você não pode conceder permissões que não possui: ${semAcesso.join(", ")}.`);

    const role = await um(`SELECT id FROM roles WHERE company_id = ? AND name = ? AND active = 1`, [
      req.usuario.companyId,
      nomeCargo,
    ]);
    if (!role) throw new ErroHttp(404, "Cargo não encontrado nesta empresa.");

    await tx(async (conn) => {
      await conn.execute(
        `DELETE rp FROM role_permissions rp
           JOIN permissions p ON p.id = rp.permission_id
          WHERE rp.role_id = ? AND p.code NOT IN (${PERMISSOES_RESERVADAS.map(() => "?").join(", ")})`,
        [role.id, ...PERMISSOES_RESERVADAS],
      );
      if (codigos.length) {
        await conn.execute(
          `INSERT INTO role_permissions (role_id, permission_id)
           SELECT ?, id FROM permissions WHERE code IN (${codigos.map(() => "?").join(", ")})`,
          [role.id, ...codigos],
        );
      }
    });

    await registrarAuditoria(
      req.usuario.companyId,
      req.usuario.id,
      "ROLE_PERMISSIONS_UPDATED",
      "roles",
      role.id,
      { cargo: nomeCargo, permissoes: codigos },
      req.ip,
      req.get("user-agent"),
    );

    res.json({ ok: true, cargo: nomeCargo, permissoes: codigos.sort() });
  }),
);
