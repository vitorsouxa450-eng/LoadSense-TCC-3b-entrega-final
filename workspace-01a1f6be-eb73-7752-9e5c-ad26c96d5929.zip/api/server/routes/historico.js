import { Router } from "express";
import { ErroHttp, asyncHandler, id, numero, texto } from "../util.js";
import { autenticar, exigirPermissao } from "../auth.js";
import { q } from "../db.js";

export const rotasHistorico = Router();
rotasHistorico.use(autenticar);

const DATA = /^\d{4}-\d{2}-\d{2}$/;
const TIPOS = ["pesagem", "criacao", "evento", "rastreio", "alerta", "edicao", "cadastro", "acesso"];

const EVENTOS_OPERACAO = {
  CREATED: { tipo: "criacao", rotulo: "Operação criada" },
  FINALIZED: { tipo: "evento", rotulo: "Operação finalizada" },
  CANCELLED: { tipo: "evento", rotulo: "Operação cancelada" },
  REOPENED: { tipo: "evento", rotulo: "Operação reaberta" },
  STATUS_CHANGED: { tipo: "evento", rotulo: "Status alterado" },
  NOTE_ADDED: { tipo: "evento", rotulo: "Observação adicionada" },
  TRANSPORT_SCHEDULED: { tipo: "evento", rotulo: "Transporte agendado" },
  TRACKING_STARTED: { tipo: "rastreio", rotulo: "Rastreio iniciado" },
  TRACKING_STOPPED: { tipo: "rastreio", rotulo: "Rastreio parado" },
  TRACKING_RESUMED: { tipo: "rastreio", rotulo: "Rastreio retomado" },
  TRACKING_ARRIVED: { tipo: "rastreio", rotulo: "Chegada registrada" },
  TRACKING_SIGNAL_LOST: { tipo: "rastreio", rotulo: "Sinal perdido" },
  TRACKING_CANCELLED: { tipo: "rastreio", rotulo: "Rastreio cancelado" },
  DELIVERY_DELAY: { tipo: "evento", rotulo: "Atraso na entrega" },
  ROUTE_DEVIATION: { tipo: "evento", rotulo: "Desvio de rota" },
};

const ETAPA = { EMPTY_TRUCK: "caminhão vazio", SEPARATED_CARGO: "carga separada", LOADED_TRUCK: "caminhão carregado" };
const ORIGEM = { DEVICE: "balança", MANUAL: "digitada", IMPORT: "importada" };
const SEVERIDADE = { CRITICAL: "Crítico", ATTENTION: "Atenção" };
const SITUACAO = { OPEN: "aberto", ACKNOWLEDGED: "reconhecido", RESOLVED: "resolvido" };

const ACOES_ACESSO = {
  LOGIN: "Login",
  LOGIN_FAILED: "Tentativa de login recusada",
  LOGIN_LOCKED: "Conta bloqueada por tentativas",
  PASSWORD_CHANGED: "Senha alterada",
  PASSWORD_CHANGE_REQUIRED: "Troca de senha exigida",
  PASSWORD_CHANGE_CLEARED: "Troca de senha concluída",
  TOTP_ENABLED: "Segundo fator ativado",
  TOTP_DISABLED: "Segundo fator desativado",
};

const ACOES_CADASTRO = {
  USER_CREATED: "Usuário criado",
  UPDATE_DRIVER: "Motorista alterado",
  ANONYMIZE_DRIVER: "Motorista anonimizado",
  UPDATE_ROUTE: "Rota alterada",
};

const CAMPOS_EDICAO = {
  motorista: "Motorista",
  produto: "Produto",
  observacoes: "Observações",
  documentoFiscal: "Nota fiscal",
  mdfe: "MDF-e",
  ciot: "CIOT",
};

function jsonSeguro(valor) {
  if (valor == null) return null;
  if (typeof valor === "object") return valor;
  try {
    return JSON.parse(valor);
  } catch {
    return null;
  }
}

function camposAlterados(antes, depois) {
  if (!antes || !depois) return [];
  return Object.keys(CAMPOS_EDICAO)
    .filter((campo) => (antes[campo] ?? null) !== (depois[campo] ?? null))
    .map((campo) => CAMPOS_EDICAO[campo]);
}

function filtrosData(coluna, de, ate, valores) {
  const partes = [];
  if (de) {
    partes.push(`${coluna} >= ?`);
    valores.push(`${de} 00:00:00`);
  }
  if (ate) {
    partes.push(`${coluna} < DATE_ADD(?, INTERVAL 1 DAY)`);
    valores.push(`${ate} 00:00:00`);
  }
  return partes;
}

rotasHistorico.get(
  "/historico",
  exigirPermissao("OPERATION_VIEW", "DASHBOARD_VIEW", "AUDIT_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const tipo = texto(req.query.tipo);
    const busca = (texto(req.query.busca) ?? "").toLowerCase();
    const operacaoId = req.query.operacaoId ? id(req.query.operacaoId) : null;
    const de = texto(req.query.de);
    const ate = texto(req.query.ate);
    const limite = Math.min(500, Math.max(10, numero(req.query.limite, 200)));
    const pagina = Math.max(1, Math.floor(numero(req.query.pagina, 1)));

    if (tipo && !TIPOS.includes(tipo)) throw new ErroHttp(422, "Tipo de atividade inválido.");
    if (de && !DATA.test(de)) throw new ErroHttp(422, "Data inicial inválida.");
    if (ate && !DATA.test(ate)) throw new ErroHttp(422, "Data final inválida.");
    if (de && ate && de > ate) throw new ErroHttp(422, "A data inicial é posterior à final.");

    const podeVerAcesso = Boolean(req.usuario.permissoes?.includes("AUDIT_VIEW"));
    const atividades = [];

    {
      const valores = [empresa];
      const filtros = ["r.company_id = ?"];
      if (operacaoId) {
        filtros.push("r.operation_id = ?");
        valores.push(operacaoId);
      }
      filtros.push(...filtrosData("r.measured_at", de, ate, valores));
      const linhas = await q(
        `SELECT r.id, r.stage, r.weight_kg, r.source, r.is_accepted, r.measured_at, r.operation_id,
                o.operation_code, v.plate, usr.full_name AS usuario
           FROM weighing_readings r
           JOIN weighing_operations o ON o.company_id = r.company_id AND o.id = r.operation_id
           LEFT JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
           LEFT JOIN users usr ON usr.company_id = r.company_id AND usr.id = r.created_by_user_id
          WHERE ${filtros.join(" AND ")}
          ORDER BY r.measured_at DESC `,
        valores,
      );
      for (const l of linhas) {
        atividades.push({
          id: `pesagem-${l.id}`,
          tipo: "pesagem",
          rotulo: `Pesagem: ${ETAPA[l.stage] ?? l.stage}`,
          data: l.measured_at,
          operacaoId: l.operation_id,
          codigo: l.operation_code,
          placa: l.plate,
          usuario: l.usuario ?? null,
          detalhe: `${Number(l.weight_kg).toLocaleString("pt-BR")} kg · ${ORIGEM[l.source] ?? l.source} · ${
            l.is_accepted ? "aceita" : "pendente"
          }`,
        });
      }
    }

    {
      const valores = [empresa];
      const filtros = ["e.company_id = ?", "e.event_type NOT LIKE 'READING_%'"];
      if (operacaoId) {
        filtros.push("e.operation_id = ?");
        valores.push(operacaoId);
      }
      filtros.push(...filtrosData("e.created_at", de, ate, valores));
      const linhas = await q(
        `SELECT e.id, e.event_type, e.event_data, e.created_at, e.operation_id,
                o.operation_code, v.plate, usr.full_name AS usuario
           FROM operation_events e
           JOIN weighing_operations o ON o.company_id = e.company_id AND o.id = e.operation_id
           LEFT JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
           LEFT JOIN users usr ON usr.company_id = e.company_id AND usr.id = e.user_id
          WHERE ${filtros.join(" AND ")}
          ORDER BY e.created_at DESC `,
        valores,
      );
      for (const l of linhas) {
        const info = EVENTOS_OPERACAO[l.event_type] ?? { tipo: "evento", rotulo: l.event_type };
        const dados = jsonSeguro(l.event_data) ?? {};
        atividades.push({
          id: `evento-${l.id}`,
          tipo: info.tipo,
          rotulo: info.rotulo,
          data: l.created_at,
          operacaoId: l.operation_id,
          codigo: l.operation_code,
          placa: l.plate,
          usuario: l.usuario ?? null,
          detalhe: dados.motivo ?? dados.observacao ?? dados.nota ?? "",
        });
      }
    }

    {
      const valores = [empresa];
      const filtros = ["a.company_id = ?"];
      if (operacaoId) {
        filtros.push("a.operation_id = ?");
        valores.push(operacaoId);
      }
      filtros.push(...filtrosData("a.created_at", de, ate, valores));
      const linhas = await q(
        `SELECT a.id, a.title, a.message, a.severity, a.state, a.created_at, a.operation_id,
                o.operation_code, v.plate
           FROM alerts a
           JOIN weighing_operations o ON o.company_id = a.company_id AND o.id = a.operation_id
           LEFT JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
          WHERE ${filtros.join(" AND ")}
          ORDER BY a.created_at DESC `,
        valores,
      );
      for (const l of linhas) {
        atividades.push({
          id: `alerta-${l.id}`,
          tipo: "alerta",
          rotulo: l.title,
          data: l.created_at,
          operacaoId: l.operation_id,
          codigo: l.operation_code,
          placa: l.plate,
          usuario: null,
          detalhe: `${SEVERIDADE[l.severity] ?? l.severity} · ${SITUACAO[l.state] ?? l.state} · ${l.message}`,
        });
      }
    }

    {
      const valores = [empresa];
      const filtros = ["a.company_id = ?"];
      if (operacaoId) {
        filtros.push("a.entity_name = 'weighing_operations' AND a.entity_id = ?");
        valores.push(String(operacaoId));
      }
      filtros.push(...filtrosData("a.created_at", de, ate, valores));
      const linhas = await q(
        `SELECT a.id, a.action, a.entity_name, a.entity_id, a.old_values, a.new_values, a.created_at,
                usr.full_name AS usuario, o.id AS op_id, o.operation_code, v.plate
           FROM audit_logs a
           LEFT JOIN users usr ON usr.company_id = a.company_id AND usr.id = a.user_id
           LEFT JOIN weighing_operations o ON a.entity_name = 'weighing_operations'
                AND o.company_id = a.company_id AND o.id = CAST(a.entity_id AS UNSIGNED)
           LEFT JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
          WHERE ${filtros.join(" AND ")}
          ORDER BY a.created_at DESC, a.id DESC `,
        valores,
      );
      for (const l of linhas) {
        const novo = jsonSeguro(l.new_values);
        const antigo = jsonSeguro(l.old_values);
        const base = {
          id: `auditoria-${l.id}`,
          data: l.created_at,
          usuario: l.usuario ?? null,
          operacaoId: l.op_id ?? null,
          codigo: l.operation_code ?? null,
          placa: l.plate ?? null,
        };

        if (ACOES_ACESSO[l.action]) {
          if (!podeVerAcesso) continue;
          atividades.push({ ...base, tipo: "acesso", rotulo: ACOES_ACESSO[l.action], detalhe: "" });
          continue;
        }

        if (l.action === "UPDATE_OPERATION") {
          const alterados = camposAlterados(antigo, novo);
          atividades.push({
            ...base,
            tipo: "edicao",
            rotulo: "Operação editada",
            temAntes: Boolean(antigo),
            antes: antigo,
            depois: novo,
            detalhe: !antigo
              ? "Versão anterior não registrada (edição feita antes da atualização do histórico)."
              : alterados.length
                ? `Campos alterados: ${alterados.join(", ")}`
                : "Nenhum campo alterado",
          });
          continue;
        }

        if (l.entity_name === "weighing_operations") {
          atividades.push({
            ...base,
            tipo: l.action === "TRACKING_ACTIVATED" ? "rastreio" : "edicao",
            rotulo: l.action === "TRACKING_ACTIVATED" ? "Rastreio ativado" : l.action.replace(/_/g, " ").toLowerCase(),
            depois: novo,
            detalhe: "",
          });
          continue;
        }

        if (!podeVerAcesso) continue;
        atividades.push({
          ...base,
          tipo: "cadastro",
          rotulo: ACOES_CADASTRO[l.action] ?? `${l.action.replace(/_/g, " ").toLowerCase()} (${l.entity_name})`,
          depois: novo,
          detalhe: "",
        });
      }
    }

    const emOrdem = atividades.sort((a, b) => new Date(b.data) - new Date(a.data));
    const textoBusca = (a) => `${a.rotulo} ${a.detalhe ?? ""} ${a.codigo ?? ""} ${a.placa ?? ""} ${a.usuario ?? ""}`;
    const contagem = Object.fromEntries(TIPOS.map((t) => [t, 0]));
    const todas = [];
    for (const a of emOrdem) {
      if (busca && !textoBusca(a).toLowerCase().includes(busca)) continue;
      contagem[a.tipo] = (contagem[a.tipo] ?? 0) + 1;
      todas.push(a);
    }
    const filtradas = todas.filter((a) => !tipo || a.tipo === tipo);
    const inicio = (pagina - 1) * limite;
    const itens = filtradas.slice(inicio, inicio + limite);

    res.json({
      atividades: itens,
      contagem,
      total: filtradas.length,
      limite,
      pagina,
      temMais: inicio + limite < filtradas.length,
    });
  }),
);
