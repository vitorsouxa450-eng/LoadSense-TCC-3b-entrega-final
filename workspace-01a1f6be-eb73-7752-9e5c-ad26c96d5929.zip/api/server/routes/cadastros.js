import { Router } from "express";
import { asyncHandler, ErroHttp, numero, requerer, texto } from "../util.js";
import { autenticar, exigirPermissao } from "../auth.js";
import { exec, tx } from "../db.js";
import { cifrar, hashBusca } from "../dados-pessoais.js";
import { buscarAlternativas } from "../rotas-mapa.js";

export const rotasCadastros = Router();

const coordenada = (valor, min, max) => {
  const n = Number(valor);
  return Number.isFinite(n) && n >= min && n <= max ? n : null;
};

rotasCadastros.post(
  "/motoristas",
  autenticar,
  exigirPermissao("DRIVER_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const nome = texto(req.body?.nome);
    requerer(nome && nome.length >= 3, 422, "Informe o nome do motorista.");
    const documento = texto(req.body?.cpf)?.replace(/\D/g, "").slice(0, 20) || null;
    const validade = texto(req.body?.validadeCnh);
    requerer(
      !validade || /^\d{4}-\d{2}-\d{2}$/.test(validade),
      422,
      "A validade da CNH deve estar no formato AAAA-MM-DD.",
    );

    if (documento) {
      const repetido = await tx(async (conn) => {
        const [[linha]] = await conn.execute(
          `SELECT id FROM drivers WHERE company_id = ? AND document_hash = ? AND active = 1 LIMIT 1`,
          [empresa, hashBusca(documento)],
        );
        return linha;
      });
      if (repetido) throw new ErroHttp(409, "Já existe um motorista com este CPF.");
    }

    const resultado = await exec(
      `INSERT INTO drivers (company_id, full_name, document_number, document_hash, employee_code, license_number,
                            license_category, license_expiration_date, phone, active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
      [
        empresa,
        nome.slice(0, 140),
        cifrar(documento),
        hashBusca(documento),
        texto(req.body?.matricula)?.slice(0, 40) ?? null,
        cifrar(texto(req.body?.cnh)?.slice(0, 40) ?? null),
        texto(req.body?.categoriaCnh)?.toUpperCase().slice(0, 10) ?? null,
        validade ?? null,
        cifrar(texto(req.body?.telefone)?.slice(0, 30) ?? null),
      ],
    );
    res.status(201).json({ id: resultado.insertId, nome });
  }),
);

rotasCadastros.get(
  "/rotas/alternativas",
  autenticar,
  exigirPermissao("TRACKING_MANAGE", "OPERATION_CREATE"),
  asyncHandler(async (req, res) => {
    const origem = { lat: coordenada(req.query.latOrigem, -90, 90), lon: coordenada(req.query.lonOrigem, -180, 180) };
    const destino = {
      lat: coordenada(req.query.latDestino, -90, 90),
      lon: coordenada(req.query.lonDestino, -180, 180),
    };
    requerer(origem.lat !== null && origem.lon !== null, 422, "Informe a origem no mapa.");
    requerer(destino.lat !== null && destino.lon !== null, 422, "Informe o destino no mapa.");
    const opcoes = await buscarAlternativas(origem, destino);
    res.json({ opcoes });
  }),
);

rotasCadastros.post(
  "/rotas",
  autenticar,
  exigirPermissao("TRACKING_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const corpo = req.body ?? {};
    const origem = texto(corpo.origem);
    const destino = texto(corpo.destino);
    requerer(origem && origem.length >= 2, 422, "Informe a origem da rota.");
    requerer(destino && destino.length >= 2, 422, "Informe o destino da rota.");
    const latO = coordenada(corpo.latOrigem, -90, 90);
    const lonO = coordenada(corpo.lonOrigem, -180, 180);
    const latD = coordenada(corpo.latDestino, -90, 90);
    const lonD = coordenada(corpo.lonDestino, -180, 180);
    requerer(latO !== null && lonO !== null, 422, "Informe a latitude e a longitude da origem.");
    requerer(latD !== null && lonD !== null, 422, "Informe a latitude e a longitude do destino.");
    const distancia = numero(corpo.distanciaKm);
    requerer(distancia && distancia > 0, 422, "Informe a distância da rota em km.");

    const paradas = (Array.isArray(corpo.paradas) ? corpo.paradas : [])
      .map((p) => ({
        nome: texto(p?.nome)?.slice(0, 160) ?? null,
        lat: coordenada(p?.lat, -90, 90),
        lon: coordenada(p?.lon, -180, 180),
      }))
      .filter((p) => p.lat !== null && p.lon !== null);

    const id = await tx(async (conn) => {
      let codigo = texto(corpo.codigo)?.slice(0, 50);
      if (codigo) {
        const [[existe]] = await conn.execute(`SELECT id FROM routes WHERE company_id = ? AND code = ? LIMIT 1`, [
          empresa,
          codigo,
        ]);
        if (existe) throw new ErroHttp(409, "Já existe uma rota com este código.");
      } else {
        const [[{ total }]] = await conn.execute(`SELECT COUNT(*) AS total FROM routes WHERE company_id = ?`, [
          empresa,
        ]);
        codigo = `ROT-${String(total + 1).padStart(3, "0")}`;
      }

      const [rota] = await conn.execute(
        `INSERT INTO routes (company_id, code, origin, destination, distance_km, description, active)
         VALUES (?, ?, ?, ?, ?, ?, 1)`,
        [
          empresa,
          codigo,
          origem.slice(0, 160),
          destino.slice(0, 160),
          distancia,
          texto(corpo.descricao)?.slice(0, 255) ?? null,
        ],
      );
      const pontos = [
        { tipo: "ORIGIN", nome: origem, lat: latO, lon: lonO },
        ...paradas.map((p) => ({ tipo: "WAYPOINT", nome: p.nome, lat: p.lat, lon: p.lon })),
        { tipo: "DESTINATION", nome: destino, lat: latD, lon: lonD },
      ];
      let sequencia = 1;
      for (const p of pontos) {
        await conn.execute(
          `INSERT INTO route_waypoints (company_id, route_id, sequence_number, waypoint_type, label, latitude, longitude)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [empresa, rota.insertId, sequencia++, p.tipo, p.nome?.slice(0, 160) ?? null, p.lat, p.lon],
        );
      }
      return rota.insertId;
    });
    res.status(201).json({ id, origem, destino });
  }),
);
