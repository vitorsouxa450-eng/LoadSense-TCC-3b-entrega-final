import { Router } from "express";
import crypto from "node:crypto";
import { ErroHttp, asyncHandler, id, numero, requerer, texto } from "../util.js";
import { autenticar, exigirPermissao, registrarAuditoria } from "../auth.js";
import { exec, q, um } from "../db.js";

export const rotasDispositivos = Router();

const ESTAGIOS = ["EMPTY_TRUCK", "SEPARATED_CARGO", "LOADED_TRUCK"];
const hashChave = (chave) => crypto.createHash("sha256").update(chave).digest("hex");

function lerMetadata(bruto) {
  try {
    return bruto ? JSON.parse(bruto) : {};
  } catch {
    return {};
  }
}

async function operacaoAceitaLeituras(empresa, operacaoId) {
  const op = await um(`SELECT id, state FROM weighing_operations WHERE company_id = ? AND id = ?`, [
    empresa,
    operacaoId,
  ]);
  if (!op) throw new ErroHttp(404, "Operação não encontrada.");
  requerer(
    op.state === "DRAFT" || op.state === "IN_PROGRESS",
    422,
    "Operação concluída ou cancelada não recebe novas leituras.",
  );
  return op;
}

rotasDispositivos.post(
  "/dispositivos/:id/chave",
  autenticar,
  exigirPermissao("DEVICE_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const dispId = id(req.params.id);
    const existe = await um(
      `SELECT id, name, device_type FROM devices WHERE company_id = ? AND id = ? AND active = 1`,
      [empresa, dispId],
    );
    if (!existe) throw new ErroHttp(404, "Dispositivo não encontrado.");

    const chave = `lsd_${crypto.randomBytes(24).toString("hex")}`;
    await exec(
      `UPDATE devices SET api_key_hash = ?, updated_at = CURRENT_TIMESTAMP(3) WHERE company_id = ? AND id = ?`,
      [hashChave(chave), empresa, dispId],
    );
    await registrarAuditoria(
      empresa,
      req.usuario.id,
      "DEVICE_KEY_CREATED",
      "devices",
      dispId,
      { nome: existe.name },
      req.ip,
      req.get("user-agent"),
    );
    res.json({ dispositivoId: dispId, nome: existe.name, chave });
  }),
);

rotasDispositivos.put(
  "/dispositivos/:id/operacao-ativa",
  autenticar,
  exigirPermissao("DEVICE_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const dispId = id(req.params.id);
    const dispositivo = await um(`SELECT id, metadata FROM devices WHERE company_id = ? AND id = ? AND active = 1`, [
      empresa,
      dispId,
    ]);
    if (!dispositivo) throw new ErroHttp(404, "Dispositivo não encontrado.");

    const operacaoId = req.body?.operacaoId === null ? null : id(req.body?.operacaoId);
    if (operacaoId) await operacaoAceitaLeituras(empresa, operacaoId);

    const metadata = { ...lerMetadata(dispositivo.metadata), operacaoAtivaId: operacaoId };
    await exec(`UPDATE devices SET metadata = ?, updated_at = CURRENT_TIMESTAMP(3) WHERE company_id = ? AND id = ?`, [
      JSON.stringify(metadata),
      empresa,
      dispId,
    ]);
    res.json({ dispositivoId: dispId, operacaoAtivaId: operacaoId });
  }),
);

rotasDispositivos.post(
  "/dispositivos/leituras",
  asyncHandler(async (req, res) => {
    const chave = texto(req.get("x-device-key"));
    requerer(chave, 401, "Chave do dispositivo ausente.");
    const dispositivo = await um(
      `SELECT id, company_id, metadata FROM devices
        WHERE api_key_hash = ? AND active = 1 AND state <> 'DISABLED'`,
      [hashChave(chave)],
    );
    if (!dispositivo) throw new ErroHttp(401, "Chave do dispositivo inválida.");

    const corpo = req.body ?? {};
    const estagio = texto(corpo.etapa)?.toUpperCase();
    requerer(ESTAGIOS.includes(estagio), 422, "Etapa inválida (use EMPTY_TRUCK, SEPARATED_CARGO ou LOADED_TRUCK).");
    const pesoKg = numero(corpo.pesoKg);
    requerer(pesoKg !== null && pesoKg >= 0, 422, "Informe o peso em kg.");
    requerer(corpo.estavel === true, 422, "Só são aceitas leituras estáveis.");

    const operacaoId = lerMetadata(dispositivo.metadata).operacaoAtivaId;
    requerer(operacaoId, 409, "Nenhuma operação foi selecionada no sistema para esta balança.");
    await operacaoAceitaLeituras(dispositivo.company_id, operacaoId);

    const sequencia = await um(
      `SELECT COALESCE(MAX(sequence_number), 0) + 1 AS proxima FROM weighing_readings WHERE operation_id = ? AND stage = ?`,
      [operacaoId, estagio],
    );
    const firmware = texto(corpo.firmware);
    const insercao = await exec(
      `INSERT INTO weighing_readings
         (company_id, operation_id, stage, sequence_number, weight_kg, source, device_id, is_stable,
          checksum_valid, signal_strength_dbm, measured_at, created_by_user_id, raw_payload)
       VALUES (?, ?, ?, ?, ?, 'DEVICE', ?, 1, NULL, ?, CURRENT_TIMESTAMP(3), NULL, ?)`,
      [
        dispositivo.company_id,
        operacaoId,
        estagio,
        sequencia?.proxima ?? 1,
        pesoKg,
        dispositivo.id,
        numero(corpo.sinalDbm),
        JSON.stringify({ etapa: estagio, pesoKg, firmware: firmware ?? null }),
      ],
    );

    await exec(
      `UPDATE devices SET state = 'ONLINE', last_seen_at = CURRENT_TIMESTAMP(3)${firmware ? ", firmware_version = ?" : ""}
        WHERE company_id = ? AND id = ?`,
      firmware ? [firmware, dispositivo.company_id, dispositivo.id] : [dispositivo.company_id, dispositivo.id],
    );

    res.status(201).json({ ok: true, leituraId: insercao.insertId, operacaoId, situacao: "PENDENTE" });
  }),
);

rotasDispositivos.post(
  "/dispositivos/sinal",
  asyncHandler(async (req, res) => {
    const chave = texto(req.get("x-device-key"));
    requerer(chave, 401, "Chave do dispositivo ausente.");
    const dispositivo = await um(
      `SELECT id, company_id FROM devices
        WHERE api_key_hash = ? AND active = 1 AND state <> 'DISABLED'`,
      [hashChave(chave)],
    );
    if (!dispositivo) throw new ErroHttp(401, "Chave do dispositivo inválida.");

    const corpo = req.body ?? {};
    const firmware = texto(corpo.firmware);
    await exec(
      `UPDATE devices SET state = 'ONLINE', last_seen_at = CURRENT_TIMESTAMP(3)${firmware ? ", firmware_version = ?" : ""}
        WHERE company_id = ? AND id = ?`,
      firmware ? [firmware, dispositivo.company_id, dispositivo.id] : [dispositivo.company_id, dispositivo.id],
    );
    res.json({ ok: true, dispositivoId: dispositivo.id });
  }),
);
