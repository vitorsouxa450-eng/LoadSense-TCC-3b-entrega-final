import { Router } from "express";
import { ErroHttp, asyncHandler, texto } from "../util.js";
import { autenticar, exigirPermissao } from "../auth.js";
import { exigirRecurso } from "../planos.js";
import { q } from "../db.js";

export const rotasAuditoria = Router();
rotasAuditoria.use(autenticar);

const DATA = /^\d{4}-\d{2}-\d{2}$/;
const LIMITE_LINHAS = 10000;

rotasAuditoria.get(
  "/auditoria/tipos",
  exigirPermissao("AUDIT_VIEW"),
  exigirRecurso("auditoria"),
  asyncHandler(async (req, res) => {
    const linhas = await q(`SELECT DISTINCT action FROM audit_logs WHERE company_id = ? ORDER BY action`, [
      req.usuario.companyId,
    ]);
    res.json({ tipos: linhas.map((l) => l.action) });
  }),
);

rotasAuditoria.get(
  "/auditoria",
  exigirPermissao("AUDIT_VIEW"),
  exigirRecurso("auditoria"),
  asyncHandler(async (req, res) => {
    const tipo = texto(req.query.tipo);
    const de = texto(req.query.de);
    const ate = texto(req.query.ate);
    const formato = req.query.formato === "csv" ? "csv" : "json";
    if (de && !dataValida(de)) throw new ErroHttp(422, "Data inicial inválida.");
    if (ate && !dataValida(ate)) throw new ErroHttp(422, "Data final inválida.");
    if (de && ate && de > ate) throw new ErroHttp(422, "A data inicial é posterior à final.");

    const filtros = ["a.company_id = ?"];
    const valores = [req.usuario.companyId];
    if (tipo) {
      filtros.push("a.action = ?");
      valores.push(tipo);
    }
    if (de) {
      filtros.push("a.created_at >= ?");
      valores.push(`${de} 00:00:00`);
    }
    if (ate) {
      filtros.push("a.created_at < DATE_ADD(?, INTERVAL 1 DAY)");
      valores.push(`${ate} 00:00:00`);
    }

    const linhas = await q(
      `SELECT a.id, a.created_at, a.action, a.entity_name, a.entity_id, a.ip_address,
              a.new_values, u.full_name AS usuario, u.email AS email_usuario
         FROM audit_logs a
         LEFT JOIN users u ON u.id = a.user_id AND u.company_id = a.company_id
        WHERE ${filtros.join(" AND ")}
        ORDER BY a.created_at DESC, a.id DESC
        LIMIT ${LIMITE_LINHAS + 1}`,
      valores,
    );
    const truncado = linhas.length > LIMITE_LINHAS;
    const registros = linhas.slice(0, LIMITE_LINHAS).map((l) => ({
      id: Number(l.id),
      quando: l.created_at,
      evento: l.action,
      entidade: l.entity_name,
      entidadeId: l.entity_id,
      usuario: l.usuario ?? null,
      emailUsuario: l.email_usuario ?? null,
      ip: l.ip_address ?? null,
      detalhes: l.new_values ? safeParse(l.new_values) : null,
    }));

    if (formato === "json") {
      return res.json({ registros, truncado });
    }

    const cabecalho = ["Data/hora", "Evento", "Entidade", "Identificador", "Usuário", "E-mail", "IP", "Detalhes"];
    const corpo = registros.map((r) =>
      [
        formatarData(r.quando),
        r.evento,
        r.entidade,
        r.entidadeId,
        r.usuario,
        r.emailUsuario,
        r.ip,
        r.detalhes ? JSON.stringify(r.detalhes) : "",
      ]
        .map(celula)
        .join(";"),
    );
    const csv = "\uFEFF" + [cabecalho.join(";"), ...corpo].join("\r\n") + "\r\n";
    const nome = `auditoria-${de ?? "inicio"}-${ate ?? "hoje"}.csv`;
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${nome}"`);
    if (truncado) res.setHeader("X-Truncado", "1");
    return res.send(csv);
  }),
);

function dataValida(valor) {
  if (!DATA.test(valor)) return false;
  const d = new Date(`${valor}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === valor;
}

function safeParse(json) {
  try {
    return typeof json === "string" ? JSON.parse(json) : json;
  } catch {
    return null;
  }
}

function formatarData(valor) {
  if (!valor) return "";
  const d = valor instanceof Date ? valor : new Date(valor);
  if (Number.isNaN(d.getTime())) return String(valor);
  return d.toISOString().replace("T", " ").slice(0, 19);
}

function celula(valor) {
  if (valor === null || valor === undefined) return "";
  let s = String(valor);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return /[";\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
