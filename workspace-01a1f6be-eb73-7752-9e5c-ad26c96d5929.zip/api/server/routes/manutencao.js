import { Router } from "express";
import { asyncHandler, ErroHttp, id, numero, requerer, texto } from "../util.js";
import { autenticar, exigirPermissao } from "../auth.js";
import { exec, um } from "../db.js";
import { cifrar, decifrar, hashBusca } from "../dados-pessoais.js";

export const rotasManutencao = Router();

const ABERTAS = ["DRAFT", "IN_PROGRESS"];

async function fotoOperacao(empresa, v) {
  const motorista = v.motoristaId
    ? await um(`SELECT full_name FROM drivers WHERE company_id = ? AND id = ?`, [empresa, v.motoristaId])
    : null;
  const produto = v.produtoId
    ? await um(`SELECT name FROM cargo_products WHERE company_id = ? AND id = ?`, [empresa, v.produtoId])
    : null;
  return {
    motorista: motorista?.full_name ?? null,
    produto: produto?.name ?? null,
    observacoes: v.observacoes ?? null,
    documentoFiscal: v.documento ?? null,
    mdfe: v.mdfe ?? null,
    ciot: v.ciot ?? null,
  };
}

async function auditar(empresa, usuario, acao, entidade, entidadeId, valores, req, antes = null) {
  try {
    await exec(
      `INSERT INTO audit_logs (company_id, user_id, action, entity_name, entity_id, old_values, new_values, ip_address, user_agent)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        empresa,
        usuario,
        acao,
        entidade,
        String(entidadeId),
        antes ? JSON.stringify(antes) : null,
        JSON.stringify(valores),
        req.ip ?? null,
        req.get("user-agent")?.slice(0, 500) ?? null,
      ],
    );
  } catch {}
}

function dataIso(valor) {
  if (!(valor instanceof Date)) return valor;
  const dois = (n) => String(n).padStart(2, "0");
  return `${valor.getFullYear()}-${dois(valor.getMonth() + 1)}-${dois(valor.getDate())}`;
}

function campo(corpo, chave, atual) {
  return Object.prototype.hasOwnProperty.call(corpo, chave) ? corpo[chave] : atual;
}

function apenasDigitos(valor) {
  return valor === null || valor === undefined ? null : String(valor).replace(/\D/g, "") || null;
}

rotasManutencao.patch(
  "/motoristas/:id",
  autenticar,
  exigirPermissao("DRIVER_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const motoristaId = id(req.params.id);
    const corpo = req.body ?? {};
    const bruto = await um(`SELECT * FROM drivers WHERE company_id = ? AND id = ?`, [empresa, motoristaId]);
    if (!bruto) throw new ErroHttp(404, "Motorista não encontrado.");
    const atual = {
      ...bruto,
      document_number: decifrar(bruto.document_number),
      license_number: decifrar(bruto.license_number),
      phone: decifrar(bruto.phone),
    };

    const nome = texto(campo(corpo, "nome", atual.full_name));
    requerer(nome && nome.length >= 3, 422, "Informe o nome do motorista.");
    const cpf = apenasDigitos(campo(corpo, "cpf", atual.document_number));
    const validade = campo(corpo, "validadeCnh", dataIso(atual.license_expiration_date));
    requerer(
      !validade || /^\d{4}-\d{2}-\d{2}$/.test(String(validade).slice(0, 10)),
      422,
      "A validade da CNH deve estar no formato AAAA-MM-DD.",
    );
    const ativo = campo(corpo, "ativo", atual.active);

    if (cpf && cpf !== atual.document_number) {
      const repetido = await um(
        `SELECT id FROM drivers WHERE company_id = ? AND document_hash = ? AND active = 1 AND id <> ? LIMIT 1`,
        [empresa, hashBusca(cpf), motoristaId],
      );
      if (repetido) throw new ErroHttp(409, "Já existe um motorista com este CPF.");
    }

    await exec(
      `UPDATE drivers
          SET full_name = ?, document_number = ?, document_hash = ?, employee_code = ?, license_number = ?,
              license_category = ?, license_expiration_date = ?, phone = ?, active = ?
        WHERE company_id = ? AND id = ?`,
      [
        nome.slice(0, 140),
        cifrar(cpf ? cpf.slice(0, 20) : null),
        hashBusca(cpf ? cpf.slice(0, 20) : null),
        texto(campo(corpo, "matricula", atual.employee_code))?.slice(0, 40) ?? null,
        cifrar(texto(campo(corpo, "cnh", atual.license_number))?.slice(0, 40) ?? null),
        texto(campo(corpo, "categoriaCnh", atual.license_category))
          ?.toUpperCase()
          .slice(0, 10) ?? null,
        validade ? String(validade).slice(0, 10) : null,
        cifrar(texto(campo(corpo, "telefone", atual.phone))?.slice(0, 30) ?? null),
        ativo ? 1 : 0,
        empresa,
        motoristaId,
      ],
    );
    await auditar(empresa, req.usuario.id, "UPDATE_DRIVER", "drivers", motoristaId, { ativo: Boolean(ativo) }, req);
    res.json({ ok: true, id: motoristaId, ativo: Boolean(ativo) });
  }),
);

rotasManutencao.post(
  "/motoristas/:id/anonimizar",
  autenticar,
  exigirPermissao("DRIVER_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const motoristaId = id(req.params.id);
    const existe = await um(`SELECT id FROM drivers WHERE company_id = ? AND id = ?`, [empresa, motoristaId]);
    if (!existe) throw new ErroHttp(404, "Motorista não encontrado.");
    await exec(
      `UPDATE drivers
          SET full_name = ?, document_number = NULL, document_hash = NULL, employee_code = NULL,
              license_number = NULL, license_category = NULL, license_expiration_date = NULL,
              phone = NULL, active = 0
        WHERE company_id = ? AND id = ?`,
      [`Motorista anonimizado #${motoristaId}`, empresa, motoristaId],
    );
    await auditar(empresa, req.usuario.id, "ANONYMIZE_DRIVER", "drivers", motoristaId, { anonimizado: true }, req);
    res.json({ ok: true, id: motoristaId });
  }),
);

rotasManutencao.patch(
  "/veiculos/:id",
  autenticar,
  exigirPermissao("VEHICLE_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const veiculoId = id(req.params.id);
    const corpo = req.body ?? {};
    const atual = await um(`SELECT * FROM vehicles WHERE company_id = ? AND id = ?`, [empresa, veiculoId]);
    if (!atual) throw new ErroHttp(404, "Caminhão não encontrado.");

    const placa = String(campo(corpo, "placa", atual.plate) ?? "")
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "");
    requerer(/^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(placa), 422, "Placa inválida (use o padrão ABC1D23 ou ABC1234).");
    const tara = numero(campo(corpo, "tara", atual.registered_tare_kg));
    const limiteBruto = numero(campo(corpo, "limiteBruto", atual.gross_weight_limit_kg));
    const cargaUtil = numero(campo(corpo, "cargaUtil", atual.payload_limit_kg));
    requerer(tara === null || tara >= 0, 422, "A tara não pode ser negativa.");
    requerer(
      limiteBruto === null || tara === null || limiteBruto >= tara,
      422,
      "O limite de peso bruto não pode ser menor que a tara.",
    );
    const ativo = campo(corpo, "ativo", atual.active);

    if (placa !== atual.plate) {
      const repetida = await um(`SELECT id FROM vehicles WHERE company_id = ? AND plate = ? AND id <> ? LIMIT 1`, [
        empresa,
        placa,
        veiculoId,
      ]);
      if (repetida) throw new ErroHttp(409, "Já existe um caminhão com esta placa.");
    }

    await exec(
      `UPDATE vehicles
          SET plate = ?, fleet_code = ?, manufacturer = ?, model = ?, manufacture_year = ?, axle_count = ?,
              registered_tare_kg = ?, gross_weight_limit_kg = ?, payload_limit_kg = ?, active = ?
        WHERE company_id = ? AND id = ?`,
      [
        placa,
        texto(campo(corpo, "frota", atual.fleet_code))?.slice(0, 40) ?? null,
        texto(campo(corpo, "fabricante", atual.manufacturer))?.slice(0, 80) ?? null,
        texto(campo(corpo, "modelo", atual.model))?.slice(0, 100) ?? null,
        numero(campo(corpo, "ano", atual.manufacture_year)),
        numero(campo(corpo, "eixos", atual.axle_count)),
        tara,
        limiteBruto,
        cargaUtil,
        ativo ? 1 : 0,
        empresa,
        veiculoId,
      ],
    );
    await auditar(
      empresa,
      req.usuario.id,
      "UPDATE_VEHICLE",
      "vehicles",
      veiculoId,
      { placa, ativo: Boolean(ativo) },
      req,
    );
    res.json({ ok: true, id: veiculoId, placa, ativo: Boolean(ativo) });
  }),
);

rotasManutencao.patch(
  "/rotas/:id",
  autenticar,
  exigirPermissao("TRACKING_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const rotaId = id(req.params.id);
    const corpo = req.body ?? {};
    const atual = await um(`SELECT * FROM routes WHERE company_id = ? AND id = ?`, [empresa, rotaId]);
    if (!atual) throw new ErroHttp(404, "Rota não encontrada.");

    const origem = texto(campo(corpo, "origem", atual.origin));
    const destino = texto(campo(corpo, "destino", atual.destination));
    requerer(origem && origem.length >= 2, 422, "Informe a origem da rota.");
    requerer(destino && destino.length >= 2, 422, "Informe o destino da rota.");
    const distancia = numero(campo(corpo, "distanciaKm", atual.distance_km));
    requerer(distancia === null || distancia > 0, 422, "A distância deve ser maior que zero.");
    const ativo = campo(corpo, "ativo", atual.active);

    await exec(
      `UPDATE routes SET origin = ?, destination = ?, distance_km = ?, description = ?, code = ?, active = ?
        WHERE company_id = ? AND id = ?`,
      [
        origem.slice(0, 160),
        destino.slice(0, 160),
        distancia,
        texto(campo(corpo, "descricao", atual.description))?.slice(0, 255) ?? null,
        texto(campo(corpo, "codigo", atual.code))?.slice(0, 50) ?? null,
        ativo ? 1 : 0,
        empresa,
        rotaId,
      ],
    );
    await auditar(empresa, req.usuario.id, "UPDATE_ROUTE", "routes", rotaId, { ativo: Boolean(ativo) }, req);
    res.json({ ok: true, id: rotaId, ativo: Boolean(ativo) });
  }),
);

rotasManutencao.patch(
  "/operacoes/:id/manutencao",
  autenticar,
  exigirPermissao("OPERATION_UPDATE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const operacaoId = id(req.params.id);
    const corpo = req.body ?? {};
    const atual = await um(
      `SELECT id, state, driver_id, observations, cargo_product_id, invoice_number, mdfe_number, ciot_number FROM weighing_operations WHERE company_id = ? AND id = ?`,
      [empresa, operacaoId],
    );
    if (!atual) throw new ErroHttp(404, "Operação não encontrada.");
    requerer(ABERTAS.includes(atual.state), 409, "Operação concluída ou cancelada não pode ser alterada.");

    let motoristaId = atual.driver_id;
    if (Object.prototype.hasOwnProperty.call(corpo, "motoristaId")) {
      motoristaId = corpo.motoristaId === null ? null : id(corpo.motoristaId);
    } else if (texto(corpo.motorista)) {
      const d = await um(`SELECT id FROM drivers WHERE company_id = ? AND full_name = ? AND active = 1 LIMIT 1`, [
        empresa,
        texto(corpo.motorista),
      ]);
      requerer(d, 422, `Motorista "${texto(corpo.motorista)}" não encontrado ou inativo.`);
      motoristaId = d.id;
    }
    if (motoristaId) {
      const d = await um(`SELECT id FROM drivers WHERE company_id = ? AND id = ? AND active = 1`, [
        empresa,
        motoristaId,
      ]);
      requerer(d, 422, "Motorista não encontrado ou inativo.");
    }

    let produtoId = atual.cargo_product_id;
    if (Object.prototype.hasOwnProperty.call(corpo, "produtoId")) {
      produtoId = corpo.produtoId === null ? null : id(corpo.produtoId);
      if (produtoId) {
        const p = await um(`SELECT id FROM cargo_products WHERE company_id = ? AND id = ? AND active = 1`, [
          empresa,
          produtoId,
        ]);
        requerer(p, 422, "Produto não encontrado ou inativo.");
      }
    }

    const observacoes = campo(corpo, "observacoes", atual.observations);
    const documento = campo(corpo, "documentoFiscal", atual.invoice_number);
    const mdfe = campo(corpo, "mdfe", atual.mdfe_number);
    const ciot = campo(corpo, "ciot", atual.ciot_number);
    await exec(
      `UPDATE weighing_operations SET driver_id = ?, cargo_product_id = ?, observations = ?, invoice_number = ?, mdfe_number = ?, ciot_number = ?
        WHERE company_id = ? AND id = ?`,
      [
        motoristaId,
        produtoId,
        texto(observacoes)?.slice(0, 500) ?? null,
        texto(documento)?.slice(0, 80) ?? null,
        texto(mdfe)?.slice(0, 80) ?? null,
        texto(ciot)?.slice(0, 80) ?? null,
        empresa,
        operacaoId,
      ],
    );
    const depois = await fotoOperacao(empresa, { motoristaId, produtoId, observacoes, documento, mdfe, ciot });
    const antes = await fotoOperacao(empresa, {
      motoristaId: atual.driver_id,
      produtoId: atual.cargo_product_id,
      observacoes: atual.observations,
      documento: atual.invoice_number,
      mdfe: atual.mdfe_number,
      ciot: atual.ciot_number,
    });
    await auditar(empresa, req.usuario.id, "UPDATE_OPERATION", "weighing_operations", operacaoId, depois, req, antes);
    res.json({ ok: true, id: operacaoId, motoristaId, produtoId });
  }),
);
