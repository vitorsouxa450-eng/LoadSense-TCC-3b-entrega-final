import { Router } from "express";
import { ErroHttp, asyncHandler, id, requerer } from "../util.js";
import { autenticar, registrarAuditoria } from "../auth.js";
import { exec, q } from "../db.js";

export const rotasSeguranca = Router();
rotasSeguranca.use(autenticar);

function descreverAgente(agente) {
  if (!agente) return "Dispositivo não identificado";
  const sistema = /Android/i.test(agente)
    ? "Android"
    : /iPhone|iPad/i.test(agente)
      ? "iPhone/iPad"
      : /Windows/i.test(agente)
        ? "Windows"
        : /Mac OS/i.test(agente)
          ? "macOS"
          : /Linux/i.test(agente)
            ? "Linux"
            : "Outro sistema";
  const navegador = /Edg\//.test(agente)
    ? "Edge"
    : /Firefox\//.test(agente)
      ? "Firefox"
      : /Chrome\//.test(agente)
        ? "Chrome"
        : /Safari\//.test(agente)
          ? "Safari"
          : "Navegador";
  return `${navegador} · ${sistema}`;
}

rotasSeguranca.get(
  "/seguranca/sessoes",
  asyncHandler(async (req, res) => {
    const linhas = await q(
      `SELECT id, user_agent, issued_at, last_used_at
         FROM auth_sessions
        WHERE company_id = ? AND user_id = ? AND revoked_at IS NULL AND expires_at > CURRENT_TIMESTAMP(3)
        ORDER BY COALESCE(last_used_at, issued_at) DESC`,
      [req.usuario.companyId, req.usuario.id],
    );
    res.json({
      sessoes: linhas.map((s) => ({
        id: Number(s.id),
        descricao: descreverAgente(s.user_agent),
        criadaEm: s.issued_at,
        ultimoUso: s.last_used_at,
        atual: Number(s.id) === Number(req.usuario.sessaoId),
      })),
    });
  }),
);

rotasSeguranca.post(
  "/seguranca/sessoes/:id/encerrar",
  asyncHandler(async (req, res) => {
    const sessaoId = id(req.params.id);
    requerer(sessaoId, 400, "Identificador inválido.");

    const resultado = await exec(
      `UPDATE auth_sessions
          SET revoked_at = CURRENT_TIMESTAMP(3), revoke_reason = 'USER_REVOKED'
        WHERE company_id = ? AND user_id = ? AND id = ? AND revoked_at IS NULL`,
      [req.usuario.companyId, req.usuario.id, sessaoId],
    );
    if (!resultado.affectedRows) throw new ErroHttp(404, "Sessão não encontrada ou já encerrada.");

    await registrarAuditoria(
      req.usuario.companyId,
      req.usuario.id,
      "SESSION_REVOKED",
      "auth_sessions",
      sessaoId,
      { motivo: "USER_REVOKED" },
      req.ip,
      req.get("user-agent"),
    );

    res.json({ ok: true, atual: sessaoId === Number(req.usuario.sessaoId) });
  }),
);
