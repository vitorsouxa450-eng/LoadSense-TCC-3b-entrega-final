import crypto from "node:crypto";
import { Router } from "express";
import { ErroHttp, asyncHandler, dataMysql, id, numero, paginacao, periodo, requerer, texto } from "../util.js";
import { autenticar, exigirPermissao } from "../auth.js";
import { limiteUsuariosDaEmpresa, planoEfetivo, resumoDoPlano } from "../planos.js";
import { call, exec, q, um } from "../db.js";
import { ROTULOS, mapearAlerta } from "../mapeadores.js";
import { ACAO_MAXIMA, ACAO_MINIMA, CODIGOS_MOTIVO, MOTIVO_EM_LOTE } from "../alertas-resolucao.js";

export const rotasGestao = Router();
rotasGestao.use(autenticar);

const SELECAO_ALERTA = `
  SELECT a.*, o.operation_code, v.plate AS vehicle_plate, d.full_name AS driver_name,
         rt.origin, rt.destination,
         ack.full_name AS acknowledged_by_user_name, rsv.full_name AS resolved_by_user_name
    FROM alerts a
    LEFT JOIN weighing_operations o ON o.company_id = a.company_id AND o.id = a.operation_id
    LEFT JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
    LEFT JOIN drivers d ON d.company_id = o.company_id AND d.id = o.driver_id
    LEFT JOIN routes rt ON rt.company_id = o.company_id AND rt.id = o.route_id
    LEFT JOIN users ack ON ack.company_id = a.company_id AND ack.id = a.acknowledged_by_user_id
    LEFT JOIN users rsv ON rsv.company_id = a.company_id AND rsv.id = a.resolved_by_user_id`;

rotasGestao.get(
  "/painel",
  exigirPermissao("DASHBOARD_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const { inicio, fim } = periodo(req.query);
    const dias = Math.min(90, Math.max(7, numero(req.query.dias, 30)));

    const kpis = await um(
      `SELECT
         COUNT(*) AS operacoes,
         SUM(o.state = 'COMPLETED') AS concluidas,
         SUM(o.state = 'IN_PROGRESS') AS em_andamento,
         SUM(o.state = 'DRAFT') AS rascunhos,
         SUM(o.state = 'CANCELLED') AS canceladas,
         SUM(o.status = 'NORMAL') AS normais,
         SUM(o.status = 'ATTENTION') AS atencao,
         SUM(o.status = 'CRITICAL') AS criticas,
         ROUND(SUM(COALESCE(o.actual_cargo_weight_kg, 0)) / 1000, 2) AS toneladas,
         ROUND(AVG(NULLIF(o.actual_cargo_weight_kg, 0)), 1) AS media_carga_kg,
         ROUND(AVG(ABS(o.difference_percent)), 4) AS desvio_medio_pct,
         ROUND(AVG(COALESCE(o.loaded_truck_weight_kg, 0)) / 1000, 2) AS media_bruto_t
       FROM weighing_operations o
      WHERE o.company_id = ? AND COALESCE(o.completed_at, o.started_at) BETWEEN ? AND ?`,
      [empresa, inicio, fim],
    );

    const rastreio = await um(
      `SELECT
         SUM(ots.tracking_state = 'IN_TRANSIT') AS em_transito,
         SUM(ots.tracking_state = 'STOPPED') AS parados,
         SUM(ots.tracking_state = 'SIGNAL_LOST') AS sem_sinal,
         SUM(ots.tracking_state = 'ARRIVED') AS chegaram,
         SUM(ots.tracking_state = 'NOT_STARTED') AS nao_iniciados,
         ROUND(AVG(ots.progress_percent), 1) AS progresso_medio
        FROM operation_tracking_status ots WHERE ots.company_id = ?`,
      [empresa],
    );

    const alertas = await um(
      `SELECT
         SUM(state IN ('OPEN','ACKNOWLEDGED')) AS abertos,
         SUM(state = 'OPEN' AND severity = 'CRITICAL') AS criticos_abertos,
         SUM(state IN ('OPEN','ACKNOWLEDGED') AND alert_context = 'WEIGHING') AS de_pesagem,
         SUM(state IN ('OPEN','ACKNOWLEDGED') AND alert_context = 'TRACKING') AS de_rastreio,
         SUM(created_at BETWEEN ? AND ?) AS criados_periodo
        FROM alerts WHERE company_id = ?`,
      [inicio, fim, empresa],
    );

    const serie = await q(
      `SELECT reference_date AS dia, total_operations AS operacoes, completed_operations AS concluidas,
              normal_operations AS normais, attention_operations AS atencao, critical_operations AS criticas,
              total_cargo_weight_kg AS carga_kg, average_absolute_difference_percent AS desvio_pct
         FROM vw_dashboard_daily
        WHERE company_id = ? AND reference_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
        ORDER BY reference_date`,
      [empresa, dias],
    );

    const porTipoCarga = await q(
      `SELECT cp.name AS produto, COUNT(*) AS operacoes, ROUND(SUM(o.actual_cargo_weight_kg) / 1000, 2) AS toneladas
         FROM weighing_operations o
         JOIN cargo_products cp ON cp.company_id = o.company_id AND cp.id = o.cargo_product_id
        WHERE o.company_id = ? AND COALESCE(o.completed_at, o.started_at) BETWEEN ? AND ?
        GROUP BY cp.name ORDER BY toneladas DESC LIMIT 8`,
      [empresa, inicio, fim],
    );

    const topVeiculos = await q(
      `SELECT v.plate, COUNT(*) AS viagens, ROUND(SUM(COALESCE(o.actual_cargo_weight_kg,0)) / 1000, 2) AS toneladas
         FROM weighing_operations o
         JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
        WHERE o.company_id = ? AND COALESCE(o.completed_at, o.started_at) BETWEEN ? AND ?
        GROUP BY v.plate ORDER BY toneladas DESC LIMIT 5`,
      [empresa, inicio, fim],
    );

    const abertos = await q(
      `${SELECAO_ALERTA} WHERE a.company_id = ? AND a.state IN ('OPEN','ACKNOWLEDGED')
        ORDER BY FIELD(a.severity,'CRITICAL','ATTENTION'), a.created_at DESC LIMIT 10`,
      [empresa],
    );

    const frota = await um(
      `SELECT (SELECT COUNT(*) FROM vehicles WHERE company_id = ? AND active = 1) AS veiculos,
              (SELECT COUNT(*) FROM devices WHERE company_id = ? AND active = 1 AND state = 'ONLINE') AS dispositivos_online,
              (SELECT COUNT(*) FROM devices WHERE company_id = ? AND active = 1) AS dispositivos`,
      [empresa, empresa, empresa],
    );

    res.json({
      periodo: { inicio, fim, dias },
      kpis: {
        operacoes: kpis?.operacoes ?? 0,
        concluidas: kpis?.concluidas ?? 0,
        emAndamento: (kpis?.em_andamento ?? 0) + (kpis?.rascunhos ?? 0),
        canceladas: kpis?.canceladas ?? 0,
        normais: kpis?.normais ?? 0,
        atencao: kpis?.atencao ?? 0,
        criticas: kpis?.criticas ?? 0,
        toneladas: kpis?.toneladas ?? 0,
        mediaCargaKg: kpis?.media_carga_kg ?? 0,
        mediaBrutoT: kpis?.media_bruto_t ?? 0,
        desvioMedioPct: kpis?.desvio_medio_pct ?? 0,
        eficienciaPct: kpis?.operacoes ? Number((((kpis.normais ?? 0) / kpis.operacoes) * 100).toFixed(1)) : 0,
      },
      rastreio,
      alertas,
      serie,
      porTipoCarga,
      topVeiculos,
      frota,
      alertasAbertos: abertos.map(mapearAlerta),
      rotulos: ROTULOS,
    });
  }),
);

rotasGestao.get(
  "/alertas",
  exigirPermissao("ALERT_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const { pagina, limite, offset } = paginacao(req.query);
    const { inicio, fim } = periodo(req.query);

    const condicoes = ["a.company_id = ?", "(a.created_at BETWEEN ? AND ? OR a.state IN ('OPEN','ACKNOWLEDGED'))"];
    const params = [empresa, inicio, fim];

    const situacoes = texto(req.query.situacao)
      ?.toUpperCase()
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (situacoes?.length) {
      condicoes.push(`a.state IN (${situacoes.map(() => "?").join(",")})`);
      params.push(...situacoes);
    }
    const contextos = texto(req.query.contexto)
      ?.toUpperCase()
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (contextos?.length) {
      condicoes.push(`a.alert_context IN (${contextos.map(() => "?").join(",")})`);
      params.push(...contextos);
    }
    const niveis = texto(req.query.nivel)
      ?.toUpperCase()
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (niveis?.length) {
      condicoes.push(`a.severity IN (${niveis.map(() => "?").join(",")})`);
      params.push(...niveis);
    }
    const busca = texto(req.query.busca);
    if (busca) {
      condicoes.push("(o.operation_code LIKE ? OR v.plate LIKE ? OR a.title LIKE ?)");
      params.push(`%${busca}%`, `%${busca}%`, `%${busca}%`);
    }
    if (id(req.query.operacaoId)) {
      condicoes.push("a.operation_id = ?");
      params.push(id(req.query.operacaoId));
    }

    const onde = condicoes.join(" AND ");
    const linhas = await q(`${SELECAO_ALERTA} WHERE ${onde} ORDER BY a.created_at DESC LIMIT ? OFFSET ?`, [
      ...params,
      limite,
      offset,
    ]);
    const total = await um(
      `SELECT COUNT(*) AS total, SUM(a.state IN ('OPEN','ACKNOWLEDGED')) AS abertos,
              SUM(a.state = 'OPEN' AND a.severity = 'CRITICAL') AS criticos
         FROM alerts a
         LEFT JOIN weighing_operations o ON o.company_id = a.company_id AND o.id = a.operation_id
         LEFT JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
        WHERE ${onde}`,
      params,
    );

    const geral = await um(
      `SELECT SUM(state IN ('OPEN','ACKNOWLEDGED')) AS abertos, SUM(state = 'OPEN' AND severity = 'CRITICAL') AS criticos
         FROM alerts WHERE company_id = ?`,
      [empresa],
    );
    res.json({
      alertas: linhas.map(mapearAlerta),
      pagina,
      limite,
      total: total?.total ?? 0,
      abertos: total?.abertos ?? 0,
      criticos: total?.criticos ?? 0,
      abertosGeral: geral?.abertos ?? 0,
      criticosGeral: geral?.criticos ?? 0,
    });
  }),
);

rotasGestao.get(
  "/alertas/:id",
  exigirPermissao("ALERT_VIEW"),
  asyncHandler(async (req, res) => {
    const linha = await um(`${SELECAO_ALERTA} WHERE a.company_id = ? AND a.id = ?`, [
      req.usuario.companyId,
      id(req.params.id),
    ]);
    if (!linha) throw new ErroHttp(404, "Alerta não encontrado.");
    const eventos = linha.operation_id
      ? await q(
          `SELECT event_type, event_data, created_at FROM operation_events
            WHERE company_id = ? AND operation_id = ? ORDER BY created_at DESC LIMIT 30`,
          [req.usuario.companyId, linha.operation_id],
        )
      : [];
    res.json({ ...mapearAlerta(linha), historico: eventos });
  }),
);

rotasGestao.post(
  "/alertas/:id/reconhecer",
  exigirPermissao("ALERT_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const alertaId = id(req.params.id);
    const alerta = await um(`SELECT id, state FROM alerts WHERE company_id = ? AND id = ?`, [empresa, alertaId]);
    if (!alerta) throw new ErroHttp(404, "Alerta não encontrado.");
    requerer(alerta.state !== "RESOLVED", 422, "Alerta já resolvido.");

    await exec(
      `UPDATE alerts SET state = 'ACKNOWLEDGED', acknowledged_by_user_id = ?, acknowledged_at = CURRENT_TIMESTAMP(3)
        WHERE company_id = ? AND id = ?`,
      [req.usuario.id, empresa, alertaId],
    );
    const linha = await um(`${SELECAO_ALERTA} WHERE a.company_id = ? AND a.id = ?`, [empresa, alertaId]);
    res.json(mapearAlerta(linha));
  }),
);

rotasGestao.post(
  "/alertas/:id/resolver",
  exigirPermissao("ALERT_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const alertaId = id(req.params.id);
    const motivo = texto(req.body?.motivo);
    const acao = (texto(req.body?.acao) ?? "").trim();
    requerer(CODIGOS_MOTIVO.includes(motivo), 422, "Escolha o motivo da resolução.");
    requerer(
      acao.length >= ACAO_MINIMA,
      422,
      `Descreva como o alerta foi resolvido (mínimo de ${ACAO_MINIMA} caracteres).`,
    );
    const alerta = await um(`SELECT id, state FROM alerts WHERE company_id = ? AND id = ?`, [empresa, alertaId]);
    if (!alerta) throw new ErroHttp(404, "Alerta não encontrado.");
    requerer(alerta.state !== "RESOLVED", 422, "Alerta já resolvido.");

    await exec(
      `UPDATE alerts
          SET state = 'RESOLVED', resolved_by_user_id = ?, resolved_at = CURRENT_TIMESTAMP(3),
              resolution_reason = ?, resolution_notes = ?
        WHERE company_id = ? AND id = ?`,
      [req.usuario.id, motivo, acao.slice(0, ACAO_MAXIMA), empresa, alertaId],
    );
    const linha = await um(`${SELECAO_ALERTA} WHERE a.company_id = ? AND a.id = ?`, [empresa, alertaId]);
    res.json(mapearAlerta(linha));
  }),
);

rotasGestao.post(
  "/alertas/:id/reabrir",
  exigirPermissao("ALERT_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const alertaId = id(req.params.id);
    const alerta = await um(`SELECT id, state FROM alerts WHERE company_id = ? AND id = ?`, [empresa, alertaId]);
    if (!alerta) throw new ErroHttp(404, "Alerta não encontrado.");
    requerer(alerta.state !== "OPEN", 422, "Alerta já está aberto.");

    await exec(
      `UPDATE alerts
          SET state = 'OPEN',
              acknowledged_by_user_id = NULL, acknowledged_at = NULL,
              resolved_by_user_id = NULL, resolved_at = NULL, resolution_reason = NULL, resolution_notes = NULL
        WHERE company_id = ? AND id = ?`,
      [empresa, alertaId],
    );
    const linha = await um(`${SELECAO_ALERTA} WHERE a.company_id = ? AND a.id = ?`, [empresa, alertaId]);
    res.json(mapearAlerta(linha));
  }),
);

rotasGestao.post(
  "/alertas/resolver-todos",
  exigirPermissao("ALERT_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const res1 = await exec(
      `UPDATE alerts SET state = 'RESOLVED', resolved_by_user_id = ?, resolved_at = CURRENT_TIMESTAMP(3),
              resolution_reason = '${MOTIVO_EM_LOTE}',
              resolution_notes = COALESCE(resolution_notes, 'Resolvido em lote pelo aplicativo.')
        WHERE company_id = ? AND state IN ('OPEN','ACKNOWLEDGED')`,
      [req.usuario.id, empresa],
    );
    res.json({ ok: true, resolvidos: res1.affectedRows ?? 0 });
  }),
);

rotasGestao.get(
  "/relatorios",
  exigirPermissao("REPORT_GENERATE", "DASHBOARD_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const linhas = await q(
      `SELECT g.id, g.report_type, g.period_start, g.period_end, g.file_format, g.generated_at,
              g.summary_json, g.recommendations, u.full_name AS gerado_por
         FROM generated_reports g
         LEFT JOIN users u ON u.company_id = g.company_id AND u.id = g.generated_by_user_id
        WHERE g.company_id = ? ORDER BY g.generated_at DESC LIMIT 100`,
      [empresa],
    );
    res.json({
      relatorios: linhas.map((l) => ({
        id: l.id,
        tipo: l.report_type,
        inicio: l.period_start,
        fim: l.period_end,
        formato: l.file_format,
        geradoEm: l.generated_at,
        geradoPor: l.gerado_por,
        resumo: l.summary_json,
        recomendacoes: l.recommendations,
      })),
    });
  }),
);

async function resumoDoPeriodo(empresa, inicio, fim) {
  const kpis = await um(
    `SELECT COUNT(*) AS operacoes,
            SUM(o.state = 'COMPLETED') AS concluidas,
            SUM(o.status = 'NORMAL') AS normais,
            SUM(o.status = 'ATTENTION') AS atencao,
            SUM(o.status = 'CRITICAL') AS criticas,
            ROUND(SUM(COALESCE(o.actual_cargo_weight_kg,0)) / 1000, 2) AS toneladas,
            ROUND(AVG(NULLIF(o.actual_cargo_weight_kg,0)), 1) AS media_carga_kg,
            ROUND(AVG(ABS(o.difference_percent)), 4) AS desvio_medio_pct,
            SUM(COALESCE(o.actual_cargo_weight_kg,0) > COALESCE(o.payload_limit_snapshot_kg, 1e18)) AS acima_capacidade
       FROM weighing_operations o
      WHERE o.company_id = ? AND COALESCE(o.completed_at, o.started_at) BETWEEN ? AND ?`,
    [empresa, inicio, fim],
  );
  const alertas = await um(
    `SELECT COUNT(*) AS total, SUM(severity = 'CRITICAL') AS criticos, SUM(state = 'RESOLVED') AS resolvidos
       FROM alerts WHERE company_id = ? AND created_at BETWEEN ? AND ?`,
    [empresa, inicio, fim],
  );
  const pesagens = await um(
    `SELECT COUNT(*) AS leituras, SUM(r.source = 'MANUAL') AS manuais,
            SUM(r.source = 'DEVICE') AS automaticas
       FROM weighing_readings r
       JOIN weighing_operations o ON o.company_id = r.company_id AND o.id = r.operation_id
      WHERE r.company_id = ? AND COALESCE(o.completed_at, o.started_at) BETWEEN ? AND ?`,
    [empresa, inicio, fim],
  );
  const porProduto = await q(
    `SELECT cp.name AS produto, COUNT(*) AS operacoes, ROUND(SUM(COALESCE(o.actual_cargo_weight_kg,0))/1000, 2) AS toneladas,
            ROUND(AVG(ABS(o.difference_percent)), 4) AS desvio_medio_pct
       FROM weighing_operations o
       JOIN cargo_products cp ON cp.company_id = o.company_id AND cp.id = o.cargo_product_id
      WHERE o.company_id = ? AND COALESCE(o.completed_at, o.started_at) BETWEEN ? AND ?
      GROUP BY cp.name ORDER BY toneladas DESC`,
    [empresa, inicio, fim],
  );
  const porDia = await q(
    `SELECT reference_date AS dia, total_operations AS operacoes, total_cargo_weight_kg AS carga_kg,
            critical_operations AS criticas, average_absolute_difference_percent AS desvio_pct
       FROM vw_dashboard_daily
      WHERE company_id = ? AND reference_date BETWEEN DATE(?) AND DATE(?) ORDER BY reference_date`,
    [empresa, inicio, fim],
  );

  return {
    operacoes: kpis?.operacoes ?? 0,
    concluidas: kpis?.concluidas ?? 0,
    normais: kpis?.normais ?? 0,
    atencao: kpis?.atencao ?? 0,
    criticas: kpis?.criticas ?? 0,
    toneladas: kpis?.toneladas ?? 0,
    mediaCargaKg: kpis?.media_carga_kg ?? 0,
    desvioMedioPct: kpis?.desvio_medio_pct ?? 0,
    acimaCapacidade: kpis?.acima_capacidade ?? 0,
    eficienciaPct: kpis?.operacoes ? Number((((kpis.normais ?? 0) / kpis.operacoes) * 100).toFixed(1)) : 0,
    alertas: alertas ?? {},
    pesagens: pesagens ?? {},
    porProduto,
    porDia,
  };
}

rotasGestao.get(
  "/relatorios/resumo",
  exigirPermissao("REPORT_GENERATE", "DASHBOARD_VIEW"),
  asyncHandler(async (req, res) => {
    const { inicio, fim } = periodo(req.query);
    res.json({ periodo: { inicio, fim }, resumo: await resumoDoPeriodo(req.usuario.companyId, inicio, fim) });
  }),
);

rotasGestao.post(
  "/relatorios",
  exigirPermissao("REPORT_GENERATE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const inicio = dataMysql(req.body?.inicio);
    const fim = dataMysql(req.body?.fim);
    requerer(inicio && fim, 422, "Informe o período (início e fim).");

    const TIPOS = {
      DIARIO: "DAILY",
      DIÁRIO: "DAILY",
      DAILY: "DAILY",
      SEMANAL: "WEEKLY",
      WEEKLY: "WEEKLY",
      MENSAL: "MONTHLY",
      MONTHLY: "MONTHLY",
      BIMESTRAL: "BIMONTHLY",
      BIMONTHLY: "BIMONTHLY",
      TRIMESTRAL: "QUARTERLY",
      QUARTERLY: "QUARTERLY",
      PERSONALIZADO: "CUSTOM",
      CUSTOM: "CUSTOM",
    };
    const tipoBruto = (texto(req.body?.tipo, "MENSAL") ?? "").toUpperCase();
    const tipo = TIPOS[tipoBruto];
    requerer(
      tipo,
      422,
      "Tipo de relatório inválido (diário, semanal, mensal, bimestral, trimestral ou personalizado).",
    );
    const formato = (texto(req.body?.formato, "PDF") ?? "").toUpperCase();
    requerer(["PDF", "CSV", "XLSX"].includes(formato), 422, "Formato inválido (PDF, CSV ou XLSX).");

    const resumo = await resumoDoPeriodo(empresa, inicio, fim);
    const recomendacoes = [];
    if (resumo.criticas > 0)
      recomendacoes.push(
        `${resumo.criticas} operação(ões) com divergência crítica no período — revisar romaneio e conferência de carga.`,
      );
    if ((resumo.alertas?.criticos ?? 0) > 0)
      recomendacoes.push(
        `${resumo.alertas.criticos} alerta(s) crítico(s) registrados — verificar causas recorrentes de sobrecarga.`,
      );
    if ((resumo.pesagens?.manuais ?? 0) > 0)
      recomendacoes.push(
        `${resumo.pesagens.manuais} leitura(s) manual(is) — avaliar estabilidade da balança e treinamento.`,
      );
    if (resumo.desvioMedioPct > Number(process.env.LS_DESVIO_ALVO ?? 1.5))
      recomendacoes.push(`Desvio médio de ${resumo.desvioMedioPct}% acima da tolerância padrão de 1,5%.`);
    if (!recomendacoes.length) recomendacoes.push("Operação dentro dos padrões de tolerância no período analisado.");

    const res1 = await exec(
      `INSERT INTO generated_reports
         (company_id, report_type, period_start, period_end, generated_by_user_id, file_format, file_location, filters_json, summary_json, recommendations)
       VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?, ?)`,
      [
        empresa,
        tipo,
        String(inicio).slice(0, 10),
        String(fim).slice(0, 10),
        req.usuario.id,
        formato,
        JSON.stringify({ inicio, fim, tipo }),
        JSON.stringify(resumo),
        recomendacoes.join(" "),
      ],
    );

    await exec(
      `INSERT INTO audit_logs (company_id, user_id, action, entity_name, entity_id, new_values)
                VALUES (?, ?, 'GENERATE_REPORT', 'generated_reports', ?, ?)`,
      [empresa, req.usuario.id, String(res1.insertId), JSON.stringify({ tipo, inicio, fim, formato })],
    );

    res.status(201).json({ id: res1.insertId, tipo, inicio, fim, formato, resumo, recomendacoes });
  }),
);

rotasGestao.get(
  "/relatorios/:id",
  exigirPermissao("REPORT_GENERATE", "DASHBOARD_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const linha = await um(
      `SELECT g.*, u.full_name AS gerado_por FROM generated_reports g
         LEFT JOIN users u ON u.company_id = g.company_id AND u.id = g.generated_by_user_id
        WHERE g.company_id = ? AND g.id = ?`,
      [empresa, id(req.params.id)],
    );
    if (!linha) throw new ErroHttp(404, "Relatório não encontrado.");
    res.json({
      id: linha.id,
      tipo: linha.report_type,
      inicio: linha.period_start,
      fim: linha.period_end,
      formato: linha.file_format,
      geradoEm: linha.generated_at,
      geradoPor: linha.gerado_por,
      resumo: linha.summary_json,
      recomendacoes: linha.recommendations,
    });
  }),
);

rotasGestao.get(
  "/relatorios/:id/exportar.csv",
  exigirPermissao("REPORT_GENERATE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const linha = await um(`SELECT * FROM generated_reports WHERE company_id = ? AND id = ?`, [
      empresa,
      id(req.params.id),
    ]);
    if (!linha) throw new ErroHttp(404, "Relatório não encontrado.");

    const operacoes = await q(
      `SELECT o.operation_code, o.state, o.status, o.started_at, o.completed_at, v.plate, d.full_name AS motorista,
              cp.name AS produto, rt.origin, rt.destination, o.declared_cargo_weight_kg, o.actual_cargo_weight_kg,
              o.difference_kg, o.difference_percent, o.loaded_truck_weight_kg, o.gross_limit_snapshot_kg
         FROM weighing_operations o
         JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
         LEFT JOIN drivers d ON d.company_id = o.company_id AND d.id = o.driver_id
         LEFT JOIN cargo_products cp ON cp.company_id = o.company_id AND cp.id = o.cargo_product_id
         LEFT JOIN routes rt ON rt.company_id = o.company_id AND rt.id = o.route_id
        WHERE o.company_id = ? AND COALESCE(o.completed_at, o.started_at) BETWEEN ? AND ?
        ORDER BY o.started_at`,
      [empresa, linha.period_start, linha.period_end],
    );

    const cabecalho = [
      "operacao",
      "estado",
      "status",
      "inicio",
      "conclusao",
      "placa",
      "motorista",
      "produto",
      "origem",
      "destino",
      "carga_declarada_kg",
      "carga_aferida_kg",
      "diferenca_kg",
      "diferenca_pct",
      "bruto_aferido_kg",
      "limite_bruto_kg",
    ];
    const linhas = operacoes.map((o) =>
      [
        o.operation_code,
        o.state,
        o.status,
        o.started_at?.toISOString?.() ?? o.started_at,
        o.completed_at?.toISOString?.() ?? "",
        o.plate,
        o.motorista ?? "",
        o.produto ?? "",
        o.origin ?? "",
        o.destination ?? "",
        o.declared_cargo_weight_kg ?? "",
        o.actual_cargo_weight_kg ?? "",
        o.difference_kg ?? "",
        o.difference_percent ?? "",
        o.loaded_truck_weight_kg ?? "",
        o.gross_limit_snapshot_kg ?? "",
      ]
        .map((c) => `"${String(c).replace(/"/g, '""')}"`)
        .join(";"),
    );

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="loadsense-relatorio-${linha.id}.csv"`);
    res.send(["\uFEFF" + cabecalho.join(";"), ...linhas].join("\n"));
  }),
);

rotasGestao.get(
  "/configuracoes",
  asyncHandler(async (req, res) => {
    const linha = await um(`SELECT * FROM company_settings WHERE company_id = ?`, [req.usuario.companyId]);
    res.json({ configuracoes: linha });
  }),
);

rotasGestao.patch(
  "/configuracoes",
  exigirPermissao("SETTINGS_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const atual = await um(`SELECT * FROM company_settings WHERE company_id = ?`, [empresa]);
    if (!atual) throw new ErroHttp(404, "Configurações não encontradas para esta empresa.");

    const camposNumericos = [
      "tolerance_percent",
      "critical_limit_percent",
      "tare_tolerance_percent",
      "reading_stability_tolerance_kg",
      "stop_speed_threshold_kmh",
    ];
    const camposInteiros = [
      "minimum_stable_readings",
      "max_reading_age_seconds",
      "unplanned_stop_alert_minutes",
      "delivery_delay_alert_minutes",
      "signal_loss_alert_minutes",
      "route_deviation_tolerance_meters",
    ];
    const camposBooleanos = [
      "allow_manual_readings",
      "require_manual_reason",
      "require_rfid",
      "automatic_sheet_refresh",
      "critical_alert_notifications",
      "automatic_email_reports",
      "tracking_alerts_enabled",
      "route_deviation_alerts_enabled",
    ];

    const sets = [];
    const valores = [];
    for (const campo of [...camposNumericos, ...camposInteiros, ...camposBooleanos]) {
      if (req.body?.[campo] === undefined) continue;
      let valor;
      if (camposBooleanos.includes(campo)) valor = req.body[campo] ? 1 : 0;
      else valor = numero(req.body[campo]);
      requerer(valor !== null, 422, `Valor inválido para ${campo}.`);
      sets.push(`${campo} = ?`);
      valores.push(valor);
    }
    if (atual.default_weight_unit && req.body?.default_weight_unit) {
      const unidade = String(req.body.default_weight_unit).toUpperCase();
      requerer(["KG", "TON"].includes(unidade), 422, "Unidade padrão inválida.");
      sets.push("default_weight_unit = ?");
      valores.push(unidade);
    }
    requerer(sets.length, 422, "Nenhum campo válido informado.");

    sets.push("updated_by_user_id = ?");
    valores.push(req.usuario.id);
    await exec(`UPDATE company_settings SET ${sets.join(", ")} WHERE company_id = ?`, [...valores, empresa]);

    await exec(
      `INSERT INTO audit_logs (company_id, user_id, action, entity_name, entity_id, new_values)
                VALUES (?, ?, 'UPDATE_SETTINGS', 'company_settings', ?, ?)`,
      [empresa, req.usuario.id, String(empresa), JSON.stringify(req.body)],
    );

    res.json({ configuracoes: await um(`SELECT * FROM company_settings WHERE company_id = ?`, [empresa]) });
  }),
);

rotasGestao.get(
  "/preferencias",
  asyncHandler(async (req, res) => {
    const linha = await um(
      `SELECT theme, language_code, push_notifications_enabled, sound_alerts_enabled,
              automatic_sync_enabled, dashboard_alert_limit, alerts_page_size, default_period_days
         FROM user_app_preferences WHERE company_id = ? AND user_id = ?`,
      [req.usuario.companyId, req.usuario.id],
    );
    res.json({ preferencias: linha });
  }),
);

rotasGestao.put(
  "/preferencias",
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const usuario = req.usuario.id;
    const tema = String(req.body?.tema ?? req.body?.theme ?? "DARK").toUpperCase();
    requerer(["SYSTEM", "DARK", "LIGHT"].includes(tema), 422, "Tema inválido.");

    await exec(
      `INSERT INTO user_app_preferences
         (company_id, user_id, theme, language_code, push_notifications_enabled, sound_alerts_enabled,
          automatic_sync_enabled, dashboard_alert_limit, alerts_page_size, default_period_days)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         theme = VALUES(theme), language_code = VALUES(language_code),
         push_notifications_enabled = VALUES(push_notifications_enabled),
         sound_alerts_enabled = VALUES(sound_alerts_enabled),
         automatic_sync_enabled = VALUES(automatic_sync_enabled),
         dashboard_alert_limit = VALUES(dashboard_alert_limit),
         alerts_page_size = VALUES(alerts_page_size),
         default_period_days = VALUES(default_period_days)`,
      [
        empresa,
        usuario,
        tema,
        String(req.body?.idioma ?? "pt-BR").slice(0, 10),
        req.body?.notificacoes === false ? 0 : 1,
        req.body?.sons === false ? 0 : 1,
        req.body?.autoSync === false ? 0 : 1,
        Math.min(10, Math.max(1, Math.trunc(numero(req.body?.limiteAlertasPainel, 3)))),
        Math.min(100, Math.max(5, Math.trunc(numero(req.body?.alertasPorPagina, 20)))),
        Math.min(366, Math.max(1, Math.trunc(numero(req.body?.periodoPadraoDias, 30)))),
      ],
    );

    res.json({
      preferencias: await um(
        `SELECT theme, language_code, push_notifications_enabled, sound_alerts_enabled,
                automatic_sync_enabled, dashboard_alert_limit, alerts_page_size, default_period_days
           FROM user_app_preferences WHERE company_id = ? AND user_id = ?`,
        [empresa, usuario],
      ),
    });
  }),
);

rotasGestao.get(
  "/assinatura",
  exigirPermissao("SUBSCRIPTION_VIEW", "DASHBOARD_VIEW"),
  asyncHandler(async (req, res) => {
    const atual = await um(`SELECT * FROM vw_company_current_subscription WHERE company_id = ? LIMIT 1`, [
      req.usuario.companyId,
    ]);
    const historico = await q(
      `SELECT cs.id, cs.status, cs.starts_at, cs.current_period_start, cs.current_period_end,
              p.code AS plan_code, p.name AS plan_name, p.monthly_price_brl
         FROM company_subscriptions cs
         JOIN subscription_plans p ON p.id = cs.plan_id
        WHERE cs.company_id = ? ORDER BY cs.starts_at DESC`,
      [req.usuario.companyId],
    );
    const plano = resumoDoPlano(
      await planoEfetivo(req.usuario.companyId),
      await limiteUsuariosDaEmpresa(req.usuario.companyId),
    );
    res.json({ atual, historico, plano });
  }),
);

rotasGestao.get(
  "/documentos-legais/pendentes",
  asyncHandler(async (req, res) => {
    const pendentes = await q(
      `SELECT legal_document_id, document_type, version, title, content_format, content, content_hash, effective_at
         FROM vw_pending_legal_documents WHERE company_id = ? AND user_id = ?`,
      [req.usuario.companyId, req.usuario.id],
    );
    res.json({ pendentes });
  }),
);

rotasGestao.post(
  "/documentos-legais",
  exigirPermissao("SETTINGS_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const tipo = (texto(req.body?.tipo) ?? "").toUpperCase();
    requerer(["TERMS_OF_USE", "PRIVACY_POLICY"].includes(tipo), 422, "Tipo inválido (TERMS_OF_USE ou PRIVACY_POLICY).");
    const versao = texto(req.body?.versao);
    const titulo = texto(req.body?.titulo);
    const conteudo = texto(req.body?.conteudo);
    requerer(versao && titulo && conteudo, 422, "Informe versão, título e conteúdo do documento.");

    const hash = crypto.createHash("sha256").update(conteudo).digest("hex");
    const formato = (texto(req.body?.formato, "MARKDOWN") ?? "").toUpperCase();
    requerer(["MARKDOWN", "HTML", "PLAIN_TEXT"].includes(formato), 422, "Formato inválido.");

    const res1 = await exec(
      `INSERT INTO legal_documents
         (company_id, document_type, version, title, content_format, content, content_hash,
          mandatory, requires_reacceptance, active, published_at, effective_at, created_by_user_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP(3), COALESCE(?, CURRENT_TIMESTAMP(3)), ?)`,
      [
        empresa,
        tipo,
        versao.slice(0, 30),
        titulo.slice(0, 180),
        formato,
        conteudo,
        hash,
        req.body?.obrigatorio === false ? 0 : 1,
        req.body?.exigirReaceite === false ? 0 : 1,
        req.body?.vigenteEm ? dataMysql(req.body.vigenteEm) : null,
        req.usuario.id,
      ],
    );
    res.status(201).json({ id: res1.insertId, hash, versao, tipo });
  }),
);

rotasGestao.post(
  "/documentos-legais/:id/aceitar",
  asyncHandler(async (req, res) => {
    await call("sp_accept_legal_document", [
      req.usuario.companyId,
      req.usuario.id,
      id(req.params.id),
      id(req.body?.dispositivoId),
      req.ip?.slice(0, 45) ?? null,
      req.get("user-agent")?.slice(0, 500) ?? null,
      texto(req.body?.versaoApp, "1.0.0")?.slice(0, 30),
      numero(req.body?.buildApp, 1),
    ]);
    res.json({ ok: true });
  }),
);
