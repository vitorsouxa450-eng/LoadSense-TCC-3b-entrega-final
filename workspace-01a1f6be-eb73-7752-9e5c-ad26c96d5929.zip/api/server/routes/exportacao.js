import { Router } from "express";
import { asyncHandler, requerer, texto, numero } from "../util.js";
import { autenticar, exigirPermissao } from "../auth.js";
import { exigirRecurso } from "../planos.js";
import { tx, um } from "../db.js";
import { criarOperacao, resolverReferencias } from "./operacoes.js";
import {
  COLUNAS_PLANILHA,
  LIMITE_IMPORTACAO_LINHAS,
  abasDaOperacao,
  abasDosDados,
  gerarCsv,
  gerarXlsx,
  linhasOperacoesPlanilha,
  lerPlanilha,
  mapearColunas,
} from "../exportacao.js";

export const rotasExportacao = Router();
rotasExportacao.use(autenticar);

const TAMANHO_MAXIMO_BYTES = 2 * 1024 * 1024;
const MOVIMENTOS = ["ENTRY", "EXIT", "TRANSFER", "WEIGHING_ONLY"];
const METODOS = ["THREE_STAGE", "GROSS_TARE"];
const ESTADOS_EDITAVEIS_PESO = ["DRAFT", "IN_PROGRESS"];

function formatoDaRequisicao(query, permitidos = ["XLSX", "CSV"]) {
  const formato = (texto(query.formato, "XLSX") ?? "").toUpperCase();
  requerer(permitidos.includes(formato), 422, `Formato inválido (${permitidos.join(" ou ")}).`);
  return formato;
}

async function enviarArquivo(res, nomeBase, formato, abas, opcoesXlsx = {}) {
  const data = new Date().toISOString().slice(0, 10);
  if (formato === "CSV") {
    const principal = abas[0];
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${nomeBase}-${data}.csv"`);
    res.send(gerarCsv(principal.colunas, principal.linhas));
    return;
  }
  const buffer = await gerarXlsx(abas, opcoesXlsx);
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", `attachment; filename="${nomeBase}-${data}.xlsx"`);
  res.send(buffer);
}

rotasExportacao.get(
  "/operacoes/exportar",
  exigirPermissao("OPERATION_VIEW"),
  exigirRecurso("exportar_planilha"),
  asyncHandler(async (req, res) => {
    const formato = formatoDaRequisicao(req.query);
    const linhas = await linhasOperacoesPlanilha(req.usuario.companyId, req.query);
    const abas = [{ nome: "Operações", colunas: COLUNAS_PLANILHA, linhas }];
    await enviarArquivo(res, "loadsense-operacoes", formato, abas);
  }),
);

rotasExportacao.get(
  "/operacoes/:id/exportar",
  exigirPermissao("OPERATION_VIEW", "TRACKING_VIEW"),
  asyncHandler(async (req, res) => {
    const formato = formatoDaRequisicao(req.query);
    const opId = numero(req.params.id);
    requerer(opId && opId > 0, 400, "Identificador inválido.");
    const abas = await abasDaOperacao(req.usuario.companyId, Math.trunc(opId));
    await enviarArquivo(res, "loadsense-operacao", formato, abas, {
      titulo: `Operação ${opId}`,
      subtitulo: "Dados completos da operação",
    });
  }),
);

rotasExportacao.get(
  "/exportar/dados",
  exigirPermissao("REPORT_GENERATE", "OPERATION_VIEW"),
  exigirRecurso("exportar_planilha"),
  asyncHandler(async (req, res) => {
    formatoDaRequisicao(req.query, ["XLSX"]);
    const abas = await abasDosDados(req.usuario.companyId);
    await enviarArquivo(res, "loadsense-dados-completos", "XLSX", abas, {
      titulo: "Dados completos da empresa",
      subtitulo: "Uma aba por tabela",
    });
  }),
);

function lerLinha(dados, mapa) {
  const v = (chave) => {
    const coluna = mapa[chave];
    if (!coluna) return null;
    const valor = dados[coluna];
    return valor === null || valor === undefined || String(valor).trim() === "" ? null : valor;
  };
  const peso = v("peso_declarado_kg");
  return {
    codigo: texto(v("codigo")),
    placa: texto(v("placa")),
    motorista: texto(v("motorista")),
    produto: texto(v("produto")),
    rotaCodigo: texto(v("rota_codigo")),
    tipoMovimento: texto(v("tipo_movimento"))?.toUpperCase() ?? null,
    metodo: texto(v("metodo"))?.toUpperCase() ?? null,
    notaFiscal: texto(v("nota_fiscal")),
    mdfe: texto(v("mdfe")),
    ciot: texto(v("ciot")),
    observacoes: texto(v("observacoes")),
    pesoDeclaradoKg: peso === null ? null : Number(String(peso).replace(",", ".")),
  };
}

async function validarLinha(empresa, linha, codigosNoArquivo) {
  const erros = [];
  if (linha.codigo) {
    if (codigosNoArquivo.has(linha.codigo)) erros.push(`Código ${linha.codigo} aparece mais de uma vez no arquivo.`);
    codigosNoArquivo.add(linha.codigo);
    const atual = await um(
      `SELECT o.id, o.state, v.plate AS placa, d.full_name AS motorista, cp.name AS produto, rt.code AS rotaCodigo,
              o.movement_type AS tipoMovimento, o.weighing_method AS metodo,
              o.declared_cargo_weight_kg AS pesoDeclarado
         FROM weighing_operations o
         JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
         LEFT JOIN drivers d ON d.company_id = o.company_id AND d.id = o.driver_id
         LEFT JOIN cargo_products cp ON cp.company_id = o.company_id AND cp.id = o.cargo_product_id
         LEFT JOIN routes rt ON rt.company_id = o.company_id AND rt.id = o.route_id
        WHERE o.company_id = ? AND o.operation_code = ?`,
      [empresa, linha.codigo],
    );
    if (!atual) return [`Código ${linha.codigo} não encontrado. Para criar uma operação nova, deixe o código vazio.`];
    if (atual.state === "CANCELLED") return ["Operação cancelada não pode ser alterada pela planilha."];
    for (const [campo, rotulo, valorAtual] of [
      ["placa", "Placa", atual.placa],
      ["motorista", "Motorista", atual.motorista],
      ["produto", "Produto", atual.produto],
      ["rotaCodigo", "Rota (código)", atual.rotaCodigo],
      ["tipoMovimento", "Tipo de movimento", atual.tipoMovimento],
      ["metodo", "Método", atual.metodo],
    ]) {
      if (linha[campo] && String(linha[campo]).toUpperCase() !== String(valorAtual ?? "").toUpperCase()) {
        erros.push(`${rotulo} não pode ser alterado depois de criada a operação.`);
      }
    }
    const pesoMudou =
      linha.pesoDeclaradoKg !== null &&
      Math.abs(Number(linha.pesoDeclaradoKg) - Number(atual.pesoDeclarado ?? NaN)) > 0.001;
    if (pesoMudou && !ESTADOS_EDITAVEIS_PESO.includes(atual.state)) {
      erros.push("Peso declarado só pode ser alterado antes da pesagem.");
    }
    if (linha.pesoDeclaradoKg !== null && !(linha.pesoDeclaradoKg > 0))
      erros.push("Peso declarado deve ser maior que zero.");
    return erros;
  }

  if (!linha.placa) erros.push("Placa obrigatória para criar uma operação.");
  if (linha.tipoMovimento && !MOVIMENTOS.includes(linha.tipoMovimento)) erros.push("Tipo de movimento inválido.");
  if (linha.metodo && !METODOS.includes(linha.metodo)) erros.push("Método inválido (GROSS_TARE ou THREE_STAGE).");
  if (linha.pesoDeclaradoKg !== null && !(linha.pesoDeclaradoKg > 0))
    erros.push("Peso declarado deve ser maior que zero.");
  if (linha.placa) {
    try {
      await resolverReferencias({ um }, empresa, {
        placa: linha.placa,
        motorista: linha.motorista,
        produto: linha.produto,
        rotaCodigo: linha.rotaCodigo,
      });
    } catch (erro) {
      erros.push(erro.message);
    }
  }
  return erros;
}

const AUDITORIA_IMPORTACAO = `INSERT INTO audit_logs (company_id, user_id, action, entity_name, entity_id, new_values)
  VALUES (?, ?, 'IMPORT_OPERATIONS', 'weighing_operations', NULL, ?)`;

rotasExportacao.post(
  "/operacoes/importar",
  exigirPermissao("OPERATION_CREATE"),
  exigirRecurso("importar_planilha"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const conteudo = texto(req.body?.conteudoBase64);
    requerer(conteudo, 422, "Envie o arquivo da planilha.");
    const buffer = Buffer.from(conteudo, "base64");
    requerer(buffer.length > 0 && buffer.length <= TAMANHO_MAXIMO_BYTES, 422, "Arquivo vazio ou maior que 2 MB.");
    const simular = req.body?.simular === true || req.body?.simular === "true";

    const { cabecalhos, linhas } = await lerPlanilha(buffer);
    const mapa = mapearColunas(cabecalhos);
    requerer(mapa.codigo || mapa.placa, 422, "A planilha precisa das colunas Código ou Placa.");
    requerer(linhas.length > 0, 422, "A planilha não tem linhas de dados.");
    requerer(
      linhas.length <= LIMITE_IMPORTACAO_LINHAS,
      422,
      `Máximo de ${LIMITE_IMPORTACAO_LINHAS} linhas por importação.`,
    );

    const codigosNoArquivo = new Set();
    const erros = [];
    const preparadas = [];
    for (const { numero: linhaPlan, dados } of linhas) {
      const linha = lerLinha(dados, mapa);
      const problemas = await validarLinha(empresa, linha, codigosNoArquivo);
      for (const mensagem of problemas) erros.push({ linha: linhaPlan, mensagem });
      preparadas.push({ linhaPlan, linha });
    }
    if (erros.length) {
      return res.status(422).json({
        aplicada: false,
        mensagem: "A importação foi cancelada: corrija os erros e envie a planilha de novo. Nenhuma linha foi gravada.",
        total: linhas.length,
        erros: erros.slice(0, 200),
      });
    }

    const criar = preparadas.filter((p) => !p.linha.codigo).length;
    const atualizar = preparadas.length - criar;
    if (simular) {
      return res.json({ aplicada: false, simulacao: true, total: linhas.length, criar, atualizar, erros: [] });
    }

    const criadas = [];
    await tx(async (conn) => {
      const db = {
        um: async (sql, params) => {
          const [rows] = await conn.execute(sql, params);
          return rows[0] ?? null;
        },
        exec: async (sql, params) => (await conn.execute(sql, params))[0],
      };
      for (const { linha } of preparadas) {
        if (linha.codigo) {
          const op = await db.um(
            "SELECT id, state FROM weighing_operations WHERE company_id = ? AND operation_code = ?",
            [empresa, linha.codigo],
          );
          const pesoAlterado = linha.pesoDeclaradoKg !== null && ESTADOS_EDITAVEIS_PESO.includes(op.state);
          await db.exec(
            `UPDATE weighing_operations
                SET observations = COALESCE(?, observations),
                    invoice_number = COALESCE(?, invoice_number),
                    mdfe_number = COALESCE(?, mdfe_number),
                    ciot_number = COALESCE(?, ciot_number),
                    declared_cargo_weight_kg = COALESCE(?, declared_cargo_weight_kg)
              WHERE company_id = ? AND id = ?`,
            [
              linha.observacoes,
              linha.notaFiscal,
              linha.mdfe,
              linha.ciot,
              pesoAlterado ? linha.pesoDeclaradoKg : null,
              empresa,
              op.id,
            ],
          );
        } else {
          const id = await criarOperacao(db, empresa, req.usuario.id, {
            placa: linha.placa,
            motorista: linha.motorista,
            produto: linha.produto,
            rotaCodigo: linha.rotaCodigo,
            tipoMovimento: linha.tipoMovimento ?? "WEIGHING_ONLY",
            metodo: linha.metodo ?? "GROSS_TARE",
            notaFiscal: linha.notaFiscal,
            mdfe: linha.mdfe,
            ciot: linha.ciot,
            observacoes: linha.observacoes,
            pesoDeclaradoKg: linha.pesoDeclaradoKg,
          });
          criadas.push(id);
        }
      }
      await db.exec(AUDITORIA_IMPORTACAO, [
        empresa,
        req.usuario.id,
        JSON.stringify({
          linhas: linhas.length,
          criadas: criadas.length,
          atualizadas: atualizar,
          arquivo: texto(req.body?.nomeArquivo),
        }),
      ]);
    });

    res.json({
      aplicada: true,
      total: linhas.length,
      criadas: criadas.length,
      atualizadas: atualizar,
      erros: [],
    });
  }),
);
