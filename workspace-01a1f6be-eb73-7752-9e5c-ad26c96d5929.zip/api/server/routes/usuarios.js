import { Router } from "express";
import { ErroHttp, asyncHandler, id, requerer, texto } from "../util.js";
import { autenticar, exigirPermissao, hashSenha, registrarAuditoria } from "../auth.js";
import { exec, q, um, tx } from "../db.js";
import { garantirLimite } from "../planos.js";
import { randomBytes } from "node:crypto";

const PAPEIS_CRIAVEIS = ["ADMINISTRATOR", "SUPERVISOR", "OPERATOR"];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const rotasUsuarios = Router();
rotasUsuarios.use(autenticar);

rotasUsuarios.get(
  "/usuarios",
  exigirPermissao("USER_MANAGE"),
  asyncHandler(async (req, res) => {
    const linhas = await q(
      `SELECT u.id, u.full_name, u.email, u.active, u.must_change_password, u.totp_enabled,
              u.last_login_at, r.name AS papel, r.description AS papel_descricao
         FROM users u
         JOIN roles r ON r.id = u.role_id
        WHERE u.company_id = ?
        ORDER BY u.active DESC, u.full_name`,
      [req.usuario.companyId],
    );
    res.json({
      usuarios: linhas.map((u) => ({
        id: u.id,
        nome: u.full_name,
        email: u.email,
        ativo: Boolean(u.active),
        papel: u.papel,
        papelDescricao: u.papel_descricao,
        trocarSenha: Boolean(u.must_change_password),
        verificacaoEmDuasEtapas: Boolean(u.totp_enabled),
        ultimoAcesso: u.last_login_at,
        eu: u.id === req.usuario.id,
      })),
    });
  }),
);

rotasUsuarios.post(
  "/usuarios",
  exigirPermissao("USER_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const nome = texto(req.body?.nome);
    const email = texto(req.body?.email)?.toLowerCase();
    const papel = texto(req.body?.papel);
    requerer(nome && nome.length >= 3, 422, "Informe o nome do usuário.");
    requerer(email && EMAIL_RE.test(email), 422, "Informe um e-mail válido.");
    requerer(PAPEIS_CRIAVEIS.includes(papel), 422, "Papel inválido.");

    await garantirLimite(empresa, "usuarios", "usuários");

    const existe = await um(`SELECT id FROM users WHERE company_id = ? AND email = ?`, [empresa, email]);
    if (existe) throw new ErroHttp(409, "Já existe um usuário com este e-mail nesta empresa.");

    const role = await um(`SELECT id FROM roles WHERE company_id = ? AND name = ? AND active = 1`, [empresa, papel]);
    if (!role) throw new ErroHttp(422, "Papel não cadastrado para esta empresa.");

    const senhaProvisoria = randomBytes(9).toString("base64url");
    const hash = await hashSenha(senhaProvisoria);

    const novoId = await tx(async (conn) => {
      const [r] = await conn.execute(
        `INSERT INTO users (company_id, role_id, full_name, email, password_hash, must_change_password, active)
         VALUES (?, ?, ?, ?, ?, 1, 1)`,
        [empresa, role.id, nome.slice(0, 140), email, hash],
      );
      await conn.execute(`INSERT INTO user_app_preferences (company_id, user_id) VALUES (?, ?)`, [empresa, r.insertId]);
      return r.insertId;
    });

    await registrarAuditoria(
      empresa,
      req.usuario.id,
      "USER_CREATED",
      "users",
      novoId,
      { usuario: nome, papel },
      req.ip,
      req.get("user-agent"),
    );

    res.status(201).json({
      usuario: { id: novoId, nome, email, papel, trocarSenha: true, ativo: true },
      senhaProvisoria,
    });
  }),
);

rotasUsuarios.patch(
  "/usuarios/:id/troca-senha",
  exigirPermissao("USER_MANAGE"),
  asyncHandler(async (req, res) => {
    const alvoId = id(req.params.id);
    requerer(alvoId, 400, "Identificador inválido.");
    const exigir = req.body?.exigir;
    requerer(typeof exigir === "boolean", 422, "Informe exigir: true ou false.");

    const alvo = await um(`SELECT id, full_name, active FROM users WHERE company_id = ? AND id = ?`, [
      req.usuario.companyId,
      alvoId,
    ]);
    if (!alvo) throw new ErroHttp(404, "Usuário não encontrado.");
    if (!alvo.active) throw new ErroHttp(409, "Usuário inativo. Reative a conta antes de mudar a senha dela.");

    await exec(`UPDATE users SET must_change_password = ? WHERE company_id = ? AND id = ?`, [
      exigir ? 1 : 0,
      req.usuario.companyId,
      alvoId,
    ]);

    if (exigir) {
      const mesmaConta = alvoId === req.usuario.id;
      await exec(
        `UPDATE auth_sessions SET revoked_at = CURRENT_TIMESTAMP(3), revoke_reason = 'PASSWORD_CHANGE_REQUIRED'
          WHERE company_id = ? AND user_id = ? AND revoked_at IS NULL ${mesmaConta ? "AND id <> ?" : ""}`,
        mesmaConta ? [req.usuario.companyId, alvoId, req.usuario.sessaoId] : [req.usuario.companyId, alvoId],
      );
    }

    await registrarAuditoria(
      req.usuario.companyId,
      req.usuario.id,
      exigir ? "PASSWORD_CHANGE_REQUIRED" : "PASSWORD_CHANGE_CLEARED",
      "users",
      alvoId,
      { usuario: alvo.full_name },
      req.ip,
      req.get("user-agent"),
    );

    res.json({ ok: true, trocarSenha: exigir });
  }),
);

async function outrosAdministradoresAtivos(companyId, excluirId) {
  const linha = await um(
    `SELECT COUNT(*) AS total FROM users u JOIN roles r ON r.id = u.role_id
      WHERE u.company_id = ? AND r.name = 'ADMINISTRATOR' AND u.active = 1 AND u.id <> ?`,
    [companyId, excluirId],
  );
  return Number(linha?.total ?? 0);
}

rotasUsuarios.patch(
  "/usuarios/:id",
  exigirPermissao("USER_MANAGE"),
  asyncHandler(async (req, res) => {
    const alvoId = id(req.params.id);
    requerer(alvoId, 400, "Identificador inválido.");
    const papel = texto(req.body?.papel);
    requerer(PAPEIS_CRIAVEIS.includes(papel), 422, "Papel inválido.");
    requerer(alvoId !== req.usuario.id, 409, "Você não pode alterar o próprio cargo.");

    const alvo = await um(
      `SELECT u.id, u.full_name, u.active, r.name AS papel
         FROM users u JOIN roles r ON r.id = u.role_id
        WHERE u.company_id = ? AND u.id = ?`,
      [req.usuario.companyId, alvoId],
    );
    if (!alvo) throw new ErroHttp(404, "Usuário não encontrado.");
    if (alvo.papel === papel) return res.json({ ok: true, papel });

    if (
      alvo.papel === "ADMINISTRATOR" &&
      alvo.active &&
      (await outrosAdministradoresAtivos(req.usuario.companyId, alvoId)) === 0
    ) {
      throw new ErroHttp(
        409,
        "Esta é a última conta de administrador ativa. Indique outro administrador antes de mudar o cargo.",
      );
    }

    const role = await um(`SELECT id FROM roles WHERE company_id = ? AND name = ? AND active = 1`, [
      req.usuario.companyId,
      papel,
    ]);
    if (!role) throw new ErroHttp(422, "Papel não cadastrado para esta empresa.");

    await exec(`UPDATE users SET role_id = ? WHERE company_id = ? AND id = ?`, [
      role.id,
      req.usuario.companyId,
      alvoId,
    ]);
    await registrarAuditoria(
      req.usuario.companyId,
      req.usuario.id,
      "USER_ROLE_CHANGED",
      "users",
      alvoId,
      { usuario: alvo.full_name, de: alvo.papel, para: papel },
      req.ip,
      req.get("user-agent"),
    );
    res.json({ ok: true, papel });
  }),
);

rotasUsuarios.patch(
  "/usuarios/:id/ativo",
  exigirPermissao("USER_MANAGE"),
  asyncHandler(async (req, res) => {
    const alvoId = id(req.params.id);
    requerer(alvoId, 400, "Identificador inválido.");
    const ativo = req.body?.ativo;
    requerer(typeof ativo === "boolean", 422, "Informe ativo: true ou false.");
    requerer(alvoId !== req.usuario.id, 409, "Você não pode desativar a própria conta.");

    const alvo = await um(
      `SELECT u.id, u.full_name, u.active, r.name AS papel
         FROM users u JOIN roles r ON r.id = u.role_id
        WHERE u.company_id = ? AND u.id = ?`,
      [req.usuario.companyId, alvoId],
    );
    if (!alvo) throw new ErroHttp(404, "Usuário não encontrado.");
    if (Boolean(alvo.active) === ativo) return res.json({ ok: true, ativo });

    if (
      !ativo &&
      alvo.papel === "ADMINISTRATOR" &&
      (await outrosAdministradoresAtivos(req.usuario.companyId, alvoId)) === 0
    ) {
      throw new ErroHttp(
        409,
        "Esta é a última conta de administrador ativa. Ative outro administrador antes de desativá-la.",
      );
    }

    await tx(async (conn) => {
      await conn.execute(`UPDATE users SET active = ? WHERE company_id = ? AND id = ?`, [
        ativo ? 1 : 0,
        req.usuario.companyId,
        alvoId,
      ]);
      if (!ativo) {
        await conn.execute(
          `UPDATE auth_sessions SET revoked_at = CURRENT_TIMESTAMP(3), revoke_reason = 'USER_DEACTIVATED'
            WHERE company_id = ? AND user_id = ? AND revoked_at IS NULL`,
          [req.usuario.companyId, alvoId],
        );
      }
    });

    await registrarAuditoria(
      req.usuario.companyId,
      req.usuario.id,
      ativo ? "USER_ACTIVATED" : "USER_DEACTIVATED",
      "users",
      alvoId,
      { usuario: alvo.full_name },
      req.ip,
      req.get("user-agent"),
    );
    res.json({ ok: true, ativo });
  }),
);
