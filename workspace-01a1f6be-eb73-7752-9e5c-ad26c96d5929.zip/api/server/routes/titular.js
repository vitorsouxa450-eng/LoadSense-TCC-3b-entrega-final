import crypto from "node:crypto";
import { Router } from "express";
import { ErroHttp, asyncHandler, requerer, texto } from "../util.js";
import { autenticar, conferirSenha, hashSenha } from "../auth.js";
import { exec, q, tx, um } from "../db.js";

export const rotasTitular = Router();

async function carregarUsuario(id) {
  return um(
    `SELECT u.id, u.company_id, u.full_name, u.email, u.phone, u.password_hash, u.active,
            u.receive_critical_alerts, u.receive_automatic_reports, u.created_at, u.last_login_at,
            r.name AS papel
       FROM users u JOIN roles r ON r.id = u.role_id
      WHERE u.id = ?`,
    [id],
  );
}

rotasTitular.get(
  "/titular/perfil",
  autenticar,
  asyncHandler(async (req, res) => {
    const usuario = await carregarUsuario(req.usuario.id);
    if (!usuario) throw new ErroHttp(404, "Usuário não encontrado.");
    res.json({
      nome: usuario.full_name,
      email: usuario.email,
      telefone: usuario.phone,
      alertasCriticos: Boolean(usuario.receive_critical_alerts),
      relatoriosAutomaticos: Boolean(usuario.receive_automatic_reports),
    });
  }),
);

rotasTitular.get(
  "/titular/meus-dados",
  autenticar,
  asyncHandler(async (req, res) => {
    const usuario = await carregarUsuario(req.usuario.id);
    if (!usuario) throw new ErroHttp(404, "Usuário não encontrado.");
    const [sessoes, aceites, auditoria, pesagens] = await Promise.all([
      q(
        `SELECT issued_at, last_used_at, expires_at, revoked_at, revoke_reason, ip_address, user_agent
           FROM auth_sessions WHERE user_id = ? ORDER BY issued_at DESC LIMIT 500`,
        [usuario.id],
      ),
      q(
        `SELECT la.accepted_at, ld.document_type, ld.version, la.ip_address
           FROM legal_acceptances la JOIN legal_documents ld ON ld.id = la.legal_document_id
          WHERE la.user_id = ? ORDER BY la.accepted_at DESC LIMIT 500`,
        [usuario.id],
      ),
      q(
        `SELECT created_at, action, entity_name, entity_id, ip_address
           FROM audit_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 1000`,
        [usuario.id],
      ),
      q(
        `SELECT operation_code, status, created_at, completed_at, actual_cargo_weight_kg
           FROM weighing_operations
          WHERE company_id = ? AND (responsible_user_id = ? OR created_by_user_id = ?)
          ORDER BY created_at DESC LIMIT 5000`,
        [usuario.company_id, usuario.id, usuario.id],
      ),
    ]);

    const pacote = {
      gerado_em: new Date().toISOString(),
      observacao: "Dados pessoais da sua conta no LoadSense, conforme LGPD (art. 18, II e V).",
      conta: {
        nome: usuario.full_name,
        email: usuario.email,
        telefone: usuario.phone,
        papel: usuario.papel,
        ativa: Boolean(usuario.active),
        criada_em: usuario.created_at,
        ultimo_login_em: usuario.last_login_at,
      },
      comunicacoes: {
        alertas_criticos: Boolean(usuario.receive_critical_alerts),
        relatorios_automaticos: Boolean(usuario.receive_automatic_reports),
      },
      sessoes,
      aceites_de_termos: aceites,
      registros_de_auditoria: auditoria,
      pesagens_vinculadas: pesagens,
    };

    res.setHeader("Content-Disposition", `attachment; filename="meus-dados-loadsense-${usuario.id}.json"`);
    res.json(pacote);
  }),
);

rotasTitular.patch(
  "/titular/meus-dados",
  autenticar,
  asyncHandler(async (req, res) => {
    const atual = await carregarUsuario(req.usuario.id);
    if (!atual) throw new ErroHttp(404, "Usuário não encontrado.");
    const corpo = req.body ?? {};
    const nome = texto(corpo.nome) ?? atual.full_name;
    requerer(nome && nome.length >= 3, 422, "Informe o nome completo.");
    const telefone = corpo.telefone === undefined ? atual.phone : (texto(corpo.telefone)?.slice(0, 30) ?? null);
    const alertas = corpo.alertasCriticos === undefined ? atual.receive_critical_alerts : corpo.alertasCriticos ? 1 : 0;
    const relatorios =
      corpo.relatoriosAutomaticos === undefined ? atual.receive_automatic_reports : corpo.relatoriosAutomaticos ? 1 : 0;

    await exec(
      `UPDATE users SET full_name = ?, phone = ?, receive_critical_alerts = ?, receive_automatic_reports = ?
        WHERE id = ?`,
      [nome.slice(0, 140), telefone, alertas, relatorios, atual.id],
    );
    res.json({ ok: true });
  }),
);

rotasTitular.post(
  "/titular/excluir-conta",
  autenticar,
  asyncHandler(async (req, res) => {
    const atual = await carregarUsuario(req.usuario.id);
    if (!atual) throw new ErroHttp(404, "Usuário não encontrado.");
    requerer(req.body?.senha, 422, "Confirme a exclusão informando sua senha.");
    const senhaOk = await conferirSenha(String(req.body.senha), atual.password_hash);
    if (!senhaOk) throw new ErroHttp(401, "Senha incorreta.");

    if (atual.papel === "ADMINISTRATOR") {
      const admins = await um(
        `SELECT COUNT(*) AS total FROM users u JOIN roles r ON r.id = u.role_id
          WHERE u.company_id = ? AND r.name = 'ADMINISTRATOR' AND u.active = 1 AND u.id <> ?`,
        [atual.company_id, atual.id],
      );
      if (!admins || Number(admins.total) === 0) {
        throw new ErroHttp(
          409,
          "Você é o último administrador ativo da empresa. Indique outro administrador antes de excluir sua conta.",
        );
      }
    }

    const lixo = await hashSenha(crypto.randomBytes(32).toString("hex"));
    await tx(async (conn) => {
      await conn.execute(
        `UPDATE users
            SET full_name = ?, email = ?, phone = NULL, password_hash = ?, active = 0,
                receive_critical_alerts = 0, receive_automatic_reports = 0,
                totp_enabled = 0, totp_secret_enc = NULL, totp_last_step = NULL, totp_enabled_at = NULL
          WHERE id = ?`,
        [`Usuário excluído #${atual.id}`, `excluido-${atual.id}@anonimizado.invalid`, lixo, atual.id],
      );
      await conn.execute(
        `UPDATE auth_sessions SET revoked_at = NOW(3), revoke_reason = 'EXCLUSAO_CONTA'
          WHERE user_id = ? AND revoked_at IS NULL`,
        [atual.id],
      );
      await conn.execute(`UPDATE audit_logs SET ip_address = NULL, user_agent = NULL WHERE user_id = ?`, [atual.id]);
    });
    res.json({ ok: true, mensagem: "Conta excluída. Os dados pessoais foram anonimizados." });
  }),
);
