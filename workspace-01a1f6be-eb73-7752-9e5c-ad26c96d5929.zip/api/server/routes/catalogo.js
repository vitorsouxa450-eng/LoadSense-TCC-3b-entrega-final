import { Router } from "express";
import { ErroHttp, asyncHandler, requerer, texto } from "../util.js";
import { autenticar, exigirPermissao } from "../auth.js";
import { q, tx, um } from "../db.js";
import { decifrar } from "../dados-pessoais.js";
import { garantirLimite } from "../planos.js";

export const rotasCatalogo = Router();
rotasCatalogo.use(autenticar);

const filtro = (req) => {
  const empresa = req.usuario.companyId;
  const busca = req.query.busca ? `%${String(req.query.busca).trim()}%` : null;
  return { empresa, busca };
};

function verInativos(req, permissao) {
  return req.query?.incluirInativos === "1" && req.usuario?.permissoes?.includes(permissao) ? 1 : 0;
}

rotasCatalogo.get(
  "/veiculos",
  exigirPermissao("OPERATION_VIEW", "VEHICLE_MANAGE", "DASHBOARD_VIEW", "TRACKING_VIEW"),
  asyncHandler(async (req, res) => {
    const { empresa, busca } = filtro(req);
    const veiculos = await q(
      `SELECT v.id, v.plate, v.fleet_code, v.vehicle_type, v.manufacturer, v.model, v.manufacture_year,
              v.axle_count, v.registered_tare_kg, v.gross_weight_limit_kg, v.payload_limit_kg, v.active,
              r.id AS rfid_id, r.code AS rfid_code,
              (SELECT COUNT(*) FROM weighing_operations o WHERE o.company_id = v.company_id AND o.vehicle_id = v.id) AS total_operacoes
         FROM vehicles v
         LEFT JOIN rfid_tags r ON r.company_id = v.company_id AND r.vehicle_id = v.id AND r.active = 1
         LEFT JOIN drivers d ON 1 = 0 AND d.company_id = v.company_id
        WHERE v.company_id = ?
          AND (v.active = 1 OR ? = 1)
          AND (? IS NULL OR v.plate LIKE ? OR v.fleet_code LIKE ?)
        ORDER BY v.plate`,
      [empresa, verInativos(req, "VEHICLE_MANAGE"), busca, busca, busca],
    );
    res.json({ veiculos });
  }),
);

const PLACA_RE = /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$|^[A-Z]{3}[0-9]{4}$/;
const TIPOS_VEICULO = ["TRUCK", "TRACTOR", "SEMI_TRAILER", "TRAILER", "OTHER"];
const RFID_RE = /^[A-Za-z0-9._:-]{1,100}$/;

function numeroOpcional(valor, rotulo) {
  if (valor === undefined || valor === null || valor === "") return null;
  const n = Number(String(valor).replace(",", "."));
  if (!Number.isFinite(n) || n < 0) throw new ErroHttp(422, `${rotulo} deve ser um número maior ou igual a zero.`);
  return n;
}

function validarVeiculo(corpo) {
  const placa = String(corpo.placa ?? "")
    .toUpperCase()
    .replace(/[\s-]/g, "");
  if (!PLACA_RE.test(placa)) throw new ErroHttp(422, "Placa inválida. Use o formato ABC1D23 ou ABC1234.");
  const tipo = texto(corpo.tipo, "TRUCK");
  if (!TIPOS_VEICULO.includes(tipo)) throw new ErroHttp(422, "Tipo de veículo inválido.");
  const rfid = texto(corpo.rfid, null);
  if (rfid && !RFID_RE.test(rfid)) {
    throw new ErroHttp(
      422,
      "Código RFID inválido. Use letras, números, ponto, hífen, dois-pontos ou sublinhado (até 100).",
    );
  }
  const frota = texto(corpo.frota, null);
  if (frota && frota.length > 40) throw new ErroHttp(422, "Código de frota: máximo de 40 caracteres.");
  const fabricante = texto(corpo.fabricante, null);
  if (fabricante && fabricante.length > 80) throw new ErroHttp(422, "Fabricante: máximo de 80 caracteres.");
  const modelo = texto(corpo.modelo, null);
  if (modelo && modelo.length > 100) throw new ErroHttp(422, "Modelo: máximo de 100 caracteres.");
  const anoBruto = texto(corpo.anoFabricacao, null);
  const ano = anoBruto === null ? null : Number(anoBruto);
  if (ano !== null && (!Number.isInteger(ano) || ano < 1950 || ano > new Date().getFullYear() + 1)) {
    throw new ErroHttp(422, "Ano de fabricação inválido.");
  }
  const eixosBruto = texto(corpo.eixos, null);
  const eixos = eixosBruto === null ? null : Number(eixosBruto);
  if (eixos !== null && (!Number.isInteger(eixos) || eixos < 2 || eixos > 20)) {
    throw new ErroHttp(422, "Número de eixos deve ser entre 2 e 20.");
  }
  const tara = numeroOpcional(corpo.taraKg, "Tara cadastrada");
  const pbt = numeroOpcional(corpo.limitePbtKg, "Limite de peso bruto");
  const carga = numeroOpcional(corpo.limiteCargaKg, "Limite de carga");
  if (tara !== null && pbt !== null && pbt < tara) {
    throw new ErroHttp(422, "O limite de peso bruto deve ser maior ou igual à tara.");
  }
  return {
    placa,
    tipo,
    rfid,
    frota,
    fabricante,
    modelo,
    ano,
    eixos,
    tara,
    pbt,
    carga,
  };
}

rotasCatalogo.post(
  "/veiculos",
  exigirPermissao("VEHICLE_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const dados = validarVeiculo(req.body ?? {});
    requerer(dados.placa, 422, "Informe a placa do caminhão.");
    await garantirLimite(empresa, "veiculos", "caminhões");

    const novoId = await tx(async (conn) => {
      const consulta = async (sql, params) => (await conn.execute(sql, params))[0];

      if (
        (
          await consulta("SELECT id FROM vehicles WHERE company_id = ? AND plate = ? LIMIT 1", [empresa, dados.placa])
        )[0]
      ) {
        throw new ErroHttp(409, "Já existe um caminhão com esta placa.");
      }
      if (
        dados.frota &&
        (
          await consulta("SELECT id FROM vehicles WHERE company_id = ? AND fleet_code = ? LIMIT 1", [
            empresa,
            dados.frota,
          ])
        )[0]
      ) {
        throw new ErroHttp(409, "Já existe um caminhão com este código de frota.");
      }
      let etiqueta = null;
      if (dados.rfid) {
        etiqueta =
          (
            await consulta("SELECT id, vehicle_id, active FROM rfid_tags WHERE company_id = ? AND code = ? LIMIT 1", [
              empresa,
              dados.rfid,
            ])
          )[0] ?? null;
        if (etiqueta && etiqueta.active === 1 && etiqueta.vehicle_id) {
          throw new ErroHttp(409, "Esta etiqueta RFID já está vinculada a outro caminhão.");
        }
      }

      const veiculo = await consulta(
        `INSERT INTO vehicles (company_id, plate, fleet_code, vehicle_type, manufacturer, model, manufacture_year,
                               axle_count, registered_tare_kg, gross_weight_limit_kg, payload_limit_kg, active)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
        [
          empresa,
          dados.placa,
          dados.frota,
          dados.tipo,
          dados.fabricante,
          dados.modelo,
          dados.ano,
          dados.eixos,
          dados.tara,
          dados.pbt,
          dados.carga,
        ],
      );
      const idVeiculo = veiculo.insertId;

      if (dados.rfid) {
        if (etiqueta) {
          await consulta(
            "UPDATE rfid_tags SET vehicle_id = ?, active = 1, deactivated_at = NULL, activated_at = NOW(3) WHERE id = ?",
            [idVeiculo, etiqueta.id],
          );
        } else {
          await consulta(
            "INSERT INTO rfid_tags (company_id, code, vehicle_id, active, notes) VALUES (?, ?, ?, 1, 'Cadastro de caminhão')",
            [empresa, dados.rfid, idVeiculo],
          );
        }
      }

      await consulta(
        `INSERT INTO audit_logs (company_id, user_id, action, entity_name, entity_id, new_values)
         VALUES (?, ?, 'CREATE_VEHICLE', 'vehicles', ?, ?)`,
        [empresa, req.usuario.id, String(idVeiculo), JSON.stringify({ placa: dados.placa, rfid: dados.rfid })],
      );
      return idVeiculo;
    });

    const linha = await um(
      `SELECT v.id, v.plate, v.fleet_code, v.vehicle_type, v.manufacturer, v.model, v.manufacture_year,
              v.axle_count, v.registered_tare_kg, v.gross_weight_limit_kg, v.payload_limit_kg, v.active,
              r.id AS rfid_id, r.code AS rfid_code, 0 AS total_operacoes
         FROM vehicles v
         LEFT JOIN rfid_tags r ON r.company_id = v.company_id AND r.vehicle_id = v.id AND r.active = 1
        WHERE v.company_id = ? AND v.id = ?`,
      [empresa, novoId],
    );
    res.status(201).json(linha);
  }),
);

rotasCatalogo.get(
  "/motoristas",
  exigirPermissao("OPERATION_VIEW", "DRIVER_MANAGE", "TRACKING_VIEW"),
  asyncHandler(async (req, res) => {
    const { empresa, busca } = filtro(req);
    const motoristas = await q(
      `SELECT id, full_name, document_number, employee_code, license_number, license_category,
              license_expiration_date, phone, active
         FROM drivers
        WHERE company_id = ? AND (active = 1 OR ? = 1)
          AND (? IS NULL OR full_name LIKE ? OR employee_code LIKE ?)
        ORDER BY full_name`,
      [empresa, verInativos(req, "DRIVER_MANAGE"), busca, busca, busca],
    );
    res.json({
      motoristas: motoristas.map((m) => ({
        ...m,
        document_number: decifrar(m.document_number),
        license_number: decifrar(m.license_number),
        phone: decifrar(m.phone),
      })),
    });
  }),
);

rotasCatalogo.get(
  "/produtos",
  exigirPermissao("OPERATION_VIEW", "PRODUCT_MANAGE"),
  asyncHandler(async (req, res) => {
    const { empresa } = filtro(req);
    const produtos = await q(
      `SELECT id, code, name, description, default_unit, active FROM cargo_products
        WHERE company_id = ? AND active = 1 ORDER BY name`,
      [empresa],
    );
    res.json({ produtos });
  }),
);

rotasCatalogo.get(
  "/rotas",
  exigirPermissao("OPERATION_VIEW", "TRACKING_VIEW", "DASHBOARD_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const rotas = await q(
      `SELECT r.id, r.code, r.origin, r.destination, r.distance_km, r.description, r.active,
              (SELECT COUNT(*) FROM weighing_operations o WHERE o.company_id = r.company_id AND o.route_id = r.id) AS total_operacoes
         FROM routes r WHERE r.company_id = ? AND (r.active = 1 OR ? = 1) ORDER BY r.code`,
      [empresa, verInativos(req, "TRACKING_MANAGE")],
    );
    const pontos = await q(
      `SELECT route_id, sequence_number, waypoint_type, label, latitude, longitude
         FROM route_waypoints WHERE company_id = ? ORDER BY route_id, sequence_number`,
      [empresa],
    );
    const porRota = new Map();
    for (const p of pontos) {
      if (!porRota.has(p.route_id)) porRota.set(p.route_id, []);
      porRota.get(p.route_id).push(p);
    }
    res.json({ rotas: rotas.map((r) => ({ ...r, waypoints: porRota.get(r.id) ?? [] })) });
  }),
);

rotasCatalogo.get(
  "/unidades",
  asyncHandler(async (req, res) => {
    const unidades = await q(
      `SELECT u.id, u.code, u.name, u.description, u.city, u.state_code, u.latitude, u.longitude, u.active,
              (SELECT COUNT(*) FROM weighing_stations ws WHERE ws.company_id = u.company_id AND ws.operational_unit_id = u.id AND ws.active = 1) AS postos
         FROM operational_units u WHERE u.company_id = ? ORDER BY u.name`,
      [req.usuario.companyId],
    );
    res.json({ unidades });
  }),
);

rotasCatalogo.get(
  "/postos",
  asyncHandler(async (req, res) => {
    const postos = await q(
      `SELECT ws.id, ws.code, ws.name, ws.description, ws.active, u.name AS unidade,
              b.name AS balanca, b.state AS balanca_estado, b.firmware_version AS balanca_firmware,
              l.name AS leitor_rfid, l.state AS leitor_estado
         FROM weighing_stations ws
         JOIN operational_units u ON u.company_id = ws.company_id AND u.id = ws.operational_unit_id
         LEFT JOIN devices b ON b.company_id = ws.company_id AND b.id = ws.scale_device_id
         LEFT JOIN devices l ON l.company_id = ws.company_id AND l.id = ws.rfid_reader_device_id
        WHERE ws.company_id = ? AND ws.active = 1 ORDER BY ws.name`,
      [req.usuario.companyId],
    );
    res.json({ postos });
  }),
);

rotasCatalogo.get(
  "/dispositivos",
  exigirPermissao("DEVICE_MANAGE", "TRACKING_VIEW", "DASHBOARD_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const dispositivos = await q(
      `SELECT d.id, d.name, d.device_type, d.serial_number, d.mac_address, d.ip_address,
              d.firmware_version, d.state, d.last_seen_at, d.last_calibrated_at, d.active,
              d.metadata AS metadata, u.name AS unidade,
              cal.performed_at AS calibrado_em, cal.expires_at AS calibracao_valida_ate, cal.result AS calibracao_resultado
         FROM devices d
         LEFT JOIN operational_units u ON u.company_id = d.company_id AND u.id = d.operational_unit_id
         LEFT JOIN vw_latest_device_calibration cal ON cal.company_id = d.company_id AND cal.device_id = d.id
        WHERE d.company_id = ? AND d.active = 1
        ORDER BY FIELD(d.device_type, 'ESP32','SCALE_CONTROLLER','LOAD_CELL','RFID_READER','GPRS_MODEM','OTHER'), d.name`,
      [empresa],
    );
    for (const d of dispositivos) {
      try {
        d.operacao_ativa_id = d.metadata ? (JSON.parse(d.metadata).operacaoAtivaId ?? null) : null;
      } catch {
        d.operacao_ativa_id = null;
      }
      delete d.metadata;
    }
    const resumo = {
      total: dispositivos.length,
      online: dispositivos.filter((d) => d.state === "ONLINE").length,
      offline: dispositivos.filter((d) => d.state === "OFFLINE").length,
      manutencao: dispositivos.filter((d) => d.state === "MAINTENANCE").length,
    };
    res.json({ dispositivos, resumo });
  }),
);

rotasCatalogo.get(
  "/resumo-cadastros",
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const linha = await um(
      `SELECT
         (SELECT COUNT(*) FROM vehicles WHERE company_id = ? AND active = 1) AS veiculos,
         (SELECT COUNT(*) FROM drivers WHERE company_id = ? AND active = 1) AS motoristas,
         (SELECT COUNT(*) FROM cargo_products WHERE company_id = ? AND active = 1) AS produtos,
         (SELECT COUNT(*) FROM routes WHERE company_id = ? AND active = 1) AS rotas,
         (SELECT COUNT(*) FROM devices WHERE company_id = ? AND active = 1) AS dispositivos,
         (SELECT COUNT(*) FROM weighing_stations WHERE company_id = ? AND active = 1) AS postos,
         (SELECT COUNT(*) FROM users WHERE company_id = ? AND active = 1) AS usuarios,
         (SELECT COUNT(*) FROM rfid_tags WHERE company_id = ? AND active = 1) AS etiquetas`,
      Array(8).fill(empresa),
    );
    res.json(linha);
  }),
);
