import { Router } from "express";
import { ErroHttp, asyncHandler, id, numero, paginacao, periodo, requerer, texto, dataMysql } from "../util.js";
import { autenticar, exigirPermissao, registrarAuditoria } from "../auth.js";
import { call, exec, q, um } from "../db.js";
import { mapearAlerta, mapearEvento, mapearLeitura, mapearOperacao } from "../mapeadores.js";
import { decifrar } from "../dados-pessoais.js";
import { queryComLimiteHistorico } from "../planos.js";
import { calcularRota } from "../rotas-mapa.js";

export const rotasOperacoes = Router();

const jsonSeguro = (valor) => {
  if (!valor) return null;
  try {
    return typeof valor === "string" ? JSON.parse(valor) : valor;
  } catch {
    return null;
  }
};
rotasOperacoes.use(autenticar);

const ORDENACAO_OPERACOES = {
  data: "COALESCE(o.completed_at, o.started_at)",
  codigo: "o.operation_code",
  placa: "v.plate",
  motorista: "d.full_name",
  rfid: "rfid.code",
  status: "o.status",
  vazio: "o.empty_truck_weight_kg",
  carga: "o.actual_cargo_weight_kg",
  esperado: "o.expected_gross_weight_kg",
  real: "o.loaded_truck_weight_kg",
  difKg: "o.difference_kg",
  difPct: "o.difference_percent",
};

export const SELECAO_OPERACAO = `
  SELECT o.id, o.company_id, o.operation_code, o.state, o.status, o.status_reason,
         o.movement_type, o.weighing_method, o.started_at, o.completed_at,
         o.planned_departure_at, o.departed_at, o.planned_arrival_at, o.arrived_at,
         o.cancelled_at, o.cancellation_reason,
         o.vehicle_id, o.driver_id, o.cargo_product_id, o.route_id,
         o.rfid_tag_id, o.tracking_enabled, o.tracking_activated_at, o.observations, o.invoice_number, o.mdfe_number, o.ciot_number,
         o.empty_truck_weight_kg, o.separated_cargo_weight_kg, o.declared_cargo_weight_kg,
         o.expected_gross_weight_kg, o.loaded_truck_weight_kg, o.actual_cargo_weight_kg,
         o.difference_kg, o.difference_percent, o.tare_difference_percent,
         o.registered_tare_snapshot_kg, o.gross_limit_snapshot_kg, o.payload_limit_snapshot_kg,
         o.tolerance_percent_snapshot, o.critical_limit_snapshot, o.tare_tolerance_snapshot,
         o.calculation_version, o.row_version,
         u.name AS operational_unit_name, ws.name AS weighing_station_name,
         v.plate AS vehicle_plate, v.fleet_code, v.vehicle_type,
         d.full_name AS driver_name, rfid.code AS rfid_code,
         cp.name AS cargo_product_name, rt.origin, rt.destination, rt.distance_km AS route_distance_km,
         resp.full_name AS responsible_user_name, cri.full_name AS created_by_user_name,
         ots.tracking_state, ots.current_latitude, ots.current_longitude, ots.speed_kmh,
         ots.heading_degrees, ots.progress_percent, ots.route_deviation_meters,
         ots.estimated_arrival_at, ots.delay_minutes, ots.last_position_at, ots.stopped_since, ots.updated_at
    FROM weighing_operations o
    JOIN operational_units u ON u.company_id = o.company_id AND u.id = o.operational_unit_id
    LEFT JOIN weighing_stations ws ON ws.company_id = o.company_id AND ws.id = o.weighing_station_id
    JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
    LEFT JOIN drivers d ON d.company_id = o.company_id AND d.id = o.driver_id
    LEFT JOIN rfid_tags rfid ON rfid.company_id = o.company_id AND rfid.id = o.rfid_tag_id
    LEFT JOIN cargo_products cp ON cp.company_id = o.company_id AND cp.id = o.cargo_product_id
    LEFT JOIN routes rt ON rt.company_id = o.company_id AND rt.id = o.route_id
    LEFT JOIN users resp ON resp.company_id = o.company_id AND resp.id = o.responsible_user_id
    LEFT JOIN users cri ON cri.company_id = o.company_id AND cri.id = o.created_by_user_id
    LEFT JOIN operation_tracking_status ots ON ots.company_id = o.company_id AND ots.operation_id = o.id`;

export function montarFiltrosOperacoes(query, empresa) {
  const { inicio, fim } = periodo(query);

  const estados =
    texto(query.estado)
      ?.split(",")
      .map((e) => e.trim().toUpperCase())
      .filter(Boolean) ?? null;
  const status =
    texto(query.status)
      ?.split(",")
      .map((s) => s.trim().toUpperCase())
      .filter(Boolean) ?? null;
  const busca = texto(query.busca) ? `%${texto(query.busca)}%` : null;
  const rastreio =
    texto(query.rastreio)
      ?.split(",")
      .map((e) => e.trim().toUpperCase())
      .filter(Boolean) ?? null;

  const condicoes = ["o.company_id = ?", "COALESCE(o.completed_at, o.started_at) BETWEEN ? AND ?"];
  const params = [empresa, inicio, fim];
  if (estados) {
    condicoes.push(`o.state IN (${estados.map(() => "?").join(",")})`);
    params.push(...estados);
  }
  if (status) {
    condicoes.push(`o.status IN (${status.map(() => "?").join(",")})`);
    params.push(...status);
  }
  if (busca) {
    condicoes.push("(o.operation_code LIKE ? OR v.plate LIKE ? OR d.full_name LIKE ? OR cp.name LIKE ?)");
    params.push(busca, busca, busca, busca);
  }
  if (id(query.veiculoId)) {
    condicoes.push("o.vehicle_id = ?");
    params.push(id(query.veiculoId));
  }
  if (id(query.rotaId)) {
    condicoes.push("o.route_id = ?");
    params.push(id(query.rotaId));
  }
  if (id(query.produtoId)) {
    condicoes.push("o.cargo_product_id = ?");
    params.push(id(query.produtoId));
  }
  if (id(query.motoristaId)) {
    condicoes.push("o.driver_id = ?");
    params.push(id(query.motoristaId));
  }
  if (texto(query.origem)) {
    condicoes.push("rt.origin LIKE ?");
    params.push(`%${texto(query.origem)}%`);
  }
  if (texto(query.destino)) {
    condicoes.push("rt.destination LIKE ?");
    params.push(`%${texto(query.destino)}%`);
  }
  if (rastreio) {
    condicoes.push(`COALESCE(ots.tracking_state, 'NOT_STARTED') IN (${rastreio.map(() => "?").join(",")})`);
    params.push(...rastreio);
  }

  const onde = condicoes.join(" AND ");
  const chaveOrdem = texto(query.ordem);
  const coluna =
    chaveOrdem && Object.hasOwn(ORDENACAO_OPERACOES, chaveOrdem)
      ? ORDENACAO_OPERACOES[chaveOrdem]
      : ORDENACAO_OPERACOES.data;
  const direcao = texto(query.direcao)?.toLowerCase() === "asc" ? "ASC" : "DESC";
  return { onde, params, coluna, direcao };
}

rotasOperacoes.get(
  "/operacoes",
  exigirPermissao("OPERATION_VIEW", "DASHBOARD_VIEW", "TRACKING_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const consulta = await queryComLimiteHistorico(req);
    const { pagina, limite, offset } = paginacao(consulta);
    const { onde, params, coluna, direcao } = montarFiltrosOperacoes(consulta, empresa);
    const linhas = await q(
      `${SELECAO_OPERACAO} WHERE ${onde} ORDER BY ${coluna} ${direcao}, o.id DESC LIMIT ? OFFSET ?`,
      [...params, limite, offset],
    );
    const total = await um(
      `SELECT COUNT(*) AS total FROM weighing_operations o
        JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
        LEFT JOIN drivers d ON d.company_id = o.company_id AND d.id = o.driver_id
        LEFT JOIN cargo_products cp ON cp.company_id = o.company_id AND cp.id = o.cargo_product_id
        LEFT JOIN routes rt ON rt.company_id = o.company_id AND rt.id = o.route_id
        LEFT JOIN operation_tracking_status ots ON ots.company_id = o.company_id AND ots.operation_id = o.id
       WHERE ${onde}`,
      params,
    );

    res.json({ operacoes: linhas.map(mapearOperacao), pagina, limite, total: total?.total ?? 0 });
  }),
);

rotasOperacoes.get(
  "/operacoes/:id",
  exigirPermissao("OPERATION_VIEW", "TRACKING_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    requerer(opId, 400, "Identificador inválido.");

    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    if (!linha) throw new ErroHttp(404, "Operação não encontrada.");

    const leituras = await q(
      `SELECT * FROM weighing_readings WHERE company_id = ? AND operation_id = ? ORDER BY stage, sequence_number`,
      [empresa, opId],
    );
    const eventos = await q(
      `SELECT e.*, usr.full_name AS user_name
         FROM operation_events e
         LEFT JOIN users usr ON usr.company_id = e.company_id AND usr.id = e.user_id
        WHERE e.company_id = ? AND e.operation_id = ?
        ORDER BY e.created_at DESC, e.id DESC LIMIT 100`,
      [empresa, opId],
    );
    const alertas = await q(
      `SELECT a.*, usr.full_name AS acknowledged_by_user_name, rsv.full_name AS resolved_by_user_name
         FROM alerts a
         LEFT JOIN users usr ON usr.company_id = a.company_id AND usr.id = a.acknowledged_by_user_id
         LEFT JOIN users rsv ON rsv.company_id = a.company_id AND rsv.id = a.resolved_by_user_id
        WHERE a.company_id = ? AND a.operation_id = ?
        ORDER BY a.created_at DESC LIMIT 50`,
      [empresa, opId],
    );
    const pontosRastreio = await q(
      `SELECT id, latitude, longitude, speed_kmh, heading_degrees, accuracy_meters, progress_percent,
              route_deviation_meters, estimated_arrival_at, signal_strength_dbm, recorded_at, received_at
         FROM operation_tracking_points
        WHERE company_id = ? AND operation_id = ?
        ORDER BY recorded_at DESC LIMIT 200`,
      [empresa, opId],
    );
    const waypoints = linha.route_id
      ? await q(
          `SELECT sequence_number, waypoint_type, label, latitude, longitude
             FROM route_waypoints WHERE company_id = ? AND route_id = ? ORDER BY sequence_number`,
          [empresa, linha.route_id],
        )
      : [];

    const contato = linha.driver_id
      ? await um(`SELECT phone FROM drivers WHERE company_id = ? AND id = ?`, [empresa, linha.driver_id])
      : null;
    const auditoria = await q(
      `SELECT a.id, a.action, a.old_values, a.new_values, a.created_at, usr.full_name AS user_name
         FROM audit_logs a
         LEFT JOIN users usr ON usr.company_id = a.company_id AND usr.id = a.user_id
        WHERE a.company_id = ? AND a.entity_name = 'weighing_operations' AND a.entity_id = ?
        ORDER BY a.created_at DESC, a.id DESC LIMIT 50`,
      [empresa, String(opId)],
    );

    res.json({
      ...mapearOperacao(linha),
      motoristaTelefone: contato ? decifrar(contato.phone) : null,
      leituras: leituras.map(mapearLeitura),
      eventos: eventos.map(mapearEvento),
      alertas: alertas.map(mapearAlerta),
      auditoria: auditoria.map((a) => ({
        id: a.id,
        acao: a.action,
        usuario: a.user_name ?? null,
        antes: jsonSeguro(a.old_values),
        depois: jsonSeguro(a.new_values),
        criadoEm: a.created_at,
      })),
      trajeto: pontosRastreio,
      waypoints,
    });
  }),
);

export async function resolverReferencias(db, empresa, corpo) {
  const um = db.um;
  const veiculoId = id(corpo.veiculoId);
  const veiculo = veiculoId
    ? await um(
        `SELECT id, plate, registered_tare_kg, gross_weight_limit_kg, payload_limit_kg FROM vehicles WHERE company_id = ? AND id = ? AND active = 1`,
        [empresa, veiculoId],
      )
    : await um(
        `SELECT id, plate, registered_tare_kg, gross_weight_limit_kg, payload_limit_kg FROM vehicles WHERE company_id = ? AND plate = ? AND active = 1`,
        [empresa, texto(corpo.placa)?.toUpperCase()],
      );
  requerer(veiculo, 422, "Veículo não encontrado ou inativo nesta empresa.");

  let motoristaId = id(corpo.motoristaId);
  if (!motoristaId && texto(corpo.motorista)) {
    const d = await um(`SELECT id FROM drivers WHERE company_id = ? AND full_name = ? AND active = 1 LIMIT 1`, [
      empresa,
      texto(corpo.motorista),
    ]);
    requerer(d, 422, `Motorista "${texto(corpo.motorista)}" não encontrado ou inativo. Cadastre-o ou escolha outro.`);
    motoristaId = d.id;
  }
  if (motoristaId) {
    const d = await um(`SELECT id FROM drivers WHERE company_id = ? AND id = ? AND active = 1`, [empresa, motoristaId]);
    requerer(d, 422, "Motorista não encontrado ou inativo.");
  }

  let produtoId = id(corpo.produtoId);
  if (!produtoId && texto(corpo.produto)) {
    const p = await um(`SELECT id FROM cargo_products WHERE company_id = ? AND name = ? AND active = 1 LIMIT 1`, [
      empresa,
      texto(corpo.produto),
    ]);
    produtoId = p?.id ?? null;
  }

  let rotaId = id(corpo.rotaId);
  if (!rotaId && texto(corpo.rotaCodigo)) {
    const r = await um(`SELECT id FROM routes WHERE company_id = ? AND code = ? AND active = 1 LIMIT 1`, [
      empresa,
      texto(corpo.rotaCodigo),
    ]);
    rotaId = r?.id ?? null;
  }
  const rota = rotaId
    ? await um(`SELECT id, origin, destination, distance_km FROM routes WHERE company_id = ? AND id = ?`, [
        empresa,
        rotaId,
      ])
    : null;

  let rfidId = id(corpo.rfidTagId);
  const rfidCodigo = texto(corpo.rfid) ?? texto(corpo.rfidCodigo);
  if (!rfidId && rfidCodigo) {
    const t = await um(`SELECT id, vehicle_id, active FROM rfid_tags WHERE company_id = ? AND code = ? LIMIT 1`, [
      empresa,
      rfidCodigo,
    ]);
    if (t) {
      requerer(Boolean(t.active), 422, "A etiqueta RFID informada está inativa.");
      requerer(t.vehicle_id === veiculo.id, 422, "A etiqueta RFID não pertence ao veículo informado.");
      rfidId = t.id;
    }
  }

  const unidade = await um(
    `SELECT id FROM operational_units WHERE company_id = ? AND active = 1 ORDER BY (code = 'MATRIZ') DESC, id LIMIT 1`,
    [empresa],
  );
  requerer(unidade, 422, "Nenhuma unidade operacional ativa cadastrada para a empresa.");

  const posto = await um(
    `SELECT id FROM weighing_stations WHERE company_id = ? AND operational_unit_id = ? AND active = 1 ORDER BY id LIMIT 1`,
    [empresa, unidade.id],
  );

  return { veiculo, motoristaId, produtoId, rota, rotaId, rfidId, unidadeId: unidade.id, postoId: posto?.id ?? null };
}

export async function proximoCodigoOperacao(empresa, db = { um }) {
  const um = db.um;
  const agora = new Date();
  const base = `PES-${agora.getFullYear()}${String(agora.getMonth() + 1).padStart(2, "0")}${String(
    agora.getDate(),
  ).padStart(2, "0")}`;
  const { ultimo } = await um(
    `SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(operation_code, '-', -1) AS UNSIGNED)), 0) AS ultimo
       FROM weighing_operations
      WHERE company_id = ? AND operation_code LIKE ?`,
    [empresa, `${base}-%`],
  );
  return { base, sequencia: Number(ultimo) + 1 };
}

export async function criarOperacao(db, empresa, usuarioId, corpo) {
  const ref = await resolverReferencias(db, empresa, corpo);
  const metodo = texto(corpo.metodo, "GROSS_TARE")?.toUpperCase();
  requerer(["THREE_STAGE", "GROSS_TARE"].includes(metodo), 422, "Método de pesagem inválido.");
  const movimento = (texto(corpo.tipoMovimento, "WEIGHING_ONLY") ?? "").toUpperCase();
  requerer(["ENTRY", "EXIT", "TRANSFER", "WEIGHING_ONLY"].includes(movimento), 422, "Tipo de movimentação inválido.");

  const valores = [
    empresa,
    ref.unidadeId,
    ref.postoId,
    movimento,
    metodo,
    ref.veiculo.id,
    ref.motoristaId,
    ref.rfidId,
    ref.produtoId,
    ref.rotaId,
    usuarioId,
    usuarioId,
    numero(corpo.pesoDeclaradoKg),
    numero(corpo.quantidadeDeclarada),
    texto(corpo.unidadeDeclarada)?.toUpperCase() ?? (corpo.quantidadeDeclarada ? "KG" : null),
    texto(corpo.notaFiscal),
    texto(corpo.mdfe),
    texto(corpo.ciot),
    texto(corpo.observacoes),
  ];

  const { base, sequencia } = await proximoCodigoOperacao(empresa);
  let res1;
  for (let tentativa = 0; tentativa < 5 && !res1; tentativa += 1) {
    try {
      res1 = await db.exec(
        `INSERT INTO weighing_operations
         (company_id, operational_unit_id, weighing_station_id, movement_type, weighing_method,
          vehicle_id, driver_id, rfid_tag_id, cargo_product_id, route_id,
          responsible_user_id, created_by_user_id, declared_cargo_weight_kg, declared_quantity,
          declared_quantity_unit, invoice_number, mdfe_number, ciot_number, observations,
          operation_code)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [...valores, `${base}-${String(sequencia + tentativa).padStart(4, "0")}`],
      );
    } catch (erro) {
      if (erro?.code !== "ER_DUP_ENTRY") throw erro;
    }
  }
  if (!res1) {
    const erro = new Error("Não foi possível gerar um código único para a operação.");
    erro.status = 409;
    throw erro;
  }

  return res1.insertId;
}

rotasOperacoes.post(
  "/operacoes",
  exigirPermissao("OPERATION_CREATE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const insertId = await criarOperacao({ um, exec }, empresa, req.usuario.id, req.body ?? {});
    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, insertId]);
    res.status(201).json(mapearOperacao(linha));
  }),
);

rotasOperacoes.post(
  "/operacoes/:id/leituras",
  exigirPermissao("READING_CREATE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    const corpo = req.body ?? {};
    requerer(opId, 400, "Identificador inválido.");

    const operacao = await um(
      `SELECT id, state, weighing_method FROM weighing_operations WHERE company_id = ? AND id = ?`,
      [empresa, opId],
    );
    if (!operacao) throw new ErroHttp(404, "Operação não encontrada.");
    requerer(
      !["COMPLETED", "CANCELLED"].includes(operacao.state),
      422,
      "Operação concluída ou cancelada não recebe novas leituras.",
    );

    const estagio = texto(corpo.estagio)?.toUpperCase();
    requerer(
      ["EMPTY_TRUCK", "SEPARATED_CARGO", "LOADED_TRUCK"].includes(estagio),
      422,
      "Estágio inválido (use EMPTY_TRUCK, SEPARATED_CARGO ou LOADED_TRUCK).",
    );

    const pesoKg = numero(corpo.pesoKg);
    requerer(pesoKg !== null && pesoKg >= 0, 422, "Informe o peso aferido em kg.");

    const origem = (texto(corpo.origem, "DEVICE") ?? "").toUpperCase();
    requerer(["DEVICE", "MANUAL", "IMPORT"].includes(origem), 422, "Origem da leitura inválida.");

    let dispositivoId = id(corpo.dispositivoId);
    if (origem === "DEVICE" && !dispositivoId) {
      const disp = await um(
        `SELECT id FROM devices WHERE company_id = ? AND active = 1 AND state <> 'DISABLED'
          ORDER BY FIELD(device_type, 'SCALE_CONTROLLER', 'ESP32', 'LOAD_CELL', 'OTHER'), id LIMIT 1`,
        [empresa],
      );
      requerer(disp, 422, "Nenhum dispositivo de pesagem ativo cadastrado para registrar leitura automática.");
      dispositivoId = disp.id;
    }

    const sequencia = await um(
      `SELECT COALESCE(MAX(sequence_number), 0) + 1 AS proxima FROM weighing_readings WHERE operation_id = ? AND stage = ?`,
      [opId, estagio],
    );

    const res1 = await exec(
      `INSERT INTO weighing_readings
         (company_id, operation_id, stage, sequence_number, weight_kg, source, device_id, is_stable,
          checksum_valid, signal_strength_dbm, manual_reason, measured_at, created_by_user_id, raw_payload)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, COALESCE(?, CURRENT_TIMESTAMP(3)), ?, ?)`,
      [
        empresa,
        opId,
        estagio,
        sequencia?.proxima ?? 1,
        pesoKg,
        origem,
        dispositivoId,
        corpo.estavel === false ? 0 : 1,
        corpo.checksumValido === undefined || corpo.checksumValido === null ? null : corpo.checksumValido ? 1 : 0,
        numero(corpo.sinalDbm),
        texto(corpo.motivoManual),
        dataMysql(corpo.medidoEm),
        req.usuario.id,
        corpo.bruto === undefined ? null : JSON.stringify(corpo.bruto),
      ],
    );

    const aceitar = corpo.aceitar !== false;
    if (aceitar) {
      await call("sp_accept_weighing_reading", [empresa, res1.insertId, req.usuario.id]);
    }

    const leitura = await um(`SELECT * FROM weighing_readings WHERE company_id = ? AND id = ?`, [
      empresa,
      res1.insertId,
    ]);
    const operacaoAtualizada = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);

    res.status(201).json({ leitura: mapearLeitura(leitura), operacao: mapearOperacao(operacaoAtualizada) });
  }),
);

rotasOperacoes.post(
  "/operacoes/:id/leituras/:leituraId/aceitar",
  exigirPermissao("READING_ACCEPT"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    const leituraId = id(req.params.leituraId);

    const leitura = await um(`SELECT id FROM weighing_readings WHERE company_id = ? AND id = ? AND operation_id = ?`, [
      empresa,
      leituraId,
      opId,
    ]);
    if (!leitura) throw new ErroHttp(404, "Leitura não encontrada para esta operação.");

    await call("sp_accept_weighing_reading", [empresa, leituraId, req.usuario.id]);
    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    res.json(mapearOperacao(linha));
  }),
);

rotasOperacoes.post(
  "/operacoes/:id/finalizar",
  exigirPermissao("OPERATION_FINALIZE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    const existe = await um(`SELECT id FROM weighing_operations WHERE company_id = ? AND id = ?`, [empresa, opId]);
    if (!existe) throw new ErroHttp(404, "Operação não encontrada.");

    await call("sp_finalize_weighing_operation", [empresa, opId, req.usuario.id]);

    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    const alertas = await q(
      `SELECT a.* FROM alerts a WHERE a.company_id = ? AND a.operation_id = ? AND a.state IN ('OPEN','ACKNOWLEDGED') ORDER BY a.severity DESC, a.created_at DESC`,
      [empresa, opId],
    );
    res.json({ operacao: mapearOperacao(linha), alertas: alertas.map(mapearAlerta) });
  }),
);

rotasOperacoes.post(
  "/operacoes/:id/cancelar",
  exigirPermissao("OPERATION_CANCEL"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    const motivo = texto(req.body?.motivo);
    requerer(motivo, 422, "Informe o motivo do cancelamento.");
    const existe = await um(`SELECT id FROM weighing_operations WHERE company_id = ? AND id = ?`, [empresa, opId]);
    if (!existe) throw new ErroHttp(404, "Operação não encontrada.");

    await call("sp_cancel_weighing_operation", [empresa, opId, req.usuario.id, motivo]);
    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    res.json(mapearOperacao(linha));
  }),
);

rotasOperacoes.post(
  "/operacoes/:id/transporte/agenda",
  exigirPermissao("TRACKING_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    const saida = dataMysql(req.body?.saidaPlanejada);
    const chegada = dataMysql(req.body?.chegadaPlanejada);
    await call("sp_set_transport_schedule", [empresa, opId, req.usuario.id, saida, chegada]);
    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    res.json(mapearOperacao(linha));
  }),
);

rotasOperacoes.post(
  "/operacoes/:id/transporte/iniciar",
  exigirPermissao("TRACKING_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    await call("sp_start_transport", [empresa, opId, req.usuario.id]);
    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    res.json(mapearOperacao(linha));
  }),
);

rotasOperacoes.post(
  "/operacoes/:id/transporte/chegada",
  exigirPermissao("TRACKING_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    await call("sp_mark_transport_arrived", [empresa, opId, req.usuario.id]);
    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    res.json(mapearOperacao(linha));
  }),
);

rotasOperacoes.post(
  "/operacoes/:id/transporte/cancelar",
  exigirPermissao("TRACKING_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    const motivo = texto(req.body?.motivo);
    requerer(motivo, 422, "Informe o motivo do cancelamento do transporte.");
    await call("sp_cancel_transport", [empresa, opId, req.usuario.id, motivo]);
    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    res.json(mapearOperacao(linha));
  }),
);

rotasOperacoes.post(
  "/operacoes/:id/rastreio/ativar",
  exigirPermissao("TRACKING_MANAGE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    const codigo = texto(req.body?.codigoRfid);
    requerer(codigo && /^[A-Za-z0-9._:-]{1,100}$/.test(codigo), 422, "Informe o código RFID fornecido pela empresa.");

    const operacao = await um(
      `SELECT id, vehicle_id, rfid_tag_id, state, tracking_enabled FROM weighing_operations WHERE company_id = ? AND id = ?`,
      [empresa, opId],
    );
    if (!operacao) throw new ErroHttp(404, "Operação não encontrada.");
    requerer(
      operacao.state !== "CANCELLED" && operacao.state !== "COMPLETED",
      409,
      "Não é possível ativar o rastreio de uma operação concluída ou cancelada.",
    );

    const etiqueta = await um(
      `SELECT id, vehicle_id, active FROM rfid_tags WHERE company_id = ? AND code = ? LIMIT 1`,
      [empresa, codigo],
    );
    if (!etiqueta) throw new ErroHttp(422, "Código RFID não encontrado nesta empresa. Confira o código fornecido.");
    requerer(Boolean(etiqueta.active), 422, "A etiqueta RFID informada está inativa.");
    requerer(
      Number(etiqueta.vehicle_id) === Number(operacao.vehicle_id),
      422,
      "A etiqueta RFID não pertence ao caminhão desta operação.",
    );
    requerer(
      !operacao.rfid_tag_id || Number(operacao.rfid_tag_id) === Number(etiqueta.id),
      422,
      "A operação já tem outra etiqueta RFID vinculada.",
    );

    const jaAtivo = Boolean(operacao.tracking_enabled) && Number(operacao.rfid_tag_id) === Number(etiqueta.id);
    if (!jaAtivo) {
      await exec(
        `UPDATE weighing_operations
            SET tracking_enabled = 1,
                tracking_activated_at = COALESCE(tracking_activated_at, CURRENT_TIMESTAMP(3)),
                rfid_tag_id = ?
          WHERE company_id = ? AND id = ?`,
        [etiqueta.id, empresa, opId],
      );
      await registrarAuditoria(
        empresa,
        req.usuario.id,
        "TRACKING_ACTIVATED",
        "weighing_operations",
        opId,
        { codigoRfid: codigo },
        req.ip,
        req.get("user-agent"),
      );
    }

    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    res.json(mapearOperacao(linha));
  }),
);

rotasOperacoes.post(
  "/operacoes/:id/rastreio",
  exigirPermissao("TRACKING_MANAGE", "READING_CREATE"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    const corpo = req.body ?? {};
    const lat = numero(corpo.latitude);
    const lng = numero(corpo.longitude);
    requerer(lat !== null && lat >= -90 && lat <= 90, 422, "Latitude inválida.");
    requerer(lng !== null && lng >= -180 && lng <= 180, 422, "Longitude inválida.");

    const operacao = await um(
      `SELECT id, route_id, tracking_enabled FROM weighing_operations WHERE company_id = ? AND id = ?`,
      [empresa, opId],
    );
    if (!operacao) throw new ErroHttp(404, "Operação não encontrada.");
    requerer(
      Boolean(operacao.tracking_enabled),
      409,
      "O rastreio ainda não está ativado. Informe o código RFID fornecido pela empresa.",
    );

    const res1 = await exec(
      `INSERT INTO operation_tracking_points
         (company_id, operation_id, device_id, latitude, longitude, speed_kmh, heading_degrees, accuracy_meters,
          progress_percent, route_deviation_meters, estimated_arrival_at, signal_strength_dbm, raw_payload, recorded_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, COALESCE(?, CURRENT_TIMESTAMP(3)), ?, ?, COALESCE(?, CURRENT_TIMESTAMP(3)))`,
      [
        empresa,
        opId,
        null,
        lat,
        lng,
        numero(corpo.velocidadeKmh),
        numero(corpo.rumo),
        numero(corpo.precisaoM),
        numero(corpo.progressoPct),
        numero(corpo.desvioMetros),
        dataMysql(corpo.eta),
        numero(corpo.sinalDbm),
        corpo.bruto === undefined ? null : JSON.stringify(corpo.bruto),
        dataMysql(corpo.registradoEm),
      ],
    );

    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    res.status(201).json({ pontoId: res1.insertId, operacao: mapearOperacao(linha) });
  }),
);

rotasOperacoes.get(
  "/operacoes/:id/rota",
  exigirPermissao("TRACKING_VIEW", "OPERATION_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    if (!linha) throw new ErroHttp(404, "Operação não encontrada.");
    const paradas = linha.route_id
      ? await q(
          `SELECT sequence_number, waypoint_type, label, latitude, longitude FROM route_waypoints WHERE company_id = ? AND route_id = ? ORDER BY sequence_number`,
          [empresa, linha.route_id],
        )
      : [];
    const rota = await calcularRota(paradas);
    res.json({ operacaoId: opId, ...rota, paradas });
  }),
);

rotasOperacoes.get(
  "/operacoes/:id/rastreio",
  exigirPermissao("TRACKING_VIEW", "OPERATION_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const opId = id(req.params.id);
    const linha = await um(`${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.id = ?`, [empresa, opId]);
    if (!linha) throw new ErroHttp(404, "Operação não encontrada.");

    const pontos = await q(
      `SELECT id, latitude, longitude, speed_kmh, heading_degrees, progress_percent, route_deviation_meters,
              estimated_arrival_at, recorded_at
         FROM operation_tracking_points WHERE company_id = ? AND operation_id = ?
        ORDER BY recorded_at DESC LIMIT 300`,
      [empresa, opId],
    );
    const waypoints = linha.route_id
      ? await q(
          `SELECT sequence_number, waypoint_type, label, latitude, longitude FROM route_waypoints WHERE company_id = ? AND route_id = ? ORDER BY sequence_number`,
          [empresa, linha.route_id],
        )
      : [];

    res.json({ operacao: mapearOperacao(linha), pontos, waypoints });
  }),
);

rotasOperacoes.get(
  "/sincronia",
  autenticar,
  asyncHandler(async (req, res) => {
    const e = req.usuario.companyId;
    const [linha] = await q(
      `SELECT CONCAT_WS('|',
          (SELECT COALESCE(MAX(id),0) FROM weighing_operations WHERE company_id = ?),
          (SELECT COALESCE(UNIX_TIMESTAMP(MAX(updated_at)),0) FROM weighing_operations WHERE company_id = ?),
          (SELECT COALESCE(MAX(id),0) FROM operation_tracking_points WHERE company_id = ?),
          (SELECT COALESCE(MAX(id),0) FROM alerts WHERE company_id = ?),
          (SELECT COALESCE(UNIX_TIMESTAMP(MAX(created_at)),0) FROM alerts WHERE company_id = ?),
          (SELECT COALESCE(MAX(id),0) FROM operation_events WHERE company_id = ?),
          (SELECT COALESCE(UNIX_TIMESTAMP(MAX(updated_at)),0) FROM routes WHERE company_id = ?),
          (SELECT COALESCE(MAX(id),0) FROM route_waypoints WHERE company_id = ?),
          (SELECT COALESCE(MAX(id),0) FROM weighing_readings WHERE company_id = ?),
          (SELECT COALESCE(UNIX_TIMESTAMP(MAX(updated_at)),0) FROM devices WHERE company_id = ?)
        ) AS versao`,
      [e, e, e, e, e, e, e, e, e, e],
    );
    res.set("Cache-Control", "no-store");
    res.json({ versao: linha?.versao ?? "0" });
  }),
);

const rastreioRotasHandler = asyncHandler(async (req, res) => {
  const empresa = req.usuario.companyId;
  const operacoes = await q(
    `SELECT o.id, o.route_id FROM weighing_operations o
      WHERE o.company_id = ? AND o.tracking_enabled = 1 AND o.state <> 'CANCELLED' AND o.route_id IS NOT NULL AND o.id IN (SELECT o2.id FROM weighing_operations o2 LEFT JOIN operation_tracking_status ots ON ots.company_id = o2.company_id AND ots.operation_id = o2.id WHERE o2.company_id = ? AND o2.tracking_enabled = 1 AND o2.state <> 'CANCELLED' AND (COALESCE(ots.tracking_state, 'NOT_STARTED') IN ('IN_TRANSIT','STOPPED') OR (COALESCE(ots.tracking_state, 'NOT_STARTED') = 'SIGNAL_LOST' AND o2.state <> 'COMPLETED') OR (COALESCE(ots.tracking_state, 'NOT_STARTED') = 'NOT_STARTED' AND o2.state <> 'COMPLETED')))`,
    [empresa, empresa],
  );
  const paradas = await q(
    `SELECT route_id, sequence_number, latitude, longitude FROM route_waypoints
      WHERE company_id = ? ORDER BY route_id, sequence_number`,
    [empresa],
  );
  const porRota = new Map();
  for (const p of paradas) {
    if (!porRota.has(p.route_id)) porRota.set(p.route_id, []);
    porRota.get(p.route_id).push(p);
  }
  const rotaIds = [...new Set(operacoes.map((o) => o.route_id))];
  const calculadas = new Map(
    await Promise.all(rotaIds.map(async (rid) => [rid, await calcularRota(porRota.get(rid) ?? [])])),
  );
  const rotas = {};
  for (const o of operacoes) {
    rotas[o.id] = { operacaoId: o.id, routeId: o.route_id, ...calculadas.get(o.route_id) };
  }
  res.json({ rotas });
});
rotasOperacoes.get("/rastreio/rotas", exigirPermissao("TRACKING_VIEW", "DASHBOARD_VIEW"), rastreioRotasHandler);

rotasOperacoes.get(
  "/rastreio/ativo",
  exigirPermissao("TRACKING_VIEW", "DASHBOARD_VIEW"),
  asyncHandler(async (req, res) => {
    const empresa = req.usuario.companyId;
    const concluidas = String(req.query.concluidas ?? "") === "1";
    const linhas = concluidas
      ? await q(
          `${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.tracking_enabled = 1 AND o.state <> 'CANCELLED' AND o.state = 'COMPLETED' AND COALESCE(ots.tracking_state, 'NOT_STARTED') NOT IN ('IN_TRANSIT','STOPPED') ORDER BY ots.last_position_at DESC LIMIT 200`,
          [empresa],
        )
      : await q(
          `${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.tracking_enabled = 1 AND o.state <> 'CANCELLED' AND (COALESCE(ots.tracking_state, 'NOT_STARTED') IN ('IN_TRANSIT','STOPPED') OR (COALESCE(ots.tracking_state, 'NOT_STARTED') IN ('NOT_STARTED','SIGNAL_LOST') AND o.state <> 'COMPLETED')) ORDER BY ots.last_position_at DESC`,
          [empresa],
        );
    const semAtivacao = concluidas
      ? []
      : await q(
          `${SELECAO_OPERACAO} WHERE o.company_id = ? AND o.tracking_enabled = 0 AND o.state IN ('DRAFT','IN_PROGRESS') ORDER BY o.id DESC LIMIT 100`,
          [empresa],
        );

    const waypoints = await q(
      `SELECT w.route_id, w.sequence_number, w.waypoint_type, w.label, w.latitude, w.longitude
         FROM route_waypoints w WHERE w.company_id = ? ORDER BY w.route_id, w.sequence_number`,
      [empresa],
    );
    const porRota = new Map();
    for (const w of waypoints) {
      if (!porRota.has(w.route_id)) porRota.set(w.route_id, []);
      porRota.get(w.route_id).push(w);
    }

    res.json({
      viagens: linhas.map((l) => ({ ...mapearOperacao(l), waypoints: porRota.get(l.route_id) ?? [] })),
      aguardandoAtivacao: semAtivacao.map((l) => {
        const op = mapearOperacao(l);
        return { id: op.id, codigo: op.codigo, placa: op.veiculo?.placa ?? null };
      }),
    });
  }),
);

rotasOperacoes.post(
  "/rastreio/avaliar",
  exigirPermissao("TRACKING_MANAGE"),
  asyncHandler(async (req, res) => {
    await call("sp_evaluate_tracking_alerts", [req.usuario.companyId]);
    const alertas = await q(
      `SELECT alert_type, COUNT(*) AS total FROM alerts
        WHERE company_id = ? AND alert_context = 'TRACKING' AND state IN ('OPEN','ACKNOWLEDGED')
        GROUP BY alert_type`,
      [req.usuario.companyId],
    );
    res.json({ ok: true, alertasAbertos: alertas });
  }),
);
