import crypto from "node:crypto";
import { ErroHttp } from "./util.js";
import { exec, um } from "./db.js";
import { segredoJwt } from "./segredo.js";
import { enviarEmail, emailConfigurado, mascararEmail } from "./email.js";

const SEGREDO = segredoJwt();
const MINUTOS_VALIDADE = 10;
const INTERVALO_REENVIO_S = 60;
const EXIBIR_CODIGO = process.env.LS_EXIBIR_CODIGO === "1";

const sqlData = (d) => d.toISOString().slice(0, 23).replace("T", " ");
const hashCodigo = (userId, finalidade, codigo) =>
  crypto.createHash("sha256").update(`${userId}|${finalidade}|${codigo}|${SEGREDO}`).digest("hex");

let tabelaPronta = null;

export function garantirTabela() {
  tabelaPronta ??= garantirContadorCodigo()
    .then(() =>
      exec(`
    CREATE TABLE IF NOT EXISTS two_factor_codes (
      id bigint unsigned NOT NULL AUTO_INCREMENT,
      company_id bigint unsigned NOT NULL,
      user_id bigint unsigned NOT NULL,
      purpose enum('LOGIN','ENABLE','DISABLE') NOT NULL,
      token_hash char(64) NOT NULL,
      expires_at datetime(3) NOT NULL,
      used_at datetime(3) DEFAULT NULL,
      created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (id),
      UNIQUE KEY uq_two_factor_hash (token_hash),
      KEY idx_two_factor_user (company_id, user_id, purpose, expires_at),
      CONSTRAINT fk_two_factor_user FOREIGN KEY (company_id, user_id) REFERENCES users (company_id, id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci`),
    )
    .catch((erro) => {
      tabelaPronta = null;
      throw erro;
    });
  return tabelaPronta;
}

async function garantirContadorCodigo() {
  const linhas = await um(
    `SELECT 1 AS existe FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'failed_2fa_attempts'`,
  );
  if (!linhas)
    await exec(
      "ALTER TABLE users ADD COLUMN failed_2fa_attempts INT UNSIGNED NOT NULL DEFAULT 0 AFTER failed_login_attempts",
    );
  const bloqueio = await um(
    `SELECT 1 AS existe FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'locked_until_2fa'`,
  );
  if (!bloqueio) await exec("ALTER TABLE users ADD COLUMN locked_until_2fa DATETIME(3) NULL AFTER locked_until");
}

function ehLocal(req) {
  const ip = req.socket?.remoteAddress ?? "";
  return ip === "127.0.0.1" || ip === "::1" || ip === "::ffff:127.0.0.1";
}

export async function enviarCodigo(req, usuario, finalidade) {
  await garantirTabela();
  const recente = await um(
    `SELECT created_at FROM two_factor_codes
      WHERE company_id = ? AND user_id = ? AND purpose = ? AND created_at > (CURRENT_TIMESTAMP(3) - INTERVAL ? SECOND)
      ORDER BY created_at DESC LIMIT 1`,
    [usuario.company_id, usuario.id, finalidade, INTERVALO_REENVIO_S],
  );
  if (recente) {
    throw new ErroHttp(429, `Aguarde ${INTERVALO_REENVIO_S} segundos antes de pedir outro código.`);
  }
  if (!emailConfigurado() && !ehLocal(req)) {
    throw new ErroHttp(503, "O envio de e-mail não está configurado no servidor. Fale com o administrador do sistema.");
  }

  await exec(
    `UPDATE two_factor_codes SET used_at = CURRENT_TIMESTAMP(3)
      WHERE company_id = ? AND user_id = ? AND purpose = ? AND used_at IS NULL`,
    [usuario.company_id, usuario.id, finalidade],
  );

  const codigo = String(crypto.randomInt(0, 1_000_000)).padStart(6, "0");
  await exec(
    `INSERT INTO two_factor_codes (company_id, user_id, purpose, token_hash, expires_at) VALUES (?, ?, ?, ?, ?)`,
    [
      usuario.company_id,
      usuario.id,
      finalidade,
      hashCodigo(usuario.id, finalidade, codigo),
      sqlData(new Date(Date.now() + MINUTOS_VALIDADE * 60_000)),
    ],
  );

  const assunto = {
    LOGIN: "Código para entrar no LoadSense",
    ENABLE: "Código para ativar a verificação em duas etapas",
    DISABLE: "Código para desativar a verificação em duas etapas",
  }[finalidade];
  const envio = await enviarEmail({
    para: usuario.email,
    assunto,
    texto: `Seu código é ${codigo}.\n\nEle vale por ${MINUTOS_VALIDADE} minutos e só pode ser usado uma vez.\nSe você não pediu este código, ignore esta mensagem e troque sua senha.`,
  });

  const resposta = { emailMascarado: mascararEmail(usuario.email) };
  if (ehLocal(req) && (EXIBIR_CODIGO || !emailConfigurado())) resposta.codigoDemo = codigo;
  if (!envio.enviado && !resposta.codigoDemo) {
    await exec(
      `UPDATE two_factor_codes SET used_at = CURRENT_TIMESTAMP(3) WHERE company_id = ? AND user_id = ? AND purpose = ? AND used_at IS NULL`,
      [usuario.company_id, usuario.id, finalidade],
    );
    throw new ErroHttp(503, "Não foi possível enviar o código por e-mail. Tente de novo em instantes.");
  }
  return resposta;
}

export async function consumirCodigo(usuario, finalidade, codigoInformado) {
  await garantirTabela();
  const bloqueado = await um(`SELECT locked_until_2fa AS l FROM users WHERE company_id = ? AND id = ?`, [
    usuario.company_id,
    usuario.id,
  ]);
  if (bloqueado?.l && new Date(bloqueado.l) > new Date()) {
    throw new ErroHttp(
      423,
      "Código bloqueado por 15 minutos após 3 códigos errados. Tente novamente depois desse prazo.",
    );
  }
  const codigo = String(codigoInformado ?? "").replace(/\D/g, "");
  const linha =
    codigo.length === 6
      ? await um(
          `SELECT id FROM two_factor_codes
            WHERE company_id = ? AND user_id = ? AND purpose = ? AND token_hash = ?
              AND used_at IS NULL AND expires_at > CURRENT_TIMESTAMP(3)`,
          [usuario.company_id, usuario.id, finalidade, hashCodigo(usuario.id, finalidade, codigo)],
        )
      : null;
  if (!linha) {
    const atual = await um(`SELECT failed_2fa_attempts AS n FROM users WHERE company_id = ? AND id = ?`, [
      usuario.company_id,
      usuario.id,
    ]);
    const tentativas = Number(atual?.n ?? 0) + 1;
    const bloquear = tentativas >= 3;
    await exec(`UPDATE users SET failed_2fa_attempts = ?, locked_until_2fa = ? WHERE company_id = ? AND id = ?`, [
      bloquear ? 0 : tentativas,
      bloquear ? sqlData(new Date(Date.now() + 15 * 60_000)) : null,
      usuario.company_id,
      usuario.id,
    ]);
    throw new ErroHttp(422, "Código inválido ou expirado. Confira o e-mail mais recente.");
  }
  await exec(`UPDATE two_factor_codes SET used_at = CURRENT_TIMESTAMP(3) WHERE id = ?`, [linha.id]);
  await exec(`UPDATE users SET failed_2fa_attempts = 0, locked_until_2fa = NULL WHERE company_id = ? AND id = ?`, [
    usuario.company_id,
    usuario.id,
  ]);
  return true;
}
