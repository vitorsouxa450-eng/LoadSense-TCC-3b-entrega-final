import mysql from "mysql2/promise";

const config = {
  host: process.env.LS_DB_HOST ?? "127.0.0.1",
  port: Number(process.env.LS_DB_PORT ?? 3306),
  user: process.env.LS_DB_USER ?? "root",
  password: process.env.LS_DB_PASSWORD ?? "",
  database: process.env.LS_DB_NAME ?? "loadsense",
  waitForConnections: true,
  connectionLimit: Number(process.env.LS_DB_POOL ?? 10),
  decimalNumbers: true,
  timezone: "Z",
  dateStrings: false,
  charset: "utf8mb4_0900_ai_ci",
  multipleStatements: false,
};

export const pool = mysql.createPool(config);

pool.on("connection", (conn) => {
  conn.query("SET time_zone = '+00:00'");
});

export async function q(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}

export async function um(sql, params = []) {
  const rows = await q(sql, params);
  return rows.length ? rows[0] : null;
}

export async function exec(sql, params = []) {
  const [res] = await pool.execute(sql, params);
  return res;
}

export async function call(procedure, params = []) {
  const placeholders = params.map(() => "?").join(", ");
  const [result] = await pool.query(`CALL ${procedure}(${placeholders})`, params);
  return result;
}

export async function tx(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const resultado = await fn(conn);
    await conn.commit();
    return resultado;
  } catch (erro) {
    await conn.rollback();
    throw erro;
  } finally {
    conn.release();
  }
}

export async function ping() {
  const inicio = Date.now();
  await q("SELECT 1");
  return Date.now() - inicio;
}
