import { q, exec } from "./db.js";
import { cifrar, estaCifrado, hashBusca } from "./dados-pessoais.js";

async function colunaExiste(coluna) {
  const linhas = await q(
    `SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'drivers' AND COLUMN_NAME = ?`,
    [coluna],
  );
  return linhas.length > 0;
}

async function indiceExiste(nome) {
  const linhas = await q(
    `SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'drivers' AND INDEX_NAME = ?`,
    [nome],
  );
  return linhas.length > 0;
}

async function garantirEstrutura() {
  if (!(await colunaExiste("document_hash"))) {
    await exec("ALTER TABLE drivers ADD COLUMN document_hash CHAR(64) DEFAULT NULL AFTER document_number");
  }
  const [tamanho] = await q(
    `SELECT CHARACTER_MAXIMUM_LENGTH AS tamanho FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'drivers' AND COLUMN_NAME = 'document_number'`,
  );
  if (tamanho && Number(tamanho.tamanho) < 255) {
    await exec(
      "ALTER TABLE drivers MODIFY COLUMN document_number VARCHAR(255) DEFAULT NULL, " +
        "MODIFY COLUMN license_number VARCHAR(255) DEFAULT NULL, " +
        "MODIFY COLUMN phone VARCHAR(255) DEFAULT NULL",
    );
  }
  if (await indiceExiste("uq_drivers_company_document")) {
    await exec("ALTER TABLE drivers DROP INDEX uq_drivers_company_document");
  }
  if (!(await indiceExiste("uq_drivers_company_document"))) {
    await exec("ALTER TABLE drivers ADD UNIQUE KEY uq_drivers_company_document (company_id, document_hash)");
  }
}

export async function protegerDadosPessoais() {
  await garantirEstrutura();
  const linhas = await q(
    `SELECT id, document_number, license_number, phone FROM drivers
      WHERE (document_number IS NOT NULL AND document_hash IS NULL)
         OR (document_number IS NOT NULL AND document_number NOT LIKE 'v1:%')
         OR (license_number IS NOT NULL AND license_number NOT LIKE 'v1:%')
         OR (phone IS NOT NULL AND phone NOT LIKE 'v1:%')`,
  );
  let protegidos = 0;
  for (const linha of linhas) {
    const documento = linha.document_number ? linha.document_number.replace(/\D/g, "") : null;
    await exec(
      `UPDATE drivers SET document_number = ?, document_hash = ?, license_number = ?, phone = ? WHERE id = ?`,
      [
        documento ? cifrar(documento) : null,
        documento ? hashBusca(documento) : null,
        linha.license_number && !estaCifrado(linha.license_number)
          ? cifrar(linha.license_number)
          : linha.license_number,
        linha.phone && !estaCifrado(linha.phone) ? cifrar(linha.phone) : linha.phone,
        linha.id,
      ],
    );
    protegidos += 1;
  }
  return protegidos;
}
