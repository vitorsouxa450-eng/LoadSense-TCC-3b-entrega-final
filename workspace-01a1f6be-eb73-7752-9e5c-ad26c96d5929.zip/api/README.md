# API — LoadSense

API REST em Node.js + Express que lê e grava no banco MySQL. É a única camada que o app e o site
usam para acessar dados.

## Rodar

```bash
cd api
npm install
node server/index.js            # porta 5174
```

## Variáveis de ambiente

| Variável | Padrão | Para quê |
| --- | --- | --- |
| `LS_PORT` | `5174` | porta da API |
| `LS_DB_HOST` / `LS_DB_PORT` | `127.0.0.1` / `3306` | servidor do banco |
| `LS_DB_USER` / `LS_DB_PASSWORD` | — | credenciais do banco |
| `LS_DB_NAME` | `loadsense` | nome do banco |
| `LS_JWT_SECRET` | gerado na 1ª execução e salvo em `server/segredo-jwt.txt` | defina em ambiente real; sem ele, o arquivo é criado sozinho |
| `LS_CHAVE_DADOS` | deriva do segredo JWT | chave da cifra de CPF, CNH e telefone (LGPD). Defina em ambiente real e guarde um backup; trocá-la sem recifrar torna os dados ilegíveis |
| `LS_CORS_ORIGENS` | vazio (só localhost) | origens extras liberadas no CORS, separadas por vírgula |
| `LS_EXIBIR_CODIGO` | desligado | `1` = devolve o código de recuperação só para requisições da própria máquina (localhost); de outros computadores o código nunca é devolvido |

## Rotas principais

| Área | Rotas |
| --- | --- |
| Saúde | `GET /api/saude` |
| Sessão | `POST /api/auth/login`, `/refresh`, `/logout`, `GET /api/auth/eu`, `PATCH /api/auth/senha` |
| Recuperação de senha | `POST /api/auth/recuperacao/codigo`, `/verificar`, `/nova-senha` |
| Painel | `GET /api/painel?dias=30` |
| Operações | `GET/POST /api/operacoes`, `GET /api/operacoes/:id`, leituras, `finalizar`, `cancelar`, transporte, rastreio |
| Rastreamento | `GET /api/rastreio/ativo` |
| Alertas | `GET /api/alertas`, `POST /api/alertas/:id/reconhecer`, `/resolver`, `/reabrir` |
| Relatórios | `GET/POST /api/relatorios`, `GET /api/relatorios/resumo?dias=` |
| Cadastros | `/api/veiculos`, `/api/motoristas`, `/api/produtos`, `/api/rotas`, `/api/postos`, `/api/dispositivos` |
| Configurações | `GET/PATCH /api/configuracoes`, `/api/preferencias`, `/api/assinatura` |

Erros seguem o formato `{ "erro": "mensagem em português", "status": 422 }`.

## Testes

```bash
npm run testes      # 71 verificações (requer banco semeado)
```

## Organização

```
api/
├── server/
│   ├── index.js          app Express e montagem das rotas
│   ├── db.js             pool MySQL
│   ├── auth.js           sessão JWT, permissões
│   ├── recuperacao.js    recuperação de senha por código
│   ├── mapeadores.js     conversão do banco para o contrato do app
│   ├── util.js           validações e erros
│   ├── routes/           auth, catálogo, operações, gestão
│   └── scripts/          seed-demo.mjs, testes-api.mjs
└── package.json
```
